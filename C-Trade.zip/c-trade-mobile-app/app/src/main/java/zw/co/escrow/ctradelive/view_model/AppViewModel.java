package zw.co.escrow.ctradelive.view_model;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import zw.co.escrow.ctradelive.model.MarketWatchFINSEC;
import zw.co.escrow.ctradelive.model.MarketWatchZSE;
import zw.co.escrow.ctradelive.model.MyCash;

public class AppViewModel extends ViewModel {


    private static final String TAG = "AppViewModel";

    //MARKET WATCH ZSE

    private MutableLiveData<List<MarketWatchZSE>> marketWatchZSEMutableLiveData = new MutableLiveData<>();


    public LiveData<List<MarketWatchZSE>> getMarketWatchZSE(){
        return marketWatchZSEMutableLiveData;

    }


    public void setMarketWatchZSEMutableLiveData(List<MarketWatchZSE> marketWatchZSE) {
        marketWatchZSEMutableLiveData.setValue(marketWatchZSE);
    }


    //MARKET WATCH FINSEC
    private MutableLiveData<List<MarketWatchFINSEC>> marketWatchFINSECMutableLiveData = new MutableLiveData<>();

    public LiveData<List<MarketWatchFINSEC>> getMarketWatchFINSEC(){
        return marketWatchFINSECMutableLiveData;

    }


    public void setMarketWatchFINSECMutableLiveData(List<MarketWatchFINSEC> marketWatchFINSEC) {
        marketWatchFINSECMutableLiveData.setValue(marketWatchFINSEC);
    }




    //MY CASH

    private MutableLiveData<List<MyCash>> myCashMutableLiveData = new MutableLiveData<>();


    public LiveData<List<MyCash>> getMyCash(){
        return myCashMutableLiveData;

    }


    public void setMyCashMutableLiveData(List<MyCash> myCashList) {
        myCashMutableLiveData.setValue(myCashList);
    }

    //SEARCH
    private MutableLiveData<List<MarketWatchZSE>> ZSE_SearchMutableLiveData = new MutableLiveData<>();
    private MutableLiveData<List<MarketWatchFINSEC>> FINSEC_SearchMutableLiveData = new MutableLiveData<>();


    public LiveData<List<MarketWatchFINSEC>> getResultsFINSEC(){
        return FINSEC_SearchMutableLiveData;

    }


    public void setResultsFINSECMutableLiveData(List<MarketWatchFINSEC> FINSEC_results) {
        FINSEC_SearchMutableLiveData.setValue(FINSEC_results);
    }


    public LiveData<List<MarketWatchZSE>> getResultsZSE(){
        return ZSE_SearchMutableLiveData;

    }


    public void setResultsZSEMutableLiveData(List<MarketWatchZSE> ZSE_results) {
        ZSE_SearchMutableLiveData.setValue(ZSE_results);
    }

    //Get brokers

    private MutableLiveData<List<String>> brokers = new MutableLiveData<>();


    public LiveData<List<String>> getBrokers(){
        return brokers;

    }


    public void setBrokers(List<String> brokers) {
         this.brokers.setValue(brokers);
    }

    //Get banks

    private MutableLiveData<List<String>> banks = new MutableLiveData<>();


    public LiveData<List<String>> getBanks(){
        return banks;

    }


    public void setBanks(List<String> banks) {
        Log.d(TAG, "setBanks: "+banks.size());
        this.banks.setValue(banks);
    }

    //Get branches

    private MutableLiveData<List<String>> branches = new MutableLiveData<>();


    public LiveData<List<String>> getBranches(){
        return branches;

    }


    public void setBranches(List<String> branches) {
        this.branches.setValue(branches);
    }



    }