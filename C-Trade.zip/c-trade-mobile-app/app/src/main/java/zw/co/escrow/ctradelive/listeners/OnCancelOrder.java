package zw.co.escrow.ctradelive.listeners;

public interface OnCancelOrder {

    void cancelOrder(String cdsNumber,String orderNumber,String orderType);
}
