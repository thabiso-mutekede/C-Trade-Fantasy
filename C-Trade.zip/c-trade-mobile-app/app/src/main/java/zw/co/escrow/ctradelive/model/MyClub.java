package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class MyClub implements Parcelable {
    String Clubid;
    String ClubName;

    protected MyClub(Parcel in) {
        Clubid = in.readString();
        ClubName = in.readString();
    }

    public static final Creator<MyClub> CREATOR = new Creator<MyClub>() {
        @Override
        public MyClub createFromParcel(Parcel in) {
            return new MyClub(in);
        }

        @Override
        public MyClub[] newArray(int size) {
            return new MyClub[size];
        }
    };

    public String getClubid() {
        return Clubid;
    }

    public void setClubid(String clubid) {
        Clubid = clubid;
    }

    public String getClubName() {
        return ClubName;
    }

    public void setClubName(String clubName) {
        ClubName = clubName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(Clubid);
        parcel.writeString(ClubName);
    }
}
