package zw.co.escrow.ctradelive;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.view.fragments.company_create_account.CompanyCustodianDetailsFragment;
import zw.co.escrow.ctradelive.view_model.AppViewModel;


public class BranchAsyncTaskC extends AsyncTask<String, Void, String> {
        String add_info_url;
    List<String> allBranch = new ArrayList<>();
    private static final String TAG = "BranchAsyncTask";

    private WeakReference<CompanyCustodianDetailsFragment> activityWeakReference; // To prevent memory leaks


    public BranchAsyncTaskC(Fragment activity) {
        try{
            activityWeakReference = new WeakReference<>((CompanyCustodianDetailsFragment) activity);
        }catch (Exception e){

        }

    }


    @Override
        protected void onPreExecute() {
            add_info_url = "https://" + Constants.APP_BASE_URL + "/GetBranchFromFullName";
        }

        @Override
        protected String doInBackground(String... args) {
            String company;
            company = args[0];
            Log.d(TAG, "doInBackground: "+company);

            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(
                                new OutputStreamWriter(outputStream, "UTF-8"));

                String data_string =
                        URLEncoder.encode("bank_name", "UTF-8") + "=" +
                                URLEncoder.encode(company, "UTF-8");

                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

//                reading from server
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            /*if (progressDialog != null)
                progressDialog.dismiss();*/
           // enableUserInteraction();
            CompanyCustodianDetailsFragment activity =  activityWeakReference.get();

            try {
                JSONArray jsonArray = new JSONArray(result);
                if (jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String name = jsonObject.optString("Name");
                        allBranch.add(name);
                    }
                    ViewModelProvider viewModelProvider = new ViewModelProvider(activity);
                    AppViewModel appViewModel = viewModelProvider.get(AppViewModel.class);

                    //post the data to AppViewModel
                    for (String s:allBranch) {
                        Log.d(TAG, "onPostExecute: "+s);
                    }
                    appViewModel.setBranches(allBranch);

                } else {
                    Toast.makeText(activity.getActivity(), R.string.badnetwork, Toast.LENGTH_SHORT).show();
                    allBranch.add("Main branch");

                    ViewModelProvider viewModelProvider = new ViewModelProvider(activity);
                    AppViewModel appViewModel = viewModelProvider.get(AppViewModel.class);

                    //post the data to AppViewModel
                    appViewModel.setBranches(allBranch);
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Log.d(TAG, "onPostExecute: "+e.getMessage());
            }
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            /*if (progressDialog != null)
                progressDialog.dismiss();*/
           // enableUserInteraction();
            super.onProgressUpdate(values);
        }
    }
