package zw.co.escrow.ctradelive.view;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import butterknife.ButterKnife;
import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;


public class ForexPostingActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener, View.OnClickListener {

    Spinner spCompanies, spBuyOrSell, spBroker, spSecurities;
    private TextInputLayout outlinedTextFieldCompany, outlinedTextFieldBuySell, outlinedTextFieldBroker, outlinedTextFieldSecurities, input_layout_qty, input_layout_password;
    

    String orderTypes, add_info_url,
            add_info_urlc, add_info_urlg, ip, mobileapi, timeInForce;
    List<String> allCompanies = new ArrayList<>();
    List<String> allOrganizations = new ArrayList<>();
    Map<String, String> brokerThreshold = new HashMap<>();
    Map<String, String> allOrganisationsMap = new HashMap<>();
    Map<String, String> allCompaniesMap = new HashMap<>();
    private DatePickerDialog fromDatePickerDialog;
    private SimpleDateFormat dateFormatter;
    private String expiresOn, selectedCompany, selectedAction, felloverip1, felloverip2;
    private boolean orRetryFetchCompanies = false;

    ArrayList<String> buyOrSell = new ArrayList<>();
    String[] orderTimeinForce = new String[]{"Day Order (DO)", "Good Till Cancelled (GTC)"
            , "Immediate/Cancel Order (IOC)", "Good Till Day (GTD)"};
    String[] orderType = new String[]{"Limit"};
    Button btnPost;
    AppConfig app;
    RelativeLayout brkz, rlHasCompany;
    TextView membership, exchange, currentPrice, validUntil, storedPrice;
    
    private Utils utils;
    private Toolbar toolbar;




    String brokr;
    String currentExchange,
            whatsSelected, entityType, corpName = null, corporateId = null;
    //RadioGroup radioGroupIndiOrCompany;
    private ProgressBar progressBar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forex_posting);
        ButterKnife.bind(this);
        
        initWidgets();


        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(ForexPostingActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("POST FOREX");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }

        allCompanies.clear();
        allOrganisationsMap.clear();
        allCompaniesMap.clear();
        brokerThreshold.clear();
        app = (AppConfig) getApplication();
        ip = AppConfig.getIpAddress();
        mobileapi = AppConfig.getMobileApiAddress();
        currentExchange = getString(R.string.FINSEC);
        selectedCompany = null;
        orderTypes = "Day";
        company = "any";
        progressBar = findViewById(R.id.progressBarOp);
        btnPost = findViewById(R.id.btnPost);

        fetchListedCompanies();
        
        
        allOrganizations.clear();

        String[] securities = orderTimeinForce;
        utils.setDropdownBoxes(securities, R.id.spSecurities);

        spSecurities.setOnItemClickListener((adapterView, view, i, l) -> {

            timeInForce=   adapterView.getSelectedItem().toString();

            if (timeInForce.equalsIgnoreCase("Good Till Day (GTD)")) {
                validUntil.setVisibility(View.VISIBLE);
                showDatePicker();
                fromDatePickerDialog.show();
            }
            else {
                validUntil.setVisibility(View.GONE);
                validUntil.setText("");
                expiresOn = "";
            }


        });





        

        exchange.setText("FOREX TRADING");
        String[] buyORsell = buyOrSell.toArray(new String[0]);
        utils.setDropdownBoxes(buyORsell, R.id.spBuyOrSell);

        selectedAction = getIntent()
                .getStringExtra(getString(R.string.selected_action));

     


        app = (AppConfig) getApplication();
        ip = AppConfig.getIpAddress();
        SharedPreferences prfs = getSharedPreferences(getString(R.string.CTRADE), Context.MODE_PRIVATE);
        brokr = prfs.getString("broker", "");
        cdsNumber = prfs.getString("cds_number", "");
        whatsSelected = prfs.getString(getString(R.string.entity_type), "");
        corpName = prfs.getString(getString(R.string.corp_name), "");
        corporateId = prfs.getString(getString(R.string.corp_cds_number), "");

        fetchBrokers();



        btnPost.setOnClickListener(this);

        getMarketStatus();
        //onEntityTypeSelected();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initWidgets(){
        outlinedTextFieldCompany=findViewById(R.id.outlinedTextFieldCompany);
        outlinedTextFieldBuySell=findViewById(R.id.outlinedTextFieldBuySell);
        outlinedTextFieldBroker=findViewById(R.id.outlinedTextFieldBroker);
        outlinedTextFieldSecurities=findViewById(R.id.outlinedTextFieldSecurities);

        input_layout_qty=findViewById(R.id.input_layout_qty);
        input_layout_password=findViewById(R.id.input_layout_password);

        membership=findViewById(R.id.membership);
        currentPrice=findViewById(R.id.currentPrice);
        validUntil=findViewById(R.id.validUntil);
        storedPrice=findViewById(R.id.storedPrice);




    }

    private void enableUserInteraction() {

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    private void disableUserInteraction() {

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    private boolean onRetryFetchBrokers = false;

    private boolean onRetryComps = false;

    private void fetchBrokers() {

        disableUserInteraction();

        if (onRetryFetchBrokers) {
            add_info_urlg = felloverip1 + "/GetCatalyst";
        } else {
            add_info_urlg = "https://" + ip + "/GetCatalyst";
        }

        StringRequest jsonObjRequest2 = new StringRequest(Request.Method.POST, add_info_urlg,
                successListenerFetchBrokers(),
                errorListenerFetchBrokers()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("company_type", "BUREAU");
                return params;
            }
        };

        jsonObjRequest2.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest2);
    }

    private void fetchListedCompanies() {

        disableUserInteraction();

        String add_info_urlc = AppConfig.getFullMobileApiAddress() + "/GetCurrency";


        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST, add_info_urlc,
                successListenerCurrency(),
                errorListenerCurrency()) {
        };

        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    private void showDatePicker() {
        dateFormatter = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(ForexPostingActivity.this,
                (view, year, monthOfYear, dayOfMonth) -> {
                    Calendar newDate = Calendar.getInstance();
                    newDate.set(year, monthOfYear, dayOfMonth);
                    validUntil.setText(getString(R.string.validuntil).concat(
                            dateFormatter.format(newDate.getTime())));
                    expiresOn = dateFormatter.format(newDate.getTime());
                }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH),
                newCalendar.get(Calendar.DAY_OF_MONTH));
    }

    private void getMarketStatus() {

        disableUserInteraction();

        String market_status_url = "https://ctrade.co.zw/mobileapi/marketStatus";
        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST, market_status_url,
                successListenerMarketStatus(),
                errorListenerMarketStatus()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("market", "FINSEC");
                return params;
            }
        };

        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        enableUserInteraction();
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, final int i, long l) {

        Spinner spinner = (Spinner) adapterView;

        if (spinner.getId() == R.id.spCompanies) {

            disableUserInteraction();

            app = (AppConfig) getApplication();
            ip = AppConfig.getIpAddress();

            add_info_url = "https://" + ip + "/GetSecurities";
            StringRequest jsonObjRequestz = new StringRequest(Request.Method.POST, add_info_url,
                    successListenerFetchSecurities(),
                    errorListenerFetchSecurities()) {
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("company", allCompanies.get(i));
                    params.put("exchange", "FINSEC");
                    return params;
                }
            };

            jsonObjRequestz.setRetryPolicy(new DefaultRetryPolicy(
                    AppConfig.REASONABLE_RETRY_MS,
                    0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            AppConfig.getInstance().addToRequestQueue(jsonObjRequestz);

        } else if (spinner.getId() == R.id.spBuyOrSell) {
            buyOrSellStr = spBuyOrSell.getSelectedItem().toString();
        }
    }

    String buyOrSellStr;

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private boolean isValidField(String pass) {
        return 0 < pass.length();
    }

    String company, currentprice, buy_or_sell, price, quantity, cdsNumber, broker;

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnPost:

                Log.d("expires on ", expiresOn);
                

                String company = outlinedTextFieldCompany.getEditText().getText().toString();
                final String buy_or_sell = outlinedTextFieldBuySell.getEditText().getText().toString();
                String broker = outlinedTextFieldBroker.getEditText().getText().toString();
                String securities = outlinedTextFieldSecurities.getEditText().getText().toString();
                String quantity = input_layout_qty.getEditText().getText().toString();
                String amount = input_layout_password.getEditText().getText().toString();

                

                if (amount.equals("") || amount.equals("0")) {
                    input_layout_password.setError("Amount should be greater than 0");
                }
                else if (buy_or_sell.equals("") || buy_or_sell.equals("0") || buy_or_sell.length()<10){
                    outlinedTextFieldBuySell.setError("Please select an option");

                }
                else if (broker.equals("") || broker.equals("0")){
                    outlinedTextFieldBroker.setError("Please select an option");

                }
                else if (quantity.equals("") || quantity.equals("0")){
                    input_layout_qty.setError("Please enter amount");

                }
                else if (securities.equals("") || securities.equals("0")){
                    outlinedTextFieldSecurities.setError("Please select an option");

                }
                else if (company.equals("") || company.equals("0")){
                    outlinedTextFieldCompany.setError("Please select an option");

                }
                else {
                    

                    outlinedTextFieldCompany.setErrorEnabled(false);
                    outlinedTextFieldBuySell.setErrorEnabled(false);
                    outlinedTextFieldBroker.setErrorEnabled(false);
                    outlinedTextFieldSecurities.setErrorEnabled(false);
                    input_layout_qty.setErrorEnabled(false);
                    input_layout_password.setErrorEnabled(false);

                    try {



                        //currentprice = app.getCurrentPrice();
                        //String pp = app.getCurrentPrice();
                        String storedPriceText = storedPrice.getText().toString();
                        String trimmedPrice = storedPriceText.replace(getString(R.string.currentpriceis),
                                "").trim();
                        currentprice = trimmedPrice;
                        Log.d("Original current price", currentprice);

                        price = "0";

                        double charges = 1.0;
                        if (buyOrSellStr.equals("Buy")) {
                            charges = Double.parseDouble("1.01693");
                        }
                        if (buyOrSellStr.equals("Sell")) {
                            charges = Double.parseDouble("0.97557");
                        }
                        DecimalFormat df = new DecimalFormat("#.####");
                        double MyTotal = Double.parseDouble(amount) * Double.parseDouble(quantity) * charges;
                        //MyTotal = Double.valueOf(df.format(MyTotal));

                        String finalCorporateId = corporateId;
                        String finalCorpName = corpName;
                        new AlertDialog.Builder(ForexPostingActivity.this)
                                .setCancelable(false)
                                .setMessage("Posting a " + buyOrSellStr + " order "
                                        + "\nQuantity: " + amount
                                        + "\nPrice: ZWL " + quantity
                                        + "\nTotal : ZWL " + MyTotal)
                                .setPositiveButton("Place Order", (dialog, which) -> {

                                    disableUserInteraction();

                                    if (selectedAction.equalsIgnoreCase(getString(R.string.deposit))) {

                                        dateFormatter = new SimpleDateFormat("dd/MM/yyyy",
                                                Locale.US);

                                        attemptPostCommodity(cdsNumber, allCompaniesMap.get(company),
                                                quantity, timeInForce, this.broker,
                                                dateFormatter.format(new Date()),
                                                amount, selectedAction);

                                    } else {

                                        PostingOrders postingOrders = new PostingOrders();
                                        postingOrders.execute(allCompaniesMap.get(company), "FOREX",
                                                timeInForce, buy_or_sell, orderTypes,
                                                quantity, price, cdsNumber,
                                                this.broker, "mobile", finalCorpName, finalCorporateId, expiresOn);

                                    }
                                })
                                .setNegativeButton("Cancel", (dialog, which) -> {

                                })
                                .show();






                    }
                    catch (Exception ex) {

                    }


                }










                break;
        }
    }

    private void attemptPostCommodity(String cdsNumber, String currency, String quantity,
                                      String tif, String bureau, String dod, String price,
                                      String tradeType) {

        disableUserInteraction();

        String url = AppConfig.getIp().concat("PostForex");

        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST, url,
                commoPostSuccessListener(),
                commoPostErrorListener()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("cds_number", cdsNumber);
                params.put("currency", currency);
                params.put("quantity", quantity);
                params.put("timeinforce", tif);
                params.put("bureau", bureau);
                params.put("dateofdelivery", dod);
                params.put("price", price);
                params.put("tradetype", tradeType);
                return params;
            }
        };

        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);

    }

    private Response.Listener<String> commoPostSuccessListener() {
        return response -> {

            System.out.println(response);
            enableUserInteraction();
            try {

                new AlertDialog.Builder(ForexPostingActivity.this)
                        .setTitle("Result")
                        .setCancelable(false)
                        .setMessage(response)
                        .setPositiveButton("OK", (dialog, which) -> {
                            finish();
                            //tODO
                       /*     startActivity(new Intent(ForexPostingActivity.this,
                                    ForexActivity.class));*/
                        })
                        .show();


            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener commoPostErrorListener() {
        return error -> {

            Log.d("tavman commo error ", error.toString());

            enableUserInteraction();
            try {
                new AlertDialog.Builder(ForexPostingActivity.this)
                        .setCancelable(false)
                        .setMessage(error.toString())
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();

            } catch (Exception e) {
                Log.d("tavman error catch ", e.toString());
            }
        };
    }

    @SuppressLint("StaticFieldLeak")
    public class PostingOrders extends AsyncTask<String, Void, String> {
        String add_info_url;

        @Override
        protected void onPreExecute() {
            add_info_url = AppConfig.getApiV2() + "/OrderPostingMakeNew";
        }

        @Override
        protected String doInBackground(String... args) {
            String company, security, tif, buy_or_sell, orderType,
                    price, quantity, cdsNumber, source, broker, expiryDate, corpName, corpId;
            company = args[0].trim();
            security = args[1];
            tif = args[2];
            buy_or_sell = args[3];
            orderType = args[4];
            quantity = args[5];
            price = args[6];
            cdsNumber = args[7];
            broker = args[8];
            source = args[9];
            corpName = args[10];
            corpId = args[11];
            expiryDate = args[12];
            Log.d("My URL", add_info_url);

            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(new OutputStreamWriter(outputStream,
                                "UTF-8"));

                String data_string;

                if (whatsSelected.equalsIgnoreCase(getString(R.string.company))) {

                    data_string =
                            URLEncoder.encode("company", "UTF-8") + "="
                                    + URLEncoder.encode(company, "UTF-8")

                                    + "&" + URLEncoder.encode("security", "UTF-8") + "=" +
                                    URLEncoder.encode(security, "UTF-8")

                                    + "&" + URLEncoder.encode("tif", "UTF-8") + "="
                                    + URLEncoder.encode(tif, "UTF-8")

                                    + "&" + URLEncoder.encode("buy_or_sell", "UTF-8") + "="
                                    + URLEncoder.encode(buy_or_sell, "UTF-8")

                                    + "&" + URLEncoder.encode("orderType", "UTF-8") + "="
                                    + URLEncoder.encode(orderType, "UTF-8")

                                    + "&" + URLEncoder.encode("quantity", "UTF-8") + "="
                                    + URLEncoder.encode(quantity, "UTF-8")

                                    + "&" + URLEncoder.encode("price", "UTF-8") + "="
                                    + URLEncoder.encode(price, "UTF-8")

                                    + "&" + URLEncoder.encode("cdsNumber", "UTF-8")
                                    + "=" + URLEncoder.encode(cdsNumber, "UTF-8")

                                    + "&" + URLEncoder.encode("broker", "UTF-8")
                                    + "=" + URLEncoder.encode(broker, "UTF-8")

                                    + "&" + URLEncoder.encode("source", "UTF-8")
                                    + "=" + URLEncoder.encode(source, "UTF-8")

                                    + "&" + URLEncoder.encode("corp_name", "UTF-8")
                                    + "=" + URLEncoder.encode(corpName, "UTF-8")

                                    + "&" + URLEncoder.encode("corp_id", "UTF-8")
                                    + "=" + URLEncoder.encode(corpId, "UTF-8")

                                    + "&" + URLEncoder.encode("date_", "UTF-8")
                                    + "=" + URLEncoder.encode(expiryDate, "UTF-8");

                } else {

                    data_string =
                            URLEncoder.encode("company", "UTF-8") + "="
                                    + URLEncoder.encode(company, "UTF-8")

                                    + "&" + URLEncoder.encode("security", "UTF-8") + "=" +
                                    URLEncoder.encode(security, "UTF-8")

                                    + "&" + URLEncoder.encode("tif", "UTF-8") + "="
                                    + URLEncoder.encode(tif, "UTF-8")

                                    + "&" + URLEncoder.encode("buy_or_sell", "UTF-8") + "="
                                    + URLEncoder.encode(buy_or_sell, "UTF-8")

                                    + "&" + URLEncoder.encode("orderType", "UTF-8") + "="
                                    + URLEncoder.encode(orderType, "UTF-8")

                                    + "&" + URLEncoder.encode("quantity", "UTF-8") + "="
                                    + URLEncoder.encode(quantity, "UTF-8")

                                    + "&" + URLEncoder.encode("price", "UTF-8") + "="
                                    + URLEncoder.encode(price, "UTF-8")

                                    + "&" + URLEncoder.encode("cdsNumber", "UTF-8")
                                    + "=" + URLEncoder.encode(cdsNumber, "UTF-8")

                                    + "&" + URLEncoder.encode("broker", "UTF-8")
                                    + "=" + URLEncoder.encode(broker, "UTF-8")

                                    + "&" + URLEncoder.encode("source", "UTF-8")
                                    + "=" + URLEncoder.encode(source, "UTF-8")

                                    + "&" + URLEncoder.encode("date_", "UTF-8")
                                    + "=" + URLEncoder.encode(expiryDate, "UTF-8");
                }


                Log.d("My URL", data_string);
                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            enableUserInteraction();

            Log.d("myTag", result);

            String message;

            if (result.equalsIgnoreCase("1"))
                message = "Your order has been posted successfully!";
            else message = result;

            new AlertDialog.Builder(ForexPostingActivity.this)
                    .setTitle(R.string.result)
                    .setCancelable(false)
                    .setMessage(message)
                    //.setMessage(R.string.order_posting_successful)
                    .setPositiveButton("OK", (dialog, which) -> {
                        //TODO
                           /*     startActivity(new Intent(getApplicationContext(),
                                        InvestProductsActivity.class));*/
                                finish();
                            }
                    ).setNegativeButton("Post new order",
                    (dialogInterface, i) -> {
                        ForexPostingActivity.this.recreate();
                    })
                    .show();

            Objects.requireNonNull(input_layout_password.getEditText()).setText("");
            Objects.requireNonNull(input_layout_qty.getEditText()).setText("");
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            enableUserInteraction();
            super.onProgressUpdate(values);
        }

    }

    List<String> allSecurities = new ArrayList<>();
    List<String> allBrokers = new ArrayList<>();

    private Response.Listener<String> successListenerFetchBrokers() {
        return response -> {
            try {
                enableUserInteraction();

                JSONArray jsonArray = new JSONArray(response);

                if (jsonArray.length() > 0) {
                    allBrokers.add("Please Select");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String broker = jsonObject.optString("Code");
                        String threshold = jsonObject.optString("threshold");

                        brokerThreshold.put(broker, threshold);
                        allBrokers.add(broker);
                    }

                    String[] brokers = allBrokers.toArray(new String[0]);
                    utils.setDropdownBoxes(brokers, R.id.spBroker);


                } else {
                    allBrokers.add("No brokers");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener errorListenerFetchBrokers() {
        return error -> {
            try {
                enableUserInteraction();

                if (onRetryFetchBrokers) {
                    new AlertDialog.Builder(ForexPostingActivity.this)
                            .setCancelable(false)
                            .setMessage(getString(R.string.badnetwork))
                            .setPositiveButton("OK", (dialog, which) -> {

                            })
                            .show();
                    onRetryFetchBrokers = false;
                } else {
                    onRetryFetchBrokers = true;
                    fetchBrokers();
                }
            } catch (Exception e) {

            }
        };
    }

    private Response.Listener<String> successListenerFetchSecurities() {
        return response -> {
            try {

                enableUserInteraction();

                JSONArray jsonArray = new JSONArray(response);

                if (jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String instrument = jsonObject.optString("Instrument");
                        String isin = jsonObject.optString("IsinNo");
                        //String price = jsonObject.optString("InitialPrice");
                        allSecurities.add(instrument);
                        Double ogValue = jsonObject.getDouble("InitialPrice");
                        String price = BigDecimal.valueOf(ogValue).toPlainString();
                        input_layout_password.getEditText().setText(price);
                        app.setCurrentPrice(price);
                        storedPrice.setText(getString(R.string.currentpriceis).concat(price));
                    }
                } else {
                    allSecurities.add("No security for the company");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener errorListenerFetchSecurities() {
        return error -> {
            try {
                enableUserInteraction();

                new AlertDialog.Builder(ForexPostingActivity.this)
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    //FETCH COMPANIES

    private Response.Listener<String> successListenerCurrency() {
        return response -> {
            try {
                JSONArray jsonArray = new JSONArray(response);
                if (jsonArray.length() > 0) {

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String name = jsonObject.optString("Name");

                        Log.d("tavman currency ", name);
                        String compInitial = jsonObject.optString("Code");

                        allCompanies.add(name);
                        allCompaniesMap.put(name, compInitial);

                        /*if (!name.equalsIgnoreCase(getString(R.string.old_mutual))) {

                            String compInitial = jsonObject.optString("compInitial");
                            price = jsonObject.optString("InitialPrice");

                            if (selectedCompany != null &&
                                    selectedCompany.equalsIgnoreCase(compInitial)
                                            & allCompanies.size() == 0) {
                                allCompanies.add(0, name);
                                allCompaniesMap.put(name, compInitial);
                            } else if (selectedCompany != null &&
                                    !selectedCompany.equalsIgnoreCase(compInitial) &&
                                    allCompanies.size() > 0) {
                                allCompanies.add(name);
                                allCompaniesMap.put(name, compInitial);
                            } else if (selectedCompany == null & allCompanies.size() == 0) {
                                allCompanies.add(0, "Please Select");
                                allCompanies.add(name);
                                allCompaniesMap.put(name, compInitial);
                            } else if (selectedCompany == null & allCompanies.size() > 0) {
                                allCompanies.add(name);
                                allCompaniesMap.put(name, compInitial);
                            }

                        }*/
                    }
                    //currentPrice.setText("");
                    app.setCurrentPrice(price);


                    String[] companies = allCompanies.toArray(new String[0]);
                    utils.setDropdownBoxes(companies, R.id.spCompanies);


                    utils.setDropdownBoxes(companies, R.id.spCompaniesSearchable);



                    enableUserInteraction();

                    /*searchableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view,
                                                   int position, long id) {

                            String spinnerCompany = searchableSpinner.getSelectedItem().toString();

                            if (!spinnerCompany.equalsIgnoreCase("Please Select")) {
                                storedPrice.setVisibility(View.VISIBLE);

                                disableUserInteraction();

                                app = (AppConfig) getApplication();
                                ip = AppConfig.getIpAddress();

                                add_info_url = "https://" + ip + "/GetSecurities";
                                StringRequest jsonObjRequestz =
                                        new StringRequest(Request.Method.POST, add_info_url,
                                                successListenerFetchSecurities(),
                                                errorListenerFetchSecurities()) {
                                            protected Map<String, String> getParams() {
                                                Map<String, String> params = new HashMap<>();
                                                params.put("company", allCompanies.get(position));
                                                params.put("exchange", "FINSEC");
                                                return params;
                                            }
                                        };

                                jsonObjRequestz.setRetryPolicy(new DefaultRetryPolicy(
                                        AppConfig.REASONABLE_RETRY_MS,
                                        0,
                                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                                AppConfig.getInstance().addToRequestQueue(jsonObjRequestz);
                            } else {
                                storedPrice.setText(getString(R.string.empty));
                                storedPrice.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });*/

                } else {
                    Toast.makeText(getApplicationContext()
                            , getString(R.string.badnetwork),
                            Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener errorListenerCurrency() {
        return error -> {
            try {
                enableUserInteraction();

                if (orRetryFetchCompanies) {
                    new AlertDialog.Builder(ForexPostingActivity.this)
                            .setCancelable(false)
                            .setMessage(getString(R.string.badnetwork))
                            .setPositiveButton("OK", (dialog, which) -> {

                            })
                            .show();
                    orRetryFetchCompanies = false;
                } else {
                    orRetryFetchCompanies = true;
                    fetchListedCompanies();
                }
            } catch (Exception e) {
            }
        };
    }

    //Market status
    private Response.ErrorListener errorListenerMarketStatus() {
        return error -> {
            try {
                enableUserInteraction();

                new AlertDialog.Builder(ForexPostingActivity.this)
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                Log.d("Error in MarketStatus ", e.getMessage());
            }

        };
    }

    private Response.Listener<String> successListenerMarketStatus() {
        return response -> {
            try {

                enableUserInteraction();

                JSONArray jsonArray = new JSONArray(response);
                if (jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String openTime = jsonObject.optString("openTime");
                        String closeTime = jsonObject.optString("closeTime");

                        //int from = 2300; //int to = 1800;
                        int from = Integer.valueOf(openTime);
                        int to = Integer.valueOf(closeTime);

                        Date date = new Date();
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(date);
                        int time = calendar.get(Calendar.HOUR_OF_DAY) * 100 +
                                calendar.get(Calendar.MINUTE);

                        boolean isBetween = to > from && time >= from && time <= to ||
                                to < from && (time >= from || time <= to);

                        Log.d("Between ", "" + isBetween);

                        if (isBetween) {
                            currentPrice.setBackgroundColor(Color.parseColor("#7CFC00"));
                            currentPrice.setText(R.string.marketopen);
                        } else {
                            currentPrice.setBackgroundColor(Color.parseColor("#c40125"));
                            currentPrice.setText(R.string.marketclosed);
                        }

                    }

                } else {
                    Toast.makeText(getApplicationContext()
                            , getString(R.string.badnetwork), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }


}
