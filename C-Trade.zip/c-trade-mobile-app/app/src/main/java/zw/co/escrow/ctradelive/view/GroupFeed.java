package zw.co.escrow.ctradelive.view;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.GroupFeedsAdapter;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.Feed;


public class GroupFeed extends AppCompatActivity implements View.OnClickListener{

    private RecyclerView feedsRecyclerView;
    private ProgressDialog progressDialog;
    private ClubModel investmentClub;
    private Intent intent;
    SwipeRefreshLayout swipeRefreshLayout;
    private RelativeLayout gfLay;
    private EditText notification_et;
    private Dialog dialog;
    private Toolbar toolbar,toolbar_;
    private boolean isMember;
    List<Feed> feeds = new ArrayList<>();
    List<Feed> mDataset;
    Parcelable mListState;

    String cdsnumber;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_feeds_view);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("NOTICE BOARD");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());
        swipeRefreshLayout = findViewById(R.id.feeds_refresh);
        gfLay = findViewById(R.id.gf_l);
        notification_et = findViewById(R.id.notification_et);
        swipeRefreshLayout.setOnRefreshListener(() -> getFeeds());
        progressDialog = new ProgressDialog(this);
        feedsRecyclerView = findViewById(R.id.group_feeds_rv);
        LinearLayoutManager ll = new LinearLayoutManager(this);
        ll.setStackFromEnd(true);
        feedsRecyclerView.setLayoutManager(ll);

        feedsRecyclerView.setHasFixedSize(true);

        intent = getIntent();
        investmentClub = intent.getParcelableExtra("club");
        isMember = investmentClub.isMember();
        findViewById(R.id.img_send).setOnClickListener(this);
        Snackbar.make(findViewById(R.id.gf_l), "Swipe Down To Refresh Page",
                BaseTransientBottomBar.LENGTH_LONG).show();
        preferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsnumber = preferences.getString("cds_number", "");
        getFeeds();
    }
    private void getFeeds(){

        String body = String.format("getNotificationToGroup?CDS_NumberGroup=%s&mcdsnumber=%s",investmentClub.getClubCdsNumber(),cdsnumber);
        String url = AppConfig.getIp() + body;

        Log.d("lloda feed",url);

        JsonArrayRequest jr = new JsonArrayRequest(url,
                response ->
                {

                    Log.i("lloda feed",response.toString());
                    try {
                        feeds.clear();
                        for (int i = 0;i<response.length();i++){
                            JSONObject jsonObject  = response.getJSONObject(i);

                            Feed feed = new Feed();
                            feed.setMessage(jsonObject.getString("Notification"));
                            feed.setId(jsonObject.getLong("ID"));
                            feed.setDate(jsonObject.getString("DateCreated"));
                            feed.setSender(jsonObject.getString("names"));
                            feed.setCdsnumber(jsonObject.getString("CDS_Number"));
                            feed.setType(jsonObject.getString("Type"));
                            feed.setTitle(jsonObject.getString("title"));
                            feeds.add(feed);
                        }
                        Log.i("lloda feeds",feeds.toString());
                        GroupFeedsAdapter groupFeedsAdapter = new GroupFeedsAdapter(this,feeds,feedsRecyclerView,investmentClub.getClubCdsNumber(),isMember,feedsRecyclerView,cdsnumber);
                        feedsRecyclerView.setAdapter(groupFeedsAdapter);
                        swipeRefreshLayout.setRefreshing(false);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                },
                error ->
                {
                    error.printStackTrace();
                });
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.img_send){

            if(!notification_et.getText().toString().equals(""))
                submitNotice(investmentClub.getClubCdsNumber(),notification_et.getText().toString(),cdsnumber);
            notification_et.setText("");
        }
    }
    public void submitNotice(String cdsNumber, String message, String mcdsnumber){

        String body = String.format("sendNotificationToGroup?CDS_NumberGroup=%s&notification=%s&mcdsnumber=%s",cdsNumber,message,mcdsnumber);

        String url = AppConfig.getIp() + body ;
        Log.d("lloda",url);

        StringRequest stringRequest = new StringRequest(url,
                response ->
                {
                    getFeeds();

                },error ->
        {
            progressDialog.dismiss();
            showDialog("Error Connecting Try Again!");
            error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(stringRequest);

    }
    public void updateNotice(String cdsNumber, Long id, String message){

        progressDialog.setMessage("Updating ");
        progressDialog.show();
        String body = String.format("sendNotificationToGroup?CDS_NumberGroup=%s&notification=%s&ID=%s",cdsNumber,message,id);
        String url = AppConfig.getIp() + body;

        StringRequest stringRequest = new StringRequest(url,
                response ->
                {
                    progressDialog.dismiss();
                    String msg = response;
                    showDialog(msg);
                },error ->
        {
            progressDialog.dismiss();
            showDialog("Error Connecting Try Again!");
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(stringRequest);



    }
    public void deleteNotice(Long id){

        progressDialog.setMessage("Adding to Notice Board");
        progressDialog.show();
        String body = String.format("deleteNotificationToGroup?id=%s",id);

        String url = AppConfig.getIp() + body ;

        StringRequest stringRequest = new StringRequest(url,
                response ->
                {
                    progressDialog.dismiss();
                    String msg = response;
                    showDialog(msg);
                },error ->
        {
            progressDialog.dismiss();
            showDialog("Error Connecting Try Again!");
            error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(stringRequest);

    }
    private void showDialog(String msg){
        new AlertDialog.Builder(this)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton("ok",null)
                .create()
                .show();
    }



}
