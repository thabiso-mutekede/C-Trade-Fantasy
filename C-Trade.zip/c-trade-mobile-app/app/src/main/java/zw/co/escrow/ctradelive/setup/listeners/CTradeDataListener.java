package zw.co.escrow.ctradelive.setup.listeners;

import android.widget.TextView;

import java.util.List;

import zw.co.escrow.ctradelive.model.ClubModel;

public interface CTradeDataListener {

    void getZSEMarketWatch(ClubModel clubModel);
    void getFINSECMarketWatch(ClubModel clubModel);
    void getMarketWatchETF();
    void getHighLow(String company,Integer period,List<TextView> high,List<TextView> low);
}
