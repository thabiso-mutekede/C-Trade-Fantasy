package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.CTradeUserModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;


public class CTradeUserAdapter extends RecyclerView.Adapter {

    private final List<CTradeUserModel> cTradeUserModelList;
    private final Context context;
    private final String clubCDSNumber;
    private final RecyclerView recyclerView;
    private final InvestmentClub.ClubServicesListener clubServicesListener;
    private final String clubname;
    private String cds_number;
    private String phone_number;
    private String email;
    SharedPreferences preferences;


    @Override
    public int getItemViewType(int position) {
        return  R.layout.ctrade_universal_adapter_view;
    }

    public CTradeUserAdapter(Context context, List<CTradeUserModel> cTradeUserModelList, String clubCDSNumber, RecyclerView recyclerView, String clubname) {
        this.cTradeUserModelList = cTradeUserModelList;
        this.context = context;
        this.clubServicesListener = new InvestmentClubService(context);
        this.clubCDSNumber = clubCDSNumber;
        this.recyclerView = recyclerView;
        preferences = context.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        this.clubname = clubname;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(viewType,parent,false);

        view.setOnClickListener(v -> {
            CTradeUserModel c = cTradeUserModelList.get(recyclerView.getChildLayoutPosition(view));
            showSendDialog(c);
        });
        return new UserViewHolder(view);
    }
    private void showSendDialog(CTradeUserModel cTradeUserModel){
        cds_number = preferences.getString("cds_number", "");
        email = preferences.getString("email","");
        phone_number = preferences.getString("club_phone", "");
        new AlertDialog.Builder(context)
                .setCancelable(false)
                .setMessage("Send An Invitation To '"+cTradeUserModel.getName()+"'")
                .setPositiveButton("SEND",(dialog, which) ->
                        {
                            dialog.dismiss();
                            clubServicesListener.onSendRequest(clubCDSNumber, cTradeUserModel.getCdsnumber(), phone_number, clubname, "i", cds_number, cTradeUserModel.getPhone());
                        }
                ).setNegativeButton("Cancel",null).create().show();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((UserViewHolder)holder).onBindData(cTradeUserModelList.get(position));
    }

    @Override
    public int getItemCount() {
        return cTradeUserModelList.size();
    }


    private class UserViewHolder extends RecyclerView.ViewHolder{

        TextView left_tt,right_tt;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            left_tt = itemView.findViewById(R.id.left_tt);
            right_tt = itemView.findViewById(R.id.right_tt);
        }

        private void onBindData(CTradeUserModel cTradeUserModel){
            left_tt.setText(cTradeUserModel.getName());
            String dt = String.format("Phone : %s\nEmail : %s",cTradeUserModel.getPhone(),cTradeUserModel.getEmail());
            right_tt.setText(dt);
        }
    }
}
