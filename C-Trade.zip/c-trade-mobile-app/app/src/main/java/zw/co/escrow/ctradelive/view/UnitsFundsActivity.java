package zw.co.escrow.ctradelive.view;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tomergoldst.tooltips.ToolTip;
import com.tomergoldst.tooltips.ToolTipsManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.MultiFormatter;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.adapters.FundsAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.Counter;
import zw.co.escrow.ctradelive.model.Fundlist;



public class UnitsFundsActivity extends AppCompatActivity implements ToolTipsManager.TipListener {
Counter counter;
String cdsNumber="";
SwipeRefreshLayout mySwipeRefreshLayout;
private TextView emptyView;
RecyclerView recyclerView;
ToolTipsManager mToolTipsManager;
List<Fundlist> fundlists = new ArrayList<>();
    FundsAdapter fundsAdapter;
    @ToolTip.Align int mAlign = ToolTip.ALIGN_CENTER;
    private static final String TAG = "UnitsFundsActivity";


    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_funds);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(UnitsFundsActivity.this);

        mToolTipsManager = new ToolTipsManager(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("UNIT FUNDS");


        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }



        Intent intent = getIntent();
        if (null != intent) {
            counter = intent.getParcelableExtra("counter");
        }
        Toast.makeText(this, counter.getTitle(), Toast.LENGTH_SHORT).show();

        findViewById(R.id.inverst).setOnClickListener(view -> dowork());

        recyclerView = findViewById(R.id.group_others);
        mySwipeRefreshLayout = findViewById(R.id.swiperefresh);
        emptyView = findViewById(R.id.empty_view);

        Log.d(TAG, "onCreate: "+fundlists.size());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        fundsAdapter = new FundsAdapter(this,fundlists);
        recyclerView.setAdapter(fundsAdapter);

        //Todo
        mToolTipsManager.findAndDismiss(mySwipeRefreshLayout);
        ToolTip.Builder builder = new ToolTip.Builder(this, toolbar, mySwipeRefreshLayout, "ok", ToolTip.POSITION_ABOVE);
        builder.setAlign(mAlign);
        //builder.setTextAppearance(R.style.TooltipTextAppearance);
        //builder.setTypeface(mCustomFont);
        mToolTipsManager.show(builder.build());


        mySwipeRefreshLayout.setOnRefreshListener(
                this::getdata
        );
        mySwipeRefreshLayout.post(() -> {
            getdata();

            mySwipeRefreshLayout.setRefreshing(true);
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void getdata() {
        fundlists.clear();
        JSONObject jsonObject = new JSONObject();
        try{
            jsonObject.put("company",counter.getTitle());
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(
                Request.Method.POST,
                Constants.COMPLETE_URL("data/unit_trusts/funds"),
                jsonObject,
                response -> {
                    try{
                        for(int i= 0;i<response.length();i++){

                            JSONObject j = response.getJSONObject(i);
                            Fundlist fundlist = new Fundlist();
                            fundlist.setID(j.getInt("id"));
                            fundlist.setCompany(j.getString("company"));
                            fundlist.setFundType(j.getString("securityType"));
                            fundlist.setEvaluationFrom(j.getString("dateFrom"));
                            fundlist.setEvaluationTo(j.getString("dateTo"));
                            fundlist.setInitialPrice(j.getDouble("initialPrice"));
                            fundlist.setIssueDate(j.getString("dateFrom"));
                            fundlist.setIssuePricePerUnit(j.getDouble("initialPrice"));
                            fundlist.setInEvaluation(j.getBoolean("inEvaluation"));
                            fundlists.add(fundlist);

                        }
                        if (fundlists.isEmpty()) {
                            emptyView.setVisibility(View.VISIBLE);
                        }
                        else {
                            emptyView.setVisibility(View.GONE);
                            fundsAdapter = new FundsAdapter(UnitsFundsActivity.this,fundlists);
                            recyclerView.setAdapter(fundsAdapter);
                        }
                        mySwipeRefreshLayout.setRefreshing(false);
                    }catch (Exception e){
                        e.printStackTrace();
                        mySwipeRefreshLayout.setRefreshing(false);
                    }
                },error -> {
            mySwipeRefreshLayout.setRefreshing(false);
                    error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }

    void dowork(){
        String currentPriceHeader = "Current Price:";

        String message = Html.fromHtml(currentPriceHeader) + " $" + counter.getChange() + "\n";

        String title = counter.getHeading();

        AlertDialog.Builder alert =
                new AlertDialog.Builder(UnitsFundsActivity.this);
        alert.setTitle(title);
        alert.setMessage(message);

        Context context = getApplicationContext();
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);

        String[] tradeOptions = {"INVEST ", "DISINVEST"};

        final ArrayAdapter<String> adp = new ArrayAdapter<>(UnitsFundsActivity.this,
                R.layout.spinner_item_dialog, tradeOptions);

        TextView tvManagementStrategy = new TextView(UnitsFundsActivity.this);
        tvManagementStrategy.setText(context.getString(R.string.management_strategy)
                .concat(" Active"));
        tvManagementStrategy.setPadding(40, 0, 30, 0);
        layout.addView(tvManagementStrategy);

        TextView tvFundTenure = new TextView(UnitsFundsActivity.this);
        tvFundTenure.setText(context.getString(R.string.funds_tunure)
                .concat(" 6 Months"));
        tvFundTenure.setPadding(40, 20, 30, 0);
        layout.addView(tvFundTenure);

        TextView tvMaturityDate = new TextView(UnitsFundsActivity.this);
        tvMaturityDate.setText(context.getString(R.string.maturity_date).concat(Html.fromHtml("<b> 06 June 2019</b>").toString()));
        tvMaturityDate.setPadding(40, 20, 30, 0);
        layout.addView(tvMaturityDate);

        TextView tvDescription = new TextView(UnitsFundsActivity.this);
        tvDescription.setText(context.getString(R.string.enter_description));
        tvDescription.setPadding(40, 20, 30, 0);
        layout.addView(tvDescription);

        final EditText etDescription = new EditText(UnitsFundsActivity.this);
        LinearLayout.LayoutParams lpd = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        etDescription.setPadding(40, 10, 30, 20);
        etDescription.setLayoutParams(lpd);
        etDescription.setHint("Security description here");
        //etDescription.setEnabled(false);
        layout.addView(etDescription);

        TextView tvSelectTradeOption = new TextView(UnitsFundsActivity.this);
        tvSelectTradeOption.setText(context.getString(R.string.select_trade_type));
        tvSelectTradeOption.setPadding(40, 20, 30, 0);
        layout.addView(tvSelectTradeOption);

        final Spinner sp = new Spinner(UnitsFundsActivity.this);
        sp.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        sp.setPadding(30, 20 ,30, 0);
        sp.setAdapter(adp);
        layout.addView(sp);

        TextView tvQuantity = new TextView(UnitsFundsActivity.this);
        tvQuantity.setHint("Please Enter Amount");
        tvQuantity.setPadding(40, 20, 30, 0);
        layout.addView(tvQuantity);

        final EditText etQuantity = new EditText(UnitsFundsActivity.this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        etQuantity.setPadding(40, 20, 30, 20);
        etQuantity.setLayoutParams(lp);
        etQuantity.setInputType(InputType.TYPE_CLASS_NUMBER);
        layout.addView(etQuantity);

        TextView tvTotalConsideration = new TextView(UnitsFundsActivity.this);
        tvTotalConsideration.setText(context.getString(R.string.total_consideration).concat(" 0"));
        tvTotalConsideration.setPadding(40, 20, 30, 0);
        layout.addView(tvTotalConsideration);

        alert.setView(layout);

        String considerText = context.getString(R.string.total_consideration);

        etQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (count > 0) {

                    int quantity = Integer.parseInt(etQuantity.getText().toString());
                    double price = Double.parseDouble(counter.getChange());
                    double total = quantity / price;

                    Log.d("tavman quantity ", String.valueOf(quantity));
                    Log.d("tavman price ", String.valueOf(price));


                    tvTotalConsideration.setText(considerText.concat(" ")
                            .concat(MultiFormatter.toTwoDecimalPlaces(String.valueOf(total))));

                } else tvTotalConsideration.setText(considerText.concat(" 0")
                        .concat(context.getString(R.string.zwl)));
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }
        });

        String dTitle = "Result";

        alert.setPositiveButton("SUBMIT", (dialog, whichButton) -> {

            String dMessage;

            if (etQuantity.getText().toString().trim().length() < 1) {
                dMessage = "Cannot submit 0 quantity.";

                MultiFormatter.showDialog(dTitle, dMessage, UnitsFundsActivity.this);

            } else {
                disableUserInteraction();

                String orderType;

                if (sp.getSelectedItem().toString()
                        .equalsIgnoreCase(getString(R.string.DISINVEST))) {
                    orderType = getString(R.string.Sell);
                } else orderType = getString(R.string.Buy);



                Log.d("lloda","ndozvatirikushandisa");

                PostingUnitTrust unitTrust = new PostingUnitTrust();
                unitTrust.execute(counter.getTitle(), "UNIT TRUST", "GOOD TILL CANCELLED", orderType, "DAY", etQuantity.getText().toString(), counter.getChange(), cdsNumber, "AKRI", "mobile", getString(R.string.empty), getString(R.string.empty), getString(R.string.empty));
            }

        });

        alert.setNegativeButton("CANCEL", (dialog, whichButton) -> {

        });
        alert.show();
    }
    private void disableUserInteraction() {
    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        // This tip is shows the first time the sample app is loaded. Use a message that gives user
        // guide on how to use the sample app. Also try to showcase the ability of the app.
        CharSequence initialGuideTex = Html.fromHtml("Click on the <a href='#'>Buttons</a> " +
                "and the <a href='#'>Radio Buttons</a> bellow to test various tool tip configurations." +

                "<br><br><font color='white'><small>GOT IT</small></font>");

        //todo

        ToolTip.Builder builder = new ToolTip.Builder(this, toolbar, mySwipeRefreshLayout, initialGuideTex, ToolTip.POSITION_BELOW);
        builder.setAlign(mAlign);
        builder.setBackgroundColor(Color.GREEN);
        //builder.setTextAppearance(R.style.TooltipTextAppearance);
        //mToolTipsManager.show(builder.build());
    }

    @Override
    public void onTipDismissed(View view, int anchorViewId, boolean byUser) {

    }


    public class PostingUnitTrust extends AsyncTask<String, Void, String> {
        String add_info_url;

        @Override
        protected void onPreExecute() {
            add_info_url = AppConfig.getApiV2() + "/OrderPostingMakeNewMe";
        }

        @Override
        protected String doInBackground(String... args) {
            String company, security, tif, orderTrans, orderType,
                    price, quantity, cdsNumber, source, broker, expiryDate, corpName, corpId;
            company = args[0].trim();
            security = args[1];
            tif = args[2];
            orderTrans = args[3];
            orderType = args[4];
            quantity = args[5];
            price = args[6];
            cdsNumber = args[7];
            broker = args[8];
            source = args[9];
            corpName = args[10];
            corpId = args[11];
            expiryDate = args[12];
            Log.d("My URL", add_info_url);

            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

                String data_string;

                data_string =
                        URLEncoder.encode("company", "UTF-8") + "="
                                + URLEncoder.encode(company, "UTF-8")

                                + "&" + URLEncoder.encode("security", "UTF-8") + "=" +
                                URLEncoder.encode(security, "UTF-8")

                                + "&" + URLEncoder.encode("tif", "UTF-8") + "="
                                + URLEncoder.encode(tif, "UTF-8")

                                + "&" + URLEncoder.encode("orderTrans", "UTF-8") + "="
                                + URLEncoder.encode(orderTrans, "UTF-8")

                                + "&" + URLEncoder.encode("orderType", "UTF-8") + "="
                                + URLEncoder.encode(orderType, "UTF-8")

                                + "&" + URLEncoder.encode("quantity", "UTF-8") + "="
                                + URLEncoder.encode(quantity, "UTF-8")

                                + "&" + URLEncoder.encode("price", "UTF-8") + "="
                                + URLEncoder.encode(price, "UTF-8")

                                + "&" + URLEncoder.encode("cdsNumber", "UTF-8")
                                + "=" + URLEncoder.encode(cdsNumber, "UTF-8")

                                + "&" + URLEncoder.encode("broker", "UTF-8")
                                + "=" + URLEncoder.encode(broker, "UTF-8")

                                + "&" + URLEncoder.encode("source", "UTF-8")
                                + "=" + URLEncoder.encode(source, "UTF-8")

                                + "&" + URLEncoder.encode("date_", "UTF-8")
                                + "=" + URLEncoder.encode(expiryDate, "UTF-8");


                Log.d("My URL", data_string);
                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }
        @Override
        protected void onPostExecute(String result) {
            //enableUserInteraction();
            Log.d("tavman myTag", result);

            String message;

            if (result.equalsIgnoreCase("1"))
                message = "Your order has been posted successfully!";
            else message = result;

            new AlertDialog.Builder(UnitsFundsActivity.this)
                    .setTitle(R.string.result)
                    .setCancelable(false)
                    .setMessage(message)
                    //.setMessage(R.string.order_posting_successful)
                    .setPositiveButton("OK", (dialog, which) -> {
                                recreate();
                            }
                    ).setNegativeButton("Cancel",
                    (dialogInterface, i) -> {
                        recreate();
                    })
                    .show();

        }
        @Override
        protected void onProgressUpdate(Void... values) {
            //enableUserInteraction();
            super.onProgressUpdate(values);
        }

    }

}
