package zw.co.escrow.ctradelive.model;

public class SliderItem {

    private int imageUrl;
    private String message;

    public SliderItem(int url, String message) {
        this.imageUrl = url;
        this.message = message;
    }



    public int getImageUrl() {
        return imageUrl;
    }

    public String getMessage() {
        return message;
    }



}
