package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MemberAdapter;
import zw.co.escrow.ctradelive.listeners.OnHandOverDone;
import zw.co.escrow.ctradelive.model.Member;

public class ChairmanHandoverDialog extends Dialog {

    private Spinner spinner;
    private List<Member> members;
    private String selectedCds;

    private OnHandOverDone onHandOverDone;

    Toolbar toolbar;

    public ChairmanHandoverDialog(@NonNull Context context,String cdsNumber,String mCdsNumber) {
        super(context);
        setContentView(R.layout.chairman_handover_view);


        toolbar = findViewById(R.id.toolbar);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Hand Over".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(view -> dismiss());
        spinner = findViewById(R.id.spSecurities);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedCds = members.get(i).getCdsNumber();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        findViewById(R.id.btnPost).setOnClickListener(v ->{
            if(selectedCds != null){
                onHandOverDone.handOverChairman(this,cdsNumber,mCdsNumber,selectedCds);
            }else{
                Toast.makeText(getContext(),"Please Select Member.",Toast.LENGTH_SHORT).show();
            }
        });

        fetchClubMembers(cdsNumber,mCdsNumber);
        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        setCancelable(false);
    }

    private void fetchClubMembers(String cdsNumber,String mcdsnumber){

        String url = AppConfig.getIp() + "allClubMembers?cdsNumber="+cdsNumber+"&mcdsnumber="+mcdsnumber;

        StringRequest clubJson = new StringRequest( url,
                response ->
                {
                    try{
                        List<String> memberNames = new ArrayList<>();
                        members = new ArrayList<>();
                        JSONArray array = new JSONArray(response);
                        for (int i = 0; i < array.length(); i++) {

                            JSONObject responses = array.getJSONObject(i);
                            Member member = new Member();
                            member.setName(responses.getString("name"));
                            member.setCdsNumber(responses.getString("cdsnumber"));
                            members.add(member);
                            memberNames.add(member.getName());
                        }

                        ArrayAdapter<String> adapterMember = new ArrayAdapter<>(getContext(), R.layout.spinner_item, memberNames);
                        spinner.setAdapter(adapterMember);

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                },
                error ->
                {

                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }

    public void setOnHandOverDone(OnHandOverDone onHandOverDone) {
        this.onHandOverDone = onHandOverDone;
    }
}
