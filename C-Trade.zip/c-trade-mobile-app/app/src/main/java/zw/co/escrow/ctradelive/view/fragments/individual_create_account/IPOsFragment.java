package zw.co.escrow.ctradelive.view.fragments.individual_create_account;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.IPOsAdapter;
import zw.co.escrow.ctradelive.model.IPO;

public class IPOsFragment extends Fragment {

    private View view;
    private RecyclerView ipoListRecyclerView;
    private static final String TAG = "MarketWatchZSEFragment";


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        ipoListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        ipoListRecyclerView.setHasFixedSize(true);
        ipoListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        fetchIpo();
        return view;
    }
    private void fetchIpo(){


    }



}