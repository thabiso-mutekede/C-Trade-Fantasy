package zw.co.escrow.ctradelive.view.fragments.graph;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.view.fragments.OneDayGraphFragment;

public class MarketFSContainer extends Fragment {

    private ViewPager viewPager;
    private SmartTabLayout smartTabLayout;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private final Bundle bundle;
    private String ticker;





    public MarketFSContainer(Bundle bundle) {
        this.bundle = bundle;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.content_graph_container,container,false);
        initWidgets(view);
        setViewPager(bundle);
        return view;
    }
    private void initWidgets(View view){
        smartTabLayout = view.findViewById(R.id.viewpagertab);
        viewPager = view.findViewById(R.id.viewPagerWatchList);
    }
    private void setViewPager(Bundle  bundle){
        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getChildFragmentManager(), FragmentPagerItems.with(getActivity())
                .add("30 Days", OneDayGraphFragment.class, bundle)
                //.add("1 Week", OneWeekGraphFragment.class)
                //.add("1 Month", OneWeekGraphFragment.class)
                //.add("6 Months", OneWeekGraphFragment.class)
                //.add("1 Year", OneWeekGraphFragment.class)
                .create());
        viewPager.setAdapter(watchListPagerAdapter);
        smartTabLayout.setViewPager(viewPager);
    }
}
