package zw.co.escrow.ctradelive.view.fragments;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.MultiFormatter;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.TrustCounterAdapter;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.UnitTrustPortAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.Counter;
import zw.co.escrow.ctradelive.model.UnitTrustPortfolio;
import zw.co.escrow.ctradelive.view.ForexPostingActivity;


/**
 * A simple {@link Fragment} subclass.
 */
public class UnitTrustPortfolioFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = "UnitTrustPortfolioFragm";
    //RecyclerView recyclerView;
    TextView toolbarTextView;
    public static final int COLUMN_SIZE = 7;
    public static int ROW_SIZE = 100;

    private boolean onRetry = false;
    private String cds_no;
    private String ip;
    private AppConfig app;

    private List<Counter> counterList = new ArrayList<>();
    private TrustCounterAdapter mStatementAdapter;
    private String cdsNumber;
    private ProgressBar progressBar;
    private UnitTrustPortfolio unitTrustPortfolio;
    private List<UnitTrustPortfolio> unitTrustPortfolioList = new ArrayList<>();
    private RecyclerView watchListRecyclerView;



    @BindView(R.id.btn_buy_forex)
    Button btnCommoditiesBuy;

    @BindView(R.id.btn_sell_forex)
    Button btnCommoditiesSell;


    public UnitTrustPortfolioFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    private void enableUserInteraction() {

        if (getActivity() != null) {
            progressBar.setVisibility(View.GONE);
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }

    }

    private void disableUserInteraction() {

        if (getActivity() != null) {
            progressBar.setVisibility(View.VISIBLE);
            getActivity().getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        }

    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        progressBar = getView().findViewById(R.id.progressBarUnitTrust);
        toolbarTextView = getView().findViewById(R.id.chartToolBarTvTitle);
        //recyclerView = getView().findViewById(R.id.recycler_view_trust_counters);

        // Let's get TableView
        // Set adapter

        counterList.clear();
        //getTrusts();

        SharedPreferences prfs = getActivity().
                getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = prfs.getString("cds_number", "");
        unitTrustPortfolioList.clear();

        fetchMyOrders();


    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_unit_trust_portfolio,
                container, false);
        ButterKnife.bind(this, view);
 /*       btnCommoditiesBuy.setOnClickListener(this);
        btnCommoditiesSell.setOnClickListener(this);*/

        watchListRecyclerView = view.findViewById(R.id.recycler_unit_trust_portfolio);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        return view;

    }

    private void fetchMyOrders() {

        JSONObject job = new JSONObject();
        try{
            job.put("cdsNumber",cdsNumber);
            job.put("type","trust");
        }catch(Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jsonRequest = new JSONArrayRequestWithObject(Request.Method.POST, Constants.COMPLETE_URL("account/portfolio"),job,
                loginSuccessListenerPortfolio(),
                loginErrorListenerPortfolio());

        jsonRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonRequest);
    }






    private Response.ErrorListener loginErrorListenerPortfolio() {
        return error -> {
            error.printStackTrace();
            /*progressDialog.dismiss();*/
            enableUserInteraction();
            new AlertDialog.Builder(getActivity())
                    .setCancelable(false)
                    .setMessage(getString(R.string.badnetwork))
                    .setPositiveButton("OK", (dialog, which) -> {

                    })
                    .show();
        };
    }

    private Response.Listener<JSONArray> loginSuccessListenerPortfolio() {
        return response -> {
            try {

                MultiFormatter dataTypesFormatter = new MultiFormatter();

                JSONArray array = new JSONArray(response);
                System.out.print(array.toString());
                List<String> My_List_Special = new ArrayList<>();
                ROW_SIZE = array.length();


                for (int i = 0; i < array.length(); i++) {

                    JSONObject responses = array.getJSONObject(i);


                    /**
                     * Portfolio portfolio = new Portfolio();
                     *                             portfolio.setCompanyFullName(jo.getString("name"));
                     *                             portfolio.setCounter(jo.getString("company"));
                     *                             portfolio.setCurrentprice(jo.getDouble("price"));
                     *                             portfolio.setLastactivitydate(jo.getString("activeDate"));
                     *                             portfolio.setNumbershares(jo.getDouble("shares"));
                     *                             portfolio.setPrevprice(jo.getDouble("prev_price"));
                     *                             portfolio.setNet(jo.getDouble("net"));
                     *                             portfolio.setTotalportvalue(portfolio.getCurrentprice() * portfolio.getNumbershares());
                     *                             portfolio.setTotalPrevPortValue(portfolio.getPrevprice() * jo.getDouble("prev_shares"));
                     */
                    //portfolio.setTotalportvalue(portfolio.getCurrentprice() * portfolio.getNumbershares());
                    //portfolio.setTotalPrevPortValue(portfolio.getPrevprice() * jo.getDouble("prev_shares"));


                    Double tot = responses.getDouble("price") * responses.getDouble("shares");
                    Double tot_r = responses.getDouble("prev_price") * responses.getDouble("prev_shares");

                    unitTrustPortfolio = new UnitTrustPortfolio(
                          String.valueOf(tot),
                            String.valueOf(tot_r),
                            String.valueOf(responses.getDouble("prev_shares"))
                          ,responses.getString("shares")
                          ,responses.getString("uncleared")
                          ,responses.getString("net")
                          ,responses.getString("price"),
                            String.valueOf(tot),
                            String.valueOf(tot_r)
                          ,responses.getString("prev_price")
                          ,""
                          ,responses.getString("activeDate")
                          ,responses.getString("instrument")
                          ,"More"
                    );

                    unitTrustPortfolioList.add(unitTrustPortfolio);

                }

                //todo set adapter here
                watchListRecyclerView.setAdapter(new UnitTrustPortAdapter(getActivity(), unitTrustPortfolioList));


                //progressDialog.dismiss();
                enableUserInteraction();
                //getPortfolioBalances();

            } catch (Exception e) {
                e.printStackTrace();
            }

        };
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_buy_forex:
                //getActivity().finish();
                Intent buyIntent = new Intent(getActivity(),
                        ForexPostingActivity.class);
                buyIntent.putExtra(getString(R.string.selected_action), getString(R.string.Buy));
                startActivity(buyIntent);
                break;

            case R.id.btn_sell_forex:
                //getActivity().finish();
                Intent sellIntent = new Intent(getActivity(),
                        ForexPostingActivity.class);
                sellIntent.putExtra(getString(R.string.selected_action), getString(R.string.Sell));
                startActivity(sellIntent);
                break;
        }
    }

/*    private void showDialog(String message) {
        new AlertDialog.Builder(getContext())
                .setTitle(R.string.result)
                .setCancelable(false)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> {
                    //getActivity().finish();
                    startActivity(new Intent(getContext(),
                            AvailableTrusts.class));
                })
                .show();
    }*/

    @SuppressLint("StaticFieldLeak")
    public class PostingUnitTrust extends AsyncTask<String, Void, String> {
        String add_info_url;

        @Override
        protected void onPreExecute() {
            add_info_url = AppConfig.getApiV2() + "/OrderPostingMakeNew";
        }

        @Override
        protected String doInBackground(String... args) {
            String company, security, tif, orderTrans, orderType,
                    price, quantity, cdsNumber, source, broker, expiryDate, corpName, corpId;
            company = args[0].trim();
            security = args[1];
            tif = args[2];
            orderTrans = args[3];
            orderType = args[4];
            quantity = args[5];
            price = args[6];
            cdsNumber = args[7];
            broker = args[8];
            source = args[9];
            corpName = args[10];
            corpId = args[11];
            expiryDate = args[12];
            Log.d("My URL", add_info_url);

            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(new OutputStreamWriter(outputStream,
                                "UTF-8"));

                String data_string;

                data_string =
                        URLEncoder.encode("company", "UTF-8") + "="
                                + URLEncoder.encode(company, "UTF-8")

                                + "&" + URLEncoder.encode("security", "UTF-8") + "=" +
                                URLEncoder.encode(security, "UTF-8")

                                + "&" + URLEncoder.encode("tif", "UTF-8") + "="
                                + URLEncoder.encode(tif, "UTF-8")

                                + "&" + URLEncoder.encode("orderTrans", "UTF-8") + "="
                                + URLEncoder.encode(orderTrans, "UTF-8")

                                + "&" + URLEncoder.encode("orderType", "UTF-8") + "="
                                + URLEncoder.encode(orderType, "UTF-8")

                                + "&" + URLEncoder.encode("quantity", "UTF-8") + "="
                                + URLEncoder.encode(quantity, "UTF-8")

                                + "&" + URLEncoder.encode("price", "UTF-8") + "="
                                + URLEncoder.encode(price, "UTF-8")

                                + "&" + URLEncoder.encode("cdsNumber", "UTF-8")
                                + "=" + URLEncoder.encode(cdsNumber, "UTF-8")

                                + "&" + URLEncoder.encode("broker", "UTF-8")
                                + "=" + URLEncoder.encode(broker, "UTF-8")

                                + "&" + URLEncoder.encode("source", "UTF-8")
                                + "=" + URLEncoder.encode(source, "UTF-8")

                                + "&" + URLEncoder.encode("date_", "UTF-8")
                                + "=" + URLEncoder.encode(expiryDate, "UTF-8");


                Log.d("My URL", data_string);
                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            enableUserInteraction();

            Log.d("tavman myTag", result);

            String message;

            if (result.equalsIgnoreCase("1"))
                message = "Your order has been posted successfully!";
            else message = result;

            new AlertDialog.Builder(getActivity())
                    .setTitle(R.string.result)
                    .setCancelable(false)
                    .setMessage(message)
                    //.setMessage(R.string.order_posting_successful)
                    .setPositiveButton("OK", (dialog, which) -> {
                                getActivity().recreate();
                            }
                    ).setNegativeButton("Cancel",
                    (dialogInterface, i) -> {
                        getActivity().recreate();
                    })
                    .show();

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            enableUserInteraction();
            super.onProgressUpdate(values);
        }

    }


    @OnClick({R.id.btn_buy_forex, R.id.btn_sell_forex, R.id.btn_forex_deposit})
    public void tradeListener(View view) {

        //if (getActivity() != null)
            //getActivity().finish();

        switch (view.getId()) {
            case R.id.btn_buy_forex:
                //getActivity().finish();
                Intent buyIntent = new Intent(getActivity(),
                        ForexPostingActivity.class);
                buyIntent.putExtra(getString(R.string.selected_action), getString(R.string.Buy));
                startActivity(buyIntent);
                break;

            case R.id.btn_sell_forex:
                //getActivity().finish();
                Intent sellIntent = new Intent(getActivity(),
                        ForexPostingActivity.class);
                sellIntent.putExtra(getString(R.string.selected_action), getString(R.string.Sell));
                startActivity(sellIntent);
                break;

            case R.id.btn_forex_deposit:
                //getActivity().finish();
                Intent depositIntent = new Intent(getActivity(),
                        ForexPostingActivity.class);
                depositIntent.putExtra(getString(R.string.selected_action),
                        getString(R.string.deposit));
                startActivity(depositIntent);
                break;
        }

    }


}
