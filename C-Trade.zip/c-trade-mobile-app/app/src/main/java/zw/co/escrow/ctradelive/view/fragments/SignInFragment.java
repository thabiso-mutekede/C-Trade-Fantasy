package zw.co.escrow.ctradelive.view.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Group;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.developer.kalert.KAlertDialog;
import com.github.ybq.android.spinkit.style.MultiplePulseRing;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.Login;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.view.ForgotPasswordActivity;
import zw.co.escrow.ctradelive.view.MainActivity;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class SignInFragment extends Fragment implements View.OnClickListener {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private LoginViewModel loginViewModel;
    private TextInputLayout outlinedTextFieldEmail, outlinedTextFieldPassword;
    private Button btnLogin, btnTermsAndConditions, btnForgotPassword;
    private Pattern emailPattern = Pattern.compile(Constants.EMAIL_PATTERN);
    private Matcher matcher;
    private Utils utils;
    private Login login;
    private AppConfig appConfig;
    private Group constraintLayoutGroup;
    private ConstraintLayout conSpin;
    private ProgressDialog progressDialog;
    private ProgressBar loadingSpinner;
    private MultiplePulseRing multiplePulseRing;

    private KAlertDialog alertDialog;

    private boolean onRetry = false;
    private String add_info_url, pin = "", email;
    View root;


    public static SignInFragment newInstance(int index) {
        SignInFragment fragment = new SignInFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_sign_in, container, false);

        utils = new Utils(getActivity());

        // login = new Login(getActivity());
        initWidgets(root);

        // loadingSpinner.setVisibility(View.GONE);

        appConfig = (AppConfig) getActivity().getApplication();


        btnLogin.setOnClickListener(this);
        btnForgotPassword.setOnClickListener(this);
        btnTermsAndConditions.setOnClickListener(this);


        return root;
    }

    private void initWidgets(View view){

        outlinedTextFieldEmail=view.findViewById(R.id.outlinedTextFieldEmail);
        outlinedTextFieldPassword=view.findViewById(R.id.outlinedTextFieldPassword);
        btnLogin=view.findViewById(R.id.btnLogin);
        btnTermsAndConditions=view.findViewById(R.id.btnTermsAndConditions);
        btnForgotPassword= view.findViewById(R.id.btnForgotPassword);

        constraintLayoutGroup = view.findViewById(R.id.group);

        loadingSpinner = view.findViewById(R.id.loadingSpinner);
        multiplePulseRing = new MultiplePulseRing();
        loadingSpinner.setIndeterminateDrawable(multiplePulseRing);
        conSpin = root.findViewById(R.id.conSpin);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.btnLogin:

                String emailAddress = outlinedTextFieldEmail.getEditText().getText().toString();
                String password = outlinedTextFieldPassword.getEditText().getText().toString();

                if (!utils.validateEmail(emailAddress, matcher, emailPattern)) {
                    outlinedTextFieldEmail.setError("Not a valid email address!");
                }
                else if (!utils.validatePassword(password)) {
                    outlinedTextFieldPassword.setError("Not a valid password!");
                }
                else {
                    outlinedTextFieldEmail.setErrorEnabled(false);
                    outlinedTextFieldPassword.setErrorEnabled(false);

                    constraintLayoutGroup.setVisibility(View.GONE);
                    conSpin.setVisibility(View.VISIBLE);
                    utils.showLoadingSpinner(root);
                    progressDialog = new ProgressDialog(getContext());
                    Toast.makeText(getContext(),"loading....",Toast.LENGTH_SHORT).show();
                    try {
                        checkIdAndPassword(emailAddress, password);
                    } catch (Exception e) {
                        new AlertDialog.Builder(getActivity())
                                .setTitle(R.string.result)
                                .setCancelable(false)
                                .setMessage("Failed To Process Login Please Try Again Later")
                                .setPositiveButton("OK", (dialog, which) -> {

                                })
                                .show();
                        e.printStackTrace();
                    }
                }


                break;

            case R.id.btnForgotPassword:
                startActivity(new Intent(getActivity(), ForgotPasswordActivity.class));
                getActivity().finish();

                break;

            case R.id.btnTermsAndConditions:
                utils.openWebPage("https://ctrade.co.zw/online/docs/terms.pdf");
        }

    }

    private void checkIdAndPassword(String emailAddress, String password) throws Exception{

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("any",emailAddress);
        jsonObject.put("password",password);
        JsonObjectRequest jsonObjRequest1 =
                new JsonObjectRequest(Constants.COMPLETE_URL("client/login"), jsonObject, response -> {
                    try {

                        if(response.has("status")){
                            constraintLayoutGroup.setVisibility(View.VISIBLE);
                            conSpin.setVisibility(View.GONE);
                            Toast.makeText(getActivity(),response.getString("message"), Toast.LENGTH_SHORT).show();
                        }else{
                            email = response.getString("email").trim().
                                    toLowerCase();
                            String name = response.optString("surname").concat(" ").concat(response.optString("forenames"));
                            String cds = response.optString("cdsNumber");
                            String broker = response.optString("custodian");
                            boolean hasCompany = response.optString("accountType").equalsIgnoreCase("c");

                            String haveCompany;

                            if (hasCompany) haveCompany = getActivity().getString(android.R.string.yes);
                            else haveCompany = getActivity().getString(android.R.string.no);

                            Log.d("have company ", haveCompany);
                            SharedPreferences pref = getActivity().getSharedPreferences(getActivity().getString(R.string.CTRADE), Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = pref.edit();
                            editor.putString("cds_number", cds);
                            editor.putString("email", email);
                            editor.putString("fullname", name);
                            long timestamp = Calendar.getInstance().getTime().getTime();
                            Log.e("timestamp :",timestamp+"") ;
                            editor.putLong("timestamp", timestamp);
                            editor.putBoolean("verified", false);
                            editor.putString("broker", broker);
                            editor.putString("version_code", "1");
                            editor.putString(getActivity().getString(R.string.has_company), haveCompany);
                            editor.apply();
                            appConfig.setCdsNumber(cds);
                            appConfig.setEmail(email);
                            appConfig.setName(name);

                            constraintLayoutGroup.setVisibility(View.VISIBLE);
                            conSpin.setVisibility(View.GONE);
                            Intent intent = new Intent(getActivity(), MainActivity.class);
                            getActivity().startActivity(intent);
                            getActivity().finish();
                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(),"Failed To Read Response Please Try Again Later", Toast.LENGTH_SHORT).show();
                    }
                },error -> {
                    progressDialog.dismiss();
                    constraintLayoutGroup.setVisibility(View.VISIBLE);
                    utils.removeLoadingSpinner(root);
                    conSpin.setVisibility(View.GONE);
                    new AlertDialog.Builder(getActivity())
                            .setTitle(R.string.result)
                            .setCancelable(false)
                            .setMessage(R.string.badnetwork)
                            .setPositiveButton("OK", (dialog, which) -> {

                            })
                            .show();
                });

        jsonObjRequest1.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest1);
    }
}