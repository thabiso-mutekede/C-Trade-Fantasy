package zw.co.escrow.ctradelive.model;

import java.util.List;

public class FundlistObject {

    private List<Fundlist> fundlist;

    public List<Fundlist> getFundlist() {
        return fundlist;
    }

    public void setFundlist(List<Fundlist> fundlist) {
        this.fundlist = fundlist;
    }
}
