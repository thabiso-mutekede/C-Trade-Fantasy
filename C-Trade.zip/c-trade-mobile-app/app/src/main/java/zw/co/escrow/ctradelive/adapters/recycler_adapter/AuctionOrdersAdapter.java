package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.FXOrders;
import zw.co.escrow.ctradelive.model.MyOrder;

public class AuctionOrdersAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<FXOrders> fxOrders;
    private Context activity;
    private MyOrder myOrder;
    private String cdsNumber;
    private final RecyclerView recyclerView;

    public AuctionOrdersAdapter(Context activity, List<FXOrders> fxOrders, RecyclerView recyclerView) {
        this.fxOrders = fxOrders;
        this.activity = activity;
        this.recyclerView = recyclerView;

        SharedPreferences sharedPreferences = activity.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = sharedPreferences.getString("cds_number", "");
    }
    @Override
    public int getItemViewType(int position) {
        return R.layout.auction_orders_adapter_view;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new MyOrdersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((MyOrdersViewHolder)holder).bindData(fxOrders.get(position));
    }
    @Override
    public int getItemCount() {
        return fxOrders.size();
    }

    public static class MyOrdersViewHolder extends RecyclerView.ViewHolder{

        private TextView txtType, txtQuantity, txtDate, txtCurrentPrice, txtValue,txtProductType;
        private CardView cardView, wl_change_indicator;

        public MyOrdersViewHolder(@NonNull View itemView) {
            super(itemView);
            txtType = itemView.findViewById(R.id.txtType);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtValue = itemView.findViewById(R.id.txtValue);
            cardView = itemView.findViewById(R.id.cardView);
            wl_change_indicator = itemView.findViewById(R.id.wl_change_indicator);
            txtProductType = itemView.findViewById(R.id.product_type);
        }

        public void bindData(FXOrders fxOrders){
            txtType.setText("ZWL".concat(fxOrders.getAmount()));
            txtQuantity.setText(fxOrders.getAuctionId());
            txtDate.setText(fxOrders.getDatePosted());
            txtCurrentPrice.setText(String.format("Rate: %s", fxOrders.getPreferredRate()));

            if(fxOrders.getAvgRate() != null)txtValue.setText(String.format("W.AVG: %s", fxOrders.getAvgRate()));
            else txtValue.setText(fxOrders.getState());

            txtProductType.setText(fxOrders.getPurpose());
        }
    }
}