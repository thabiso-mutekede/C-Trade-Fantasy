package zw.co.escrow.ctradelive.view.dialogs;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.textfield.TextInputEditText;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;

public class TradeDialogFantasy extends DialogFragment implements AdapterView.OnItemSelectedListener , View.OnClickListener{
    public static final String TAG = TradeDialogFantasy.class.getSimpleName();
    String cds_number;
    ArrayAdapter<String> marketAdapter;
    String title="";
    private Toolbar toolbar;



    Spinner spCompanies, spBuyOrSell, spBroker, spSecurities,spMarket;
    String orderTypes, add_info_url, add_info_urlc, add_info_urlg, ip, mobileapi, timeInForce;
    List<String> allCompanies = new ArrayList<>();
    List<String> allOrganizations = new ArrayList<>();
    Map<String, String> brokerThreshold = new HashMap<>();
    Map<String, String> allOrganisationsMap = new HashMap<>();
    Map<String, String> allCompaniesMap = new HashMap<>();
    SearchableSpinner searchableSpinner;
    private DatePickerDialog fromDatePickerDialog;
    private SimpleDateFormat dateFormatter;
    private String expiresOn, selectedCompany;/*felloverip1*/;
    private boolean orRetryFetchCompanies = false;

    ArrayList<String> buyOrSell = new ArrayList<>();
    String[] orderTimeinForce = new String[]{"Day Order (DO)", "Good Till Cancelled (GTC)", "Immediate/Cancel Order (IOC)", "Good Till Day (GTD)"};
    String[] orderType = new String[]{"Limit"};
    Button btnPost;
    AppConfig app;
    TextInputEditText etQuantity, etPrice;
    RelativeLayout brkz;
    TextView currentPrice, validUntil, storedPrice;
    String brokr;
    String currentExchange, whatsSelected, entityType, corpName = null, corporateId = null;
    String cdsnumber;
    private String market;
    private ProgressBar progressBar;
    //RelativeLayout rlPbOrderPosting;

    //@BindView(R.id.card_view_order_posting)
    CardView cardViewOrderPosting;

    public static TradeDialogFantasy newInstance(String market,String sell, String cdsnumber) {
        Bundle args = new Bundle();
        args.putString("title", sell);
        args.putString("cdsnumber",cdsnumber);
        args.putString("market",market);
        TradeDialogFantasy userPopUp = new TradeDialogFantasy();
        userPopUp.setArguments(args);
        return userPopUp;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prfs = getContext().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        String whatsSelected = prfs.getString(getString(R.string.entity_type), "");
        Bundle mArgs = getArguments();
        title = mArgs.getString("title");
        cdsnumber = mArgs.getString("cdsnumber");
        market = mArgs.getString("market");

        if (whatsSelected.equalsIgnoreCase(getString(R.string.company)))
            cds_number = prfs.getString(getString(R.string.corp_cds_number), "");
        else cds_number = prfs.getString("cds_number", "");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_trade_club_dialog, container, false);
        toolbar = v.findViewById(R.id.toolbar);
        toolbar = v.findViewById(R.id.toolbar);
        toolbar.setTitle("Fantasy Trade".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(view -> dismiss());

        v.findViewById(R.id.green_line).setVisibility(View.GONE);

        marketAdapter = new ArrayAdapter<>(getContext(), R.layout.spinner_item, new String[]{market});
        spMarket =  v.findViewById(R.id.spMarket);
        spMarket.setAdapter(marketAdapter);
        spMarket.setOnItemSelectedListener(this);

        if(title.equalsIgnoreCase("sell")){
            //optionAdapter=new ArrayAdapter<>(getContext(), R.layout.spinner_item, new String[]{"SellForBureau","SellForWallet"});

        } else if  (title.equalsIgnoreCase("buy")){
            //optionAdapter=new ArrayAdapter<>(getContext(), R.layout.spinner_item, new String[]{"BuyForPickUp","BuyForWallet"});

        }
        cardViewOrderPosting= v.findViewById(R.id.card_view_order_posting);
        //rlPbOrderPosting= v.findViewById(R.id.rl_pb_order_posting);
        allCompanies.clear();
        allOrganisationsMap.clear();
        allCompaniesMap.clear();
        brokerThreshold.clear();
        app = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();
        //felloverip1 = AppConfig.getFellOverIpAddress1();
        //felloverip2 = AppConfig.getFellOverIpAddress2();
        mobileapi = AppConfig.getMobileApiAddress();
        currentExchange = "ZSE";
        //selectedCompany = getIntent().getExtras().getString(getString(R.string.selected_company));
        orderTypes = "Day";
        company = "any";
        progressBar =  v.findViewById(R.id.progressBarOp);
        btnPost =  v.findViewById(R.id.btnPost);

        fetchListedCompanies();

        currentPrice =  v.findViewById(R.id.currentPrice);
        //exchange =  v.findViewById(R.id.title_dialod);
        spBroker =  v.findViewById(R.id.spBroker);

        spCompanies =  v.findViewById(R.id.spCompanies);
        //rlMyOrganization = findViewById(R.id.rlMyOrganisation);

        searchableSpinner =  v.findViewById(R.id.spCompaniesSearchable);
        searchableSpinner.setTitle("Search a company");
        searchableSpinner.setPositiveButton("OK");


        allOrganizations.clear();

        spSecurities = v.findViewById(R.id.spSecurities);
        spBuyOrSell = v.findViewById(R.id.spBuyOrSell);
        etQuantity = v.findViewById(R.id.etQuantity);
        validUntil = v.findViewById(R.id.validUntil);
        etPrice = v.findViewById(R.id.etPrice);
        storedPrice = v.findViewById(R.id.storedPrice);
        brkz = v.findViewById(R.id.rl_bureau);

        spSecurities.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                timeInForce = spSecurities.getSelectedItem().toString();
                if (timeInForce.equalsIgnoreCase("Good Till Day (GTD)")) {
                    validUntil.setVisibility(View.VISIBLE);
                    showDatePicker();
                    fromDatePickerDialog.show();
                } else {
                    validUntil.setVisibility(View.GONE);
                    validUntil.setText("");
                    expiresOn = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        // exchange.setText(getString(R.string.EXCHANGE_COLON_SUFFIX).concat(currentExchange));
        spBuyOrSell.setOnItemSelectedListener(this);

        final String selectedAction = title;

        if (selectedAction != null && selectedAction.equalsIgnoreCase(getString(R.string.none))) {
            buyOrSell.add(getString(R.string.Buy));
            buyOrSell.add(getString(R.string.Sell));

        } else buyOrSell.add(selectedAction);

        ArrayAdapter<String> adapterBuyOrSell = new ArrayAdapter<>(getContext(), R.layout.spinner_item, buyOrSell);
        spBuyOrSell.setAdapter(adapterBuyOrSell);

        ArrayAdapter<String> adapterBuyOrSell1 = new ArrayAdapter<>(getContext(), R.layout.spinner_item, orderTimeinForce);
        spSecurities.setAdapter(adapterBuyOrSell1);

        app = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();
        SharedPreferences prfs = getContext().getSharedPreferences(getString(R.string.CTRADE), Context.MODE_PRIVATE);
        brokr = prfs.getString("broker", "");
        cdsNumber = prfs.getString("cds_number", "");
        whatsSelected = prfs.getString(getString(R.string.entity_type), "");
        corpName = prfs.getString(getString(R.string.corp_name), "");
        corporateId = prfs.getString(getString(R.string.corp_cds_number), "");

        fetchBrokers();

//        if (brokr.equals("")) {
//            //fetchBrokers();
//        } else {
//            brkz.setVisibility(View.GONE);
//        }
        spCompanies.setOnItemSelectedListener(this);
        searchableSpinner.setOnItemSelectedListener(this);

        btnPost.setOnClickListener(this);

        getMarketStatus();
        //onEntityTypeSelected();


        v.findViewById(R.id.btnPost).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentExchange =  spMarket.getSelectedItem().toString();
                //ProgressDialog progressDialog = new ProgressDialog(getContext());
                //progressDialog.setMessage("Please wait");
                // progressDialog.show();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                String today = formatter.format(new Date());

                Log.d("expires on ", expiresOn);


                boolean isValid = true;

                quantity = etQuantity.getText().toString();
                try {
                    //company = spCompanies.getSelectedItem().toString();
                    /**company = searchableSpinner.getSelectedItem().toString();
                     if (brokr.equals("")) {


                     } else {
                     broker = brokr;

                     }*/
                    broker = spBroker.getSelectedItem().toString();
                    if (broker.equalsIgnoreCase(getString(R.string.pleaseselect))) {
                        isValid = false;
                        Toast.makeText(getContext(), "Please select a broker", Toast.LENGTH_SHORT).show();
                    }
                    orderTrans = spBuyOrSell.getSelectedItem().toString();

                } catch (Exception ex) {
                    company = getString(R.string.pleaseselect);
                    orderTrans = getString(R.string.pleaseselect);
                    broker = getString(R.string.pleaseselect);
                }

                if (orderTrans.equals(getString(R.string.pleaseselect))) {
                    Toast.makeText(getContext(), "Please select Order Type", Toast.LENGTH_SHORT).show();
                    isValid = false;
                }

                if (company.equalsIgnoreCase(getString(R.string.pleaseselect))) {
                    isValid = false;
                    Toast.makeText(getContext(), "Please select company", Toast.LENGTH_SHORT).show();
                }

                String priceText = etPrice.getText().toString();

                if (String.valueOf(priceText).isEmpty() ||
                        priceText.length() < 1) {
                    isValid = false;
                    etPrice.setError("Please Insert Price");
                } else if (!String.valueOf(priceText).isEmpty() & Double.valueOf(priceText) == 0) {
                    isValid = false;
                    etPrice.setError("Please Insert a Share Price above 0");
                }

                currentprice = app.getCurrentPrice();
                //String pp = app.getCurrentPrice();
                String storedPriceText = storedPrice.getText().toString();
                String trimmedPrice = storedPriceText.replace(getString(R.string.currentpriceis),
                        "").trim();
                currentprice = trimmedPrice;
                Log.d("Original current price", currentprice);

                price = "0";
            /*  SharedPreferences prfs = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
                cdsNumber = prfs.getString("cds_number", "");*/
                // = app.getCdsNumber();

                if (!isValidField(quantity)) {
                    etQuantity.setError("Enter Quantity");
                    isValid = false;
                } else if (!String.valueOf(quantity).isEmpty() & Double.valueOf(quantity) == 0) {
                    isValid = false;
                    etQuantity.setError("Please note input a quantity greater than 0");
                }

                if (isValid) {

                    Double selectedPrice = Double.valueOf(priceText);
                    Double selectedQuantity = Double.valueOf(etQuantity.getText().toString());
                    Double total = selectedPrice * selectedQuantity;

                    Log.d("Quantity ", selectedQuantity.toString());
                    Log.d("Price ", selectedPrice.toString());
                    Log.d("Total ", total.toString());

                    Double threshold = Double.valueOf(brokerThreshold.get(broker));

                    if (total < 10) {

                        isValid = false;
                        etQuantity.setError("Please note the minimum transaction total is ZWL 10.");

                    } else if (threshold != null && total < threshold) {

                        isValid = false;
                        String brokerlimitviolation = "Your selected broker only " +
                                "accepts orders above ZWL " + threshold + ". " +
                                "Please select another broker and try again.";

                        etQuantity.setError(brokerlimitviolation);

                    }
                }


                if (etPrice.getVisibility() == View.VISIBLE) {
                    price = etPrice.getText().toString();
                    if (orderType.equals("Limit") && !isValidField(price)) {
                        etPrice.setError("Enter Price");
                        isValid = false;
                    }
                }

                if (price.equals(""))
                    price = "0.0";
                price = etPrice.getText().toString();
                Log.d("Entered price ", price);
                try {

                    Double newPrice = Double.valueOf(price);
                    Double priceProtectionUpper, priceProtectionLower;

                    if (currentExchange.equalsIgnoreCase("ZSE")) {

                        if (newPrice >= 0.01) {

                            priceProtectionUpper = Double.valueOf(currentprice) * 1.2;

                            priceProtectionLower = Double.valueOf(currentprice) * 0.8;

                            if (newPrice > priceProtectionUpper || newPrice < priceProtectionLower) {
                                etPrice.setError(getString(R.string.price_protection));
                                isValid = false;

                            }

                        } else {

                            priceProtectionUpper = Double.valueOf(currentprice) * 2;

                            if (newPrice > priceProtectionUpper || newPrice == 0) {
                                etPrice.setError(getString(R.string.price_protection));
                                isValid = false;
                            }
                        }
                    } else if (currentExchange.equalsIgnoreCase("FINSEC")) {
                        Log.e("empty",currentprice);
                        priceProtectionUpper = Double.valueOf(currentprice) * 1.1;
                        priceProtectionLower = Double.valueOf(currentprice) * 0.9;

                        if (newPrice > priceProtectionUpper || newPrice < priceProtectionLower) {
                            etPrice.setError(getString(R.string.price_protection));
                            isValid = false;
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }

                if (isValid) {
                    double charges = 1.0;
                    if (buyOrSellStr.equalsIgnoreCase("Buy")) {
                        charges = Double.valueOf("1.01693");
                    }
                    if (buyOrSellStr.equalsIgnoreCase("Sell")) {
                        charges = Double.valueOf("0.97557");
                    }
                    DecimalFormat df = new DecimalFormat("#.####");
                    double MyTotal = Double.valueOf(etPrice.getText().toString()) * Double.valueOf(etQuantity.getText().toString()) * charges;
                    //MyTotal = Double.valueOf(df.format(MyTotal));

                    String finalCorporateId = corporateId;
                    String finalCorpName = corpName;
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                            .setCancelable(false)
                            .setMessage("Posting a " + buyOrSellStr + " ORDER "
                                    + "\nQuantity: " + Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(etQuantity.getText().toString())))//.
                                    + "\nPrice: ZWL " + etPrice.getText()
                                    + "\nTotal : ZWL " +Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(MyTotal)))))
                            .setPositiveButton("Place Order", (dialog, which) -> {

                                disableUserInteraction();


                                Log.d("em"," ->> "+allCompaniesMap.toString() +"  -  "+company);

                                //PostingOrders postingOrders = new PostingOrders();
//                                postingOrders.execute(allCompaniesMap.get(company), "EQUITY", timeInForce, orderTrans,
//                                        orderTypes, quantity, price, cdsnumber, broker, "mobile", finalCorpName, finalCorporateId, expiresOn);

                                postTrade(allCompaniesMap.get(selectedCompany),orderTrans,Integer.parseInt(quantity),Double.parseDouble(price),cdsNumber,broker,"Android",timeInForce,expiresOn);
                            })
                            .setNegativeButton("Cancel", (dialog, which) -> {

                            }).create();


                    alertDialog.setOnShowListener(dialogInterface -> {
                        alertDialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorAccent));
                        alertDialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.white));
                    });
                    alertDialog.show();

                }




                new Handler().postDelayed(() -> {
                    //progressDialog.dismiss();
                },2000);
            }
        });


        return v;
    }



    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
        }
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        timeInForce = spSecurities.getSelectedItem().toString();
        if (timeInForce.equalsIgnoreCase("Good Till Day (GTD)")) {
            validUntil.setVisibility(View.VISIBLE);
            showDatePicker();
            fromDatePickerDialog.show();
        } else {
            validUntil.setVisibility(View.GONE);
            validUntil.setText("");
            expiresOn = "";
        }

        Spinner spinner = (Spinner) adapterView;
        if(spinner.getId() == R.id.spMarket){
            getMarketStatus();
            fetchListedCompanies();
        }

        if (spinner.getId() == R.id.spCompanies) {

            disableUserInteraction();

            app = (AppConfig) getActivity().getApplication();
            ip = AppConfig.getIpAddress();

            add_info_url = "https://" + ip + "/GetSecurities";
            StringRequest jsonObjRequestz = new StringRequest(Request.Method.POST, add_info_url,
                    successListenerFetchSecurities(),
                    errorListenerFetchSecurities()) {
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("company", allCompanies.get(i));
                    params.put("exchange", spMarket.getSelectedItem().toString());
                    return params;
                }
            };

            jsonObjRequestz.setRetryPolicy(new DefaultRetryPolicy(AppConfig.REASONABLE_RETRY_MS, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            AppConfig.getInstance().addToRequestQueue(jsonObjRequestz);

        } else if (spinner.getId() == R.id.spBuyOrSell) {
            buyOrSellStr = spBuyOrSell.getSelectedItem().toString();
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onClick(View view) {

    }
    private void enableUserInteraction() {

        //progressBar.setVisibility(View.GONE);
        //rlPbOrderPosting.setVisibility(View.GONE);
        //btnPost.setVisibility(View.VISIBLE);
        cardViewOrderPosting.setVisibility(View.VISIBLE);
        // rlPbOrderPosting.setVisibility(View.GONE);
        //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    private void disableUserInteraction() {

        //progressBar.setVisibility(View.VISIBLE);
        //rlPbOrderPosting.setVisibility(View.VISIBLE);
        //btnPost.setVisibility(View.GONE);


        cardViewOrderPosting.setVisibility(View.GONE);
        //rlPbOrderPosting.setVisibility(View.VISIBLE);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    //private boolean onRetryFetchBrokers = false;

    private boolean onRetryComps = false;
    String buyOrSellStr;



    private boolean isValidField(String pass) {
        return 0 < pass.length();
    }

    String company, currentprice, orderTrans, price, quantity, cdsNumber, broker;

    private void fetchBrokers() {

        disableUserInteraction();
        StringRequest jsonObjRequest2 = new StringRequest(Request.Method.POST,
                Constants.COMPLETE_URL("data/broker"),
                successListenerFetchBrokers(),
                errorListenerFetchBrokers());
        jsonObjRequest2.setRetryPolicy(new DefaultRetryPolicy(AppConfig.REASONABLE_RETRY_MS, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        AppConfig.getInstance().addToRequestQueue(jsonObjRequest2);
    }

    private void fetchListedCompanies() {

        disableUserInteraction();
        JSONObject jo = new JSONObject();
        try {
            jo.put("market",spMarket.getSelectedItem().toString());
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jsonObjRequest = new JSONArrayRequestWithObject(Request.Method.POST,Constants.COMPLETE_URL("data/companies/listed"),jo, successListenerFetchCompanies(), errorListenerFetchCompanies());
        jsonObjRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 5000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 5;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                error.printStackTrace();
            }
        });
        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    private void showDatePicker() {
        dateFormatter = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(getContext(),
                (view, year, monthOfYear, dayOfMonth) -> {
                    Calendar newDate = Calendar.getInstance();
                    newDate.set(year, monthOfYear, dayOfMonth);
                    validUntil.setText(getString(R.string.validuntil).concat(dateFormatter.format(newDate.getTime())));
                    expiresOn = dateFormatter.format(newDate.getTime());
                }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH),
                newCalendar.get(Calendar.DAY_OF_MONTH));
    }

    private void getMarketStatus() {

        disableUserInteraction();

        JSONObject jo = new JSONObject();
        try {
            jo.put("market",spMarket.getSelectedItem().toString());
        }catch (Exception e){
            e.printStackTrace();
        }
        JsonObjectRequest jsonObjRequest = new JsonObjectRequest(Constants.COMPLETE_URL("data/status"),
                jo,
                response -> {
                    enableUserInteraction();
                    try{
                        if(response.getBoolean("open")){
                            currentPrice.setBackgroundColor(Color.parseColor("#7CFC00"));
                            currentPrice.setText(R.string.marketopen);
                        }else{
                            currentPrice.setBackgroundColor(Color.parseColor("#c40125"));
                            currentPrice.setText(R.string.marketclosed);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                },
                errorListenerMarketStatus());


        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(AppConfig.REASONABLE_RETRY_MS, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        enableUserInteraction();
    }

    List<String> allSecurities = new ArrayList<>();
    List<String> allBrokers = new ArrayList<>();

    private com.android.volley.Response.Listener<String> successListenerFetchBrokers() {
        return response -> {
            try {
                enableUserInteraction();
                Log.d("brokers",response);

                JSONArray jsonArray = new JSONArray(response);

                if (jsonArray.length() > 0) {
                    allBrokers.add("Please Select");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String broker = jsonObject.optString("code");
                        String threshold = jsonObject.optString("threshold");

                        brokerThreshold.put(broker, threshold);
                        allBrokers.add(broker);
                    }

                    ArrayAdapter<String> adapterBroker = new ArrayAdapter<>(getContext(), R.layout.spinner_item, allBrokers);
                    spBroker.setAdapter(adapterBroker);

                } else {
                    allBrokers.add("No brokers");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private com.android.volley.Response.ErrorListener errorListenerFetchBrokers() {
        return error -> {
            try {
                enableUserInteraction();

                //if (onRetryFetchBrokers) {
                new AlertDialog.Builder(getContext())
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
                //  onRetryFetchBrokers = false;
                //} else {
                //onRetryFetchBrokers = true;
                fetchBrokers();
                //}
            } catch (Exception e) {

            }
        };
    }

    private com.android.volley.Response.Listener<String> successListenerFetchSecurities() {
        return response -> {
            try {
                /*if (progressDialogs != null)
                    progressDialogs.dismiss();*/
                enableUserInteraction();

                JSONArray jsonArray = new JSONArray(response);

                if (jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String instrument = jsonObject.optString("Instrument");
                        String isin = jsonObject.optString("IsinNo");
                        //String price = jsonObject.optString("InitialPrice");
                        allSecurities.add(instrument);
                        Double ogValue = jsonObject.getDouble("InitialPrice");
                        String price = BigDecimal.valueOf(ogValue).toPlainString();
                        Log.d("price_",price);
                        etPrice.setText(String.valueOf(price));
                        app.setCurrentPrice(price);
                        storedPrice.setText(getString(R.string.currentpriceis).concat(price));
                    }
                } else {
                    allSecurities.add("No security for the company");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private com.android.volley.Response.ErrorListener errorListenerFetchSecurities() {
        return error -> {
            try {
                enableUserInteraction();

                new AlertDialog.Builder(getContext())
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    //FETCH COMPANIES

    private com.android.volley.Response.Listener<JSONArray> successListenerFetchCompanies() {
        return response -> {
            try {
                JSONArray jsonArray = response;
                if (jsonArray.length() > 0) {
                    allCompanies.clear();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String name = jsonObject.optString("fullName");
                        String compInitial = jsonObject.optString("company");
                        price = jsonObject.optString("initialPrice");

                        if (selectedCompany != null &&
                                selectedCompany.equalsIgnoreCase(compInitial)
                                        & allCompanies.size() == 0) {
                            allCompanies.add(0, name);
                            allCompaniesMap.put(name, compInitial);
                        } else if (selectedCompany != null &&
                                !selectedCompany.equalsIgnoreCase(compInitial) &&
                                allCompanies.size() > 0) {
                            allCompanies.add(name);
                            allCompaniesMap.put(name, compInitial);
                        } else if (selectedCompany == null & allCompanies.size() == 0) {
                            allCompanies.add(0, "Please Select");
                            allCompanies.add(name);
                            allCompaniesMap.put(name, compInitial);
                        } else if (selectedCompany == null & allCompanies.size() > 0) {
                            allCompanies.add(name);
                            allCompaniesMap.put(name, compInitial);
                        }
                    }
                    app.setCurrentPrice(price);
                    ArrayAdapter<String> adapterCompanies = new ArrayAdapter<>(getContext(), R.layout.spinner_item, allCompanies);
                    spCompanies.setAdapter(adapterCompanies);

                    ArrayAdapter<String> adapterCompaniesSearchable = new ArrayAdapter<>(getContext(), R.layout.spinner_item, allCompanies);
                    searchableSpinner.setAdapter(adapterCompaniesSearchable);

                    //enableUserInteraction();

                    searchableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            String spinnerCompany = searchableSpinner.getSelectedItem().toString();

                            if (!spinnerCompany.equalsIgnoreCase("Please Select")) {
                                storedPrice.setVisibility(View.VISIBLE);

                                disableUserInteraction();

                                selectedCompany = allCompanies.get(position);
                                app = (AppConfig) getActivity().getApplication();
                                ip = AppConfig.getIpAddress();

                                add_info_url = "https://" + ip + "/GetSecurities";
                                StringRequest jsonObjRequestz = new StringRequest(Request.Method.POST, add_info_url, successListenerFetchSecurities(), errorListenerFetchSecurities()) {
                                    protected Map<String, String> getParams() {
                                        Map<String, String> params = new HashMap<>();
                                        params.put("company", allCompanies.get(position));
                                        params.put("exchange", spMarket.getSelectedItem().toString());
                                        return params;
                                    }
                                };

                                jsonObjRequestz.setRetryPolicy(new DefaultRetryPolicy(AppConfig.REASONABLE_RETRY_MS, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                                AppConfig.getInstance().addToRequestQueue(jsonObjRequestz);
                            } else {
                                storedPrice.setText(getString(R.string.empty));
                                storedPrice.setVisibility(View.GONE);
                            }

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });
                    enableUserInteraction();
                } else {
                    Toast.makeText(getContext()
                            , getString(R.string.badnetwork),
                            Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private com.android.volley.Response.ErrorListener errorListenerFetchCompanies() {
        return error -> {
            try {
                enableUserInteraction();

                if (orRetryFetchCompanies) {
                    new AlertDialog.Builder(getContext())
                            .setCancelable(false)
                            .setMessage(getString(R.string.badnetwork))
                            .setPositiveButton("OK", (dialog, which) -> {
                            })
                            .show();
                    orRetryFetchCompanies = false;
                } else {
                    orRetryFetchCompanies = true;
                    fetchListedCompanies();
                }
            } catch (Exception e) {
            }
        };
    }

    //Market status
    private com.android.volley.Response.ErrorListener errorListenerMarketStatus() {
        return error -> {
            try {
                enableUserInteraction();

                new AlertDialog.Builder(getContext())
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                Log.d("Error in MarketStatus ", e.getMessage());
            }

        };
    }
    private void postTrade(String company,String orderType,int quantity,double price,String cdsNumber,
                           String broker,String source,String tif,String date){
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Posting Order....");
        progressDialog.show();
        JSONObject jo = new JSONObject();
        try{
            jo.put("company",company);
            jo.put("orderType",orderType);
            jo.put("quantity",quantity);
            jo.put("price",price);
            jo.put("cdsNumber",cdsNumber);
            jo.put("broker",broker);
            jo.put("source",source);
            jo.put("tif",tif);
            jo.put("date_",date);
        }catch (Exception e){
            e.printStackTrace();
        }
        Log.d("jo",jo.toString());
        JsonObjectRequest jr = new JsonObjectRequest(Constants.COMPLETE_URL("fantasy/shares/new/order"),jo,
                response -> {
                    try {
                        progressDialog.dismiss();
                        AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                                .setTitle(R.string.result)
                                .setCancelable(false)
                                .setMessage(response.getString("message"))
                                //.setMessage(R.string.order_posting_successful)
                                .setPositiveButton("OK", (dialog, which) -> {
                                            //startActivity(new Intent(getContext(), TradeNowActivity.class));
                                            //finish();
                                            dismiss();
                                        }
                                ).create();

                        alertDialog.setOnShowListener(dialogInterface -> {
                            alertDialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorAccent));
                            alertDialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.white));
                        });

                        alertDialog.show();
                    }catch (Exception e){
                        Constants.showDialog(getContext(),"Something Went Wrong!");
                        progressDialog.dismiss();
                        e.printStackTrace();
                    }

                },error -> {
            progressDialog.dismiss();
            Constants.showDialog(getContext(),Constants.ERROR_MESSAGE);
            error.printStackTrace();
        }){
            @Override
            public RetryPolicy getRetryPolicy() {
                return new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 500000;
                    }

                    @Override
                    public int getCurrentRetryCount() {
                        return 0;
                    }

                    @Override
                    public void retry(VolleyError error) throws VolleyError {

                    }
                };
            }
        };
        AppConfig.getInstance().addToRequestQueue(jr);
    }

}
