package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class CPAYTransaction implements Parcelable {
    
        private String amount;
        private String currency;
        private String transaction_type;
        private String date_created;
        private Boolean authorised;

    protected CPAYTransaction(Parcel in) {
        amount = in.readString();
        currency = in.readString();
        transaction_type = in.readString();
        date_created = in.readString();
        byte tmpAuthorised = in.readByte();
        authorised = tmpAuthorised == 0 ? null : tmpAuthorised == 1;
    }

    public static final Creator<CPAYTransaction> CREATOR = new Creator<CPAYTransaction>() {
        @Override
        public CPAYTransaction createFromParcel(Parcel in) {
            return new CPAYTransaction(in);
        }

        @Override
        public CPAYTransaction[] newArray(int size) {
            return new CPAYTransaction[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(amount);
        parcel.writeString(currency);
        parcel.writeString(transaction_type);
        parcel.writeString(date_created);
        parcel.writeByte((byte) (authorised == null ? 0 : authorised ? 1 : 2));
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTransaction_type() {
        return transaction_type;
    }

    public void setTransaction_type(String transaction_type) {
        this.transaction_type = transaction_type;
    }

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    public Boolean getAuthorised() {
        return authorised;
    }

    public void setAuthorised(Boolean authorised) {
        this.authorised = authorised;
    }
}
