package zw.co.escrow.ctradelive.view;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.JsonArrayRequest;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.GroupStatement;

public class ClubStatementsView extends AppCompatActivity {

    private RecyclerView recyclerView;
    ProgressDialog progressDialog;

    List<String> comps = new ArrayList<>();
    List<GroupStatement> groupStatements = new ArrayList<>();
    ClubModel investmentClub;
    String type;
    Toolbar toolbar;
    Intent intent;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_holdings_view);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        intent = getIntent();
        investmentClub = intent.getParcelableExtra("club");
        type = intent.getStringExtra("");
        toolbar.setTitle(investmentClub.getClubName());


        recyclerView = findViewById(R.id.member_holdings_rv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        getHoldCompaniesForGroup();

        /*searchableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getHoldingsList(comps.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/
    }

    private void getHoldCompaniesForGroup(){

        investmentClub.getClubName();

        String number = investmentClub.getClubCdsNumber();
        String url = String.format("transCompanies?group_cds_number=%s",number);
        String api = AppConfig.getIp().concat(url);
        Log.d("group_holdings",api);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(api,
                response -> {
                    try{

                        for(int i = 0;i<response.length();i++){
                            comps.add(response.getJSONObject(i).getString("Company"));
                        }
                        ///ArrayAdapter<String> adapterPTypes = new ArrayAdapter<>(this, R.layout.spinner_item, comps);
                        //searchableSpinner.setAdapter(adapterPTypes);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                },error -> {
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);

    }
    /***********************private void getHoldingsList(String company){

        progressDialog.setMessage("processing request");
        progressDialog.show();
        investmentClub.getClubName();


        String url = String.format("/Holdings?groupid=%s&company=%s",investmentClub.getClubCdsNumber(),company);

        String api = AppConfig.getIp().concat(url);

        Log.d("group_holdings",api);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(api,
                response -> {

                    try{

                        groupStatements = new ArrayList<>();
                        for(int i = 0;i<response.length();i++){
                            JSONObject statement = response.getJSONObject(i);
                            groupStatements.add(new GroupStatement(
                                    statement.getString("fullName"),
                                    statement.getString("company"),
                                    statement.getString("shares"),
                                    statement.getString("cds_number")
                                    ));
                        }

                        GroupHoldingsAdapter groupHoldingsAdapter = new GroupHoldingsAdapter(this,groupStatements,recyclerView,investmentClub.getClubCdsNumber(),company);
                        recyclerView.setAdapter(groupHoldingsAdapter);
                        progressDialog.dismiss();
                    }catch (Exception e){
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }

                },error -> {
            progressDialog.dismiss();
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);

    }*************/
}
