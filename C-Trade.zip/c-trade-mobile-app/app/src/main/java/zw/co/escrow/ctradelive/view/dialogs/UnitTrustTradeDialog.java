package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.adapters.FundsAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.Fundlist;
import zw.co.escrow.ctradelive.model.FundlistObject;
import zw.co.escrow.ctradelive.view.UnitsFundsActivity;

public class UnitTrustTradeDialog extends Dialog {


    private TextView fundDescriptionTv,fundWarningTv,fundTsncsLink;
    private TextInputEditText amountEt,sourceEt,reasonEt,orderTypeEt;
    private Spinner selectTrustSP,selectFundSP;
    private RelativeLayout warningRl;
    private String cds_number;
    private String orderType;
    private Map<String,String> trustsMap;
    private Map<String,Fundlist> fundMap;
    private Fundlist fund;
    private Toolbar toolbar;
    private CheckBox warningCheckBox,termsNConLinkCheckBox;
    private DateFormat formatter;

    private final ProgressDialog progressDialog;

    public UnitTrustTradeDialog(@NonNull Context context, Bundle bundle) {
        super(context);
        setContentView(R.layout.unit_trust_trade_dialog);
        cds_number = bundle.getString("cds_number");
        orderType = bundle.getString("orderType");
        fund = bundle.getParcelable("fundlist");
        progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);

        Utils utils = new Utils(getOwnerActivity());

        formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("UNIT TRUST ORDER".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        termsNConLinkCheckBox = findViewById(R.id.confirm_tsncs);
        fundTsncsLink = findViewById(R.id.tsncs_link);
        fundTsncsLink.setOnClickListener(
                view -> {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.COMPLETE_URL("pdf/unittrust/omut/tsncs")));
                    getContext().startActivity(browserIntent);
                }
        );

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        initWidgets();
        setUpWidgets();

    }

    private void setUpWidgets() {
        orderTypeEt.setText(orderType);
        orderTypeEt.setEnabled(false);
        warningRl.setVisibility(View.GONE);

        if(!orderType.equalsIgnoreCase(getContext().getString(R.string.investtrusts))){
            amountEt.setHint("Enter Quantity (Units)");
        }
        selectTrustSP.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                getFunds(trustsMap.get(selectTrustSP.getSelectedItem().toString()));
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        selectFundSP.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Fundlist fundlist = fundMap.get(selectFundSP.getSelectedItem().toString());
                String fundDescription = String.format("Indicative Unit Price ZWL%s As Per %s",fundlist.getIssuePricePerUnit(),fundlist.getIssueDate());
                fundDescriptionTv.setText(fundDescription);
                fund = fundlist;
                if(fundlist.getInEvaluation()){
                    findViewById(R.id.btnPost).setVisibility(View.GONE);
                    warningRl.setVisibility(View.VISIBLE);
                    String fundWarning = String.format("This Fund Is In Evaluation From %s to %s Please tick The Check Box To Proceed.",fundlist.getEvaluationFrom(),fundlist.getEvaluationTo());
                    fundWarningTv.setText(fundWarning);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        warningCheckBox.setOnCheckedChangeListener((compoundButton, b) -> {
            if(b)findViewById(R.id.btnPost).setVisibility(View.VISIBLE);
            else findViewById(R.id.btnPost).setVisibility(View.GONE);
        });
        if(fund != null){
            selectTrustSP.setVisibility(View.GONE);
            findViewById(R.id.selectTrustTxt).setVisibility(View.GONE);
            findViewById(R.id.selectFundTxt).setVisibility(View.INVISIBLE);
            List<String> fullnames = new ArrayList<>();
            fullnames.add(fund.getCompany());
            fundMap = new HashMap<>();
            fundMap.put(fund.getCompany(),fund);

            selectFundSP.setAdapter(new ArrayAdapter<>(getContext(), R.layout.spinner_item, fullnames));
        }
        else getTrusts();
        findViewById(R.id.btnPost).setOnClickListener(view -> {
            if(termsNConLinkCheckBox.isChecked()){
                postOrder();
            }else{
                Toast.makeText(getContext(),"Please Accept Terms And Conditions!",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initWidgets() {
        amountEt = findViewById(R.id.etOrderAmount);
        sourceEt = findViewById(R.id.etOrderSourceOfFunds);
        reasonEt =  findViewById(R.id.etReasonOfInvestment);
        orderTypeEt = findViewById(R.id.etOrderType);

        selectFundSP = findViewById(R.id.selectFund);
        selectTrustSP = findViewById(R.id.selectTrust);

        warningRl = findViewById(R.id.fund_warning_layout);
        warningCheckBox = findViewById(R.id.confirm_post_cb);
        fundDescriptionTv = findViewById(R.id.fund_description_txt);
        fundWarningTv = findViewById(R.id.revaluation_desc);
    }
    private void getFunds(String trust) {

        JSONObject jsonObject = new JSONObject();
        try{
            jsonObject.put("company",trust);
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(
                Request.Method.POST,
                Constants.COMPLETE_URL("data/unit_trusts/funds"),
                jsonObject,
                response -> {
                    try {
                        List<Fundlist> fundlists = new ArrayList<>();
                        for (int i = 0; i < response.length(); i++) {

                            JSONObject j = response.getJSONObject(i);
                            Fundlist fundlist = new Fundlist();
                            fundlist.setID(j.getInt("id"));
                            fundlist.setCompany(j.getString("company"));
                            fundlist.setFundType(j.getString("securityType"));
                            fundlist.setEvaluationFrom(j.getString("dateFrom"));
                            fundlist.setEvaluationTo(j.getString("dateTo"));
                            fundlist.setInitialPrice(j.getDouble("initialPrice"));
                            fundlist.setIssueDate(j.getString("dateFrom"));
                            fundlist.setIssuePricePerUnit(j.getDouble("initialPrice"));
                            fundlist.setInEvaluation(j.getBoolean("inEvaluation"));
                            fundlists.add(fundlist);

                        }
                        List<String> fullnames = new ArrayList<>();

                        fundMap = new HashMap<>();
                        for (Fundlist fundlist : fundlists) {
                            Log.d("lloda", "onResponse: " + fundlist.getCompany());
                            fullnames.add(fundlist.getCompany());
                            fundMap.put(fundlist.getCompany(), fundlist);
                        }

                        selectFundSP.setAdapter(new ArrayAdapter<>(getContext(), R.layout.spinner_item, fullnames));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },

                error -> {
            error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    private void getTrusts() {
        StringRequest jsonObjRequest1 =
                new StringRequest(Request.Method.POST, Constants.COMPLETE_URL("data/unit_trusts"),
                         response -> {

                             try {
                                 System.out.println(response);

                                 if (response.equals(getContext().getString(R.string.no_data_was_found))) {
                                     // showDialog(getString(R.string.no_data_was_found));
                                 } else {

                                     try {

                                         JSONArray jsonArray = new JSONArray(response);
                                         trustsMap = new HashMap<>();
                                         List<String> trustFullNames = new ArrayList<>();

                                         if (jsonArray.length() > 0) {

                                             Log.d("Json array size ", " is " + jsonArray.length());

                                             for (int i = 0; i < jsonArray.length(); i++) {
                                                 JSONObject jsonObject = jsonArray.getJSONObject(i);
                                                 System.out.println("Json object " + jsonObject);

                                                 String fullname = jsonObject.optString("fullName");
                                                 String company = jsonObject.optString("company");

                                                 trustsMap.put(fullname,company);
                                                 trustFullNames.add(fullname);

                                             }

                                             selectTrustSP.setAdapter(new ArrayAdapter<>(getContext(), R.layout.spinner_item, trustFullNames));


                                         } else {
                                             //    showDialog(getString(R.string.no_data_was_found));
                                         }
                                     } catch (JSONException e) {
                                         e.printStackTrace();
                                         // showDialog(getString(R.string.no_data_was_found));
                                     }
                                 }

                             } catch (Exception e) {
                                 e.printStackTrace();
                             }
                         },
                        error -> {

                        }) {
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<>();
                        params.put("type", "ut");
                        return params;
                    }
                };

        jsonObjRequest1.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest1);
    }

    private void postOrder(){
        String selectedOption = orderTypeEt.getText().toString();
        double units = 0;
        double value = 0;
        String orderType;

        try{
            value = Double.parseDouble(amountEt.getText().toString());
        }catch (Exception e){
            amountEt.setError("Enter A Valid Amount");
            return;
        }





        if(sourceEt.getText().toString().equalsIgnoreCase("")){
            sourceEt.setError("Enter Your Source Of Funds");
            return;
        }else if(reasonEt.getText().toString().equalsIgnoreCase("")){
            reasonEt.setError("Enter The Reason For Investment");

        }
        else if (selectedOption.equals("") || selectedOption.equals("0") || selectedOption.length() == 0){
            orderTypeEt.setError("Please select option");
        }
        else {

            progressDialog.setTitle("Posting..");
            progressDialog.setMessage("Please wait ");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.show();

            if (selectedOption.equals(getContext().getString(R.string.investtrusts))) {
                units = value / fund.getInitialPrice();
                orderType = "BUY";
            } else {
                value = value  * fund.getInitialPrice();
                units = value;
                orderType = "Sell";
            }

            JSONObject jsonObject = new JSONObject();
            try{

                jsonObject.put("company",fund.getCompany());
                jsonObject.put("orderType",orderType);
                jsonObject.put("quantity",units);
                jsonObject.put("value",value);
                jsonObject.put("price",fund.getInitialPrice());
                jsonObject.put("cdsNumber",cds_number);
                jsonObject.put("reason",reasonEt.getText().toString());
                jsonObject.put("sourceOfFunds",sourceEt.getText().toString());
                jsonObject.put("source","ANDROID");
                //reasonEt.getText().toString(),sourceEt.getText().toString()
            }catch (Exception e){
                e.printStackTrace();
                progressDialog.dismiss();
            }

            Log.d("jo",jsonObject.toString());
            JsonObjectRequest jr = new JsonObjectRequest(Constants.COMPLETE_URL("trade/unit_trust/new/order"),jsonObject,
                    response -> {
                        try {
                            progressDialog.dismiss();
                            AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                                    .setTitle(R.string.result)
                                    .setCancelable(false)
                                    .setMessage(response.getString("message"))
                                    //.setMessage(R.string.order_posting_successful)
                                    .setPositiveButton("OK", (dialog, which) -> {
                                                //startActivity(new Intent(getContext(), TradeNowActivity.class));
                                                //finish();
                                                dismiss();
                                            }
                                    ).create();

                            alertDialog.setOnShowListener(dialogInterface -> {
                                alertDialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getContext().getResources().getColor(R.color.colorAccent));
                                alertDialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(getContext().getResources().getColor(R.color.white));
                            });
                            alertDialog.show();
                        }catch (Exception e){
                            progressDialog.dismiss();
                            e.printStackTrace();
                        }

                    },error -> {
                progressDialog.dismiss();
                error.printStackTrace();
            });
            AppConfig.getInstance().addToRequestQueue(jr);
        }

    }
}
