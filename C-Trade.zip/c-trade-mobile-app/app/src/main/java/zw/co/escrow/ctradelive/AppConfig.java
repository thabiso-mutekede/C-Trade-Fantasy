package zw.co.escrow.ctradelive;

import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import androidx.multidex.MultiDexApplication;


public class AppConfig extends MultiDexApplication {


    public AppConfig() {

    }

    public static final int REASONABLE_RETRY_MS = 100000;

    public static String getMobileApiAddress() {
        return Constants.APP_BASE_URL;
    }

    public static String getFullMobileApiAddress() {
        return Constants.APP_BASE_FULL_URL;
    }

    public static String getIpDemo() {
        return Constants.APP_BASE_FULL_URL;
    }

    public static String getApiV2() {
        return Constants.APP_BASE_FULL_URL;
    }

    public static String getIpAddress() {
        return Constants.APP_BASE_URL;
    }

    public static String getIp() {
        return Constants.APP_BASE_FULL_URL;
    }


    String regCds, regEmail, regFullName;

    public String getRegCds() {
        return regCds;
    }

    public void setRegCds(String regCds) {
        this.regCds = regCds;
    }

    public String getRegEmail() {
        return regEmail;
    }

    public void setRegEmail(String regEmail) {
        this.regEmail = regEmail;
    }

    public String getRegFullName() {
        return regFullName;
    }

    public void setRegFullName(String regFillName) {
        this.regFullName = regFillName;
    }

    String name;
    String broker;
    String cdsNumber;
    boolean isLoggedIn;

    String id;
    String username;
    String email;

    String currentPrice;

    public String getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    ArrayList<String> all_subs = new ArrayList<>();
    ArrayList<String> my_subs = new ArrayList<>();

    ArrayList<String> addSubs = new ArrayList<>();
    ArrayList<String> remSubs = new ArrayList<>();

    public ArrayList<String> getAll_subs() {
        return all_subs;
    }

    public void setAll_subs(ArrayList<String> all_subs) {
        this.all_subs = all_subs;
    }

    public ArrayList<String> getMy_subs() {
        return my_subs;
    }

    public void setMy_subs(ArrayList<String> my_subs) {
        this.my_subs = my_subs;
    }

    public ArrayList<String> getAddSubs() {
        return addSubs;
    }

    public void setAddSubs(ArrayList<String> addSubs) {
        this.addSubs = addSubs;
    }

    public ArrayList<String> getRemSubs() {
        return remSubs;
    }

    public void setRemSubs(ArrayList<String> remSubs) {
        this.remSubs = remSubs;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBroker() {
        return broker;
    }

    public void setBroker(String broker) {
        this.broker = broker;
    }

    public String getCdsNumber() {
        return cdsNumber;
    }

    public void setCdsNumber(String cdsNumber) {
        this.cdsNumber = cdsNumber;
    }


    public static final String TAG = AppConfig.class.getSimpleName();

    private RequestQueue mRequestQueue;

    private static AppConfig mInstance;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }

    public static synchronized AppConfig getInstance() {
        return mInstance;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }

    public <T> void addToRequestQueue(Request<T> req) {
        req.setTag(TAG);
        getRequestQueue().add(req);
    }

    public void cancelPendingRequests(Object tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }
}
