package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class MarketWatchZSE implements Parcelable {

    private int id;
    private String Ticker, ISIN, FullCompanyName;
    private double Best_Ask, Best_bid, Current_price, Ask_Volume, Bid_Volume, PrevPrice, PrevPer, PrevChange;

    public MarketWatchZSE() {
    }

    public MarketWatchZSE(int id, String ticker, String ISIN, String fullCompanyName, double bestAsk, double Best_bid, double Current_price, double Ask_Volume, double Bid_Volume, double PrevPrice, double PrevPer, double PrevChange) {
        this.id = id;
        this.Ticker = ticker;
        this.ISIN = ISIN;
        this.FullCompanyName = fullCompanyName;
        this.Best_Ask = bestAsk;
        this.Best_bid = Best_bid;
        this.Current_price = Current_price;
        this.Ask_Volume = Ask_Volume;
        this.Bid_Volume = Bid_Volume;
        this.PrevPrice = PrevPrice;
        this.PrevPer = PrevPer;
        this.PrevChange = PrevChange;
    }

    public MarketWatchZSE(MarketWatchZSE marketWatchZSE) {
        this.id = marketWatchZSE.getId();
        this.Ticker = marketWatchZSE.getTicker();
        this.ISIN = marketWatchZSE.getISIN();
        this.FullCompanyName = marketWatchZSE.getFullCompanyName();
        this.Best_Ask = marketWatchZSE.getBest_Ask();
        this.Best_bid = marketWatchZSE.getBest_bid();
        this.Current_price = marketWatchZSE.getCurrent_price();
        this.Ask_Volume = marketWatchZSE.getAsk_Volume();
        this.Bid_Volume = marketWatchZSE.getBid_Volume();
        this.PrevPrice = marketWatchZSE.getPrevPrice();
        this.PrevPer = marketWatchZSE.getPrevPer();
        this.PrevChange = marketWatchZSE.getPrevChange();
    }


    protected MarketWatchZSE(Parcel in) {
        Ticker = in.readString();
        ISIN = in.readString();
        FullCompanyName = in.readString();
        Best_Ask = in.readDouble();
        Best_bid = in.readDouble();
        Current_price = in.readDouble();
        Ask_Volume = in.readDouble();
        Bid_Volume = in.readDouble();
        PrevPrice = in.readDouble();
        PrevPer = in.readDouble();
        PrevChange = in.readDouble();
        id = in.readInt();
    }

    public static final Creator<MarketWatchZSE> CREATOR = new Creator<MarketWatchZSE>() {
        @Override
        public MarketWatchZSE createFromParcel(Parcel in) {
            return new MarketWatchZSE(in);
        }

        @Override
        public MarketWatchZSE[] newArray(int size) {
            return new MarketWatchZSE[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTicker() {
        return Ticker;
    }

    public void setTicker(String ticker) {
        this.Ticker = ticker;
    }

    public String getISIN() {
        return ISIN;
    }

    public void setISIN(String ISIN) {
        this.ISIN = ISIN;
    }

    public String getFullCompanyName() {
        return FullCompanyName;
    }

    public void setFullCompanyName(String fullCompanyName) {
        this.FullCompanyName = fullCompanyName;
    }

    public double getBest_Ask() {
        return Best_Ask;
    }

    public void setBest_Ask(double best_Ask) {
        this.Best_Ask = best_Ask;
    }

    public double getBest_bid() {
        return Best_bid;
    }

    public void setBest_bid(double best_bid) {
        this.Best_bid = best_bid;
    }

    public double getCurrent_price() {
        return Current_price;
    }

    public void setCurrent_price(double current_price) {
        this.Current_price = current_price;
    }

    public double getAsk_Volume() {
        return Ask_Volume;
    }

    public void setAsk_Volume(double ask_Volume) {
        this.Ask_Volume = ask_Volume;
    }

    public double getBid_Volume() {
        return Bid_Volume;
    }

    public void setBid_Volume(double bid_Volume) {
        this.Bid_Volume = bid_Volume;
    }

    public double getPrevPrice() {
        return PrevPrice;
    }

    public void setPrevPrice(double prevPrice) {
        this.PrevPrice = prevPrice;
    }

    public double getPrevPer() {
        return PrevPer;
    }

    public void setPrevPer(double prevPer) {
        this.PrevPer = prevPer;
    }

    public double getPrevChange() {
        return PrevChange;
    }

    public void setPrevChange(double prevChange) {
        this.PrevChange = prevChange;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

        parcel.writeString(Ticker);
        parcel.writeString(ISIN);
        parcel.writeString(FullCompanyName);

        parcel.writeDouble(Best_Ask);
        parcel.writeDouble(Best_bid);
        parcel.writeDouble(Current_price);
        parcel.writeDouble(Ask_Volume);
        parcel.writeDouble(Bid_Volume);

        parcel.writeDouble(PrevPrice);
        parcel.writeDouble(PrevPer);
        parcel.writeDouble(PrevChange);
        parcel.writeInt(id);
    }



}
