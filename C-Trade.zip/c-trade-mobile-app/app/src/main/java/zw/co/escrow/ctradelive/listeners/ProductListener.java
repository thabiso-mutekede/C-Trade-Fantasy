package zw.co.escrow.ctradelive.listeners;

public interface ProductListener {
    void productChanged(String product);
}
