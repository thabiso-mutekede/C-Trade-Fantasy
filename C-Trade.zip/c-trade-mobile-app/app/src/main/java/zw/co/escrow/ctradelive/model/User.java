package zw.co.escrow.ctradelive.model;

public class User {
    public User() {
    }

    private String BrokerCode;
    private String Surname;
    private String Forenames;
    private String Title;
    private String Nationality;
    private String Add_1;
    private String Country;
    private String Mobile;
    private String Email;
    private String Custodian;
    private String CashBank;
    private String Cash_Branch;
    private String Cash_AccountNo;
    private String idnopp;
    private String mobile_number;
    private String CDS_Number;
    private String min_value_threshold;

    public String getBrokerCode() {
        return BrokerCode;
    }

    public void setBrokerCode(String brokerCode) {
        BrokerCode = brokerCode;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public String getForenames() {
        return Forenames;
    }

    public void setForenames(String forenames) {
        Forenames = forenames;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getNationality() {
        return Nationality;
    }

    public void setNationality(String nationality) {
        Nationality = nationality;
    }

    public String getAdd_1() {
        return Add_1;
    }

    public void setAdd_1(String add_1) {
        Add_1 = add_1;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getCustodian() {
        return Custodian;
    }

    public void setCustodian(String custodian) {
        Custodian = custodian;
    }

    public String getCashBank() {
        return CashBank;
    }

    public void setCashBank(String cashBank) {
        CashBank = cashBank;
    }

    public String getCash_Branch() {
        return Cash_Branch;
    }

    public void setCash_Branch(String cash_Branch) {
        Cash_Branch = cash_Branch;
    }

    public String getCash_AccountNo() {
        return Cash_AccountNo;
    }

    public void setCash_AccountNo(String cash_AccountNo) {
        Cash_AccountNo = cash_AccountNo;
    }

    public String getIdnopp() {
        return idnopp;
    }

    public void setIdnopp(String idnopp) {
        this.idnopp = idnopp;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getCDS_Number() {
        return CDS_Number;
    }

    public void setCDS_Number(String CDS_Number) {
        this.CDS_Number = CDS_Number;
    }

    public String getMin_value_threshold() {
        return min_value_threshold;
    }

    public void setMin_value_threshold(String min_value_threshold) {
        this.min_value_threshold = min_value_threshold;
    }
}
