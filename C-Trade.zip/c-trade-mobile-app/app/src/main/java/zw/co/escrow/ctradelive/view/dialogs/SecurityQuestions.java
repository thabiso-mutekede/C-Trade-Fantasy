package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONObject;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;

public class SecurityQuestions extends Dialog {
    private TextInputEditText book,road,name,otp;
    private TextInputLayout otp_lay;
    private TextView otpTV;
    private Button secBtn;
    private ProgressDialog progressDialog;
    private boolean isOtp = false;
    private Toolbar toolbar;
    private Complete complete;


    public SecurityQuestions(@NonNull Context context, String cdsNumber, Boolean isProfileUpdate, @Nullable JSONObject jos) {
        super(context);
        setContentView(R.layout.dialog_security_questions);
        progressDialog = new ProgressDialog(context);
        secBtn = findViewById(R.id.btnPost);
        road = findViewById(R.id.road_name_e_txt);
        book = findViewById(R.id.book_e_txt);
        name = findViewById(R.id.maiden_e_txt);
        otp = findViewById(R.id.otp_e_txt);
        otp_lay = findViewById(R.id.otp_e_txt_l);
        otpTV = findViewById(R.id.otp_e_txt_view);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        if(isProfileUpdate){
            secBtn.setText("confirm");
        }

        otp.setVisibility(View.GONE);
        otp_lay.setVisibility(View.GONE);
        otpTV.setVisibility(View.GONE);

        secBtn.setOnClickListener(view -> {

            JSONObject jo = new JSONObject();

            try{
                jo.put("cdsNumber",cdsNumber);
                jo.put("motherMaidenName",name.getText().toString());
                jo.put("road",road.getText().toString());
                jo.put("bookRead",book.getText().toString());

                if(isProfileUpdate){
                    jos.put("securityQuestions",jo);
                    complete.go(jos);
                }else {
                    if(isOtp){
                        complete.otp(otp.getText().toString(),this);
                    } else {
                        send(jo);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        });

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);

    }
    private void send(JSONObject jo){
        progressDialog.setMessage("Updating Security Questions...");
        progressDialog.show();
        Log.d("jo",jo.toString());
        JsonObjectRequest jr = new JsonObjectRequest(
                Constants.COMPLETE_URL("client/sq/update"),
                jo,
                response -> {
                    try {
                        progressDialog.dismiss();
                        if(response.getBoolean("status")){
                            otp.setVisibility(View.VISIBLE);
                            otp_lay.setVisibility(View.VISIBLE);
                            otpTV.setVisibility(View.VISIBLE);

                            isOtp = true;
                            secBtn.setText("Confirm");

                        }
                        Constants.showDialog(getContext(),response.getString("message"));
                    }catch (Exception e){
                        progressDialog.dismiss();
                        e.printStackTrace();
                        Constants.showDialog(getContext(),
                                "Failed To Read Data.");
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    error.printStackTrace();
                    Constants.showDialog(getContext(), Constants.ERROR_MESSAGE);
                }){
            @Override
            public RetryPolicy getRetryPolicy() {
                return new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 500000;
                    }
                    @Override
                    public int getCurrentRetryCount() {
                        return 0;
                    }
                    @Override
                    public void retry(VolleyError error) throws VolleyError {

                    }
                };
            }
        };

        AppConfig.getInstance().addToRequestQueue(jr);
    }
    public interface Complete{
        void go(JSONObject jsonObject);
        void otp(String otp,Dialog dialog);
    }

    public void setComplete(Complete complete) {
        this.complete = complete;
    }
}
