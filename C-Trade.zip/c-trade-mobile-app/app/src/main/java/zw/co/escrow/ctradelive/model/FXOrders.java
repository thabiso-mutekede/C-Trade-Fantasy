package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class FXOrders implements Parcelable {

    private String amount;
    private String preferredRate;
    private String auctionId;
    private String AvgRate;
    private String purpose;
    private String datePosted;
    private String TransType;
    private String state;

    protected FXOrders(Parcel in) {
        amount = in.readString();
        preferredRate = in.readString();
        auctionId = in.readString();
        AvgRate = in.readString();
        purpose = in.readString();
        datePosted = in.readString();
        TransType = in.readString();
        state = in.readString();
    }

    public static final Creator<FXOrders> CREATOR = new Creator<FXOrders>() {
        @Override
        public FXOrders createFromParcel(Parcel in) {
            return new FXOrders(in);
        }

        @Override
        public FXOrders[] newArray(int size) {
            return new FXOrders[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(amount);
        parcel.writeString(preferredRate);
        parcel.writeString(auctionId);
        parcel.writeString(AvgRate);
        parcel.writeString(purpose);
        parcel.writeString(datePosted);
        parcel.writeString(TransType);
        parcel.writeString(state);
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPreferredRate() {
        return preferredRate;
    }

    public void setPreferredRate(String preferredRate) {
        this.preferredRate = preferredRate;
    }

    public String getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(String auctionId) {
        this.auctionId = auctionId;
    }

    public String getAvgRate() {
        return AvgRate;
    }

    public void setAvgRate(String avgRate) {
        AvgRate = avgRate;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getDatePosted() {
        return datePosted;
    }

    public void setDatePosted(String datePosted) {
        this.datePosted = datePosted;
    }

    public String getTransType() {
        return TransType;
    }

    public void setTransType(String transType) {
        TransType = transType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
