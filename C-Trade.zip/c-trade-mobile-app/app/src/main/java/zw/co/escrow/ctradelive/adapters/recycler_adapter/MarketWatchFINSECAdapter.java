package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.MarketWatchFINSEC;
import zw.co.escrow.ctradelive.view.CompanyAnalysisActivity;

public class MarketWatchFINSECAdapter extends RecyclerView.Adapter<MarketWatchFINSECAdapter.WatchListViewHolder> {

    private final List<MarketWatchFINSEC> marketWatchFINSEC;
    private Activity activity;
    private final ClubModel clubModel;
    private SharedPreferences sharedPreferences;

    public MarketWatchFINSECAdapter(Activity activity, List<MarketWatchFINSEC> marketWatchFINSEC, ClubModel clubModel) {
        this.marketWatchFINSEC = marketWatchFINSEC;
        this.activity = activity;
        this.clubModel = clubModel;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.watch_list_adapter_view;
    }

    @NonNull
    @Override
    public WatchListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);

        /*sharedPreferences = activity.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
            intent.putExtra("cdsnumber",sharedPreferences.getString("cds_number",""));
            if(clubModel != null){
                intent.putExtra("isClub",true);
                intent.putExtra("club",clubModel);
            }*/

        return new WatchListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WatchListViewHolder holder, int position) {

        holder.txtTicker.setText(marketWatchFINSEC.get(position).getMarket_company());
        holder.txtCompanyName.setText(marketWatchFINSEC.get(position).getFullCompanyName());
        holder.txtBestBid.setText(String.format("BEST BID: %s", marketWatchFINSEC.get(position).getMarket_bp()));
        holder.txtBestAsk.setText(String.format("BEST ASK: %s", marketWatchFINSEC.get(position).getMarket_ap()));
        holder.txtCurrentPrice.setText(String.valueOf(marketWatchFINSEC.get(position).getMarket_vwap()));

        holder.txtPercentageChange.setText(String.format("%s%%", marketWatchFINSEC.get(position).getMarket_per_change()));

        if (marketWatchFINSEC.get(position).getMarket_per_change() > 0){
            holder.cardView.setCardBackgroundColor(activity.getResources().getColor(R.color.colorDarkGreen));

        }
        holder.cardViewCompany.setOnClickListener(view -> {

            Intent intent = new Intent(activity, CompanyAnalysisActivity.class);

            intent.putExtra("FINSEC", marketWatchFINSEC.get(position));
            sharedPreferences = activity.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
            intent.putExtra("cdsnumber",sharedPreferences.getString("cds_number",""));
            if(clubModel != null){
                intent.putExtra("isClub",true);
                intent.putExtra("club",clubModel);
            }

            activity.startActivity(intent);

        });


    }

    @Override
    public int getItemCount() {
        return marketWatchFINSEC.size();
    }

    static class WatchListViewHolder extends RecyclerView.ViewHolder{

        private TextView txtTicker, txtCompanyName, txtBestBid, txtBestAsk, txtCurrentPrice, txtPercentageChange;
        private CardView cardView, cardViewCompany;

        public WatchListViewHolder(@NonNull View itemView) {
            super(itemView);

            txtTicker = itemView.findViewById(R.id.txtTicker);
            txtCompanyName = itemView.findViewById(R.id.txtCompanyName);
            txtBestBid = itemView.findViewById(R.id.txtBestBid);
            txtBestAsk = itemView.findViewById(R.id.txtBestAsk);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtPercentageChange = itemView.findViewById(R.id.txtPercentageChange);
            cardView = itemView.findViewById(R.id.wl_change_indicator);
            cardViewCompany = itemView.findViewById(R.id.cardViewCompany);


        }
    }
}