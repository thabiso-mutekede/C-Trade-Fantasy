package zw.co.escrow.ctradelive;

/**
 * Created by tinah on 8/11/2017.
 */

public class App {

    private int mDrawable;
    private String mName;
    private String cate;
    private String allLists;
    private String mRating;
    private String Desc;

    public App(String name,
               String catex,
               String dsc,
               int drawable,
               String rating,
               String My_Lists) {
        mName = name;
        cate = catex;
        mDrawable = drawable;
        mRating = rating;
        Desc = dsc;
        allLists = My_Lists;
    }

    public String getRating() {
        return mRating;
    }

    public int getDrawable() {
        return mDrawable;
    }

    public String getName() {
        return mName;
    }

    public String getCate() {
        return cate;
    }

    public String getAllLists() {
        return allLists;
    }

    public String getDesc() {
        return Desc;
    }
}