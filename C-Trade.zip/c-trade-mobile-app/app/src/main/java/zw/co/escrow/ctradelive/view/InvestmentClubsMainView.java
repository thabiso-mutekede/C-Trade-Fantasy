package zw.co.escrow.ctradelive.view;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.toolbox.JsonObjectRequest;
import com.github.ybq.android.spinkit.style.MultiplePulseRing;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomappbar.BottomAppBar;
import com.mikepenz.materialdrawer.holder.StringHolder;
import com.mikepenz.materialdrawer.widget.AccountHeaderView;
import com.mikepenz.materialdrawer.widget.MaterialDrawerSliderView;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import org.json.JSONObject;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;
import zw.co.escrow.ctradelive.view.dialogs.CreateClubDialog;
import zw.co.escrow.ctradelive.view.fragments.MarketWatchFINSECFragment;
import zw.co.escrow.ctradelive.view.fragments.MarketWatchZSEFragment;

public class InvestmentClubsMainView extends AppCompatActivity implements View.OnClickListener , CreateClubDialog.OnSubmitListener {

    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    private MaterialDrawerSliderView cTradeDrawerSlider;
    private RelativeLayout viewsLayout;
    private CoordinatorLayout dashboard_menu;
    private AppBarLayout appBarLayout;
    private BottomAppBar bottomAppBar;
    private AccountHeaderView c_tradeDrawerHeader;
    private static final String TAG = "MainActivity";

    private CreateClubDialog createClubDialog;

    private String cds_number;
    private String phone_number;
    private String email;

    private TextView txtUnclearedCash,txtClearedCash, txtCashBalance, txtMyPortfolio, txtTotalAccount, txtNetPerfomance, txtForexWallerBalance, txtOutStandingCharges;
    private String cdsNumber;
    private SharedPreferences sharedPreferences;

    private ProgressBar loadingSpinner;
    private MultiplePulseRing multiplePulseRing;
    private Toolbar toolbar;
    private SharedPreferences preferences;

    private InvestmentClub.ClubServicesListener clubServicesListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.investment_clubs_main_view);
        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(InvestmentClubsMainView.this);
        initWidgets();

        clubServicesListener = new InvestmentClubService(this);

        clubServicesListener = new InvestmentClubService(this);


        createClubDialog = new CreateClubDialog(this);
        createClubDialog.setOnSubmitListener(this);
        findViewById(R.id.chipMyClubs).setOnClickListener(this);
        findViewById(R.id.investment_chip).setOnClickListener(this);
        findViewById(R.id.contribution_chip).setOnClickListener(this);
        findViewById(R.id.chipCreate).setOnClickListener(this);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Investment Clubs".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v ->{
            startActivity(
                    new Intent(this,MainActivity.class)
            );
            finish();

        });
        sharedPreferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = sharedPreferences.getString("cds_number", "");

        preferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = preferences.getString("cds_number", "");
        cds_number = preferences.getString("cds_number", "");
        email = preferences.getString("email","");


        clubServicesListener.onLoadRequest(cdsNumber,"i","","");
        //clubServicesListener.onLoadRequest(cdsNumber,"","URC",email);

        //Read my cash and populate the view if cds number is not empty
        if (!cdsNumber.equals("")){
            JsonObjectRequest jr = new JsonObjectRequest(
                    Constants.COMPLETE_URL("account/cash"),
                    Constants.cdsNumberJSON(cdsNumber),
                    response -> {

                        try {
                            loadingSpinner.setVisibility(View.GONE);
                            appBarLayout.setVisibility(View.VISIBLE);
                            watchListPagerTab.setVisibility(View.VISIBLE);
                            watchListPager.setVisibility(View.VISIBLE);
                            bottomAppBar.setVisibility(View.VISIBLE);
                            txtUnclearedCash.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("virtualCashBal")))))));
                            txtClearedCash.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("actualCashBal")))))));
                            txtCashBalance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("actualCashBal")))))));
                            txtMyPortfolio.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("potValue")))))));
                            txtTotalAccount.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("totalAccount")))))));
                            txtNetPerfomance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("profitLoss")))))));
                            //txtForexWallerBalance.setText(String.format("$ %s","0.00"));
                            txtForexWallerBalance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("forexBalance")))))));
                        }catch (Exception e){
                            e.printStackTrace();
                        }

                    },
                    error -> {

                        error.printStackTrace();
                    }

            );
            AppConfig.getInstance().addToRequestQueue(jr);
        }
        else {
            loadingSpinner.setVisibility(View.GONE);
            appBarLayout.setVisibility(View.VISIBLE);
            watchListPagerTab.setVisibility(View.VISIBLE);
            watchListPager.setVisibility(View.VISIBLE);
            bottomAppBar.setVisibility(View.VISIBLE);
        }

        setUpWatchList();
        setUpView();
    }

    private void initWidgets(){

        dashboard_menu = findViewById(R.id.dashboard_menu);
        appBarLayout = findViewById(R.id.appbar);
        bottomAppBar = findViewById(R.id.bottom_app_bar);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPager = findViewById(R.id.viewPagerWatchList);

        txtUnclearedCash = findViewById(R.id.txtUnclearedCashFantasy);
        txtClearedCash = findViewById(R.id.txtClearedCashFantasy);
        txtCashBalance = findViewById(R.id.txtCashBalanceFantasy);
        txtMyPortfolio = findViewById(R.id.txtMyPortfolioFantasy);
        txtTotalAccount = findViewById(R.id.txtTotalAccountFantasy);
        txtNetPerfomance = findViewById(R.id.txtNetPerfomance);
        txtForexWallerBalance = findViewById(R.id.txtForexWallerBalance);
        txtOutStandingCharges = findViewById(R.id.txtOutStandingCharges);
        loadingSpinner = findViewById(R.id.loadingSpinner);
        multiplePulseRing = new MultiplePulseRing();
        loadingSpinner.setIndeterminateDrawable(multiplePulseRing);
        loadingSpinner.setVisibility(View.VISIBLE);
    }

    private void setUpWatchList(){

        Bundle bundle = new Bundle();

        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("ZSE", MarketWatchZSEFragment.class,bundle)
                .add("FINSEC", MarketWatchFINSECFragment.class,bundle)
                .create());
        watchListPager.setAdapter(watchListPagerAdapter);
        watchListPagerTab.setViewPager(watchListPager);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.chipCreate:
                createClubDialog.show();
                break;
            case R.id.contribution_chip:
                clubServicesListener.onLoadMyContribution(cds_number,null,null);
                break;

            case R.id.investment_chip:
                //TODO first check if user is logged on
                clubServicesListener.onLoadInvestments("b",false,null,null);
                break;

            case R.id.chipSell:

                //TODO first check if user is logged on
                if (cdsNumber.equals("")) {

                    startActivity(new Intent(this, LoginActivity2.class));
                    finish();

                }
                else {
                    Toast.makeText(this, "Sell dialog to be shown here", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.chipDeposit:
                startActivity(new Intent(this, DepositActivity.class));
                break;

            case R.id.chipWithdraw:
                startActivityForResult(new Intent(this, WithdrawActivity.class), Constants.WITHDRAW_REQUEST_CODE);
                break;
            case R.id.chipNews:
                startActivityForResult(new Intent(this, ConvertActivity.class), Constants.CONVERT_REQUEST_CODE);
                break;

            case R.id.chipMyClubs:
                startActivity(new Intent(this, MyInvestmentClubsView.class));
                break;
        }

    }

    private StringHolder setTitle(String title){
        return new StringHolder(title);
    }

    private void setUpView(){
        //viewsLayout.setVisibility(View.GONE);
        //c_tradeMainDashboard.setVisibility(View.VISIBLE);

    }

    @Override
    public void createGroup(String groupName, String welcomeMessage, Boolean isPublic, Dialog dialog) {
        dialog.dismiss();
        JSONObject jo = new JSONObject();
        try {
            jo.put("name",groupName);
            jo.put("phone",phone_number);
            jo.put("cdsNumber",cds_number);
            jo.put("welcomeMessage",welcomeMessage);
            jo.put("isPublic",isPublic);
            jo.put("email",email);
        }catch (Exception e){

        }
        JsonObjectRequest jr = new JsonObjectRequest(
                Constants.COMPLETE_URL("clubs/create"),
                jo,
                response -> {
                    try{
                            boolean b = response.getBoolean("status");
                            if(b){
                                new android.app.AlertDialog.Builder(InvestmentClubsMainView.this)
                                        .setMessage(response.getString("message"))
                                        .setPositiveButton("ok",null)
                                        .create()
                                        .show();
                            }else{
                                showDialog(response.getString("message"));
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                            showDialog("Failed To Read Data.Please Try Again Later");
                        }

                },
                error -> {
                    error.printStackTrace();
                }
        );
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    private void showDialog(String message){
        new android.app.AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("ok",null)
                .create()
                .show();
    }
}