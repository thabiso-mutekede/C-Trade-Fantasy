package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.RequestModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;


public class RequestAdapter extends RecyclerView.Adapter {
    private String cds_number;
    private String phone_number;
    private String email;
    private final String club_cdsNumber;
    private final InvestmentClub.ClubServicesListener clubServicesListener;
    private final InvestmentClub.ICRefreshRefreshLister refreshRefreshLister;
    private final List<RequestModel> requestModelList;
    private final Context context;
    private final RecyclerView recyclerView;
    private SharedPreferences preferences;
    public RequestAdapter(String club_cdsNumber, InvestmentClub.ICRefreshRefreshLister refreshRefreshLister, List<RequestModel> requestModelList, Context context, RecyclerView recyclerView) {
        this.club_cdsNumber = club_cdsNumber;
        this.refreshRefreshLister = refreshRefreshLister;
        this.requestModelList = requestModelList;
        this.context = context;
        this.recyclerView = recyclerView;
        preferences = context.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        clubServicesListener = new InvestmentClubService(context);
        ((InvestmentClubService)clubServicesListener).setIcRefreshRefreshLister(refreshRefreshLister);
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.ctrade_universal_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(viewType,parent,false);

        view.setOnClickListener(v -> {
            RequestModel c = requestModelList.get(recyclerView.getChildLayoutPosition(view));
            showSendDialog(c);
        });
        return new RequestViewHolder(view);
    }
    private void showSendDialog(RequestModel requestModel){
        cds_number = preferences.getString("cds_number", "");
        email = preferences.getString("email","");
        phone_number = preferences.getString("club_phone", "");

        String msg = "Accept Request For "+requestModel.getClubname();
        new AlertDialog.Builder(context)
                .setCancelable(false)
                .setMessage(msg)
                .setPositiveButton("Accept",(dialog, which) ->
                        clubServicesListener.onAcceptRequests(context,requestModel.getToken(),true)
                ).setNegativeButton("Reject",(dialog, which) -> {
                    dialog.dismiss();
            clubServicesListener.onAcceptRequests(context,requestModel.getToken(),true);
        }).create().show();
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((RequestViewHolder)holder).onBindData(requestModelList.get(position));
    }
    @Override
    public int getItemCount() {
        return requestModelList.size();
    }
    private class RequestViewHolder extends RecyclerView.ViewHolder{

        TextView left_tt,right_tt;

        public RequestViewHolder(@NonNull View itemView) {
            super(itemView);

            left_tt = itemView.findViewById(R.id.left_tt);
            right_tt = itemView.findViewById(R.id.right_tt);
        }

        private void onBindData(RequestModel requestModel){
                left_tt.setText(requestModel.getClubname());
                String dt = String.format("Phone : %s\nEmail : %s",requestModel.getPhone(),requestModel.getEmail());
                right_tt.setText(dt);

        }
    }
}
