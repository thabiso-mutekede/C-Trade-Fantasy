package zw.co.escrow.ctradelive.view;

import android.os.Bundle;

import com.ogaclejapan.smarttablayout.SmartTabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import zw.co.escrow.ctradelive.BanksAsyncTask;
import zw.co.escrow.ctradelive.CustodianAsyncTask;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.LoginSectionsPagerAdapter;
import zw.co.escrow.ctradelive.view_model.AppViewModel;

public class LoginActivity2 extends AppCompatActivity {

    private AppViewModel appViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        CustodianAsyncTask custodianAsyncTask = new CustodianAsyncTask(this);
        custodianAsyncTask.execute("Com");

        BanksAsyncTask banksAsyncTask = new BanksAsyncTask(this);
        banksAsyncTask.execute("Com");



        LoginSectionsPagerAdapter loginSectionsPagerAdapter = new LoginSectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(loginSectionsPagerAdapter);
        SmartTabLayout tabs = findViewById(R.id.viewpagertab);
        tabs.setViewPager(viewPager);

    }

}