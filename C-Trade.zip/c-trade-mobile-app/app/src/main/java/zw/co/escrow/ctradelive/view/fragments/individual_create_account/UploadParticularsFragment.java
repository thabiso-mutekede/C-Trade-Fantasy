package zw.co.escrow.ctradelive.view.fragments.individual_create_account;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.features.ReturnMode;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.setup.listeners.Registration;
import zw.co.escrow.ctradelive.setup.services.RegistrationService;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class UploadParticularsFragment extends Fragment implements View.OnClickListener {

    private static final String ARG_SECTION_NUMBER = "DETAILS";
    private static final String TAG = "UploadParticularsFragme";
    private RegistrationData registrationData;
    private LoginViewModel loginViewModel;
    private CardView cardViewProfilePic, cardViewID, cardViewProofOfResidence;
    private String profilePath,nationalIdPath;
    private TextView profileTxt,nationalTxt;
    private Registration.DataListener dataListener;
    public static final int REQUEST_PERMISSION = 700;

    private Button submitButton;



    public static UploadParticularsFragment newInstance(RegistrationData registrationData) {
        UploadParticularsFragment fragment = new UploadParticularsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_upload_particulars, container, false);

        initWidgets(root);

        dataListener = new RegistrationService(getContext());

        cardViewProfilePic.setOnClickListener(this);
        cardViewID.setOnClickListener(this);
        cardViewProofOfResidence.setOnClickListener(this);

        checkPermissions();

        verifyStoragePermissions(getActivity());

        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
            registrationData.getRegistrationSession().setQnaDone(true);
        }

        root.findViewById(R.id.btnSubmit).setOnClickListener(v->{

            submitButton.setEnabled(false);

            try {
                JSONObject body = getClientBody();
                if(body != null){
                   createACTradeAccount(body.toString());
                }else{
                    submitButton.setEnabled(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
                submitButton.setEnabled(true);
                new AlertDialog.Builder(getActivity())
                        .setTitle("Result")
                        .setCancelable(false)
                        .setMessage(R.string.error_while_compiling_account_details)
                        .setPositiveButton("OK", (dialog, which) -> {
                        })
                        .show();
            }

        });

        return root;
    }

    private boolean uploadIndividualDocuments() {
        if(profilePath == null) {
            Toast.makeText(getContext(), "Upload Profile.", Toast.LENGTH_SHORT).show();
            return false;
        }else if(nationalIdPath == null){
            Toast.makeText(getContext(), "Upload National Id.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void initWidgets(View view){
        cardViewProfilePic =view.findViewById(R.id.cardViewProfilePic);
        cardViewID =view.findViewById(R.id.cardViewID);
        cardViewProofOfResidence =view.findViewById(R.id.cardViewProofOfResidence);
        profileTxt = view.findViewById(R.id.txtProfile);
        nationalTxt = view.findViewById(R.id.txtID);
        submitButton = view.findViewById(R.id.btnSubmit);
    }

    @Override
    public void onClick(View view) {

        Intent pickPhoto = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        switch (view.getId()){
            case R.id.cardViewProfilePic:

                startActivityForResult(pickPhoto, Constants.REQUEST_FILE_PROFILE);

                break;

            case R.id.cardViewID:

                startActivityForResult(pickPhoto, Constants.REQUEST_FILE_NATIONAL);

                break;

            case R.id.cardViewProofOfResidence:

                uploadImage("Upload your Proof of residence");

                break;
        }

    }

    private void uploadImage(String message){
        ImagePicker.create(getActivity())
                .returnMode(ReturnMode.GALLERY_ONLY)
                .folderMode(true)
                .toolbarFolderTitle(message)
                .toolbarImageTitle("Tap to select")
                .toolbarArrowColor(getActivity().getResources().getColor(R.color.colorWhite))
                .includeVideo(false)
                .includeAnimation(false)
                .single()
                .limit(1)
                .showCamera(true)
                .imageDirectory("Camera")
                .theme(R.style.AppTheme)
                .enableLog(true)
                .start();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case Constants.REQUEST_FILE_NATIONAL:
                if (requestCode == Constants.REQUEST_FILE_NATIONAL) {
                    //docPaths = new ArrayList<>();
                    //docPaths.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                    if (requestCode == Constants.REQUEST_FILE_NATIONAL && resultCode == getActivity().RESULT_OK) {

                        if (resultCode == Activity.RESULT_OK) {
                            //Uri uri = data.getParcelableExtra("path");
                            Uri uri = data.getData();
                            String[] filePathColumn = {MediaStore.Images.Media.DATA};
                            // Get the cursor
                            Cursor cursor = getActivity().getContentResolver().query(uri, filePathColumn, null, null, null);
                            // Move to first row
                            cursor.moveToFirst();
                            //Get the column index of MediaStore.Images.Media.DATA
                            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                            //Gets the String value in the column
                            String imgDecodableString = cursor.getString(columnIndex);
                            cursor.close();
                            // Set the Image in ImageView after decoding the String
                            //imageView.setImageBitmap(BitmapFactory.decodeFile(imgDecodableString));
                            //uploadToServerID(imgDecodableString);
                            nationalIdPath= imgDecodableString;
                            String name = queryName(getActivity().getContentResolver(),uri);
                            nationalTxt.setText(name);
                        }

                    }
                }
                break;
            case Constants.REQUEST_FILE_PROFILE:
                if (requestCode == Constants.REQUEST_FILE_PROFILE) {
                    //docPaths = new ArrayList<>();
                    //docPaths.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                    if (requestCode == Constants.REQUEST_FILE_PROFILE && resultCode == getActivity().RESULT_OK) {

                        if (resultCode == Activity.RESULT_OK) {
                            //Uri uri = data.getParcelableExtra("path");
                            Uri uri = data.getData();
                            String[] filePathColumn = {MediaStore.Images.Media.DATA};
                            // Get the cursor
                            Cursor cursor = getActivity().getContentResolver().query(uri, filePathColumn, null, null, null);
                            // Move to first row
                            cursor.moveToFirst();
                            //Get the column index of MediaStore.Images.Media.DATA
                            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                            //Gets the String value in the column
                            String imgDecodableString = cursor.getString(columnIndex);
                            cursor.close();
                            // Set the Image in ImageView after decoding the String
                            //imageView.setImageBitmap(BitmapFactory.decodeFile(imgDecodableString));

                            profilePath= imgDecodableString;
                            String name = queryName(getActivity().getContentResolver(),uri);
                            profileTxt.setText(name);
                        }

                    }
                }
                break;
            default:
                Toast.makeText(getActivity(), " fall down", Toast.LENGTH_LONG).show();

        }
    }

    private JSONObject getClientBody() throws Exception{
        boolean isValid = true;
        boolean ii = true;
        JSONObject jo = new JSONObject();
        JSONObject regJo = new JSONObject();
        JSONObject seqQ = new JSONObject();

        JSONArray repJa = new JSONArray();
        try{

            if(uploadIndividualDocuments()){
                String title, gender, surname, name, idNumber, dob, phone, address, nationality, custodian, bank, branch, accountNumber
                        , email, password, book, motherMaidenName, road,occupation,industry,pep_status,cdc_number;
                title = registrationData.getDetails().getTitle();
                gender = registrationData.getDetails().getGender();
                surname = registrationData.getDetails().getSurname();
                name = registrationData.getDetails().getForenames();
                idNumber = registrationData.getDetails().getIdnoPP();
                dob = registrationData.getDetails().getDob();
                phone = registrationData.getDetails().getMobile();
                address = registrationData.getDetails().getAdd1();
                nationality = registrationData.getDetails().getNationality();
                custodian = registrationData.getDetails().getCustodian();
                bank = registrationData.getDetails().getCashBank();
                branch = registrationData.getDetails().getCashBranch();
                accountNumber = registrationData.getDetails().getCashAccountNo();
                email = registrationData.getDetails().getEmail();
                password = registrationData.getPassword();
                book = registrationData.getBook();
                motherMaidenName = registrationData.getMotherName();
                road = registrationData.getRoad();
                occupation = registrationData.getDetails().getClient_occupation();
                industry = registrationData.getDetails().getIndustry_of_profession();
                pep_status = registrationData.getDetails().getPep_status();
                cdc_number = registrationData.getDetails().getCdc_number();

                jo.put("accountType", getString(R.string.account_type_individual));
                jo.put("surname", surname);
                jo.put("forenames", name);
                jo.put("title", title);
                jo.put("country", nationality);
                jo.put("city", "");
                jo.put("tel", phone);
                jo.put("mobile", phone);
                jo.put("idnoPP", idNumber);
                jo.put("dob", dob);
                jo.put("client_occupation",occupation);
                jo.put("industry_of_profession",industry);
                jo.put("pep_status",pep_status);
                jo.put("gender", gender);
                jo.put("add1", address);
                jo.put("email", email);
                jo.put("cashBank", bank);
                jo.put("cashBranch", branch);
                jo.put("cashAccountNo", accountNumber);
                jo.put("custodian", custodian);
                jo.put("createdBy", "ANDROID");
                jo.put("cdcNumber",cdc_number);

                seqQ.put("bookRead",book);
                seqQ.put("motherMaidenName",motherMaidenName);
                seqQ.put("road",road);

                regJo.put("securityQuestions",seqQ);
                regJo.put("password", password);
                regJo.put("accountsClientsWeb",jo);
                regJo.put("representatives",repJa);

                return  regJo;
            }
            return null;
        }catch (Exception e){
            e.printStackTrace();
            throw new Exception();
        }
    }

    private void createACTradeAccount(String body){
        if(profilePath != null && nationalIdPath != null){
            File natId = new File(nationalIdPath);
            File pic = new File(profilePath);
            Bitmap natId_bitmap = BitmapFactory.decodeFile(natId.getAbsolutePath());
            Bitmap pic_bitmap = BitmapFactory.decodeFile(pic.getAbsolutePath());
            dataListener.createCTradeAccount(getContext(),body,pic_bitmap,natId_bitmap);
        }else{
            showDialog("Something Is Wrong With The Image You Are Trying To Submit,Please Try Selecting An Image From Your 'Gallery'");
        }
    }
    private String queryName(ContentResolver resolver, Uri uri) {
        Cursor returnCursor =
                resolver.query(uri, null, null, null, null);
        assert returnCursor != null;
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        returnCursor.moveToFirst();
        String name = returnCursor.getString(nameIndex);
        returnCursor.close();
        return name;
    }

    private void showDialog(String message){
        new android.app.AlertDialog.Builder(getContext())
                .setMessage(message)
                .setPositiveButton("ok",(
                        (dialogInterface, i) -> {
                        }))
                .create()
                .show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkPermissions(){
        if (Build.VERSION.SDK_INT >= 23) {
            int permissionCheck = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        }
    }

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }
}