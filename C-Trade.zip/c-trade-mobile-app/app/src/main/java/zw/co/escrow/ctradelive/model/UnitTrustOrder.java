package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author Tinashe Chandalala
 */
public class UnitTrustOrder implements Parcelable {

    private String counter, status, type,currentPrice, rawAskVolume, rawBidVolume, askVolume,
    bidVolume, volume, price, AmountValue, date;

    public UnitTrustOrder(String counter, String status, String type, String currentPrice, String rawAskVolume, String rawBidVolume, String askVolume, String bidVolume, String volume, String price, String amountValue, String date) {
        this.counter = counter;
        this.status = status;
        this.type = type;
        this.currentPrice = currentPrice;
        this.rawAskVolume = rawAskVolume;
        this.rawBidVolume = rawBidVolume;
        this.askVolume = askVolume;
        this.bidVolume = bidVolume;
        this.volume = volume;
        this.price = price;
        AmountValue = amountValue;
        this.date = date;
    }


    protected UnitTrustOrder(Parcel in) {
        counter = in.readString();
        status = in.readString();
        type = in.readString();
        currentPrice = in.readString();
        rawAskVolume = in.readString();
        rawBidVolume = in.readString();
        askVolume = in.readString();
        bidVolume = in.readString();
        volume = in.readString();
        price = in.readString();
        AmountValue = in.readString();
        date = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(counter);
        dest.writeString(status);
        dest.writeString(type);
        dest.writeString(currentPrice);
        dest.writeString(rawAskVolume);
        dest.writeString(rawBidVolume);
        dest.writeString(askVolume);
        dest.writeString(bidVolume);
        dest.writeString(volume);
        dest.writeString(price);
        dest.writeString(AmountValue);
        dest.writeString(date);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<UnitTrustOrder> CREATOR = new Creator<UnitTrustOrder>() {
        @Override
        public UnitTrustOrder createFromParcel(Parcel in) {
            return new UnitTrustOrder(in);
        }

        @Override
        public UnitTrustOrder[] newArray(int size) {
            return new UnitTrustOrder[size];
        }
    };

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public String getRawAskVolume() {
        return rawAskVolume;
    }

    public void setRawAskVolume(String rawAskVolume) {
        this.rawAskVolume = rawAskVolume;
    }

    public String getRawBidVolume() {
        return rawBidVolume;
    }

    public void setRawBidVolume(String rawBidVolume) {
        this.rawBidVolume = rawBidVolume;
    }

    public String getAskVolume() {
        return askVolume;
    }

    public void setAskVolume(String askVolume) {
        this.askVolume = askVolume;
    }

    public String getBidVolume() {
        return bidVolume;
    }

    public void setBidVolume(String bidVolume) {
        this.bidVolume = bidVolume;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAmountValue() {
        return AmountValue;
    }

    public void setAmountValue(String amountValue) {
        AmountValue = amountValue;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
