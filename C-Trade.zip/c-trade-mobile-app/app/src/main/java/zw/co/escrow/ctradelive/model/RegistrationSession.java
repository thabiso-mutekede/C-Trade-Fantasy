package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class RegistrationSession implements Parcelable {
    private boolean detailsDone;
    private boolean signatoryDone;
    private boolean custodianDone;
    private boolean credentialsDone;
    private boolean qnaDone;


    public RegistrationSession() {
    }

    protected RegistrationSession(Parcel in) {
        detailsDone = in.readByte() != 0;
        signatoryDone = in.readByte() != 0;
        custodianDone = in.readByte() != 0;
        credentialsDone = in.readByte() != 0;
        qnaDone = in.readByte() != 0;
    }

    public static final Creator<RegistrationSession> CREATOR = new Creator<RegistrationSession>() {
        @Override
        public RegistrationSession createFromParcel(Parcel in) {
            return new RegistrationSession(in);
        }

        @Override
        public RegistrationSession[] newArray(int size) {
            return new RegistrationSession[size];
        }
    };

    public boolean isDetailsDone() {
        return detailsDone;
    }

    public void setDetailsDone(boolean detailsDone) {
        this.detailsDone = detailsDone;
    }

    public boolean isSignatoryDone() {
        return signatoryDone;
    }

    public void setSignatoryDone(boolean signatoryDone) {
        this.signatoryDone = signatoryDone;
    }

    public boolean isCustodianDone() {
        return custodianDone;
    }

    public void setCustodianDone(boolean custodianDone) {
        this.custodianDone = custodianDone;
    }

    public boolean isCredentialsDone() {
        return credentialsDone;
    }

    public void setCredentialsDone(boolean credentialsDone) {
        this.credentialsDone = credentialsDone;
    }

    public boolean isQnaDone() {
        return qnaDone;
    }

    public void setQnaDone(boolean qnaDone) {
        this.qnaDone = qnaDone;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeByte((byte) (detailsDone ? 1 : 0));
        parcel.writeByte((byte) (signatoryDone ? 1 : 0));
        parcel.writeByte((byte) (custodianDone ? 1 : 0));
        parcel.writeByte((byte) (credentialsDone ? 1 : 0));
        parcel.writeByte((byte) (qnaDone ? 1 : 0));
    }
}
