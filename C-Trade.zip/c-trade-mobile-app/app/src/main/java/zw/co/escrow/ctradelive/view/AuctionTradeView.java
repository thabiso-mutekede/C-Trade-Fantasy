package zw.co.escrow.ctradelive.view;
//
//import android.Manifest;
//import android.app.Activity;
//import android.app.AlertDialog;
//import android.content.ContentResolver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.pm.PackageManager;
//import android.database.Cursor;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Bundle;
//import android.provider.MediaStore;
//import android.provider.OpenableColumns;
//import android.view.View;
//import android.widget.ArrayAdapter;
//import android.widget.Spinner;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.annotation.RequiresApi;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.Toolbar;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//
//import com.android.volley.toolbox.JsonArrayRequest;
//import com.google.android.material.textfield.TextInputEditText;
//
//import org.json.JSONObject;
//
//import java.io.File;
//import java.util.ArrayList;
//import java.util.List;
//
//import okhttp3.MediaType;
//import okhttp3.MultipartBody;
//import okhttp3.RequestBody;
//import zw.co.escrow.ctradelive.AppConfig;
//import zw.co.escrow.ctradelive.R;
//import zw.co.escrow.ctradelive.setup.listeners.Forex;
//import zw.co.escrow.ctradelive.setup.services.ForexService;
//
//
//public class AuctionTradeView extends AppCompatActivity implements View.OnClickListener{
//
//    private Forex.ForexServicesListener forexServicesListener;
//    private TextInputEditText amount_txt,rate_txt,bpno_txt;
//    private String invoice_path;
//    TextView invoice_txt;
//    public static final int REQUEST_A = 100;
//    public static final int REQUEST_B = 101;
//    public static final int REQUEST_C = 102;
//    public static final int REQUEST_D = 103;
//    public static final int REQUEST_PERMISSION = 700;
//    private static final int PERMISSION_REQUEST_CODE = 200;
//    private List<String> sectors;
//    private static final Float charge = 0.035f;
//
//    private Toolbar toolbar;
//
//    @RequiresApi(api = Build.VERSION_CODES.M)
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.buy_forex_dialog_view);
//        toolbar = findViewById(R.id.toolbar);
//        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
//        toolbar.setTitle("Bid Posting");
//        toolbar.setNavigationOnClickListener((v)->finish());
//
//        selectBidPurpose = findViewById(R.id.spPurposeSearchable);
//        selectSector = findViewById(R.id.spSectorSearchable);
//        rate_txt = findViewById(R.id.et_preferred_txt);
//        amount_txt = findViewById(R.id.et_pay_amount);
//        invoice_txt = findViewById(R.id.invoice_tv);
//        bpno_txt = findViewById(R.id.et_bpno_txt);
//        forexServicesListener = new ForexService(this);
//        forexServicesListener.onGetBidPurpose(selectBidPurpose);
//        findViewById(R.id.btnPost).setOnClickListener(this);
//        findViewById(R.id.upload_invoice_lay).setOnClickListener(this);
//        getSectors();
//        checkPermissions();
//    }
//    boolean validate(){
//        if(rate_txt.getText().toString().equalsIgnoreCase("")){
//            rate_txt.setError("Enter Preferred Rate");
//            return false;
//        }else if(amount_txt.getText().toString().equalsIgnoreCase("")){
//            amount_txt.setError("Enter Amount");
//            return false;
//        }else if(bpno_txt.getText().toString().equalsIgnoreCase("")){
//            bpno_txt.setError("Enter BPNo.");
//            return false;
//        }
//        return true;
//    }
//
//
//    private void getSectors(){
//        String url = "";
//        JsonArrayRequest jr = new JsonArrayRequest(url, response -> {
//            try{
//                sectors = new ArrayList<>();
//                for(int i = 0;i<response.length();i++){
//                    JSONObject jo = response.getJSONObject(i);
//                    sectors.add(jo.getString("name").toUpperCase());
//                }
//                ArrayAdapter<String> adapterCompaniesSearchable =
//                        new ArrayAdapter<>(this,
//                                R.layout.spinner_item, sectors);
//                selectSector.setAdapter(adapterCompaniesSearchable);
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//        },error ->
//            error.printStackTrace()
//        );
//        AppConfig.getInstance().addToRequestQueue(jr);
//    }
//
//    Spinner selectBidPurpose,selectSector;
//    @RequiresApi(api = Build.VERSION_CODES.M)
//    @Override
//    public void onClick(View v) {
//        if (v.getId() == R.id.btnPost) {
//
//            Float chargeString = charge * convertToFloat(amount_txt.getText().toString());
//            Float amount = convertToFloat(amount_txt.getText().toString()) + chargeString;
//
//            if (validate()) {
//                AlertDialog alertDialog = new AlertDialog.Builder(this)
//                        .setTitle("Confirm Bid")
//                        .setMessage("Amount : " + amount_txt.getText().toString() + "\nCharges : " + chargeString + "\nGross : " + amount)
//                        .setPositiveButton("Ok"
//                                , ((dialogInterface, i) -> {
//                                    postBid(invoice_path,amount);
//                                })).setNegativeButton("Cancel", null).create();
//
//                alertDialog.setOnShowListener(dialogInterface -> {
//                    alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getColor(R.color.colorAccent));
//                    alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getColor(R.color.red));
//                });
//                alertDialog.show();
//            }
//        }
//        if (v.getId() == R.id.upload_invoice_lay) {
//            launchGalleryIntent(REQUEST_A);
//        }
//    }
//
//    private Float convertToFloat(String s){
//        float i;
//        try{
//            i = Float.parseFloat(s);
//        }catch (Exception e){
//            i = 0;
//        }
//        return i;
//    }
//    private void postBid(String invoicePath, Float amount){
//        if(invoicePath != null){
//            //File natIdFile = new File(nationalPath);
//            File invoiceFile = new File(invoicePath);
//            //File taxFile = new File(taxPath);
//           //File c14File = new File(c14Path);
//            //RequestBody fileReqN = RequestBody.create(MediaType.parse("image/*"), natIdFile);
//            //MultipartBody.Part national = MultipartBody.Part.createFormData("national", natIdFile.getName(), fileReqN);
//            RequestBody fileReqI = RequestBody.create(MediaType.parse("image/*"), invoiceFile);
//            MultipartBody.Part invoice = MultipartBody.Part.createFormData("invoice", invoiceFile.getName(), fileReqI);
//            //RequestBody fileReqT = RequestBody.create(MediaType.parse("image/*"), taxFile);
//            //MultipartBody.Part tax = MultipartBody.Part.createFormData("taxclearance", taxFile.getName(), fileReqT);
//            //RequestBody fileReqC = RequestBody.create(MediaType.parse("image/*"), c14File);
//            //MultipartBody.Part c14 = MultipartBody.Part.createFormData("c14", c14File.getName(), fileReqC);
//            RequestBody amountBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(amount));
//            RequestBody rate = RequestBody.create(MediaType.parse("text/plain"), rate_txt.getText().toString());
//            RequestBody purpose = RequestBody.create(MediaType.parse("text/plain"), selectBidPurpose.getSelectedItem().toString());
//            RequestBody type = RequestBody.create(MediaType.parse("text/plain"), "BUY");
//            RequestBody bpno = RequestBody.create(MediaType.parse("text/plain"), bpno_txt.getText().toString());
//            RequestBody sector = RequestBody.create(MediaType.parse("text/plain"),selectSector.getSelectedItem().toString());
//
//            RequestBody cds = RequestBody.create(MediaType.parse("text/plain"),getSharedPreferences("CTRADE", Context.MODE_PRIVATE).getString("cds_number",""));
//
//            forexServicesListener.onPostBid(cds,type,amountBody,purpose,rate,sector,bpno,invoice);
//        }else{
//            showDialog("Something Is Wrong With The Image You Are Trying To Submit,Please Try Selecting An Image From Your 'Gallery'");
//        }
//    }
//    private void requestPermission() {
//        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
//    }
//
//    private void launchGalleryIntent(int req_type) {
//
//
//        /*Intent intent = new Intent();
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        startActivityForResult(Intent.createChooser(intent, "Select Picture"),req_type);*/
//
//        /*Intent intent = new Intent(this, ImagePickerActivity.class);
//        intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION, ImagePickerActivity.REQUEST_GALLERY_IMAGE);
//
//        // setting aspect ratio
//        intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
//        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 1); // 16x9, 1x1, 3:4, 3:2
//        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 1);
//        startActivityForResult(intent, req_type);*/
//
//
//        /*Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
//        photoPickerIntent.setType("image/*");
//        startActivityForResult(photoPickerIntent, req_type);*/
//        Intent pickPhoto = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//        startActivityForResult(pickPhoto, req_type);
//    }
//
//    private void showDialog(String message){
//        new AlertDialog.Builder(this)
//                .setMessage(message)
//                .setPositiveButton("ok",null)
//                .create()
//                .show();
//        }
//
//    @RequiresApi(api = Build.VERSION_CODES.M)
//    private void checkPermissions(){
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
//                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
//                    REQUEST_PERMISSION);
//
//            return;
//        }
//    }
//
//    public String getRealPathFromURI(Uri uri) {
//        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
//        cursor.moveToFirst();
//        int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
//        return cursor.getString(idx);
//    }
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == REQUEST_A) {
//            if (requestCode == REQUEST_A && resultCode == RESULT_OK) {
//                if (resultCode == Activity.RESULT_OK) {
//                    if(data != null){
//                        Uri uri = data.getData();
//                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
//                        // Get the cursor
//                        Cursor cursor = getContentResolver().query(uri, filePathColumn, null, null, null);
//                        // Move to first row
//                        cursor.moveToFirst();
//                        //Get the column index of MediaStore.Images.Media.DATA
//                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
//                        //Gets the String value in the column
//                        String imgDecodableString = cursor.getString(columnIndex);
//                        cursor.close();
//                        // Set the Image in ImageView after decoding the String
//                        //imageView.setImageBitmap(BitmapFactory.decodeFile(imgDecodableString));
//                        //Toast.makeText(this, "uploadToServerPS" + imgDecodableString, Toast.LENGTH_LONG).show();
//
//                        invoice_path = imgDecodableString;
//                        String name = queryName(getContentResolver(),uri);
//                        invoice_txt.setText(name);
//                    }
//                }
//            }
//        }
//    }
//    private String queryName(ContentResolver resolver, Uri uri) {
//        Cursor returnCursor =
//                resolver.query(uri, null, null, null, null);
//        assert returnCursor != null;
//        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
//        returnCursor.moveToFirst();
//        String name = returnCursor.getString(nameIndex);
//        returnCursor.close();
//        return name;
//    }
//
//    @Override
//    public void onRequestPermissionsResult(final int requestCode, @NonNull final String[] permissions, @NonNull final int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == REQUEST_PERMISSION) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(this,"Thanks", Toast.LENGTH_LONG).show();
//            } else {
//                // User refused to grant permission.
//            }
//        }
//    }
//    private boolean checkPermissionMe() {
//        int result = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE);
//        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
//
//        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
//    }
//
//
//}
