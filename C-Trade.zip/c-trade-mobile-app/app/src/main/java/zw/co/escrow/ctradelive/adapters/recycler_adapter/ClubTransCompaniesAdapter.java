package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubTransCompany;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;


public class ClubTransCompaniesAdapter extends RecyclerView.Adapter{

    private final List<ClubTransCompany> clubTransCompanies;
    private final Context context;
    private final Dialog dialog;
    private final RecyclerView recyclerView;
    private final InvestmentClub.ClubServicesListener clubServicesListener;
    private final String clubCdsNumber;

    public ClubTransCompaniesAdapter(List<ClubTransCompany> clubTransCompanies, Context context, Dialog dialog, RecyclerView recyclerView, InvestmentClub.ClubServicesListener clubServicesListener, String clubCdsNumber) {
        this.clubTransCompanies = clubTransCompanies;
        this.context = context;
        this.dialog = dialog;
        this.recyclerView = recyclerView;
        this.clubServicesListener = clubServicesListener;
        this.clubCdsNumber = clubCdsNumber;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.ctrade_universal_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        view.setOnClickListener(v -> {
            ClubTransCompany company = clubTransCompanies.get(recyclerView.getChildLayoutPosition(view));
            clubServicesListener.onLoadClubStatementOnCompany(clubCdsNumber,company.getCompany(),dialog);
        });
        return new TransCompanyVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((TransCompanyVH)holder).onBindData(clubTransCompanies.get(position));
    }

    @Override
    public int getItemCount() {
        return clubTransCompanies.size();
    }

    private class TransCompanyVH extends RecyclerView.ViewHolder{

        private TextView main_text,sub_text;

        public TransCompanyVH(@NonNull View itemView) {
            super(itemView);
            main_text = itemView.findViewById(R.id.right_tt);
            sub_text = itemView.findViewById(R.id.left_tt);
        }
        public void onBindData(ClubTransCompany clubTransCompany){
            main_text.setText(clubTransCompany.getCompany());
            sub_text.setVisibility(View.GONE);

        }
    }
}
