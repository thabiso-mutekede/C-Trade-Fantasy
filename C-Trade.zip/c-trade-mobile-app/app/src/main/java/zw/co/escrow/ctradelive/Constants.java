package zw.co.escrow.ctradelive;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

import zw.co.escrow.ctradelive.model.Signatory;

public class Constants {

    //live
    public static final String APP_BASE_FULL_URL = "https://ctrade.co.zw/mobileapi/";
    public static final String APP_BASE_URL = "ctrade.co.zw/mobileapi/";
            //"";
    //public static final String EMAIL_PATTERN = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
    public static final String EMAIL_PATTERN = "^[a-zA-Z0-9#_\\-\\~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
    public static  final int CONVERT_REQUEST_CODE=1888;
    public static  final int WITHDRAW_REQUEST_CODE=1889;
    public static  final int DEPOSIT_REQUEST_CODE=1890;
    public static  final int AUTO_TRADE_REQUEST_CODE=1891;

    public static final int REQUEST_FILE_TAX = 400;
    public static final int REQUEST_FILE_BOARD = 500;
    public static final int REQUEST_FILE_CORP = 600;

    public static final int REQUEST_FILE_PROFILE = 501;
    public static final int REQUEST_FILE_NATIONAL = 601;


    public static final String EQUITY = "EQUITY";
    public static final String ETF = "ETF";
    public static final String ZSE = "ZSE";
    public static final String NONE = "NONE";
    public static final String PRODUCT = "PRODUCT";
    public static final String PRODUCTS_PREF = "PRODUCTS_PREF";
    public static final String FINSEC = "FINSEC";

    public static final String MOBILE_API = "https://mariketi.com/mainapi/";
    //public static final String MOBILE_API = "https://online.ctrade.co.zw/mainapi/";

    public static final String ERROR_MESSAGE = "Error Occurred.Please Try Again Later!";


    public static ArrayList<Signatory> signatories = new ArrayList<>();


    public static final String COMPLETE_URL(String method){
        return String.format("%s%s",MOBILE_API,method);
    }
    public static Float convertToFloat(String s){
        float i;
        try{
            i = Float.parseFloat(s);
        }catch (Exception e){
            i = 0;
        }
        return i;
    }
    public static String getThousandSep(Float amount){
        try{
           return String.format("%,.2f",amount);
        }catch (Exception e){
           return String.valueOf(amount);
        }

    }

    public static Float roundToDecimalPlaceShare(Float amount){
        try{
            DecimalFormat df = new DecimalFormat("#.##");
            String value = df.format(amount);
            return Float.parseFloat(value);
        }catch (Exception e){
            e.printStackTrace();
            return  amount;
        }
    }
    public static Float getRoundedPriceForOder(Float amount_,String type){
        String amount = String.valueOf(amount_);
        String numberAfterComma = amount.substring(amount.indexOf('.') + 1);
        if(!(numberAfterComma.length() < 4)){
            int lastDigit = Integer.parseInt(String.valueOf(numberAfterComma.charAt(numberAfterComma.length() - 1)));
            if(lastDigit % 2 != 0){
                switch(type){
                    case "BUY":
                        amount_ -= 0.0001f;
                        break;
                    case "SELL":
                        amount_ += 0.0001f;
                        break;
                }
            }
        }
        return amount_;
    }
    public static Float roundToDecimalPrice(Float amount){
        try{
            DecimalFormat df = new DecimalFormat("#.##");
            String value = df.format(amount);
            return Float.parseFloat(value);
        }catch (Exception e){
            e.printStackTrace();
            return  amount;
        }
    }

    public static JSONObject cdsNumberJSON(@NonNull String cdsNumber){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("cdsNumber",cdsNumber);
            return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static JSONObject cdsNumberJSON(@NonNull String cdsNumber,@NonNull String memberCdsNumber){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("memberCdsNumber",memberCdsNumber);
            jsonObject.put("clubCdsNumber",cdsNumber);
            return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    public static JSONObject amountIndividualJSON(@NonNull String cdsNumber,@NonNull Float amount){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("amount",amount);
            jsonObject.put("cdsNumber",cdsNumber);
            return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    public static JSONObject amountClubJSON(@NonNull String clubCdsNumber,@NonNull String cdsNumber,@NonNull Float amount){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("amount",amount);
            jsonObject.put("clubCdsNumber",clubCdsNumber);
            jsonObject.put("cdsNumber",cdsNumber);
            Log.d("jo",jsonObject.toString());
            return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static void showDialog(Context context, String message){
        new AlertDialog.Builder(context)
                .setMessage(message)
                .setPositiveButton("ok",null)
                .create()
                .show();
    }
}
