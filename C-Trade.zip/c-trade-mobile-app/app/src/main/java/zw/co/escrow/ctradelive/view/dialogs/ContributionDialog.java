package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.Request;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.listeners.TableDataClickListener;
import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.column_adapters.UniversalHeaderAdapter;
import zw.co.escrow.ctradelive.adapters.header_adapters.ContributionStatementColumnAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.ContributionStatement;
import zw.co.escrow.ctradelive.model.MyCashData;

public class ContributionDialog extends Dialog implements TableDataClickListener {

    private TableView tableView;
    private final String cdsNumber,mcdsnumber;
    private final List<String> table_headers = Arrays.asList("Name","Cumulative","Available","State");
    List<MyCashData> myCashDataList;
    private Toolbar toolbar;

    public ContributionDialog(@NonNull Context context, String cdsNumber, String mcdsnumber) {
        super(context);
        this.cdsNumber = cdsNumber;
        this.mcdsnumber = mcdsnumber;
        setContentView(R.layout.activity_my_cash_view);
        myCashDataList = new ArrayList<>();

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Club Contributions".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        fetchTransactions();

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public void onDataClicked(int rowIndex, Object clickedData) {
        
    }

    private void fetchTransactions(){
        JSONObject jsonObject = new  JSONObject();
        try {
            jsonObject.put("type","club");
            jsonObject.put("cdsNumber",mcdsnumber);
            jsonObject.put("clubCdsNumber",cdsNumber);
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(
                Request.Method.POST,
                Constants.COMPLETE_URL("clubs/contributions"),
                jsonObject,
                response -> {

                    Log.d("ja",response.toString());
                    try{
                        List<ContributionStatement> contributionStatements = new ArrayList<>();
                        for (int i = 0;i<response.length();i++){
                            JSONObject obj = response.getJSONObject(i);
                            ContributionStatement contributionStatement = new ContributionStatement();
                            contributionStatement.setContribution_(String.valueOf(Float.parseFloat(String.valueOf(obj.getDouble("contribution")))));
                            contributionStatement.setActive(obj.getBoolean("active"));
                            contributionStatement.setCumulative(String.valueOf(Float.parseFloat(String.valueOf(obj.getDouble("accumulative")))));
                            contributionStatement.setExit_date(obj.getString("date"));
                            contributionStatement.setName(obj.getString("names"));
                            contributionStatements.add(contributionStatement);
                        }

                        tableView = findViewById(R.id.portfolio_table);
                        tableView.setColumnCount(4);
                        tableView.setHeaderAdapter(new UniversalHeaderAdapter(getContext(),table_headers.size(),table_headers));

                        tableView.setDataAdapter(new ContributionStatementColumnAdapter(getContext(),contributionStatements));
                        tableView.addDataClickListener(ContributionDialog.this::onDataClicked);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                },error -> {
                    Constants.showDialog(getContext(),Constants.ERROR_MESSAGE);
                    error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jr);

      }
}