package zw.co.escrow.ctradelive.model;

public class KYCResponse {

    private String id;
    private String cdsNumber;
    private String nationalIdFile;
    private String passportPhotoFile;
    private String payslipFile;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCdsNumber() {
        return cdsNumber;
    }

    public void setCdsNumber(String cdsNumber) {
        this.cdsNumber = cdsNumber;
    }

    public String getNationalIdFile() {
        return nationalIdFile;
    }

    public void setNationalIdFile(String nationalIdFile) {
        this.nationalIdFile = nationalIdFile;
    }

    public String getPassportPhotoFile() {
        return passportPhotoFile;
    }

    public void setPassportPhotoFile(String passportPhotoFile) {
        this.passportPhotoFile = passportPhotoFile;
    }

    public String getPayslipFile() {
        return payslipFile;
    }

    public void setPayslipFile(String payslipFile) {
        this.payslipFile = payslipFile;
    }
}
