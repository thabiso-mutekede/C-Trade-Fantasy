package zw.co.escrow.ctradelive.model;

public class DrillDown {

    private String date;
    private String shares;

    public DrillDown(String date, String shares) {
        this.date = date;
        this.shares = shares;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getShares() {
        return shares;
    }

    public void setShares(String shares) {
        this.shares = shares;
    }
}
