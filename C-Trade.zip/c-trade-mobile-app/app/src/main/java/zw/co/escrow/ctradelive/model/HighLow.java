package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class HighLow implements Parcelable {

    private double low;
    private double high;

    protected HighLow(Parcel in) {
        low = in.readDouble();
        high = in.readDouble();
    }

    public static final Creator<HighLow> CREATOR = new Creator<HighLow>() {
        @Override
        public HighLow createFromParcel(Parcel in) {
            return new HighLow(in);
        }

        @Override
        public HighLow[] newArray(int size) {
            return new HighLow[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeDouble(low);
        parcel.writeDouble(high);
    }

    public double getLow() {
        return low;
    }

    public void setLow(double low) {
        this.low = low;
    }

    public double getHigh() {
        return high;
    }

    public void setHigh(double high) {
        this.high = high;
    }
}
