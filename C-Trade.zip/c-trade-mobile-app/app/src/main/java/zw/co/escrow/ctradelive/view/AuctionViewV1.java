package zw.co.escrow.ctradelive.view;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.Toolbar;
//import androidx.viewpager.widget.ViewPager;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.TextView;
//
//
//import com.ogaclejapan.smarttablayout.SmartTabLayout;
//import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
//import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;
//
//import zw.co.escrow.ctradelive.Constants;
//import zw.co.escrow.ctradelive.R;
////import zw.co.escrow.ctradelive.setup.listeners.Forex;
////import zw.co.escrow.ctradelive.setup.services.ForexService;
//import zw.co.escrow.ctradelive.view.dialogs.CPayCashDialog;
//import zw.co.escrow.ctradelive.view.fragments.ForexOrdersFragment;
//import zw.co.escrow.ctradelive.view.fragments.ForexPortfolioFragment;
//
//public class AuctionViewV1 extends AppCompatActivity implements View.OnClickListener {
//
//    private Toolbar toolbar;
//    private String cdsnumber;
////    private Forex.ForexServicesListener forexServicesListener;
//    private FragmentPagerItemAdapter auctionPagerAdapter;
//    private ViewPager auctionPager;
//    private SmartTabLayout auctionPagerTab;
//    private TextView txt1,txt2,txt3,txt4;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_auction_view);
//        toolbar = findViewById(R.id.toolbar);
//        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
//        toolbar.setTitle("FX Auction");
//        toolbar.setNavigationOnClickListener((v)->finish());
//
//        cdsnumber = getIntent().getExtras().getString("cdsnumber");
//
//        txt1 = findViewById(R.id.v_cash);
//        txt2 = findViewById(R.id.a_cash);
//        txt3 = findViewById(R.id.bal_cash);
//        txt4 = findViewById(R.id.forex_balance_cash);
//
//        findViewById(R.id.chipViewTxn).setOnClickListener(this);
//        findViewById(R.id.chipWithdraw).setOnClickListener(this);
//        findViewById(R.id.chipDeposit).setOnClickListener(this);
//        findViewById(R.id.chipBuy).setOnClickListener(this);
//
//        forexServicesListener = new ForexService(this);
//        forexServicesListener.onGetForexBalances(cdsnumber,txt1,txt2,txt3,txt4);
//        setUpAuction();
//    }
//
//    @Override
//    public void onClick(View view) {
//
//        switch(view.getId()){
//            case R.id.chipViewTxn:
//                new CPayCashDialog(this,cdsnumber).show();
//                break;
//            case R.id.chipDeposit:
//                startActivityForResult(new Intent(this, DepositActivity.class), Constants.DEPOSIT_REQUEST_CODE);
//                break;
//            case R.id.chipWithdraw:
//                startActivityForResult(new Intent(this, WithdrawActivity.class), Constants.WITHDRAW_REQUEST_CODE);
//                break;
//            case R.id.chipBuy:
//                startActivity(new Intent(this,AuctionTradeView.class).putExtra("cdsnumber",cdsnumber));
//                break;
//        }
//    }
//
//    private void setUpAuction(){
//        auctionPagerAdapter = new FragmentPagerItemAdapter(
//                getSupportFragmentManager(), FragmentPagerItems.with(this)
//                .add("PORTFOLIO", ForexPortfolioFragment.class)
//                .add("ORDERS", ForexOrdersFragment.class)
//                .create());
//        auctionPager = findViewById(R.id.viewPagerAuction);
//        auctionPager.setAdapter(auctionPagerAdapter);
//
//        auctionPagerTab = findViewById(R.id.viewpagertab);
//        auctionPagerTab.setViewPager(auctionPager);
//    }
//}