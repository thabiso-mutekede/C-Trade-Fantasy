package zw.co.escrow.ctradelive;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ProgressBar;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.github.ybq.android.spinkit.style.MultiplePulseRing;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Utils {

    private Activity activity;
    private ProgressBar loadingSpinner;
    private MultiplePulseRing multiplePulseRing;

    public Utils(Activity activity) {
        this.activity = activity;
    }


    //Sets the status bar color to color primary dark
    public static void setStatusBarColor(Activity activity){
        Window window = activity.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(ContextCompat.getColor(activity, R.color.colorPrimaryDark));
    }


    // This populates all or any material dropdown boxes in the app
    public void setDropdownBoxes(String[] dropdown_items, int dropdown_id){

        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity, R.layout.dropdown_menu_popup_item, dropdown_items);
        AutoCompleteTextView editTextFilledExposedDropdown =  activity.findViewById(dropdown_id);
        editTextFilledExposedDropdown.setAdapter(adapter);

    }

    // This populates all or any material dropdown boxes in the app
    public void setDropdownBoxes(String[] dropdown_items, int dropdown_id, View view){

        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity, R.layout.dropdown_menu_popup_item, dropdown_items);
        AutoCompleteTextView editTextFilledExposedDropdown =  view.findViewById(dropdown_id);
        editTextFilledExposedDropdown.setAdapter(adapter);

    }


    public void startNewFragment(View view, Fragment fragment, Object object){

        fragment.getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.container_create_account_layout, (Fragment) object, "findThisFragment")
                .addToBackStack(null)
                .commit();

    }

    public void openWebPage(String url) {
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if (intent.resolveActivity(activity.getPackageManager()) != null) {
            activity.startActivity(intent);
        }
    }

    public boolean validateEmail(String email, Matcher matcher, Pattern pattern) {
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public boolean validatePassword(String password) {
        return password.length() >= 4;
    }


    public void showLoadingSpinner(View view){
        loadingSpinner = view.findViewById(R.id.loadingSpinner);
        multiplePulseRing = new MultiplePulseRing();
        loadingSpinner.setIndeterminateDrawable(multiplePulseRing);
        loadingSpinner.setVisibility(View.VISIBLE);

    }

    public void removeLoadingSpinner(View view){
        loadingSpinner = view.findViewById(R.id.loadingSpinner);

        loadingSpinner.setVisibility(View.VISIBLE);

    }




}
