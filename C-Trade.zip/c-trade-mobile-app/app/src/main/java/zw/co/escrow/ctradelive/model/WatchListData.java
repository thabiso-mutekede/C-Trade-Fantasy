package zw.co.escrow.ctradelive.model;

public class WatchListData {
}