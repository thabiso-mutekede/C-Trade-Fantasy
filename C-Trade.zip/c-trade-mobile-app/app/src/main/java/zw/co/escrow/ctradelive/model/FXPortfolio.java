package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class FXPortfolio implements Parcelable {
    
    private String Description;
    private String state;
    private String amount;
    private String currency;
    private String auctionId;
    private String purpose;
    private Boolean is_rollover;
    private String datePosted;

    protected FXPortfolio(Parcel in) {
        Description = in.readString();
        state = in.readString();
        amount = in.readString();
        currency = in.readString();
        auctionId = in.readString();
        purpose = in.readString();
        byte tmpIs_rollover = in.readByte();
        is_rollover = tmpIs_rollover == 0 ? null : tmpIs_rollover == 1;
        datePosted = in.readString();
    }

    public static final Creator<FXPortfolio> CREATOR = new Creator<FXPortfolio>() {
        @Override
        public FXPortfolio createFromParcel(Parcel in) {
            return new FXPortfolio(in);
        }

        @Override
        public FXPortfolio[] newArray(int size) {
            return new FXPortfolio[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(Description);
        parcel.writeString(state);
        parcel.writeString(amount);
        parcel.writeString(currency);
        parcel.writeString(auctionId);
        parcel.writeString(purpose);
        parcel.writeByte((byte) (is_rollover == null ? 0 : is_rollover ? 1 : 2));
        parcel.writeString(datePosted);
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(String auctionId) {
        this.auctionId = auctionId;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Boolean getIs_rollover() {
        return is_rollover;
    }

    public void setIs_rollover(Boolean is_rollover) {
        this.is_rollover = is_rollover;
    }

    public String getDatePosted() {
        return datePosted;
    }

    public void setDatePosted(String datePosted) {
        this.datePosted = datePosted;
    }
}
