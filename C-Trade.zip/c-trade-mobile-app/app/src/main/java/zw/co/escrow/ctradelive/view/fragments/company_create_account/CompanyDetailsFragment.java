package zw.co.escrow.ctradelive.view.fragments.company_create_account;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class CompanyDetailsFragment extends Fragment  implements View.OnClickListener {

    private static final String ARG_SECTION_NUMBER = "DETAILS";
    private Date real_date;
    private TextView dobTXT;
    private SimpleDateFormat dateFormatter,dateValidatorFormatter;
    private DatePickerDialog fromDatePickerDialog;
    private LoginViewModel loginViewModel;
    private Utils utils;
    private RegistrationData registrationData;
    private TextInputLayout outlinedTextFieldCompanyName, outlinedTextFieldAddress, outlinedTextFieldCertInCorp, outlinedTextFieldEmail, outlinedTextFieldPhone, outlinedTextFieldMobileNumber, outlinedTextFieldCity
    , outlinedTextFieldDateInCorp, outlinedTextFieldCompanyPassword, outlinedTextFieldCountryInCorp;





    public static CompanyDetailsFragment newInstance(RegistrationData registrationData) {
        CompanyDetailsFragment fragment = new CompanyDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;

        if (getArguments() != null){
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_company_details, container, false);

        initWidgets(root);
        setDateTimeField();

        utils = new Utils(getActivity());

        dobTXT = root.findViewById(R.id.txtTextFieldDateInCorp);

        dateFormatter = new SimpleDateFormat("dd MMM yyyy", Locale.US);
        dateValidatorFormatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);


        String[] countries = new String[] {"Zimbabwe", "South Africa", "Botswana", "Zambia"};

        utils.setDropdownBoxes(countries, R.id.country_incorp_dropdown_items, root);
        Map<String, String> detailsMap = new HashMap<>();


        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }

        if(registrationData.getRegistrationSession().isDetailsDone())setUpFields();

        root.findViewById(R.id.btnNext).setOnClickListener(v->{

            if(validateFields()) {
                String company_name = outlinedTextFieldCompanyName.getEditText().getText().toString()
                        ,company_address = outlinedTextFieldAddress.getEditText().getText().toString()
                        ,cert_incorp = outlinedTextFieldCertInCorp.getEditText().getText().toString()
                        ,company_email = outlinedTextFieldEmail.getEditText().getText().toString()
                        ,phone = outlinedTextFieldPhone.getEditText().getText().toString()
                        ,company_mobile_number = outlinedTextFieldMobileNumber.getEditText().getText().toString()
                        ,city = outlinedTextFieldCity.getEditText().getText().toString()
                        ,date_incorp = real_date == null ? registrationData.getDetails().getDob() : dateValidatorFormatter.format(real_date)
                        ,company_password = outlinedTextFieldCompanyPassword.getEditText().getText().toString()
                        ,country_incorp = outlinedTextFieldCountryInCorp.getEditText().getText().toString();


                registrationData.getDetails().setForenames(company_name);
                registrationData.getDetails().setAdd1(company_address);
                registrationData.getDetails().setIdnoPP(cert_incorp);
                registrationData.getDetails().setEmail(company_email);
                registrationData.getDetails().setMobile(company_mobile_number);
                registrationData.getDetails().setCity(city);
                registrationData.getDetails().setTel(phone);
                registrationData.getDetails().setDob(date_incorp);
                registrationData.setPassword(company_password);
                registrationData.getDetails().setNationality(country_incorp);
                utils.startNewFragment(root, CompanyDetailsFragment.this, CompanySignatoryFragment.newInstance(registrationData));
            }
        });
        return root;
    }

    private void setUpFields() {
        outlinedTextFieldCompanyName.getEditText().setText(registrationData.getDetails().getForenames());
        outlinedTextFieldAddress.getEditText().setText(registrationData.getDetails().getAdd1());
        outlinedTextFieldCertInCorp.getEditText().setText(registrationData.getDetails().getIdnoPP());
        outlinedTextFieldEmail.getEditText().setText(registrationData.getDetails().getEmail());
        outlinedTextFieldMobileNumber.getEditText().setText(registrationData.getDetails().getMobile());
        outlinedTextFieldCity.getEditText().setText(registrationData.getDetails().getCity());
        outlinedTextFieldPhone.getEditText().setText(registrationData.getDetails().getTel());
        outlinedTextFieldCompanyPassword.getEditText().setText(registrationData.getPassword());
        outlinedTextFieldCountryInCorp.getEditText().setText(registrationData.getDetails().getNationality());
        dobTXT.setText(registrationData.getDetails().getDob());

    }

    private boolean validateFields(){
        if(outlinedTextFieldCompanyName.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldCompanyName.setError("Enter Company Name");
            return false;
        }
        if(outlinedTextFieldAddress.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldAddress.setError("Enter Company Physical Address");
            return false;
        }
        if(outlinedTextFieldCertInCorp.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldCertInCorp.setError("Enter Certificate Number");
            return false;
        }
        if(outlinedTextFieldEmail.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldEmail.setError("Enter Company Email Address");
            return false;
        }
        if(outlinedTextFieldMobileNumber.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldMobileNumber.setError("Enter Company Phone Number");
            return false;
        }
        if(outlinedTextFieldCity.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldCity.setError("Enter City");
            return false;
        }
        if(outlinedTextFieldPhone.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldPhone.setError("Enter Company Phone");
            return false;
        }
        if(outlinedTextFieldCompanyPassword.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldCompanyPassword.setError("Enter Password");
            return false;
        }
        if(outlinedTextFieldCountryInCorp.getEditText().getText().toString().equalsIgnoreCase("")){
            outlinedTextFieldCountryInCorp.setError("Enter Country Of Incorporation");
            return false;
        }
        return true;
    }

    private void initWidgets(View view){

        outlinedTextFieldCompanyName =view.findViewById(R.id.outlinedTextFieldCompanyName);
        outlinedTextFieldAddress =view.findViewById(R.id.outlinedTextFieldAddress);
        outlinedTextFieldCertInCorp =view.findViewById(R.id.outlinedTextFieldCertInCorp);
        outlinedTextFieldEmail =view.findViewById(R.id.outlinedTextFieldEmail);
        outlinedTextFieldMobileNumber =view.findViewById(R.id.outlinedTextFieldMobileNumber);
        outlinedTextFieldCity =view.findViewById(R.id.outlinedTextFieldCity);
        outlinedTextFieldPhone=view.findViewById(R.id.outlinedTextFieldPhone);
        outlinedTextFieldCompanyPassword =view.findViewById(R.id.outlinedTextFieldCompanyPassword);
        outlinedTextFieldCountryInCorp=view.findViewById(R.id.outlinedTextFieldCountryInCorp);

        view.findViewById(R.id.txtTextFieldDateInCorp).setOnClickListener(this);

    }


    @SuppressLint("ResourceAsColor")
    private void setDateTimeField() {
        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(getContext(),
                (view, year, monthOfYear, dayOfMonth) -> {
                    Calendar newDate = Calendar.getInstance();
                    newDate.set(year, monthOfYear, dayOfMonth);
                    dobTXT.setText(dateFormatter.format(newDate.getTime()));
                    real_date = newDate.getTime();
                }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH),
                newCalendar.get(Calendar.DAY_OF_MONTH));

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.txtTextFieldDateInCorp){
            Log.d("lloda","posted _ ");

            fromDatePickerDialog.show();

            fromDatePickerDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.WHITE);
            fromDatePickerDialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(Color.WHITE);
            fromDatePickerDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.WHITE);
        }
    }
}