package zw.co.escrow.ctradelive.view;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.view.fragments.AvailableTrustFragment;
import zw.co.escrow.ctradelive.view.fragments.UnitTrustOrdersFragment;
import zw.co.escrow.ctradelive.view.fragments.UnitTrustPortfolioFragment;

public class UnitTrustActivity extends AppCompatActivity {

    private Utils utils;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    private ExtendedFloatingActionButton fabAutoTrade;
    private Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_trust);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(UnitTrustActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("UNIT TRUST");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }



        fabAutoTrade = findViewById(R.id.fabAutoTrade);

        /*fabAutoTrade.setOnClickListener(view -> {
            startActivityForResult(new Intent(this, AutoTradePostingActivity.class), Constants.AUTO_TRADE_REQUEST_CODE);
        });*/
        setUpWatchList();


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpWatchList(){

        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("AVAILABLE TRUSTS", AvailableTrustFragment.class)
                .add("MY TRANSACTIONS", UnitTrustOrdersFragment.class)
                .add("MY PORTFOLIO", UnitTrustPortfolioFragment.class)
                .create());
        watchListPager = findViewById(R.id.viewPagerWatchList);
        watchListPager.setAdapter(watchListPagerAdapter);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPagerTab.setViewPager(watchListPager);
    }




}