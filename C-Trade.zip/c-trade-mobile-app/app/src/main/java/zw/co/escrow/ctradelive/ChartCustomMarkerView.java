package zw.co.escrow.ctradelive;

import android.annotation.SuppressLint;
import android.content.Context;
import android.widget.TextView;

import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;

import java.util.List;


@SuppressLint("ViewConstructor")
public class ChartCustomMarkerView extends MarkerView {
    TextView markerViewText;

    private MPPointF mOffset;

    private List<String> dates;

    @SuppressWarnings("SameParameterValue")
    public ChartCustomMarkerView(Context context, int layoutResource, List<String> dates) {
        super(context, layoutResource);
        this.dates = dates;
        markerViewText = findViewById(R.id.chart_marker_view_text);
    }

    @Override
    public void refreshContent(Entry e, Highlight highlight) {

        float focusedPrice = e.getY();
        int dateIndex = Math.round(highlight.getX());

        if (!dates.isEmpty()) {
            String date = dates.get(dateIndex);
            String price = StringUtils.getPrice(focusedPrice);

            markerViewText.setText(String.format("%s: %s", date, price));
            super.refreshContent(e, highlight);
        }

    }

    @Override
    public MPPointF getOffset() {

        if (mOffset == null) {
            mOffset = new MPPointF(-(getWidth()), -getHeight());
        }

        return mOffset;
    }
}
