package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author Godwin Tavirimirwa
 */
public class Counter implements Parcelable {
    private String title;
    private String heading;
    private String change;
    private String issuedShares;

    public Counter() {
    }

    public Counter(String title, String heading, String change, String issuedShares) {
        this.title = title;
        this.heading = heading;
        this.change = change;
        this.issuedShares = issuedShares;
    }

    protected Counter(Parcel in) {
        title = in.readString();
        heading = in.readString();
        change = in.readString();
        issuedShares = in.readString();
    }

    public static final Creator<Counter> CREATOR = new Creator<Counter>() {
        @Override
        public Counter createFromParcel(Parcel in) {
            return new Counter(in);
        }

        @Override
        public Counter[] newArray(int size) {
            return new Counter[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public String getHeading() {
        return heading;
    }

    public String getChange() {
        return change;
    }

    public String getIssuedShares() {
        return issuedShares;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeString(heading);
        parcel.writeString(change);
        parcel.writeString(issuedShares);
    }
}
