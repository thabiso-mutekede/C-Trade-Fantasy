package zw.co.escrow.ctradelive.view;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;

public class AutoTradePostingActivity extends AppCompatActivity {

    private Utils utils;
    private static final String TAG = "AutoTradePostingActivit";

    private TextInputLayout outlinedTextFieldCompany, outlinedTextFieldInstruction, outlinedTextFieldBroker, outlinedTextFieldPriceLimit, outlinedTextFieldTimeInForce, outlinedTextFieldInputUnits;
    private String company, price, priceLimit, units, cdsNumber, selectedInstruction, expiresOn, selectedCompany, felloverip1, felloverip2,
            currentExchange, whatsSelected, entityType, corpName = null, corporateId = null, orderTypes, add_info_url, add_info_urlc, add_info_urlg,
            ip, mobileapi, timeInForce, brokr;
    private boolean orRetryFetchCompanies = false;
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog fromDatePickerDialog;
    private List<String> allCompanies = new ArrayList<>();
    private List<String> allOrganizations = new ArrayList<>();
    private Map<String, String> brokerThreshold = new HashMap<>();
    private Map<String, String> allOrganisationsMap = new HashMap<>();
    private Map<String, String> allCompaniesMap = new HashMap<>();
    List<String> allBrokers = new ArrayList<>();

    private AppConfig appConfig;
    private ProgressBar progressBar;
    private TextView validUntil, membership, storedPrice, currentPrice;
    private Button btnPost;
    private    String[] orderTimeinForce = new String[]{"Day Order (DO)", "Good Till Cancelled (GTC)"
            , "Immediate/Cancel Order (IOC)", "Good Till Day (GTD)"};
    private Toolbar toolbar;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_trade);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(AutoTradePostingActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("AUTO-TRADE");


        toolbar=findViewById(R.id.home_toolbar);

        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }

        initWidgets();


        allCompanies.clear();
        allOrganisationsMap.clear();
        allCompaniesMap.clear();
        brokerThreshold.clear();
        appConfig = (AppConfig) getApplication();
        ip = AppConfig.getIpAddress();
        mobileapi = AppConfig.getMobileApiAddress();
        currentExchange = "ZSE";
        selectedCompany = null;
        orderTypes = "Day";
        company = "any";

        fetchListedCompanies();

        allOrganizations.clear();


        String[] instructions = new String[] {"Alert me", "Auto Post Buy", "Auto Post Sell"};

  
        utils.setDropdownBoxes(instructions, R.id.instruction_dropdown_items);
        utils.setDropdownBoxes(orderTimeinForce, R.id.time_in_force_dropdown_items);


        outlinedTextFieldInstruction.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


                String hint = "Price limit";
                if (charSequence.toString().equalsIgnoreCase("Alert Me")) {
                    outlinedTextFieldInputUnits.setVisibility(View.GONE);
                }
                else if (charSequence.toString().equalsIgnoreCase("Auto Post Buy")) {
                    hint = "Price Limit (Lower)";
                    outlinedTextFieldInputUnits.setVisibility(View.VISIBLE);

                }
                else if (charSequence.toString().equalsIgnoreCase("Auto Post Sell")) {
                    hint = "Price Limit (Upper)";
                    outlinedTextFieldInputUnits.setVisibility(View.VISIBLE);

                }

                outlinedTextFieldPriceLimit.getEditText().setHint(hint);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        outlinedTextFieldCompany.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (!charSequence.toString().equalsIgnoreCase("Select company")) {
                    storedPrice.setVisibility(View.VISIBLE);

                    //Todo add loading spinner

                    appConfig = (AppConfig) getApplication();
                    ip = AppConfig.getIpAddress();

                    add_info_url = "https://" + ip + "/GetSecurities";
                    StringRequest jsonObjRequestz =
                            new StringRequest(Request.Method.POST, add_info_url,
                                    successListenerFetchSecurities(),
                                    errorListenerFetchSecurities()) {
                                protected Map<String, String> getParams() {
                                    Map<String, String> params = new HashMap<>();
                                    params.put("company", charSequence.toString());
                                    params.put("exchange", "ZSE");
                                    return params;
                                }
                            };

                    jsonObjRequestz.setRetryPolicy(new DefaultRetryPolicy(
                            AppConfig.REASONABLE_RETRY_MS,
                            0,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                    AppConfig.getInstance().addToRequestQueue(jsonObjRequestz);
                }
                else {
                    storedPrice.setText(getString(R.string.empty));
                    storedPrice.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });





        appConfig = (AppConfig) getApplication();
        ip = AppConfig.getIpAddress();
        SharedPreferences prfs = getSharedPreferences(getString(R.string.CTRADE), Context.MODE_PRIVATE);
        brokr = prfs.getString("broker", "");
        cdsNumber = prfs.getString("cds_number", "");
        whatsSelected = prfs.getString(getString(R.string.entity_type), "");
        corpName = prfs.getString(getString(R.string.corp_name), "");
        corporateId = prfs.getString(getString(R.string.corp_cds_number), "");

        fetchBrokers();

        if (brokr.equals("")) {
            //fetchBrokers();
        } else {
           // Todo brkz.setVisibility(View.GONE);
        }

        btnPost.setOnClickListener(view -> {

            company = outlinedTextFieldCompany.getEditText().getText().toString();
            selectedInstruction = outlinedTextFieldInstruction.getEditText().getText().toString();
            String broker = outlinedTextFieldBroker.getEditText().getText().toString();
            priceLimit = outlinedTextFieldPriceLimit.getEditText().getText().toString();
            price = currentPrice.getText().toString();
            units = outlinedTextFieldInputUnits.getEditText().getText().toString();
            timeInForce = outlinedTextFieldTimeInForce.getEditText().getText().toString();

            

            if (company.equals("") || company.equals("0")) {
                outlinedTextFieldCompany.setError("Please select company");
            }
            else if (selectedInstruction.equals("") || selectedInstruction.equals("0")){
                outlinedTextFieldInstruction.setError("Please select selectedInstruction");

            }
            else if (broker.equals("") || broker.equals("0")){
                outlinedTextFieldBroker.setError("Please select broker");

            }
            else if (priceLimit.equals("") || priceLimit.equals("0")){
                outlinedTextFieldPriceLimit.setError("Please enter price limit");

            }
            else if (outlinedTextFieldInputUnits.getVisibility() == View.VISIBLE && units == null){
                outlinedTextFieldInputUnits.setError("Please enter number of units");

            }
            else {




                if (selectedInstruction.equalsIgnoreCase("Auto Post Buy")) {
                    selectedInstruction = "BUY";
                } else if (selectedInstruction.equalsIgnoreCase("Auto Post Sell")) {
                    selectedInstruction = "SELL";
                }





                    if (selectedInstruction.equalsIgnoreCase("Alert Me")) {

                        attemptPostAlert(allCompaniesMap.get(company), cdsNumber, priceLimit);

                    }
                else {

                        new AlertDialog.Builder(AutoTradePostingActivity.this)
                                .setCancelable(false)
                                .setMessage("Post Auto trade? "
                                        + "\nQuantity: " + units
                                        + "\nCompany: " + allCompaniesMap.get(company)
                                        + "\nTif: " + timeInForce
                                        + "\nSelected Instruction: " + selectedInstruction
                                        + "\nPrice: " + price)
                                .setPositiveButton("Place Order", (dialog, which) -> {


                                    //Todo remove loading spinner

                                    PostingOrders postingOrders = new PostingOrders();
                                    postingOrders.execute(allCompaniesMap.get(company), "EQUITY",
                                            timeInForce, selectedInstruction, orderTypes,
                                            units, price, cdsNumber,
                                            broker, "mobile", "", "", expiresOn, "AUTO TRADE");
                                })
                                .setNegativeButton("Cancel", (dialog, which) -> {

                                })
                                .show();

                    }

            }

        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initWidgets(){
        outlinedTextFieldCompany =findViewById(R.id.outlinedTextFieldCompany);
        outlinedTextFieldInstruction =findViewById(R.id.outlinedTextFieldInstruction);
        outlinedTextFieldBroker =findViewById(R.id.outlinedTextFieldBroker);
        outlinedTextFieldPriceLimit =findViewById(R.id.outlinedTextFieldPriceLimit);
        outlinedTextFieldTimeInForce =findViewById(R.id.outlinedTextFieldTimeInForce);
        outlinedTextFieldInputUnits =findViewById(R.id.outlinedTextFieldInputUnits);

        


        progressBar = findViewById(R.id.progressBarOp);
        btnPost = findViewById(R.id.btnPost);
        validUntil = findViewById(R.id.validUntil);
        membership = findViewById(R.id.membership);
        currentPrice = findViewById(R.id.currentPrice);
        storedPrice = findViewById(R.id.storedPrice);

        


    }

    private void fetchListedCompanies() {

        //Todo add loading spinner

        if (orRetryFetchCompanies) {
            Toast.makeText(AutoTradePostingActivity.this,
                    R.string.retry_on_fellover, Toast.LENGTH_SHORT).show();
            add_info_urlc = felloverip2 + "/GetMyCompanies";
        } else {
            add_info_urlc = AppConfig.getIp() + "/GetMyCompanies";
        }

        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST, add_info_urlc,
                successListenerFetchCompanies(),
                errorListenerFetchCompanies()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("company", company);
                params.put("exchange", currentExchange);
                return params;
            }
        };

        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    private void fetchBrokers() {

        //Todo add loading spinner


        add_info_urlg = AppConfig.getFullMobileApiAddress() + "/GetBrokers";

        StringRequest jsonObjRequest2 = new StringRequest(Request.Method.POST, add_info_urlg,
                successListenerFetchBrokers(),
                errorListenerFetchBrokers()) {

        };

        jsonObjRequest2.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest2);
    }

    private Response.Listener<String> successListenerFetchBrokers() {
        return response -> {
            try {
                //Todo remove loading spinner


                JSONArray jsonArray = new JSONArray(response);

                if (jsonArray.length() > 0) {
                    allBrokers.add("Please Select");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String broker = jsonObject.optString("Code");
                        String threshold = jsonObject.optString("threshold");

                        brokerThreshold.put(broker, threshold);
                        allBrokers.add(broker);
                    }
                    

                } 
                else {
                    allBrokers.add("No brokers");
                }
                String[] brokers = allBrokers.toArray(new String[0]);
                utils.setDropdownBoxes(brokers, R.id.broker_dropdown_items);
                
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener errorListenerFetchBrokers() {
        return error -> {
            try {
                //Todo remove loading spinner

                new AlertDialog.Builder(AutoTradePostingActivity.this)
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    private void showDatePicker() {
        dateFormatter = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(AutoTradePostingActivity.this,
                (view, year, monthOfYear, dayOfMonth) -> {
                    Calendar newDate = Calendar.getInstance();
                    newDate.set(year, monthOfYear, dayOfMonth);
                    validUntil.setText(getString(R.string.validuntil).concat(
                            dateFormatter.format(newDate.getTime())));
                    expiresOn = dateFormatter.format(newDate.getTime());
                }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH),
                newCalendar.get(Calendar.DAY_OF_MONTH));
    }

    private boolean isValidField(String pass) {
        return 0 < pass.length();
    }


    private Response.Listener<String> successListenerFetchCompanies() {
        return response -> {

            Log.d("tavman companies ", response);

            try {
                JSONArray jsonArray = new JSONArray(response);
                if (jsonArray.length() > 0) {

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String name = jsonObject.optString("Name");
                        String compInitial = jsonObject.optString("compInitial");
                        price = jsonObject.optString("InitialPrice");
                        currentPrice.setText(price);

                        if (selectedCompany != null &&
                                selectedCompany.equalsIgnoreCase(compInitial)
                                        & allCompanies.size() == 0) {
                            allCompanies.add(0, name);
                            allCompaniesMap.put(name, compInitial);
                        } 
                        else if (selectedCompany != null &&
                                !selectedCompany.equalsIgnoreCase(compInitial) &&
                                allCompanies.size() > 0) {
                            allCompanies.add(name);
                            allCompaniesMap.put(name, compInitial);
                        } 
                        else if (selectedCompany == null & allCompanies.size() == 0) {
                            allCompanies.add(0, "Please Select");
                            allCompanies.add(name);
                            allCompaniesMap.put(name, compInitial);
                        } 
                        else if (selectedCompany == null & allCompanies.size() > 0) {
                            allCompanies.add(name);
                            allCompaniesMap.put(name, compInitial);
                        }
                    }

                    String[] companies = allCompanies.toArray(new String[0]);
                    utils.setDropdownBoxes(companies, R.id.company_dropdown_items);


                    //Todo remove loading spinner
                    

                } else {
                    Toast.makeText(getApplicationContext()
                            , getString(R.string.badnetwork),
                            Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener errorListenerFetchCompanies() {
        return error -> {
            try {
                //Todo remove loading spinner

                if (orRetryFetchCompanies) {
                    new AlertDialog.Builder(AutoTradePostingActivity.this)
                            .setCancelable(false)
                            .setMessage(getString(R.string.badnetwork))
                            .setPositiveButton("OK", (dialog, which) -> {

                            })
                            .show();
                    orRetryFetchCompanies = false;
                } else {
                    orRetryFetchCompanies = true;
                    fetchListedCompanies();
                }
            } catch (Exception e) {
            }
        };
    }

    private void attemptSubmitDemat(String cdsNumber, String certificateNumber, String shares, String company) {

        //Todo add loading spinner
        String url;

        url = AppConfig.getApiV2().concat("/executedemat");

        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST, url,
                secQuestionsSuccessListener(),
                secQuestionsErrorListener()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("cds_number", cdsNumber);
                params.put("certificate_number", certificateNumber);
                params.put("shares", shares.trim());
                params.put("company", company.trim());
                return params;
            }
        };

        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    private Response.Listener<String> secQuestionsSuccessListener() {
        return response -> {

            System.out.println(response);
            //Todo remove loading spinner
            try {

                new AlertDialog.Builder(AutoTradePostingActivity.this)
                        .setTitle("Result")
                        .setCancelable(false)
                        .setMessage(response)
                        .setPositiveButton("OK", (dialog, which) -> {
                            finish();
                            Toast.makeText(getApplicationContext(),
                                    "Login success! ",
                                    Toast.LENGTH_SHORT).show();
                            finish();
                            startActivity(new Intent(AutoTradePostingActivity.this,
                                    MyOrdersActivity.class));
                        })
                        .show();


            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener secQuestionsErrorListener() {
        return error -> {

            //Todo remove loading spinner
            try {

                error.printStackTrace();
                new AlertDialog.Builder(AutoTradePostingActivity.this)
                        .setCancelable(false)
                        .setMessage(R.string.badnetwork)
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();

            } catch (Exception e) {

            }
        };
    }

    private Response.Listener<String> successListenerFetchSecurities() {
        return response -> {
            try {
                /*if (progressDialogs != null)
                    progressDialogs.dismiss();*/
                //Todo remove loading spinner

                JSONArray jsonArray = new JSONArray(response);

                if (jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String instrument = jsonObject.optString("Instrument");
                        String isin = jsonObject.optString("IsinNo");
                        //String price = jsonObject.optString("InitialPrice");
                        //allSecurities.add(instrument);
                        Double ogValue = jsonObject.getDouble("InitialPrice");
                        String price = BigDecimal.valueOf(ogValue).toPlainString();
                        this.price = price;
                        outlinedTextFieldPriceLimit.getEditText().setText("Current Price: " + price);
                        Toast.makeText(AutoTradePostingActivity.this, price, Toast.LENGTH_SHORT).show();
                        appConfig.setCurrentPrice(price);
                        storedPrice.setText(getString(R.string.currentpriceis).concat(price));
                    }
                } else {
                    Toast.makeText(AutoTradePostingActivity.this,
                            "No security for the company", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener errorListenerFetchSecurities() {
        return error -> {
            try {
                //Todo remove loading spinner

                new AlertDialog.Builder(AutoTradePostingActivity.this)
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    @SuppressLint("StaticFieldLeak")
    public class PostingOrders extends AsyncTask<String, Void, String> {
        String add_info_url;

        @Override
        protected void onPreExecute() {
            add_info_url = AppConfig.getApiV2() + "/OrderPostingAutoTrade";
        }

        @Override
        protected String doInBackground(String... args) {
            String company, security, tif, orderTrans, orderType,
                    price, quantity, cdsNumber, source, broker, expiryDate, ostatus, corpName, corpId;
            company = args[0].trim();
            security = args[1];
            tif = args[2];
            orderTrans = args[3];
            orderType = args[4];
            quantity = args[5];
            price = args[6];
            cdsNumber = args[7];
            broker = args[8];
            source = args[9];
            corpName = args[10];
            corpId = args[11];
            expiryDate = args[12];
            ostatus = args[13];
            Log.d("My URL", add_info_url);

            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(new OutputStreamWriter(outputStream,
                                "UTF-8"));

                String data_string;

                data_string =
                        URLEncoder.encode("company", "UTF-8") + "="
                                + URLEncoder.encode(company, "UTF-8")

                                + "&" + URLEncoder.encode("security", "UTF-8") + "=" +
                                URLEncoder.encode(security, "UTF-8")

                                + "&" + URLEncoder.encode("tif", "UTF-8") + "="
                                + URLEncoder.encode(tif, "UTF-8")

                                + "&" + URLEncoder.encode("orderTrans", "UTF-8") + "="
                                + URLEncoder.encode(orderTrans, "UTF-8")

                                + "&" + URLEncoder.encode("orderType", "UTF-8") + "="
                                + URLEncoder.encode(orderType, "UTF-8")

                                + "&" + URLEncoder.encode("quantity", "UTF-8") + "="
                                + URLEncoder.encode(quantity, "UTF-8")

                                + "&" + URLEncoder.encode("price", "UTF-8") + "="
                                + URLEncoder.encode(price, "UTF-8")

                                + "&" + URLEncoder.encode("cdsNumber", "UTF-8")
                                + "=" + URLEncoder.encode(cdsNumber, "UTF-8")

                                + "&" + URLEncoder.encode("broker", "UTF-8")
                                + "=" + URLEncoder.encode(broker, "UTF-8")

                                + "&" + URLEncoder.encode("source", "UTF-8")
                                + "=" + URLEncoder.encode(source, "UTF-8")

                                + "&" + URLEncoder.encode("date_", "UTF-8")
                                + "=" + URLEncoder.encode(expiryDate, "UTF-8")

                                + "&" + URLEncoder.encode("ostatus", "UTF-8")
                                + "=" + URLEncoder.encode(ostatus, "UTF-8");

                Log.d("My URL", data_string);
                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            //Todo remove loading spinner

            Log.d("myTag", result);

            String message;

            if (result.equalsIgnoreCase("1"))
                message = "Your order has been posted successfully!";
            else message = result;

            new AlertDialog.Builder(AutoTradePostingActivity.this)
                    .setTitle(R.string.result)
                    .setCancelable(false)
                    .setMessage(message)
                    //.setMessage(R.string.order_posting_successful)
                    .setPositiveButton("OK", (dialog, which) -> {
                        //Todo in the comment

                         /*       startActivity(new Intent(getApplicationContext(),
                                        TradeNowActivity.class));*/
                                finish();
                            }
                    ).setNegativeButton("Post new order",
                    (dialogInterface, i) -> {
                        AutoTradePostingActivity.this.recreate();
                    })
                    .show();

            //etPrice.getText().c;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //Todo remove loading spinner
            super.onProgressUpdate(values);
        }

    }

    private void attemptPostAlert(String cdsNumber, String company, String price) {

        //Todo add loading spinner
        String url;

        url = AppConfig.getApiV2().concat("/insertalerts");

        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST, url,
                secAlertSuccessListener(),
                secAlertErrorListener()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("company", cdsNumber);
                params.put("cds_number", company);
                params.put("price", price);
                return params;
            }
        };

        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    private Response.Listener<String> secAlertSuccessListener() {
        return response -> {

            System.out.println(response);
            //Todo remove loading spinner
            try {

                new AlertDialog.Builder(AutoTradePostingActivity.this)
                        .setTitle("Result")
                        .setCancelable(false)
                        .setMessage(response)
                        .setPositiveButton("OK", (dialog, which) -> {
                            finish();
                            //Todo in the comment
                   /*         startActivity(new Intent(AutoTradePostingActivity.this,
                                    TradeNowActivity.class));*/
                        })
                        .show();


            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    private Response.ErrorListener secAlertErrorListener() {
        return error -> {

            //Todo remove loading spinner
            try {

                error.printStackTrace();
                new AlertDialog.Builder(AutoTradePostingActivity.this)
                        .setCancelable(false)
                        .setMessage(R.string.badnetwork)
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();

            } catch (Exception e) {

            }
        };
    }


}