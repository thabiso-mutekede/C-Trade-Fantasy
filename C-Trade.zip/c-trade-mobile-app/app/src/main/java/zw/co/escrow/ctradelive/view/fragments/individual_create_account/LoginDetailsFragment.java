package zw.co.escrow.ctradelive.view.fragments.individual_create_account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class LoginDetailsFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";
    private RegistrationData registrationData;
    private LoginViewModel loginViewModel;
    private Utils utils;
    private TextInputLayout outlinedTextFieldEmail, outlinedTextFieldPassword, outlinedTextFieldPasswordConfirm;

    public static LoginDetailsFragment newInstance(RegistrationData registrationData) {
        LoginDetailsFragment fragment = new LoginDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_login_details, container, false);

        initWidgets(root);


        utils = new Utils(getActivity());


        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
            registrationData.getRegistrationSession().setCustodianDone(true);
        }
        if(registrationData.getRegistrationSession().isCredentialsDone())setUpFields();
        root.findViewById(R.id.btnNext).setOnClickListener(v->{


            String email = outlinedTextFieldEmail.getEditText().getText().toString()
                    ,password = outlinedTextFieldPassword.getEditText().getText().toString()
                    ,passwordConfirm = outlinedTextFieldPasswordConfirm.getEditText().getText().toString();


            if (email.equals("")) {
                outlinedTextFieldEmail.setError("Please add email");
            }
            else if (password.equals("")) {
                outlinedTextFieldPassword.setError("Please add password");

            }
            else if (passwordConfirm.equals("")) {
                outlinedTextFieldPasswordConfirm.setError("Please confirm password");

            }
            else if(!password.equals(passwordConfirm)){
                outlinedTextFieldPassword.setError("Passwords do not match");
                outlinedTextFieldPasswordConfirm.setError("Passwords do not match");
            }
            else {
                registrationData.getDetails().setEmail(email);
                registrationData.setPassword(password);

                utils.startNewFragment(root, LoginDetailsFragment.this, ClientStatusFragment.newInstance(registrationData) );
            }
        });
        return root;
    }

    private void setUpFields() {
        outlinedTextFieldEmail.getEditText().setText(registrationData.getDetails().getEmail());
        outlinedTextFieldPassword.getEditText().setText(registrationData.getPassword());
        outlinedTextFieldPasswordConfirm.getEditText().setText(registrationData.getPassword());
    }

    private void initWidgets(View view){
        outlinedTextFieldEmail =view.findViewById(R.id.outlinedTextFieldEmail);
        outlinedTextFieldPassword =view.findViewById(R.id.outlinedTextFieldPassword);
        outlinedTextFieldPasswordConfirm =view.findViewById(R.id.outlinedTextFieldPasswordConfirm);

    }
}