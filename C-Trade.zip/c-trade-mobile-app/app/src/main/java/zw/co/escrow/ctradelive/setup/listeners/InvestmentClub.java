package zw.co.escrow.ctradelive.setup.listeners;


import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.widget.TextView;

import zw.co.escrow.ctradelive.model.ClubModel;


public class InvestmentClub {
    public interface ClubServicesListener{
        void onLoadMembership(String cdsNumber);
        void onLoadMyClubs(String cdsNumber);
        void onLoadContribution(String cdsnumber, TextView txt1, TextView txt2);
        void onLoadInvestments(String isMember, boolean isInGroup, TextView txt1, TextView txt2);
        void onLoadClubInvestments(String gcdsnumber, String mcdsnumba, TextView txt1, TextView txt2);
        void onSearchCTradeClubs(String cdsNumber);
        void onLoadMyContribution(String cds, TextView txt1, TextView txt2);
        void onLoadCTradeUsers(String name, String clubCdsNumber, String clubname);
        void onSendRequest(String gcdsnum, String mcdsnum, String gphone, String gname, String type, String reqBy, String mphone);
        void onLoadRequest(String cdsnumber, String type, String sp, String em);
        void onAcceptRequests(Context context, String token,Boolean accepted);
        void onLoadContribution(String cdsnumber);
        void onLoadClubContributions(String cdsnumber, String mcdsnumber, TextView txt1, TextView txt2);
        void onSearchCTradeClubsByText(String text);
        void onExitClub(String clubCdsNumber, String cdsnumber);
        void onCheckInvestmentTermsAndConditions(String cdsnumber);
        void onAcceptTermsAndConditions(String cdsnumber);
        void onLoadClubOrders(String cdsnumber);
        void onLoadClubTransCompanies(String cdsnumber, InvestmentClub.ClubServicesListener clubServicesListener);
        void onLoadClubStatementOnCompany(String cdsnumber, String company, Dialog dialog);
        void onLoadInvestmentStatementDrillDownForIndividual(String cdsnumber, String clubcdsnumber, String company);
        void onAddClubRequestsURC(String gcdsnumber, String fname, String sname, String email, String phone, String clubphone, String clubname, ClubModel clubModel);

        void onContribute(String cCdsNumber, String mCdsNumber, String amount, Activity activity);
        void onWithdraw(String cCdsNumber,String mCdsNumber,String amount,Activity activity);

    }
    public interface ICRefreshRefreshLister{
        void doRefresh(String msg);
    }

}
