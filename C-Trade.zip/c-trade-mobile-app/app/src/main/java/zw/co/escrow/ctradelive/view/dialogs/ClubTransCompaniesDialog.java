package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.ClubTransCompaniesAdapter;
import zw.co.escrow.ctradelive.model.ClubTransCompany;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.view.ClubHoldingsView;


public class ClubTransCompaniesDialog extends Dialog {

    private RecyclerView ddRv;
    private final InvestmentClub.ClubServicesListener clubServicesListener;
    private Toolbar toolbar;

    public ClubTransCompaniesDialog(@NonNull Context context, List<ClubTransCompany> clubTransCompanies, String title, String clubcdsnumber, InvestmentClub.ClubServicesListener clubServicesListener) {
        super(context);
        this.clubServicesListener = clubServicesListener;

        setContentView(R.layout.drill_down_on_holdings_view);
        findViewById(R.id.drill_down_rv);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> ((ClubHoldingsView)context).finish());
        toolbar.setTitle(title);
        ddRv = findViewById(R.id.drill_down_rv);
        ddRv.setHasFixedSize(true);
        ddRv.setLayoutManager(new LinearLayoutManager(getContext()));

        ClubTransCompaniesAdapter clubTransCompaniesAdapter = new ClubTransCompaniesAdapter(
                clubTransCompanies,
                getContext(),
                this,
                ddRv,
                this.clubServicesListener,clubcdsnumber
        );

        ddRv.setAdapter(clubTransCompaniesAdapter);

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

    }
}
