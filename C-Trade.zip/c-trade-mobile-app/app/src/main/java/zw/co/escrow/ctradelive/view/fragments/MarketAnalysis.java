package zw.co.escrow.ctradelive.view.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MarketDataAdapter;
import zw.co.escrow.ctradelive.model.MDataContaner;
import zw.co.escrow.ctradelive.model.MDisp;
import zw.co.escrow.ctradelive.model.MarketAnalysisData;


public class MarketAnalysis extends Fragment {

    private RecyclerView recyclerView;
    List<MarketAnalysisData> marketAnalysisDataList;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.market_analysis_view,container,false);

        recyclerView = view.findViewById(R.id.market_data_rv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        marketAnalysisDataList = new ArrayList<>();

        getMarketData();

        return view;
    }


    private void getMarketData(){
        //String url = String.format("MArketDataDetails?exchange=ZSE");
        String url = AppConfig.getIp().concat("allSEData");
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, response ->
        {
            try {
                for(int i = 0;i<response.length();i++){
                    JSONObject jsonObject = response.getJSONObject(i);
                    MarketAnalysisData marketAnalysisData = new MarketAnalysisData();
                    marketAnalysisData.setIndexpercentage(jsonObject.getString("indexpercentage"));
                    marketAnalysisData.setSecurityType(jsonObject.getString("SecurityType"));
                    marketAnalysisData.setDateCapture(jsonObject.getString("DateCaptured"));
                    marketAnalysisData.setMarkertCapUSD(jsonObject.getString("MarkertCapUSD"));
                    marketAnalysisData.setMarkertCapZWL(jsonObject.getString("MarkertCapZWL"));
                    marketAnalysisData.setMarkertPercentageIncr_DecreZWL(jsonObject.getString("MarkertPercentageIncr_DecreZWL"));
                    marketAnalysisData.setMarkertPercentageIncr_DecreUSD(jsonObject.getString("MarkertPercentageIncr_DecreUSD"));
                    marketAnalysisData.setTurnOverPercentageIncrease_DecrZWL(jsonObject.getString("TurnOverPercentageIncrease_DecrZWL"));
                    marketAnalysisData.setTurnOverPercentageIncrease_DecrUSD(jsonObject.getString("TurnOverPercentageIncrease_DecrUSD"));
                    marketAnalysisData.setIndex(jsonObject.getString("Index"));
                    marketAnalysisData.setVolumeTrade(jsonObject.getString("VolumeTrade"));
                    marketAnalysisData.setSecuritySubType(jsonObject.getString("SecuritySubType"));
                    marketAnalysisData.setTurnoverUSD(jsonObject.getString("turnoverUSD"));
                    marketAnalysisData.setTurnoverZWL(jsonObject.getString("turnoverZWL"));
                    marketAnalysisData.setBlackMarketBond(jsonObject.getString("BlackMarketBond"));
                    marketAnalysisData.setBlackMarketRTGS(jsonObject.getString("BlackMarketRTGS"));
                    marketAnalysisData.setBlackMarketZWL(jsonObject.getString("BlackMarketZWL"));
                    marketAnalysisData.setBlackmarkertBondPercentage(jsonObject.getString("blackmarkertBondPercentage"));
                    marketAnalysisData.setBlackmarkertRTSPercentage(jsonObject.getString("blackmarkertRTSPercentage"));
                    marketAnalysisData.setBlackmarkertZWLPercentage(jsonObject.getString("blackmarkertZWLPercentage"));
                    marketAnalysisDataList.add(marketAnalysisData);
                }


                List<MDataContaner> mDataContanerList = new ArrayList<>();
                for (MarketAnalysisData marketAnalysisData:marketAnalysisDataList){
                    String se = marketAnalysisData.getSecurityType();
                    List<MDisp> mDispList = new ArrayList<>();
                    if(se.equalsIgnoreCase("EQUITY")){
                        MDisp capital = new MDisp();
                        MDisp turnover = new MDisp();
                        MDisp capitalZWL = new MDisp();
                        MDisp turnoverZWL = new MDisp();
                        MDisp index = new MDisp();
                        MDisp  volume_traded = new MDisp();

                        capital.setAmount(marketAnalysisData.getMarkertCapUSD());
                        capital.setTitle("CAPITAL");
                        capital.setCurrencyDisplay("USD");
                        capital.setRate(marketAnalysisData.getMarkertPercentageIncr_DecreUSD());

                        turnover.setAmount(marketAnalysisData.getTurnoverUSD());
                        turnover.setTitle("turnover");
                        turnover.setCurrencyDisplay("USD");
                        turnover.setRate(marketAnalysisData.getTurnOverPercentageIncrease_DecrUSD());

                        capitalZWL.setAmount(marketAnalysisData.getMarkertCapZWL());
                        capitalZWL.setTitle("CAPITAL");
                        capitalZWL.setCurrencyDisplay("ZWL");
                        capitalZWL.setRate(marketAnalysisData.getMarkertPercentageIncr_DecreZWL());

                        turnoverZWL.setAmount(marketAnalysisData.getTurnoverZWL());
                        turnoverZWL.setTitle("turnover");
                        turnoverZWL.setCurrencyDisplay("ZWL");
                        turnoverZWL.setRate(marketAnalysisData.getTurnOverPercentageIncrease_DecrZWL());

                        index.setAmount(marketAnalysisData.getIndex());
                        index.setTitle("INDEX");
                        index.setCurrencyDisplay("");
                        index.setRate(marketAnalysisData.getIndexpercentage());

                        volume_traded.setAmount(marketAnalysisData.getVolumeTrade());
                        volume_traded.setTitle("Volume trades");
                        volume_traded.setCurrencyDisplay("");
                        volume_traded.setRate("");

                        mDispList.add(capital);
                        mDispList.add(capitalZWL);
                        mDispList.add(turnover);
                        mDispList.add(turnoverZWL);
                        mDispList.add(index);
                        mDispList.add(volume_traded);
                    }else if(se.equalsIgnoreCase("FOREX")){
                        MDisp rbz = new MDisp();
                        MDisp omir = new MDisp();
                        MDisp blackMarket = new MDisp();
                        MDisp blackMarketBond = new MDisp();

                        rbz.setAmount(marketAnalysisData.getBlackMarketZWL());
                        rbz.setTitle("RBZ");
                        rbz.setCurrencyDisplay("USD : ZWL");
                        rbz.setRate(marketAnalysisData.getBlackmarkertZWLPercentage());

                        omir.setAmount(marketAnalysisData.getOMIR());
                        omir.setTitle("OMIR");
                        omir.setCurrencyDisplay("USD");
                        omir.setRate(marketAnalysisData.getOMIRPercentage());

                        blackMarket.setAmount(marketAnalysisData.getBlackMarketRTGS());
                        blackMarket.setTitle("BLACK\nMARKET");
                        blackMarket.setCurrencyDisplay("USD : ZWL");
                        blackMarket.setRate(marketAnalysisData.getBlackmarkertRTSPercentage());

                        blackMarketBond.setAmount(marketAnalysisData.getBlackMarketBond());
                        blackMarketBond.setTitle("BLACK\nMARKET");
                        blackMarketBond.setCurrencyDisplay("USD : BOND");
                        blackMarketBond.setRate(marketAnalysisData.getBlackmarkertBondPercentage());

                        mDispList.add(rbz);
                        mDispList.add(omir);
                        mDispList.add(blackMarket);
                        mDispList.add(blackMarketBond);
                    }
                    if(mDispList.size()>0) {
                        MDataContaner mDataContaner = new MDataContaner();
                        mDataContaner.setTitle(marketAnalysisData.getSecuritySubType());
                        mDataContaner.setmDispList(mDispList);
                        mDataContanerList.add(mDataContaner);
                    }
                }

                MarketDataAdapter marketDataAdapter = new MarketDataAdapter(getContext(),recyclerView,mDataContanerList);
                recyclerView.setAdapter(marketDataAdapter);
            }catch (Exception e){
                e.printStackTrace();
            }


        },error -> {
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
    }

}
