package zw.co.escrow.ctradelive.view.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import zw.co.escrow.ctradelive.R;

public class MarketWatchPlaceHolderFragment extends Fragment {

    private View view;
    private static final String TAG = "MarketWatchPlaceHolderF";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_market_watch_placeholder,container,false);



        return view;
    }
}