package zw.co.escrow.ctradelive.adapters;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Counter;
import zw.co.escrow.ctradelive.view.UnitsFundsActivity;


/**
 * @author Godwin Tavirimirwa
 */
public class TrustCounterAdapter extends RecyclerView.Adapter<TrustCounterAdapter.MyViewHolder> {

    private List<Counter> counterList;
    private Activity activity;
    private static final String TAG = "TrustCounterAdapter";


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView heading, counterInitial, change;
        //public ImageView imageViewTrend;
        public CardView cardView, wl_change_indicator;
       // public GraphView graph;

        public MyViewHolder(View view) {
            super(view);
            heading = view.findViewById(R.id.tv_heading);
            counterInitial = view.findViewById(R.id.tv_company_initial);
            change = view.findViewById(R.id.tv_change);
            change.setVisibility(View.GONE);
            //graph = view.findViewById(R.id.graph);
            //imageViewTrend = view.findViewById(R.id.image_view_trend);
            cardView = view.findViewById(R.id.cardView);
            wl_change_indicator = view.findViewById(R.id.wl_change_indicator);



        }
    }

    public TrustCounterAdapter(Activity activity, List<Counter> counterList) {
        this.counterList = counterList;
        this.activity = activity;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;

        if (viewType == 0) {
            Log.d(TAG, "onCreateViewHolder: "+"munomu");
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.counter_list_item, parent, false);
            return new MyViewHolder(view);
        }

        return null;    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Counter counter = counterList.get(position);
        holder.heading.setText(counter.getTitle());
        if(counter.getHeading().equals("OMUT")){
            holder.counterInitial.setText("OLD MUTUAL UNIT TRUSTS");
        }else {
            holder.counterInitial.setText(counter.getHeading());
        }


        if (counter.getChange().contains("-")) {
           //holder.imageViewTrend.setImageResource(R.drawable.ic_drop_down);
            holder.wl_change_indicator.setCardBackgroundColor(activity.getResources().getColor(R.color.colorRed));
        } else {
            //holder.imageViewTrend.setImageResource(R.drawable.ic_drop_up);
            holder.wl_change_indicator.setCardBackgroundColor(activity.getResources().getColor(R.color.colorDarkGreen));

        }

        holder.change.setText(counter.getChange());
        // myViewHolder.graph.addSeries(series);

        holder.cardView.setOnClickListener(view -> {
            Toast.makeText(activity, counter.getTitle(), Toast.LENGTH_SHORT).show();

            Intent i = new Intent(activity, UnitsFundsActivity.class);
            Bundle mBundle = new Bundle();
            mBundle.putParcelable("counter",counter);
            i.putExtras(mBundle);
            activity.startActivity(i);

                   /* Intent i = new Intent(activity, UnitsFundsActivity.class);
                    Counter counter= counterList.get(position);
                    Bundle mBundle = new Bundle();
                    mBundle.putParcelable("counter", counter);
                    i.putExtras(mBundle);
                    activity.startActivity(i)*/;

        });

    }



    @Override
    public int getItemCount() {
        return counterList.size();
    }
}
