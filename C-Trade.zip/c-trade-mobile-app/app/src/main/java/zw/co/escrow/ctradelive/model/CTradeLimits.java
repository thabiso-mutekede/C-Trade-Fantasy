package zw.co.escrow.ctradelive.model;

public class CTradeLimits {

    private String LimitType;
    private int Id;
    private float Minimum;
    private float Maximum;

    public String getLimitType() {
        return LimitType;
    }

    public void setLimitType(String limitType) {
        LimitType = limitType;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public float getMinimum() {
        return Minimum;
    }

    public void setMinimum(float minimum) {
        Minimum = minimum;
    }

    public float getMaximum() {
        return Maximum;
    }

    public void setMaximum(float maximum) {
        Maximum = maximum;
    }
}
