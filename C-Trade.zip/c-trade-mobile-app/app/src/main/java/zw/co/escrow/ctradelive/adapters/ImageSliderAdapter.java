package zw.co.escrow.ctradelive.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnSlideTaped;
import zw.co.escrow.ctradelive.model.SliderItem;

public class ImageSliderAdapter extends SliderViewAdapter<ImageSliderAdapter.SliderAdapterVH> {

    private Context context;
    private List<SliderItem> mSliderItems = new ArrayList<>();
    private static final String TAG = "ImageSliderAdapter";
    private OnSlideTaped onSlideTaped;

    public ImageSliderAdapter(Context context) {
        this.context = context;
    }

    public void renewItems(List<SliderItem> sliderItems) {
        this.mSliderItems = sliderItems;
        notifyDataSetChanged();
    }


    @Override
    public SliderAdapterVH onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_slider_layout_item, null);
        inflate.setOnClickListener(view ->{
            if(onSlideTaped != null){
                onSlideTaped.taped();
            }
        });
        return new SliderAdapterVH(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterVH viewHolder, final int position) {

        SliderItem sliderItem = mSliderItems.get(position);

        viewHolder.textViewDescription.setText(sliderItem.getMessage());
        viewHolder.textViewDescription.setTextColor(context.getResources().getColor(R.color.white));
        viewHolder.imageViewBackground.setImageResource(sliderItem.getImageUrl());

        /*Glide.with(context)
                .load( sliderItem.getImageUrl())
                .fitCenter()
                .into(viewHolder.imageViewBackground);*/

    }

    @Override
    public int getCount() {
        //slider view count could be dynamic size
        return mSliderItems.size();
    }

    class SliderAdapterVH extends SliderViewAdapter.ViewHolder {

        View itemView;
        ImageView imageViewBackground;
        ImageView imageGifContainer;
        TextView textViewDescription;

        public SliderAdapterVH(View itemView) {
            super(itemView);
            imageViewBackground = itemView.findViewById(R.id.iv_auto_image_slider);
            imageGifContainer = itemView.findViewById(R.id.iv_gif_container);
            textViewDescription = itemView.findViewById(R.id.tv_auto_image_slider);
            this.itemView = itemView;
        }
    }

    public void setOnSlideTaped(OnSlideTaped onSlideTaped) {
        this.onSlideTaped = onSlideTaped;
    }
}
