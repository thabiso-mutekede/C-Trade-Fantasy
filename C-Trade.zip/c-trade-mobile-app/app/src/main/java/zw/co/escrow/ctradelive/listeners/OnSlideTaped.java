package zw.co.escrow.ctradelive.listeners;

public interface OnSlideTaped {
    void taped();
}
