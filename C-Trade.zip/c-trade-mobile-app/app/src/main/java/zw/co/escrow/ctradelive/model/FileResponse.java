package zw.co.escrow.ctradelive.model;

public class FileResponse {
    String pathName;

    public String getPathName() {
        return pathName;
    }

    public void setPathName(String pathName) {
        this.pathName = pathName;
    }
}
