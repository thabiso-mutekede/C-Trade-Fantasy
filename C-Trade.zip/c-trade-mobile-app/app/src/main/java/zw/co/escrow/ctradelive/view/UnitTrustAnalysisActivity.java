package zw.co.escrow.ctradelive.view;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.toolbox.JsonArrayRequest;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import org.json.JSONObject;

import java.util.Calendar;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.Fundlist;
import zw.co.escrow.ctradelive.view.dialogs.UnitTrustTradeDialog;
import zw.co.escrow.ctradelive.view.fragments.OneDayGraphFragment;

public class UnitTrustAnalysisActivity extends AppCompatActivity {


    private Utils utils;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private String[] unitDetails;
    private TextView txtTicker, txtCompanyName, txtBestBid, txtDay, txtCurrentPrice, txtPercentageChange;
    private Toolbar toolbar;

    private ViewPager viewPager;
    private SmartTabLayout smartTabLayout;
    private TextView txtBestAsk, txtAskVolume, txtIssueDate, txtBidVolume,txtCompany,
            txtPreviousPrice, txtChangePrice, txtFundtype, txtISIN, txtInitialPrice, txtIssuePricePerUnit;
    private static final String TAG = "UnitTrustAnalysisActivi";
    private Fundlist fundlist;
    private String cdsnumber;
    private SharedPreferences sharedPreferences;
    private CardView descLayout;
    private TextView  descText;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_trust_analysis);

        Bundle mArgs = getIntent().getExtras();

        fundlist = mArgs.getParcelable("fundlist");

        sharedPreferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsnumber = sharedPreferences.getString("cds_number", "");


        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(UnitTrustAnalysisActivity.this);

        initWidgets();

        toolbar=findViewById(R.id.home_toolbar);

        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }

        utils = new Utils(this);

        unitDetails = getIntent().getStringArrayExtra(getString(R.string.EXCHANGE));

        Calendar calendar = Calendar.getInstance();



            txtTicker.setText(fundlist.getCompany());
            txtCompanyName.setText(fundlist.getFundType());
            txtBestBid.setText(String.format("%s/unit", fundlist.getIssuePricePerUnit()));
            txtDay.setText(calendar.getTime().toString().substring(0, calendar.getTime().toString().indexOf('G')));
            txtCurrentPrice.setText(String.format("%s", fundlist.getInitialPrice()));
            //txtPercentageChange.setText(unitDetails[5]);

            Log.d(TAG, "onCreate11: "+fundlist.getID());

            txtIssueDate.setText(fundlist.getIssueDate());
            txtCompany.setText(fundlist.getCompany());
            txtInitialPrice.setText(String.format("%s", fundlist.getInitialPrice()));
            txtFundtype.setText(fundlist.getFundType());
            txtIssuePricePerUnit.setText(String.format("%s", fundlist.getIssuePricePerUnit()));


        findViewById(R.id.chipDe_Invest).setOnClickListener(view -> {
            if (cdsnumber.equals("")) {
                startActivity(new Intent(this, LoginActivity2.class));
                finish();
            }else {
                Bundle bundle = new Bundle();
                bundle.putString("orderType",getString(R.string.deinvesttrusts));
                bundle.putString("cds_number",cdsnumber);
                bundle.putParcelable("fundlist", fundlist);
                new UnitTrustTradeDialog(this,bundle).show();
            }
        });

        findViewById(R.id.chipInvest).setOnClickListener(view -> {
            if (cdsnumber.equals("")) {
                startActivity(new Intent(this, LoginActivity2.class));
                finish();
            }else {
                Bundle bundle = new Bundle();
                bundle.putString("orderType",getString(R.string.investtrusts));
                bundle.putString("cds_number",cdsnumber);
                bundle.putParcelable("fundlist", fundlist);
                new UnitTrustTradeDialog(this,bundle).show();
            }
        });
        getCompanyDescription(fundlist.getCompany());
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initWidgets(){
        smartTabLayout = findViewById(R.id.viewpagertab);
        viewPager = findViewById(R.id.viewPagerWatchList);

        txtBestAsk = findViewById(R.id.txtBestAsk);
        txtAskVolume = findViewById(R.id.txtAskVolume);
        txtBestBid = findViewById(R.id.txtBestBid);
        txtBidVolume = findViewById(R.id.txtBidVolume);
        txtCurrentPrice = findViewById(R.id.txtCurrentPrice);
        txtPreviousPrice = findViewById(R.id.txtPreviousPrice);
        txtChangePrice = findViewById(R.id.txtChangePrice);
        txtPercentageChange = findViewById(R.id.txtPercentageChange);
        txtISIN = findViewById(R.id.txtISIN);

        txtIssueDate = findViewById(R.id.txtIssueDate);
        txtCompany = findViewById(R.id.txtCompany);
        txtFundtype = findViewById(R.id.txtFundtype);
        txtInitialPrice = findViewById(R.id.txtInitialPrice);
        txtIssuePricePerUnit = findViewById(R.id.txtIssuePricePerUnit);

        descText = findViewById(R.id.desc_text);
        descLayout = findViewById(R.id.cardViewCompanyDescription);


        //toolbar
        txtTicker = findViewById(R.id.txtTicker);
        txtCompanyName = findViewById(R.id.txtCompanyName);
        txtDay = findViewById(R.id.txtDay);


        setUpWatchList(fundlist);

    }
    private void getCompanyDescription(String company){
        String url = AppConfig.getIp().concat("getCompanyPerfomanceFeeds?company=").concat(company);
        Log.d("lloda",url);
        JsonArrayRequest jr = new JsonArrayRequest(url, response -> {
            try {
                if(response.length() > 0){
                    JSONObject o = response.getJSONObject(0);
                    final SpannableString s =
                            new SpannableString(o.getString("message"));
                    Linkify.addLinks(s, Linkify.WEB_URLS);
                    descText.setGravity(Gravity.CENTER);

                    descText.setText(s);
                    descText.setMovementMethod(LinkMovementMethod.getInstance());
                    descLayout.setVisibility(View.VISIBLE);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        },error -> error.printStackTrace());
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    private void setUpWatchList(Fundlist fundlist){

        Bundle bundle = new Bundle();
        bundle.putStringArray(getString(R.string.EXCHANGE),unitDetails);
        bundle.putString(getString(R.string.EXCHANGE),fundlist.getCompany());



        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("30 Days", OneDayGraphFragment.class, bundle)
                .create());
        viewPager.setAdapter(watchListPagerAdapter);

        smartTabLayout.setViewPager(viewPager);
    }

}