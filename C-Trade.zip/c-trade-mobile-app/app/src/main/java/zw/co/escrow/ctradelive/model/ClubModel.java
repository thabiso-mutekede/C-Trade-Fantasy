package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class ClubModel implements Parcelable {

    private ChairmanModel chairman;
    private String clubName;
    private String clubSigName;
    private String clubCdsNumber;
    private String nbNote;
    private String invNote;
    private String contNote;
    private String mbNote;
    private String message;
    private String last_updated;
    private boolean readMessage;
    private boolean isMember;

    protected ClubModel(Parcel in) {
        chairman = in.readParcelable(ChairmanModel.class.getClassLoader());
        clubName = in.readString();
        clubSigName = in.readString();
        clubCdsNumber = in.readString();
        nbNote = in.readString();
        invNote = in.readString();
        contNote = in.readString();
        mbNote = in.readString();
        message = in.readString();
        last_updated = in.readString();
        readMessage = in.readByte() != 0;
        isMember = in.readByte() != 0;
    }

    public ClubModel() {
    }

    public static final Creator<ClubModel> CREATOR = new Creator<ClubModel>() {
        @Override
        public ClubModel createFromParcel(Parcel in) {
            return new ClubModel(in);
        }

        @Override
        public ClubModel[] newArray(int size) {
            return new ClubModel[size];
        }
    };

    public ChairmanModel getChairman() {
        return chairman;
    }

    public void setChairman(ChairmanModel chairman) {
        this.chairman = chairman;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getClubSigName() {
        return clubSigName;
    }

    public void setClubSigName(String clubSigName) {
        this.clubSigName = clubSigName;
    }

    public String getClubCdsNumber() {
        return clubCdsNumber;
    }

    public void setClubCdsNumber(String clubCdsNumber) {
        this.clubCdsNumber = clubCdsNumber;
    }

    public String getNbNote() {
        return nbNote;
    }

    public void setNbNote(String nbNote) {
        this.nbNote = nbNote;
    }

    public String getInvNote() {
        return invNote;
    }

    public void setInvNote(String invNote) {
        this.invNote = invNote;
    }

    public String getContNote() {
        return contNote;
    }

    public void setContNote(String contNote) {
        this.contNote = contNote;
    }

    public String getMbNote() {
        return mbNote;
    }

    public void setMbNote(String mbNote) {
        this.mbNote = mbNote;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLast_updated() {
        return last_updated;
    }

    public void setLast_updated(String last_updated) {
        this.last_updated = last_updated;
    }

    public boolean isReadMessage() {
        return readMessage;
    }

    public void setReadMessage(boolean readMessage) {
        this.readMessage = readMessage;
    }

    public boolean isMember() {
        return isMember;
    }

    public void setMember(boolean member) {
        isMember = member;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(chairman, flags);
        dest.writeString(clubName);
        dest.writeString(clubSigName);
        dest.writeString(clubCdsNumber);
        dest.writeString(nbNote);
        dest.writeString(invNote);
        dest.writeString(contNote);
        dest.writeString(mbNote);
        dest.writeString(message);
        dest.writeString(last_updated);
        dest.writeByte((byte) (readMessage ? 1 : 0));
        dest.writeByte((byte) (isMember ? 1 : 0));
    }
}
