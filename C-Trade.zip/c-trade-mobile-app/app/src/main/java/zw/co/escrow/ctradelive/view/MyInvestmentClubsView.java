package zw.co.escrow.ctradelive.view;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.view.fragments.MyClubs;

public class MyInvestmentClubsView extends AppCompatActivity {

    /*************private TabLayout tabLayout;
    private ViewPager viewPager;
    private TabAdapter tabAdapter;***********/
    ProgressDialog progressDialog;
    private Toolbar toolbar;
    private SwipeRefreshLayout swipeRefreshLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_investment_clubs_view);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("My Investment CLUBS".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());
        progressDialog = new ProgressDialog(this);
        swipeRefreshLayout = findViewById(R.id.refresher);
        swipeRefreshLayout.setOnRefreshListener(() -> recreate());

        MyClubs myClubs = new MyClubs();
        getSupportFragmentManager().beginTransaction().add(R.id.clubs_container,myClubs).commit();

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this, InvestmentClubsMainView.class));
        finish();
    }
}