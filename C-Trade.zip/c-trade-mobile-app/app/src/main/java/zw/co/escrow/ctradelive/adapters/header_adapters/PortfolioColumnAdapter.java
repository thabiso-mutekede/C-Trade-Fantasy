package zw.co.escrow.ctradelive.adapters.header_adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import de.codecrafters.tableview.TableDataAdapter;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.PortfolioData;


public class PortfolioColumnAdapter extends TableDataAdapter {

    TextView textView;
    ImageView imageView;

    public PortfolioColumnAdapter(Context context, List data) {
        super(context, data);
    }


    @Override
    public View getCellView(int rowIndex, int columnIndex, ViewGroup parentView) {

        View view = LayoutInflater.from(parentView.getContext()).inflate(R.layout.universal_column_adapter_view,parentView,false);
        textView = view.findViewById(R.id.text_id);
        imageView = view.findViewById(R.id.more_img);
        PortfolioData portfolioData = (PortfolioData)getData().get(rowIndex);
        switch (columnIndex){
            case 0:
                textView.setTextColor(Color.parseColor("#ff0099cc"));
                textView.setText(portfolioData.getCounter());
                break;
            case 1:
                textView.setText(portfolioData.getType());
                break;
            case 2:
                //#FF4081
                textView.setTextColor(Color.parseColor("#FF4081"));
                textView.setText(portfolioData.getQuantity());
                break;
            case 3:
                textView.setTextColor(Color.parseColor("#FF4081"));
                textView.setText(portfolioData.getPrice());
                break;
            case 4:
                textView.setVisibility(View.GONE);
                imageView.setImageResource(R.drawable.unfold_more_ic);
                break;
        }

        return view;
    }
}
