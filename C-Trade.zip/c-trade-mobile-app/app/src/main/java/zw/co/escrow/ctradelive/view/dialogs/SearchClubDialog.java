package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;


public class SearchClubDialog extends Dialog {

    private Toolbar toolbar;
    private EditText searchText;

    public SearchClubDialog(@NonNull Context context, InvestmentClub.ICRefreshRefreshLister icRefreshRefreshLister) {
        super(context);
        setContentView(R.layout.search_club_dialog_view);
        setCancelable(false);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Search Club");
        searchText = findViewById(R.id.search_text);
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        findViewById(R.id.search_btn).setOnClickListener(v -> {
            if(searchText.getText().toString().equalsIgnoreCase("")){
                searchText.setError("please enter club name");
            }else{
                icRefreshRefreshLister.doRefresh(searchText.getText().toString());
                dismiss();
            }
        });

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        setCancelable(false);
    }
}
