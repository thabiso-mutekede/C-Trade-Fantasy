package zw.co.escrow.ctradelive.model;

public class Forex {
    String ActualCashBal;

    public Forex() {
    }

    public String getActualCashBal() {
        return ActualCashBal;
    }

    public void setActualCashBal(String actualCashBal) {
        ActualCashBal = actualCashBal;
    }
}
