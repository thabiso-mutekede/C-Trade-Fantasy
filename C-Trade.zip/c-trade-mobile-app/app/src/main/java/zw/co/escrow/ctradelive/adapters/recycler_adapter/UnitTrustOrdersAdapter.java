package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.shreyaspatil.MaterialDialog.MaterialDialog;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.UnitTrustOrder;

public class UnitTrustOrdersAdapter extends RecyclerView.Adapter<UnitTrustOrdersAdapter.MyOrdersViewHolder> {

    private final List<UnitTrustOrder> unitTrustOrderList;
    private Activity activity;
    private UnitTrustOrder unitTrustOrder;

    public UnitTrustOrdersAdapter(Activity activity, List<UnitTrustOrder> unitTrustOrderList) {
        this.unitTrustOrderList = unitTrustOrderList;
        this.activity = activity;
    }


    @Override
    public int getItemViewType(int position) {
        return R.layout.unit_trust_order_item;
    }


    @NonNull
    @Override
    public MyOrdersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new MyOrdersViewHolder(view);    }

    @Override
    public void onBindViewHolder(@NonNull MyOrdersViewHolder holder, int position) {


        holder.txtType.setText(unitTrustOrderList.get(position).getType());
        holder.txtCounter.setText(unitTrustOrderList.get(position).getCounter());

        holder.txtAskVolume.setText(String.format("Ask volume: %s", unitTrustOrderList.get(position).getAskVolume()));
            holder.txtBidVolume.setText(String.format("Bid volume: %s", unitTrustOrderList.get(position).getBidVolume()));
            holder.txtDate.setText(unitTrustOrderList.get(position).getDate());
            holder.txtCurrentPrice.setText(unitTrustOrderList.get(position).getPrice());
            holder.txtValue.setText(unitTrustOrderList.get(position).getAmountValue());

            if (unitTrustOrderList.get(position).getStatus().equals("1")){
                holder.wl_change_indicator.setCardBackgroundColor(activity.getResources().getColor(R.color.colorDarkGreen));
            }

            unitTrustOrder = unitTrustOrderList.get(position);

            holder.cardView.setOnClickListener(view -> {


                new MaterialDialog.Builder(activity)
                        .setTitle("My order")
                        .setMessage(unitTrustOrder.getType().concat("\n")
                                .concat(unitTrustOrder.getDate()).concat("\n"))
                        .setCancelable(false)
                        .setPositiveButton("Edit order", (dialogInterface, which) -> {

                            //todo


                        })
                        .setNegativeButton("Cancel order", (dialogInterface, which) -> dialogInterface.dismiss())
                        .build()
                        .show();


            });

    }



    @Override
    public int getItemCount() {
        return unitTrustOrderList.size();
    }



    public static class MyOrdersViewHolder extends RecyclerView.ViewHolder{

        private TextView txtType, txtAskVolume, txtBidVolume,txtDate, txtCurrentPrice, txtValue, txtCounter;
        private CardView cardView, wl_change_indicator;

        public MyOrdersViewHolder(@NonNull View itemView) {
            super(itemView);

            txtType = itemView.findViewById(R.id.txtType);
            txtCounter = itemView.findViewById(R.id.txtCounter);

            txtAskVolume = itemView.findViewById(R.id.txtAskVolume);
            txtBidVolume = itemView.findViewById(R.id.txtBidVolume);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtValue = itemView.findViewById(R.id.txtValue);
            cardView = itemView.findViewById(R.id.cardViewCompany);
            wl_change_indicator = itemView.findViewById(R.id.wl_change_indicator);


        }
    }
}