package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.R;

public class CreateClubDialog extends Dialog implements View.OnClickListener {

    private OnSubmitListener onSubmitListener;
    private TextInputEditText club_name_txt,club_message_txt;
    TextView alert_text;
    private TextInputLayout cl_name_tl,cl_message_tl;
    private RadioGroup radioGroup,security_group;
    private Toolbar toolbar;
    private Boolean isPublic = false;
    private Button buttonAdd;

    public void setOnSubmitListener(OnSubmitListener onSubmitListener) {
        this.onSubmitListener = onSubmitListener;
    }

    public CreateClubDialog(@NonNull Context context) {
        super(context);
        setContentView(R.layout.create_club_view);
        findViewById(R.id.btn_add_group).setOnClickListener(this);
        buttonAdd = findViewById(R.id.btn_add_group);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Create New Club");
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        alert_text = findViewById(R.id.alert_text);
        alertMessage(true);
        alert_text.setSelected(true);
        security_group = findViewById(R.id.security_level_radgp);
        club_name_txt = findViewById(R.id.group_name);
        club_name_txt.requestFocus();
        club_message_txt = findViewById(R.id.club_welcome_message);
        club_name_txt.setText("");
        club_message_txt.setText("");
        cl_name_tl = findViewById(R.id.group_name_loyout);
        cl_message_tl = findViewById(R.id.club_message_layout);
        cl_message_tl.setVisibility(View.GONE);
        radioGroup = findViewById(R.id.set_message_radgp);
        toolbar.setNavigationOnClickListener(v -> dismiss());
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if(checkedId == R.id.yes_rad) {
                if(!(club_name_txt.getText().toString().length()<0)){
                    cl_message_tl.setVisibility(View.VISIBLE);
                    club_message_txt.requestFocus();
                }else{
                    club_name_txt.setText("Enter Club Name");
                }

            }
            else cl_message_tl.setVisibility(View.GONE);
        });
        security_group.setOnCheckedChangeListener((group, checkedId) -> {
            if(checkedId == R.id.pub_rad){

                alertMessage(true);
                isPublic = true;
            }
            else {
                alertMessage(false);
                isPublic = false;
            }
        });
        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        setCancelable(false);
    }
    private void alertMessage(boolean isPublic) {
        alert_text.setVisibility(View.GONE);
        if(isPublic){
            alert_text.setBackgroundColor(Color.parseColor("#1C980E"));
            alert_text.setText("Other Investors Are Able To View The Clubs Profile.And Can Request To Join");
        }else{
            alert_text.setBackgroundColor(Color.parseColor("#FFC61D"));
            alert_text.setText("Only Investors You Invite Can Be Part Of Your Club.And Your Club Cannot Be Searched");
        }
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_add_group){
            if(onSubmitListener != null){
                if(club_name_txt.getText().toString().length() <5)
                    club_name_txt.setError("Enter Club Name");
                else if(cl_message_tl.getVisibility() == View.VISIBLE)
                    if (club_message_txt.getText().length() < 60)
                        club_message_txt.setError("Welcome Message Should Be At Least 60 Characters");
                    else {
                        buttonAdd.setEnabled(false);
                        onSubmitListener.createGroup(club_name_txt.getText().toString(),
                                club_message_txt.getText().toString(),isPublic,this);
                    }
                else {
                    buttonAdd.setEnabled(false);
                    onSubmitListener.createGroup(club_name_txt.getText().toString(),"",isPublic,this);
                }
            }
        }
    }

    public interface OnSubmitListener{
        void createGroup(String groupName, String welcomeMessage, Boolean isPublic, Dialog dialog);
    }
}
