package zw.co.escrow.ctradelive.model;

public class ClubTransCompany {

    private String company;

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}
