package zw.co.escrow.ctradelive.view_model;

public class dummy {
    private String Ticker;
    private String ISIN;
    private String Best_Ask;
    private String Best_bid;
    private String Current_price;
    private String Ask_Volume;
    private String Bid_Volume;
    private String FullCompanyName;

}
