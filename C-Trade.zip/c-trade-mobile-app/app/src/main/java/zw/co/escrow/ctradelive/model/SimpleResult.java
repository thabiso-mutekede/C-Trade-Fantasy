package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class SimpleResult implements Parcelable {

    private String status;
    private String message;

    protected SimpleResult(Parcel in) {
        status = in.readString();
        message = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(status);
        dest.writeString(message);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<SimpleResult> CREATOR = new Creator<SimpleResult>() {
        @Override
        public SimpleResult createFromParcel(Parcel in) {
            return new SimpleResult(in);
        }

        @Override
        public SimpleResult[] newArray(int size) {
            return new SimpleResult[size];
        }
    };

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
