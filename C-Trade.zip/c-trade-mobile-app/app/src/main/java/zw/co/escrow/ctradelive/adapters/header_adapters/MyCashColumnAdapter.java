package zw.co.escrow.ctradelive.adapters.header_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import de.codecrafters.tableview.TableDataAdapter;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Transaction;


public class MyCashColumnAdapter extends TableDataAdapter {

    TextView textView;
    ImageView imageView;

    public MyCashColumnAdapter(Context context, List data) {
        super(context, data);
    }


    @SuppressLint("ResourceAsColor")
    @Override
    public View getCellView(int rowIndex, int columnIndex, ViewGroup parentView) {

        View view = LayoutInflater.from(parentView.getContext()).inflate(R.layout.universal_column_adapter_view,parentView,false);
        textView = view.findViewById(R.id.text_id);
        imageView = view.findViewById(R.id.more_img);
        Transaction transaction = (Transaction) getData().get(rowIndex);
        switch (columnIndex){
            case 0:
                //textView.setTextColor(Color.parseColor("#39ff14"));
                textView.setText(transaction.getDate());

                break;
            case 1:
                if(transaction.getAmmount()>0)
                    textView.setTextColor(Color.parseColor("#39ff14"));
                else
                    textView.setTextColor(Color.parseColor("#FF4233"));

                textView.setText(transaction.getType());
                break;
            case 2:
                //#FF4081
                if(transaction.getAmmount()>0)
                    textView.setTextColor(Color.parseColor("#39ff14"));
                else
                    textView.setTextColor(Color.parseColor("#FF4233"));
                textView.setText(Constants.getThousandSep(transaction.getAmmount()));
                break;
            case 3:
                //textView.setTextColor(Color.parseColor("#FF4081"));
                textView.setText(Constants.getThousandSep(Float.valueOf(transaction.getBalance())));
                break;
        }

        return view;
    }

}
