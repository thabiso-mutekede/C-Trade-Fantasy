package zw.co.escrow.ctradelive.view;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.toolbox.JsonObjectRequest;
import com.github.ybq.android.spinkit.style.MultiplePulseRing;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomappbar.BottomAppBar;

import com.mikepenz.materialdrawer.holder.StringHolder;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import org.json.JSONObject;


import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.listeners.OnContributionClosed;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;
import zw.co.escrow.ctradelive.view.dialogs.AddANewMemberDialog;
import zw.co.escrow.ctradelive.view.dialogs.ChairmanHandoverDialog;
import zw.co.escrow.ctradelive.view.dialogs.ContributionDialog;
import zw.co.escrow.ctradelive.view.dialogs.MyCashDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradeClubDialog;
import zw.co.escrow.ctradelive.view.dialogs.TranferClubDialog;
import zw.co.escrow.ctradelive.view.fragments.MarketWatchFINSECFragment;
import zw.co.escrow.ctradelive.view.fragments.MarketWatchZSEFragment;

public class ClubView extends AppCompatActivity implements View.OnClickListener, OnContributionClosed {


    private InvestmentClub.ClubServicesListener clubServicesListener;

    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    private RelativeLayout viewsLayout;
    private CoordinatorLayout dashboard_menu;
    private AppBarLayout appBarLayout;
    private BottomAppBar bottomAppBar;
    private static final String TAG = "MainActivity";
    ProgressDialog progressDialog;


    private TextView txtUnclearedCash,txtClearedCash, txtCashBalance, txtMyPortfolio, txtTotalAccount, txtNetPerfomance, txtForexWallerBalance, txtOutStandingCharges;
    private String cdsNumber,myCdsNumber;
    private SharedPreferences sharedPreferences;
    AddANewMemberDialog addANewMemberDialog;

    private ProgressBar loadingSpinner;
    private MultiplePulseRing multiplePulseRing;

    private Toolbar toolbar;

    private ClubModel club;
    private Runnable refresh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_view);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(ClubView.this);
        initWidgets();

        progressDialog = new ProgressDialog(this);
        clubServicesListener = new InvestmentClubService(this);
        club = getIntent().getParcelableExtra("club");
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(club.getClubName());
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        addANewMemberDialog = new AddANewMemberDialog(this,club);
        sharedPreferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        myCdsNumber = sharedPreferences.getString("cds_number", "");

        cdsNumber = club.getClubCdsNumber();
        //Toast.makeText(this,cdsNumber,Toast.LENGTH_SHORT).show();

        findViewById(R.id.chipBuy).setOnClickListener(this);
        findViewById(R.id.chipSell).setOnClickListener(this);
        findViewById(R.id.chipTxn).setOnClickListener(this);
        findViewById(R.id.chipAddMember).setOnClickListener(this);
        findViewById(R.id.chipMembers).setOnClickListener(this);
        findViewById(R.id.chipContribute).setOnClickListener(this);
        findViewById(R.id.noticeChip).setOnClickListener(this);
        findViewById(R.id.chipOrders).setOnClickListener(this);
        findViewById(R.id.chipContributions).setOnClickListener(this);
        findViewById(R.id.chipInvestments).setOnClickListener(this);

        //Read my cash and populate the view if cds number is not empty
        if (!cdsNumber.equals("")){
            getBalances(cdsNumber);
        }
        else {
            loadingSpinner.setVisibility(View.GONE);
            appBarLayout.setVisibility(View.VISIBLE);
            watchListPagerTab.setVisibility(View.VISIBLE);
            watchListPager.setVisibility(View.VISIBLE);
            bottomAppBar.setVisibility(View.VISIBLE);
        }



        setUpWatchList();
        setUpView();

        Handler handler = new Handler();
        refresh = () -> {
            getBalances(club.getClubCdsNumber());
            handler.postDelayed(refresh, 500);
        };
    }

    void getBalances(String cdsNumber){
        JsonObjectRequest jr = new JsonObjectRequest(
                Constants.COMPLETE_URL("account/cash"),
                Constants.cdsNumberJSON(cdsNumber),
                response -> {

                    try {
                        txtUnclearedCash.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("virtualCashBal")))))));
                        txtClearedCash.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("actualCashBal")))))));
                        txtCashBalance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("actualCashBal")))))));
                        txtMyPortfolio.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("potValue")))))));
                        txtTotalAccount.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("totalAccount")))))));
                        txtNetPerfomance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("profitLoss")))))));
                        //txtForexWallerBalance.setText(String.format("$ %s","0.00"));
                        txtForexWallerBalance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("forexBalance")))))));
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                },
                error -> {

                    error.printStackTrace();
                }

        );
        AppConfig.getInstance().addToRequestQueue(jr);
    }

    private void initWidgets(){
        dashboard_menu = findViewById(R.id.dashboard_menu);
        appBarLayout = findViewById(R.id.appbar);
        bottomAppBar = findViewById(R.id.bottom_app_bar);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPager = findViewById(R.id.viewPagerWatchList);

        txtUnclearedCash = findViewById(R.id.txtUnclearedCashFantasy);
        txtClearedCash = findViewById(R.id.txtClearedCashFantasy);
        txtCashBalance = findViewById(R.id.txtCashBalanceFantasy);
        txtMyPortfolio = findViewById(R.id.txtMyPortfolioFantasy);
        txtTotalAccount = findViewById(R.id.txtTotalAccountFantasy);
        txtNetPerfomance = findViewById(R.id.txtNetPerfomance);
        txtForexWallerBalance = findViewById(R.id.txtForexWallerBalance);
        txtOutStandingCharges = findViewById(R.id.txtOutStandingCharges);

        loadingSpinner = findViewById(R.id.loadingSpinner);
        multiplePulseRing = new MultiplePulseRing();
        loadingSpinner.setIndeterminateDrawable(multiplePulseRing);
        loadingSpinner.setVisibility(View.VISIBLE);
    }

    private void setUpWatchList(){
        Bundle bundle = new Bundle();
        bundle.putParcelable("club",club);
        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("ZSE", MarketWatchZSEFragment.class,bundle)
                .add("FINSEC", MarketWatchFINSECFragment.class,bundle)
                .create());
        watchListPager.setAdapter(watchListPagerAdapter);

        watchListPagerTab.setViewPager(watchListPager);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.noticeChip:
                startActivity(new Intent(this,GroupFeed.class).putExtra("club",club));
                break;
            case R.id.chipContribute:
                ContributeClubDialog contributionDialog = new ContributeClubDialog(this);
                contributionDialog.setOnContributionClosed(this::process);
                contributionDialog.show();
                break;

            case R.id.chipOrders:
                startActivity(new Intent(this,MyOrdersActivity.class).putExtra("cdsnumber",club.getClubCdsNumber()).putExtra("isClub",true).putExtra("club",club));
                break;

            case R.id.chipBuy:
                TradeClubDialog dialogBuy = TradeClubDialog.newInstance("BUY",club);
                FragmentTransaction ftBuy = getSupportFragmentManager().beginTransaction();
                dialogBuy.show(ftBuy, TradeClubDialog.TAG);
                break;
            case R.id.chipSell:
                TradeClubDialog dialogSell = TradeClubDialog.newInstance("SELL", club);
                FragmentTransaction ftSell = getSupportFragmentManager().beginTransaction();
                dialogSell.show(ftSell, TradeClubDialog.TAG);
                break;
            case R.id.chipInvestments:
                startActivity(new Intent(this, InClubInvestmentView.class)
                .putExtra("club",club));
                break;

            case R.id.chipContributions:
                new ContributionDialog(this,cdsNumber,myCdsNumber).show();
                break;

            case R.id.chipMembers:
                startActivity(new Intent(this, MembershipView.class).putExtra("club",club));
                break;

            case R.id.chipAddMember:
                if(club.isMember())Toast.makeText(this,"Members Can't Add Other Members",Toast.LENGTH_SHORT).show();
                else addANewMemberDialog.show();
                break;
            case R.id.chipClub:
                startActivity(new Intent(this,InvestmentClubsMainView.class));
                break;
            case R.id.chipTxn:
               new MyCashDialog(this,cdsNumber,10).show();
                break;
        }

    }

    public interface ContributionListener{
        void onContributionDialogClosedListener(DialogFragment dialogFragment);
    }
    private StringHolder setTitle(String title){
        return new StringHolder(title);
    }

    private void setUpView(){
        if(club.isMember()){
            findViewById(R.id.chipBuy).setVisibility(View.GONE);
            findViewById(R.id.chipSell).setVisibility(View.GONE);
        }

    }
    private void showContributionDialog(){
        TranferClubDialog dialog = TranferClubDialog.newInstance("SELL",club.getClubCdsNumber(),club.getClubName());
        dialog.setContributionListener(dialogFragment -> {
            dialogFragment.dismiss();
            recreate();
        });
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        dialog.show(ft, "lloda");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String amount;
        switch (requestCode){
            case Constants.CONVERT_REQUEST_CODE:
                amount= data != null ? data.getStringExtra("AMOUNT") : null;
                Toast.makeText(this, "Converted "+amount, Toast.LENGTH_SHORT).show();
                break;
            case Constants.WITHDRAW_REQUEST_CODE:
                amount= data != null ? data.getStringExtra("AMOUNT") : null;
                Toast.makeText(this, "Withdrew "+amount, Toast.LENGTH_SHORT).show();
                break;
            case Constants.DEPOSIT_REQUEST_CODE:

                Toast.makeText(this, "Yah", Toast.LENGTH_LONG).show();
                /*
                String[] depositDetails =  data.getStringArrayExtra("DEPOSIT_DETAILS");

                for (String depositDetail : depositDetails) {
                    Log.d(TAG, "onActivityResult: " + depositDetail);
                }*/
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.club_view_menu, menu);
        if(club.isMember()){
            menu.removeItem(1);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.exit_group_opt){
            if(!club.isMember()){
                showDialog("CHAIRMAN CAN'T EXIT GROUP");
            }else{
                new AlertDialog.Builder(this)
                        .setMessage("Are You Sure You Want Exit '"+club.getClubName()+"'")
                        .setPositiveButton("Yes",(dialog, which) ->
                                clubServicesListener.onExitClub(club.getClubCdsNumber(),myCdsNumber)
                        )
                        .setNegativeButton("Cancel",null)
                        .create()
                        .show();
            }
        }else if (id == R.id.hand_over_opt){
            if(club.isMember())
                showDialog("You're not the chairman");
            else {
              ChairmanHandoverDialog chairmanHandoverDialog =
                      new ChairmanHandoverDialog(this, club.getClubCdsNumber(), myCdsNumber);

               chairmanHandoverDialog.setOnHandOverDone(
                       (dialog, gcdsnumber, ccdsnumber, mcdsnumber) -> {
                  dialog.dismiss();
                  progressDialog.setMessage("Please Wait A Moment....");
                  progressDialog.show();

                  JSONObject jsonObject = new JSONObject();
                   try {
                       jsonObject.put("memberCdsNumber",mcdsnumber);
                       jsonObject.put("clubCdsNumber",gcdsnumber);
                   }catch (Exception e){
                       e.printStackTrace();
                   }

                  JsonObjectRequest jr = new JsonObjectRequest(Constants.COMPLETE_URL("clubs/handover"),
                          Constants.cdsNumberJSON(gcdsnumber,cdsNumber),
                          response -> {
                              try {
                              if(response.getBoolean("status")) {
                                  new AlertDialog.Builder(ClubView.this)
                                          .setMessage(response.getString("message"))
                                          .setPositiveButton("ok", (d, which)
                                                  -> {
                                              startActivity(new Intent(ClubView.this, InvestmentClubsMainView.class));
                                              finish();
                                          })
                                          .create()
                                          .show();
                              }
                              } catch (Exception e) {
                                  e.printStackTrace();
                              progressDialog.dismiss();
                              showDialog("Failed To Read Data.Please Try Again Later");
                              }
                          },

                          error -> {
                      progressDialog.dismiss();
                      error.printStackTrace();
                              showDialog("Error On Connecting.Please Try Again Later");
                          });

                   AppConfig.getInstance().addToRequestQueue(jr);
              });
              chairmanHandoverDialog.show();
            }
        }
        return super.onOptionsItemSelected(item);
    }
    private void showDialog(String message){
        new android.app.AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("ok",null)
                .create()
                .show();
    }

    @Override
    public void process(String transType, String amount, Dialog dialog) {
        dialog.dismiss();
        if(transType.equalsIgnoreCase("CNT"))
            clubServicesListener.onContribute(cdsNumber,myCdsNumber,amount,this);
        else clubServicesListener.onWithdraw(cdsNumber,myCdsNumber,amount,this);
    }

}