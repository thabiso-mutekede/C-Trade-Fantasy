package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnPlaceOrder;
import zw.co.escrow.ctradelive.model.OpenBuyOrder;
import zw.co.escrow.ctradelive.model.OrderDetails;

public class OpenBuyOrdersAdapter extends RecyclerView.Adapter<OpenBuyOrdersAdapter.OpenBuyOrdersViewHolder> {

    private final List<OpenBuyOrder> openBuyOrders;
    private Activity activity;

    private OnPlaceOrder onPlaceOrder;

    public void setOnPlaceOrder(OnPlaceOrder onPlaceOrder) {
        this.onPlaceOrder = onPlaceOrder;
    }


    public OpenBuyOrdersAdapter(Activity activity, List<OpenBuyOrder> openBuyOrders) {
        this.openBuyOrders = openBuyOrders;
        this.activity = activity;
    }


    @Override
    public int getItemViewType(int position) {
        return R.layout.open_buy_orders_item;
    }


    @NonNull
    @Override
    public OpenBuyOrdersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new OpenBuyOrdersViewHolder(view);    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull OpenBuyOrdersViewHolder holder, int position) {


        holder.txtTicker.setText(openBuyOrders.get(position).getTicker());
        holder.txtCompanyName.setText(openBuyOrders.get(position).getFullCompanyName());
        holder.txtBestBid.setText(String.format("BEST BID: %s", openBuyOrders.get(position).getBestBid()));
        holder.txtCurrentPrice.setText(openBuyOrders.get(position).getCurrentPrice());
        holder.txtBidVolume.setText(String.format("BID VOLUME: %s", openBuyOrders.get(position).getBidVolume()));
        holder.txtPercentageChange.setText("[SELL]");


        holder.wl_change_indicator.setCardBackgroundColor(activity.getResources().getColor(R.color.colorOrange));
        OpenBuyOrder order = openBuyOrders.get(position);

        holder.cardView.setOnClickListener(view -> {

            OrderDetails orderDetails = new OrderDetails();
            orderDetails.setCurrentPrice(order.getBestBid());
            orderDetails.setFullCompanyName(order.getFullCompanyName());
            orderDetails.setMarket("ZSE");
            orderDetails.setCompany(order.getTicker());
        AlertDialog alertDialog  =  new AlertDialog.Builder(activity)
                    .setTitle("Open Buy Order")
                    .setMessage(order.getTicker().concat("\n")
                            .concat(order.getFullCompanyName()).concat("\n")
                            .concat("Best bid: "+order.getBestBid()).concat("\n")
                            .concat("Current price: "+order.getCurrentPrice()).concat("\n")
                            .concat("Bid volume: "+order.getBidVolume()))
                    .setCancelable(false)
                    .setPositiveButton("SELL", (dialogInterface, which) -> {
                        if(onPlaceOrder != null) onPlaceOrder.showDialog(orderDetails);
                    })
                    .setNegativeButton("Cancel", (dialogInterface, which) -> dialogInterface.dismiss())
                    .create();

            alertDialog.setOnShowListener(dialogInterface -> {
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(activity.getColor(R.color.red));
                alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(activity.getColor(R.color.white));
            });
            alertDialog.show();
        });

    }



    @Override
    public int getItemCount() {
        return openBuyOrders.size();
    }



    public static class OpenBuyOrdersViewHolder extends RecyclerView.ViewHolder{

        private TextView txtTicker, txtCompanyName, txtBestBid, txtCurrentPrice, txtBidVolume, txtPercentageChange;
        private CardView cardView, wl_change_indicator;

        public OpenBuyOrdersViewHolder(@NonNull View itemView) {
            super(itemView);

            txtTicker = itemView.findViewById(R.id.txtTicker);
            txtCompanyName = itemView.findViewById(R.id.txtCompanyName);
            txtBestBid = itemView.findViewById(R.id.txtBestBid);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtBidVolume = itemView.findViewById(R.id.txtBidVolume);
            txtPercentageChange = itemView.findViewById(R.id.txtPercentageChange);
            cardView = itemView.findViewById(R.id.cardViewCompany);
            wl_change_indicator = itemView.findViewById(R.id.wl_change_indicator);
        }
    }
}