package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author Godwin Tavirimirwa
 */
public class UnitTrustPortfolio implements Parcelable {

    private String previousPortfolioValue,portfolioValue,previousNumberShares,numberShares, uncleared,
    net, currentPrice, totalPortfolioValue, totalPrevPortValue, prevPrice, returns, lastActivityDate,
            instrument, more;


    public UnitTrustPortfolio(String previousPortfolioValue, String portfolioValue, String previousNumberShares,
                              String numberShares, String uncleared, String net, String currentPrice, String totalPortfolioValue,
                              String totalPrevPortValue, String prevPrice, String returns, String lastActivityDate, String instrument,
                              String more) {
        this.previousPortfolioValue = previousPortfolioValue;
        this.portfolioValue = portfolioValue;
        this.previousNumberShares = previousNumberShares;
        this.numberShares = numberShares;
        this.uncleared = uncleared;
        this.net = net;
        this.currentPrice = currentPrice;
        this.totalPortfolioValue = totalPortfolioValue;
        this.totalPrevPortValue = totalPrevPortValue;
        this.prevPrice = prevPrice;
        this.returns = returns;
        this.lastActivityDate = lastActivityDate;
        this.instrument = instrument;
        this.more = more;
    }

    protected UnitTrustPortfolio(Parcel in) {
        previousPortfolioValue = in.readString();
        portfolioValue = in.readString();
        previousNumberShares = in.readString();
        numberShares = in.readString();
        uncleared = in.readString();
        net = in.readString();
        currentPrice = in.readString();
        totalPortfolioValue = in.readString();
        totalPrevPortValue = in.readString();
        prevPrice = in.readString();
        returns = in.readString();
        lastActivityDate = in.readString();
        instrument = in.readString();
        more = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(previousPortfolioValue);
        dest.writeString(portfolioValue);
        dest.writeString(previousNumberShares);
        dest.writeString(numberShares);
        dest.writeString(uncleared);
        dest.writeString(net);
        dest.writeString(currentPrice);
        dest.writeString(totalPortfolioValue);
        dest.writeString(totalPrevPortValue);
        dest.writeString(prevPrice);
        dest.writeString(returns);
        dest.writeString(lastActivityDate);
        dest.writeString(instrument);
        dest.writeString(more);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<UnitTrustPortfolio> CREATOR = new Creator<UnitTrustPortfolio>() {
        @Override
        public UnitTrustPortfolio createFromParcel(Parcel in) {
            return new UnitTrustPortfolio(in);
        }

        @Override
        public UnitTrustPortfolio[] newArray(int size) {
            return new UnitTrustPortfolio[size];
        }
    };

    public String getPreviousPortfolioValue() {
        return previousPortfolioValue;
    }

    public void setPreviousPortfolioValue(String previousPortfolioValue) {
        this.previousPortfolioValue = previousPortfolioValue;
    }

    public String getPortfolioValue() {
        return portfolioValue;
    }

    public void setPortfolioValue(String portfolioValue) {
        this.portfolioValue = portfolioValue;
    }

    public String getPreviousNumberShares() {
        return previousNumberShares;
    }

    public void setPreviousNumberShares(String previousNumberShares) {
        this.previousNumberShares = previousNumberShares;
    }

    public String getNumberShares() {
        return numberShares;
    }

    public void setNumberShares(String numberShares) {
        this.numberShares = numberShares;
    }

    public String getUncleared() {
        return uncleared;
    }

    public void setUncleared(String uncleared) {
        this.uncleared = uncleared;
    }

    public String getNet() {
        return net;
    }

    public void setNet(String net) {
        this.net = net;
    }

    public String getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public String getTotalPortfolioValue() {
        return totalPortfolioValue;
    }

    public void setTotalPortfolioValue(String totalPortfolioValue) {
        this.totalPortfolioValue = totalPortfolioValue;
    }

    public String getTotalPrevPortValue() {
        return totalPrevPortValue;
    }

    public void setTotalPrevPortValue(String totalPrevPortValue) {
        this.totalPrevPortValue = totalPrevPortValue;
    }

    public String getPrevPrice() {
        return prevPrice;
    }

    public void setPrevPrice(String prevPrice) {
        this.prevPrice = prevPrice;
    }

    public String getReturns() {
        return returns;
    }

    public void setReturns(String returns) {
        this.returns = returns;
    }

    public String getLastActivityDate() {
        return lastActivityDate;
    }

    public void setLastActivityDate(String lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    public String getInstrument() {
        return instrument;
    }

    public void setInstrument(String instrument) {
        this.instrument = instrument;
    }

    public String getMore() {
        return more;
    }

    public void setMore(String more) {
        this.more = more;
    }
}
