package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Investment implements Parcelable {
    private String counter;
    private String type;
    private String units;
    private String price;
    private String value;
    private String myshare;

    public Investment() {
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getMyshare() {
        return myshare;
    }

    public void setMyshare(String myshare) {
        this.myshare = myshare;
    }

    public static Creator<Investment> getCREATOR() {
        return CREATOR;
    }

    protected Investment(Parcel in) {
        counter = in.readString();
        type = in.readString();
        units = in.readString();
        price = in.readString();
        value = in.readString();
        myshare = in.readString();
    }

    public static final Creator<Investment> CREATOR = new Creator<Investment>() {
        @Override
        public Investment createFromParcel(Parcel in) {
            return new Investment(in);
        }

        @Override
        public Investment[] newArray(int size) {
            return new Investment[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(counter);
        parcel.writeString(type);
        parcel.writeString(units);
        parcel.writeString(price);
        parcel.writeString(value);
        parcel.writeString(myshare);
    }
}
