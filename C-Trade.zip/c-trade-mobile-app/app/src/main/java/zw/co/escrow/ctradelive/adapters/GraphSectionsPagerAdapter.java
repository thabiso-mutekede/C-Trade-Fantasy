package zw.co.escrow.ctradelive.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.ChartCustomMarkerView;
import zw.co.escrow.ctradelive.MyXAxisFormatter;
import zw.co.escrow.ctradelive.MyYAxisFormatter;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.view.fragments.OneDayGraphFragment;
import zw.co.escrow.ctradelive.view.fragments.OneWeekGraphFragment;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class GraphSectionsPagerAdapter extends FragmentPagerAdapter {

    private static final String[] TAB_TITLES = new String[]{"ONE DAY", "ONE WEEK","ONE MONTH", "SIX MONTHS","ONE YEAR"};
    private final Context mContext;

    public GraphSectionsPagerAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position){
            case 0:
                return OneDayGraphFragment.newInstance(position + 1);
            case 1:
                return OneWeekGraphFragment.newInstance(position + 1);
            case 2:
                return OneDayGraphFragment.newInstance(position + 1);
            case 3:
                return OneWeekGraphFragment.newInstance(position + 1);
            case 4:
                return OneWeekGraphFragment.newInstance(position + 1);

        }


        return OneDayGraphFragment.newInstance(position + 1);
    }



    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return TAB_TITLES[position];
    }

    @Override
    public int getCount() {
        // Show 2 total pages.
        return TAB_TITLES.length;
    }

    public static class ChartDataAdapter {

        public void setChartData(List<String> dates,
                                 List<Float> prices,
                                 Context context,
                                 LineChart historyChart) {
            if (dates.size() > 4) {
                List<Entry> values = new ArrayList<>();

                for (int i = 0; i < prices.size(); i++) {
                    values.add(new Entry((float) i, prices.get(i)));
                }

                LineDataSet dataSet = new LineDataSet(values, "Prices");
                dataSet.setAxisDependency(YAxis.AxisDependency.LEFT);

                List<ILineDataSet> dataSets = new ArrayList<>();
                dataSets.add(dataSet);
                int chartColor = ContextCompat.getColor(context, R.color.colorAccent);
                int circleColor = ContextCompat.getColor(context, R.color.colorAccent);
                int circleColorHole = ContextCompat.getColor(context, R.color.colorAccent);
                int axisTextColor = ContextCompat.getColor(context, R.color.colorOrange);
                dataSet.setColor(chartColor);
                dataSet.setCircleColor(circleColor);
                dataSet.setCircleColorHole(circleColorHole);
                dataSet.setLineWidth(2f);
                dataSet.setDrawFilled(true);
                Drawable drawable = ContextCompat.getDrawable(context, R.drawable.graph_bg);
                dataSet.setFillDrawable(drawable);
                dataSet.setCircleRadius(2f);
                dataSet.setDrawCircles(true);
                dataSet.setDrawValues(false);
                dataSet.setDrawHighlightIndicators(true);

                YAxis axisLeft = historyChart.getAxisLeft();
                axisLeft.setTextColor(axisTextColor);
                axisLeft.setValueFormatter(new MyYAxisFormatter());

                XAxis xAxis = historyChart.getXAxis();
                xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                xAxis.setTextColor(axisTextColor);
                xAxis.setGranularity(1f);
                xAxis.setValueFormatter(new MyXAxisFormatter());
                Log.d("dates size is ", "" + dates.size());
                xAxis.setValueFormatter((value, axis) -> dates.get((int) value));

                LineData data = new LineData(dataSets);
                historyChart.setData(data);

                // Touch behaviour
                historyChart.setTouchEnabled(true);
                historyChart.setDragEnabled(true);
                historyChart.setPinchZoom(true);
                historyChart.setDoubleTapToZoomEnabled(true);
                historyChart.setKeepPositionOnRotation(true);
                historyChart.setHighlightPerTapEnabled(true);
                historyChart.setMaxHighlightDistance(50f);
                Description desc = new Description();
                desc.setEnabled(false);
                historyChart.setDescription(desc);
                //Style
                historyChart.setDrawBorders(true);
                historyChart.setBorderColor(axisTextColor);
                historyChart.setBorderWidth(1f);
                ChartCustomMarkerView customMarkerView =
                        new ChartCustomMarkerView(context, R.layout.chart_marker_view, dates
                        );
                historyChart.setMarker(customMarkerView);

                Legend legend = historyChart.getLegend();
                legend.setTextColor(R.color.white);
                legend.setEnabled(true);

                historyChart.invalidate();
            } else {
                historyChart.clear();
                Toast.makeText(context, R.string.insufficient_data,
                        Toast.LENGTH_SHORT).show();
            }


        }
    }
}