package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Signatory implements Parcelable {

    String signatoryName,signatoryEmail,signatoryPhone,signatoryPassword;
    Boolean initiator, authoriser;


    public Signatory(String signatoryName, String signatoryEmail, String signatoryPhone, String signatoryPassword, Boolean initiator, Boolean authoriser) {
        this.signatoryName = signatoryName;
        this.signatoryEmail = signatoryEmail;
        this.signatoryPhone = signatoryPhone;
        this.signatoryPassword = signatoryPassword;
        this.initiator = initiator;
        this.authoriser = authoriser;
    }

    protected Signatory(Parcel in) {
        signatoryName = in.readString();
        signatoryEmail = in.readString();
        signatoryPhone = in.readString();
        signatoryPassword = in.readString();
        byte tmpInitiator = in.readByte();
        initiator = tmpInitiator == 0 ? null : tmpInitiator == 1;
        byte tmpAuthoriser = in.readByte();
        authoriser = tmpAuthoriser == 0 ? null : tmpAuthoriser == 1;
    }

    public static final Creator<Signatory> CREATOR = new Creator<Signatory>() {
        @Override
        public Signatory createFromParcel(Parcel in) {
            return new Signatory(in);
        }

        @Override
        public Signatory[] newArray(int size) {
            return new Signatory[size];
        }
    };

    public String getSignatoryName() {
        return signatoryName;
    }

    public void setSignatoryName(String signatoryName) {
        this.signatoryName = signatoryName;
    }

    public String getSignatoryEmail() {
        return signatoryEmail;
    }

    public void setSignatoryEmail(String signatoryEmail) {
        this.signatoryEmail = signatoryEmail;
    }

    public String getSignatoryPhone() {
        return signatoryPhone;
    }

    public void setSignatoryPhone(String signatoryPhone) {
        this.signatoryPhone = signatoryPhone;
    }

    public String getSignatoryPassword() {
        return signatoryPassword;
    }

    public void setSignatoryPassword(String signatoryPassword) {
        this.signatoryPassword = signatoryPassword;
    }

    public Boolean getInitiator() {
        return initiator;
    }

    public void setInitiator(Boolean initiator) {
        this.initiator = initiator;
    }

    public Boolean getAuthoriser() {
        return authoriser;
    }

    public void setAuthoriser(Boolean authoriser) {
        this.authoriser = authoriser;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(signatoryName);
        parcel.writeString(signatoryEmail);
        parcel.writeString(signatoryPhone);
        parcel.writeString(signatoryPassword);
        parcel.writeByte((byte) (initiator == null ? 0 : initiator ? 1 : 2));
        parcel.writeByte((byte) (authoriser == null ? 0 : authoriser ? 1 : 2));
    }
}
