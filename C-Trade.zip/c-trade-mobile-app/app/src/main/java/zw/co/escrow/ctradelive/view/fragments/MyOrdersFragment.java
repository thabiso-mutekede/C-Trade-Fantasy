package zw.co.escrow.ctradelive.view.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MyOrdersAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.listeners.OnCancelOrder;
import zw.co.escrow.ctradelive.model.MyOrder;
import zw.co.escrow.ctradelive.model.WatchListData;

public class MyOrdersFragment extends Fragment implements OnCancelOrder {

    private View view;
    private RecyclerView watchListRecyclerView;
    private List<WatchListData> watchListDataList;
    private static final String TAG = "MyOrdersFragment";
    private  List<MyOrder> myOrderList = new ArrayList<>();
    private String mobileip, felloverip1, felloverip2, ip, cds_number;
    private AppConfig appConfig;
    private ProgressDialog progressDialog;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        watchListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        progressDialog = new ProgressDialog(getContext());



        appConfig = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();
        mobileip = AppConfig.getMobileApiAddress();

        /*SharedPreferences prfs = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cds_number = prfs.getString("cds_number", "");*/
        cds_number = getArguments().getString("cdsnumber");
        Log.d(TAG, "onCreateView: "+cds_number);
        myOrderList.clear();

        fetchMyOrders();



        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);



    }

    private void fetchMyOrders() {
        JSONObject jo = new JSONObject();
        try{
            jo.put("cdsNumber",cds_number);
            jo.put("type","equity");
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(
                Request.Method.POST,
                Constants.COMPLETE_URL("account/orders"),
                jo,
                response -> {
                    try{
                        List<MyOrder> myOrderList = new ArrayList<>();
                        for(int i = 0;i<response.length();i++){
                            JSONObject c = response.getJSONObject(i);
                            MyOrder myOrder = new MyOrder();
                            myOrder.setCounter(c.getString("company"));
                            myOrder.setStatus(c.getString("orderstatus"));
                            myOrder.setRej_message(c.getString("reject_Reason"));
                            myOrder.setQuantity(String.valueOf(c.getDouble("quantity")));
                            myOrder.setValue(String.valueOf(c.getDouble("value")));
                            myOrder.setDate(c.getString("date"));
                            myOrder.setType(c.getString("ordertype"));
                            myOrder.setPrice(c.getString("baseprice"));
                            myOrder.setId(c.getString("orderNo"));

                            myOrderList.add(myOrder);
                        }
                        MyOrdersAdapter myOrdersAdapter = new MyOrdersAdapter(getActivity(), myOrderList, watchListRecyclerView,cds_number);
                        myOrdersAdapter.setOnCancelOrder(this);
                        watchListRecyclerView.setAdapter(myOrdersAdapter);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                },error -> {

                    error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(jr);

    }

    @Override
    public void cancelOrder(String cdsNumber, String orderNumber, String orderType) {
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Cancelling Order ...");
        progressDialog.show();

        JSONObject jo = new JSONObject();
        try{
            jo.put("orderNo",orderNumber);
        }catch (Exception e){
            e.printStackTrace();
        }

        JsonObjectRequest jr = new JsonObjectRequest(
                Constants.COMPLETE_URL("account/orders/cancel"),
                jo,
                response -> {
                    try {
                        progressDialog.dismiss();
                        new AlertDialog.Builder(getContext())
                                .setMessage(response.getString("message"))
                                .setPositiveButton("Ok", null).create().show();
                    } catch (Exception e) {
                        e.printStackTrace();
                        new AlertDialog.Builder(getContext())
                                .setMessage("An Error Occurred,Try Again Later.")
                                .setPositiveButton("Ok", null).create().show();
                    }
                }, error -> {
                progressDialog.dismiss();
                new AlertDialog.Builder(getContext())
                        .setMessage("An Error Occurred,Try Again Later.")
                        .setPositiveButton("Ok",null).create().show();
                error.printStackTrace();
        }){
            @Override
            public RetryPolicy getRetryPolicy() {
                return new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 500000;
                    }

                    @Override
                    public int getCurrentRetryCount() {
                        return 0;
                    }

                    @Override
                    public void retry(VolleyError error) throws VolleyError {

                    }
                };
            }
        };
        AppConfig.getInstance().addToRequestQueue(jr);
    }



}