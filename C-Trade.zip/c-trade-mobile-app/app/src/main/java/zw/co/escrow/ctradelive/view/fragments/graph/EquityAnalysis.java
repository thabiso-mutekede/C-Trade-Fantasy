package zw.co.escrow.ctradelive.view.fragments.graph;

import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.toolbox.JsonArrayRequest;
import com.github.mikephil.charting.charts.CandleStickChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.CandleData;
import com.github.mikephil.charting.data.CandleDataSet;
import com.github.mikephil.charting.data.CandleEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import org.json.JSONObject;

import java.util.ArrayList;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;

public class EquityAnalysis extends Fragment {

    CandleStickChart candleStickChart;
    private final ArrayList<CandleEntry> yValues = new ArrayList<>();
    private Bundle bundle;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.equity_analysis_view,container,false);
        candleStickChart = view.findViewById(R.id.candle_stick_chart);
        candleStickChart.setHighlightPerDragEnabled(true);
        candleStickChart.setDrawBorders(true);

        candleStickChart.setBorderColor(getResources().getColor(R.color.white));
        candleStickChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                //float high = candleStickChart.getCandleData().getDataSetForEntry(e).getEntryForIndex(h.getDataIndex()).getHigh();
                //Toast.makeText(getContext(),""+high, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected() {

            }
        });

        bundle = getArguments();

        YAxis yAxis = candleStickChart.getAxisLeft();
        YAxis rightAxis = candleStickChart.getAxisRight();
        yAxis.setDrawGridLines(false);
        rightAxis.setDrawGridLines(false);
        candleStickChart.requestDisallowInterceptTouchEvent(true);

        XAxis xAxis = candleStickChart.getXAxis();

        xAxis.setDrawGridLines(false);// disable x axis grid lines
        xAxis.setDrawLabels(true);
        rightAxis.setTextColor(getResources().getColor(R.color.white));

        yAxis.setDrawLabels(false);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setAvoidFirstLastClipping(true);

        Legend l = candleStickChart.getLegend();
        l.setEnabled(false);
        getData(bundle.getString(getString(R.string.EXCHANGE)));
        return view;
    }
    private void getData(String company){
        String url = AppConfig.getIp()+"equityData?company="+company;
        Log.d("lloda",url);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, response ->
        {
            try{

                if(response.length()>0) {
                    Log.d("lloda","length --> "+response.length());
                    for (int i = 0; i < response.length(); i++) {
                        if(i == 15)break;
                        JSONObject jsonObject = response.getJSONObject(i);
                        yValues.add(new CandleEntry(i, Float.parseFloat(jsonObject.getString("hstP"))
                                , Float.parseFloat(jsonObject.getString("lstP"))
                                , Float.parseFloat(jsonObject.getString("oP"))
                                , Float.parseFloat(jsonObject.getString("cP"))));


                    }
                    CandleDataSet set1 = new CandleDataSet(yValues, "EQUITY");
                    set1.setColor(Color.rgb(80, 80, 80));
                    set1.setShadowColor(getResources().getColor(R.color.yellow));
                    set1.setShadowWidth(0.8f);
                    set1.setFormSize(0.2f);
                    set1.setDecreasingColor(getResources().getColor(R.color.trend_down));
                    set1.setDecreasingPaintStyle(Paint.Style.FILL);
                    set1.setIncreasingColor(getResources().getColor(R.color.trend_up));
                    set1.setIncreasingPaintStyle(Paint.Style.FILL);
                    set1.setNeutralColor(Color.LTGRAY);
                    set1.setDrawValues(false);
                    CandleData data = new CandleData(set1);
                    candleStickChart.setData(data);
                    candleStickChart.invalidate();
                }

            }catch (Exception e){
                e.printStackTrace();
            }
        },error -> {
            error.printStackTrace();

        });

        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
    }
}
