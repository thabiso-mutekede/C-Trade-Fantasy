package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Feed;
import zw.co.escrow.ctradelive.view.GroupFeed;

public class GroupFeedsAdapter extends RecyclerView.Adapter implements View.OnClickListener{

    private Context context;
    private List<Feed> feeds;
    private RecyclerView rv;
    private EditText notification_et;
    private Dialog dialog;
    private String cdsNumber;
    private final boolean isMember;
    private Long id;
    private String cds;
    private final RecyclerView recyclerView;
    private final String member_cds;

    Toolbar toolbar;
    Button submit_btn,edit_btn,delete_btn;
    LinearLayout submitting_ll,options_ll;
    View view;

    @Override
    public int getItemViewType(int position) {

        Feed feed = feeds.get(position);
        if(feed.getType().equalsIgnoreCase(context.getString(R.string.feedAlert))){
            return R.layout.feed_view_alert;
        }else if(feed.getCdsnumber().equalsIgnoreCase(member_cds)){
            return R.layout.feed_view_mine;
        }
        return R.layout.feed_view_others;
    }

    public GroupFeedsAdapter(Context context, List<Feed> feeds, RecyclerView rv, String cdsNumber, boolean isMember, RecyclerView recyclerView, String member_cds) {
        this.context = context;
        this.feeds = feeds;
        this.rv = rv;
        this.isMember = isMember;
        this.cdsNumber = cdsNumber;
        this.recyclerView = recyclerView;
        this.member_cds = member_cds;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view;

        if(viewType == R.layout.feed_view_alert){
            view  = LayoutInflater.from(context).inflate(R.layout.feed_view_alert,parent,false);
            return new FeedAlertViewHolder(view);
        }else if(viewType == R.layout.feed_view_others){
            view  = LayoutInflater.from(context).inflate(R.layout.feed_view_others,parent,false);
            return new FeedOthersViewHolder(view);
        }else{
            view  = LayoutInflater.from(context).inflate(R.layout.feed_view_mine,parent,false);
            return new FeedMineViewHolder(view);
        }
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        Feed feed = feeds.get(position);
        if(feed.getType().equalsIgnoreCase(context.getString(R.string.feedAlert))){
            ((FeedAlertViewHolder)holder).onBindData(feeds.get(position));
        }else if(feed.getCdsnumber().equalsIgnoreCase(member_cds)){
            ((FeedMineViewHolder)holder).onBindData(feeds.get(position));
        }else{
            ((FeedOthersViewHolder)holder).onBindData(feeds.get(position));
        }

    }

    @Override
    public int getItemCount() {
        return feeds.size();
    }

    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.feed_edit_btn){
            notification_et.setEnabled(true);
            options_ll.setVisibility(View.GONE);
            submitting_ll.setVisibility(View.VISIBLE);
        }if(v.getId() == R.id.submit_feed){
            dialog.dismiss();
            ((GroupFeed)context).updateNotice(cdsNumber,id,notification_et.getText().toString());
        }if(v.getId() == R.id.feed_delete_btn){
            dialog.dismiss();
            ((GroupFeed)context).deleteNotice(id);
        }
    }

    private class FeedOthersViewHolder extends RecyclerView.ViewHolder {
        private TextView feed_tv,date_tv,names_tv;

        public FeedOthersViewHolder(@NonNull View itemView) {
            super(itemView);

            feed_tv = itemView.findViewById(R.id.feed_tv);
            date_tv = itemView.findViewById(R.id.datePosted_tv);
            names_tv = itemView.findViewById(R.id.name_txt);

        }

        public void onBindData(Feed feed){
            feed_tv.setText(feed.getMessage());
            date_tv.setText(feed.getDate());
            names_tv.setText(feed.getSender());
        }
    }

    private class FeedAlertViewHolder extends RecyclerView.ViewHolder {
        private TextView not_title,not_txt;
        private LinearLayout ll;

        public FeedAlertViewHolder(@NonNull View itemView) {
            super(itemView);
            ll = itemView.findViewById(R.id.notification_cnt);
            not_title = itemView.findViewById(R.id.title_text);
            not_txt = itemView.findViewById(R.id.notification_txt);
            not_title = itemView.findViewById(R.id.title_txt);
        }

        public void onBindData(Feed feed){
            not_txt.setText(feed.getMessage());
            not_title.setText(feed.getTitle());
        }
    }

    private class FeedMineViewHolder extends RecyclerView.ViewHolder {

        private TextView feed_tv2,date_tv2,names_tv2;

        public FeedMineViewHolder(@NonNull View itemView) {
            super(itemView);
            feed_tv2 = itemView.findViewById(R.id.feed_tv2);
            date_tv2 = itemView.findViewById(R.id.datePosted_tv2);
            names_tv2 = itemView.findViewById(R.id.name_txt2);
        }

        public void onBindData(Feed feed){
            if(feed.getCdsnumber().equalsIgnoreCase(member_cds)){
                feed_tv2.setText(feed.getMessage());
                date_tv2.setText(feed.getDate());
                names_tv2.setVisibility(View.GONE);
            }
        }
    }
}
