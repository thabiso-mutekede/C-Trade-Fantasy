package zw.co.escrow.ctradelive.view;

import static zw.co.escrow.ctradelive.Constants.COMPLETE_URL;
import static zw.co.escrow.ctradelive.Constants.convertToFloat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.Portfolio;
import zw.co.escrow.ctradelive.view.dialogs.UnitTrustTradeDialog;
import zw.co.escrow.ctradelive.view.fragments.PortfolioCashTransFragment;
import zw.co.escrow.ctradelive.view.fragments.UnitTrustOrdersFragment;

public class UnitTrustMainDashBoard extends AppCompatActivity {

    private Utils utils;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    Toolbar toolbar;
    private Bundle bundle;
    private String cdsnumber;
    private TextView txt1,txt2,txt3,txt4;
    private String currentValue,previousValue,netMovement,ntm_percentage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.unit_trust_main_dashboard);



        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        txt3 = findViewById(R.id.txt3);
        txt4 = findViewById(R.id.txt4);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(UnitTrustMainDashBoard.this);
        utils = new Utils(this);
        bundle = getIntent().getExtras();
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("UnitTrusts");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());

        cdsnumber = bundle.getString("cdsNumber");


        findViewById(R.id.chipDisInvest).setOnClickListener(view -> {

            Bundle bundle = new Bundle();
            bundle.putString("orderType",getString(R.string.deinvesttrusts));
            bundle.putString("cds_number",cdsnumber);
            new UnitTrustTradeDialog(this,bundle).show();
        });

        findViewById(R.id.chipInvest).setOnClickListener(view -> {
            Bundle bundle = new Bundle();
            bundle.putString("orderType",getString(R.string.investtrusts));
            bundle.putString("cds_number",cdsnumber);
            new UnitTrustTradeDialog(this,bundle).show();
        });
        findViewById(R.id.chipAvailableTrusts).setOnClickListener(view -> startActivity(new Intent(this,UnitTrustOrdersView.class)));

        getPortFolio();

    }

    private void getPortFolio(){
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        JSONObject job = new JSONObject();
        try{
            job.put("cdsNumber",cdsnumber);
            job.put("type","unit trust");
        }catch(Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(Request.Method.POST,COMPLETE_URL("account/portfolio"),job,
                response -> {
                    try{
                        List<Portfolio> portfolioList = new ArrayList<>();
                        for (int i = 0;i<response.length();i++){
                            JSONObject jo = response.getJSONObject(i);
                            Portfolio portfolio = new Portfolio();
                            portfolio.setCompanyFullName(jo.getString("name"));
                            portfolio.setCounter(jo.getString("company"));
                            portfolio.setCurrentprice(jo.getDouble("price"));
                            portfolio.setLastactivitydate(jo.getString("activeDate"));
                            portfolio.setNumbershares(jo.getDouble("shares"));
                            portfolio.setPrevprice(jo.getDouble("prev_price"));
                            portfolio.setNet(jo.getDouble("net"));
                            portfolio.setTotalportvalue(portfolio.getCurrentprice() * portfolio.getNumbershares());
                            portfolio.setTotalPrevPortValue(portfolio.getPrevprice() * jo.getDouble("prev_shares"));
                            //portfolio.setUncleared(jo.getString("uncleared"));
                            //portfolio.setReturns("returns");
                            portfolioList.add(portfolio);
                        }


                        List<Float> prevValueList = new ArrayList<>();
                        List<Float> currValueList = new ArrayList<>();

                        for (Portfolio p : portfolioList){
                            Float prevValue = convertToFloat(String.valueOf(p.getNumbershares())) * convertToFloat(String.valueOf(p.getPrevprice()));
                            Float todayValue = convertToFloat(String.valueOf(p.getNumbershares())) * convertToFloat(String.valueOf(p.getCurrentprice()));

                            prevValueList.add(prevValue);
                            currValueList.add(todayValue);

                        }

                        Float todayValue = 0f;
                        Float prevValue = 0f;

                        for(Float f : prevValueList)prevValue+=f;
                        for(Float f : currValueList)todayValue+=f;

                        Float netMovement = todayValue - prevValue;

                        Float percentage = (netMovement/todayValue)*100;

                        txt1.setText(getThousandSep(todayValue));
                        txt2.setText(getThousandSep(prevValue));
                        txt3.setText(getThousandSep(netMovement));
                        txt4.setText(String.valueOf(roundToDecimalPlace(percentage)));

                        bundle.putParcelableArrayList("portfolioList", (ArrayList<? extends Parcelable>) portfolioList);
                        setUpWatchList();
                        progressDialog.dismiss();

                    }catch (Exception e){
                        e.printStackTrace();
                        e.printStackTrace();
                    }
                },
                error -> {
                    error.printStackTrace();
                    progressDialog.dismiss();
                });

        jr.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return  5000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 5;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }

    private void setUpWatchList(){
        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("MY PORTFOLIO".toUpperCase(), PortfolioCashTransFragment.class,bundle)
                .add("My Orders", UnitTrustOrdersFragment.class)
                .create());
        watchListPager = findViewById(R.id.viewPagerWatchList);
        watchListPager.setAdapter(watchListPagerAdapter);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPagerTab.setViewPager(watchListPager);
    }

    private Float convertToFloat(String s){
        float i;
        try{
            i = Float.parseFloat(s);
        }catch (Exception e){
            i = 0;
        }
        return i;
    }

    private double convertToDouble(String s){
        double i;
        try{
            i = Double.parseDouble(s);
        }catch (Exception e){
            i = 0;
        }
        return i;
    }

    private String getThousandSep(Float amount){
        Float roundedAmount = roundToDecimalPlace(amount);
        DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance(Locale.US);
        DecimalFormatSymbols symbols = formatter.getDecimalFormatSymbols();
        symbols.setGroupingSeparator(',');
        formatter.setDecimalFormatSymbols(symbols);
        return formatter.format(roundedAmount);
    }
    private Float roundToDecimalPlace(Float amount){
        DecimalFormat df = new DecimalFormat("#.##");
        String value = df.format(amount);
        return Float.parseFloat(value);
    }




}
