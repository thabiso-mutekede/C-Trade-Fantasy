package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Contribution;


public class ContributionAdapter extends RecyclerView.Adapter {
    private final List<Contribution> contributions;

    public ContributionAdapter(List<Contribution> contributions) {
        this.contributions = contributions;
    }

    @Override
    public int getItemViewType(int position) {
        return  R.layout.ctrade_universal_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new RequestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((RequestViewHolder)holder).onBindData(contributions.get(position));
    }

    @Override
    public int getItemCount() {
        return contributions.size();
    }

    private class RequestViewHolder extends RecyclerView.ViewHolder{

        TextView left_tt,right_tt,status_tt,exit_tt;

        public RequestViewHolder(@NonNull View itemView) {
            super(itemView);

            left_tt = itemView.findViewById(R.id.left_tt);
            right_tt = itemView.findViewById(R.id.right_tt);
            status_tt = itemView.findViewById(R.id.status_tt);
            exit_tt = itemView.findViewById(R.id.date_ext);

        }

        private void onBindData(Contribution requestModel){
                left_tt.setText(requestModel.getName());
                String dt = String.format("Total Amount : %s",requestModel.getAmount());
                right_tt.setText(dt);
                if(requestModel.isActive()){
                    status_tt.setText("Active");
                }else{
                    status_tt.setText("Inactive");
                    exit_tt.setText(requestModel.getExit_date());
                }

            Log.d("lloda .. doing this",dt);

        }
    }
}
