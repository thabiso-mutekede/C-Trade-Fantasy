package zw.co.escrow.ctradelive.model;

public class MyCash {

    private double MyPotValue, MyPrevPotValue, MyProfitLoss, CashBal, VirtCashBal, ActualCashBal, totalAccount;

    public MyCash(double myPotValue, double myPrevPotValue, double myProfitLoss, double cashBal, double virtCashBal, double actualCashBal, double totalAccount) {
        MyPotValue = myPotValue;
        MyPrevPotValue = myPrevPotValue;
        MyProfitLoss = myProfitLoss;
        CashBal = cashBal;
        VirtCashBal = virtCashBal;
        ActualCashBal = actualCashBal;
        this.totalAccount = totalAccount;
    }

    public MyCash(MyCash myCash) {
        MyPotValue = myCash.getMyPotValue();
        MyPrevPotValue = myCash.getMyPrevPotValue();
        MyProfitLoss = myCash.getMyProfitLoss();
        CashBal = myCash.getCashBal();
        VirtCashBal = myCash.getVirtCashBal();
        ActualCashBal = myCash.getActualCashBal();
        this.totalAccount = totalAccount;
    }

    public double getMyPotValue() {
        return MyPotValue;
    }

    public void setMyPotValue(double myPotValue) {
        MyPotValue = myPotValue;
    }

    public double getMyPrevPotValue() {
        return MyPrevPotValue;
    }

    public void setMyPrevPotValue(double myPrevPotValue) {
        MyPrevPotValue = myPrevPotValue;
    }

    public double getMyProfitLoss() {
        return MyProfitLoss;
    }

    public void setMyProfitLoss(double myProfitLoss) {
        MyProfitLoss = myProfitLoss;
    }

    public double getCashBal() {
        return CashBal;
    }

    public void setCashBal(double cashBal) {
        CashBal = cashBal;
    }

    public double getVirtCashBal() {
        return VirtCashBal;
    }

    public void setVirtCashBal(double virtCashBal) {
        VirtCashBal = virtCashBal;
    }

    public double getActualCashBal() {
        return ActualCashBal;
    }

    public void setActualCashBal(double actualCashBal) {
        ActualCashBal = actualCashBal;
    }

    public double getTotalAccount() {
        return totalAccount;
    }

    public void setTotalAccount(double totalAccount) {
        this.totalAccount = totalAccount;
    }
}
