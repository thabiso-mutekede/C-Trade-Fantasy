package zw.co.escrow.ctradelive.view;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnContributionClosed;

public class ContributeClubDialog extends Dialog implements View.OnClickListener {


    private RadioGroup cnt_group;
    private String TRANS_TYPE = "CNT";
    private TextInputEditText etAmount;
    private Toolbar toolbar;
    private OnContributionClosed onContributionClosed;

    public ContributeClubDialog(@NonNull Context context) {
        super(context);
        setContentView(R.layout.contribute_club_view);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Club Transaction");
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(view -> dismiss());

        etAmount = findViewById(R.id.etAmount);
        cnt_group = findViewById(R.id.cnt_group);
        cnt_group.setOnCheckedChangeListener((radioGroup, i) -> {
            if(i == R.id.contribute_btn){
                TRANS_TYPE = "CNT";
            }else{
                TRANS_TYPE = "WTD";
            }
        });

        findViewById(R.id.btnPost).setOnClickListener(this);

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }


    public void setOnContributionClosed(OnContributionClosed onContributionClosed) {
        this.onContributionClosed = onContributionClosed;
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnPost){
            if(onContributionClosed != null){
                Float amount = Constants.convertToFloat(etAmount.getText().toString());
                if(amount == 0){
                    etAmount.setError("Enter A Valid Investment");
                }else {
                    onContributionClosed.process(TRANS_TYPE,String.valueOf(amount),this);
                }
            }else{
                Toast.makeText(getContext(),"Error",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
