package zw.co.escrow.ctradelive.listeners;

public interface OnProductSelected {

    void click(String product);
}
