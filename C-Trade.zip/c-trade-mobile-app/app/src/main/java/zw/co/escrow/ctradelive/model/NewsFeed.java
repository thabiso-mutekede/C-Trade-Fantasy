package zw.co.escrow.ctradelive.model;

/**
 * @author Godwin Tavirimirwa
 */
public class NewsFeed {
    private String title;
    private String heading;
    private String change;
    private String issuedShares;

    public NewsFeed() {
    }

    public NewsFeed(String title, String heading, String change, String issuedShares) {
        this.title = title;
        this.heading = heading;
        this.change = change;
        this.issuedShares = issuedShares;
    }

    public String getTitle() {
        return title;
    }

    public String getHeading() {
        return heading;
    }

    public String getChange() {
        return change;
    }

    public String getIssuedShares() {
        return issuedShares;
    }
}
