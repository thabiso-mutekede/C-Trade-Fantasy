package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.StringRequest;

import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.ActivityAdapter;
import zw.co.escrow.ctradelive.model.CTradeActivity;

public class RecentActivityDialog extends Dialog {

    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private List<CTradeActivity> cTradeActivityList;

    public RecentActivityDialog(@NonNull Context context,String cds_number,List<CTradeActivity> cTradeActivityList) {
        super(context);
        setContentView(R.layout.recent_activity_dialog);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Recent Activity".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        Log.d("lloda","act cont = " +cTradeActivityList.size());

        ActivityAdapter activityAdapter = new ActivityAdapter(cTradeActivityList);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(activityAdapter);
        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        setCancelable(false);

        clearNotifications(cds_number);
    }

    private void clearNotifications(String userCDS){
        String url = AppConfig.getIp().concat("activityViewed?cdsnumber=").concat(userCDS);
        Log.d("lloda",url);
        StringRequest sr = new StringRequest(url,response -> Log.d("resp","ran"),error -> error.printStackTrace());
        AppConfig.getInstance().addToRequestQueue(sr);
    }
}
