package zw.co.escrow.ctradelive.view;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputLayout;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;

public class ForgotPasswordActivity extends AppCompatActivity {

    private Utils utils;

    private TextInputLayout outlinedTextFieldEmail, outlinedTextFieldIDNum, outlinedTextFieldNewPass, outlinedTextFieldConfirmPass;
    private static final String TAG = "ForgotPasswordActivity";

    AppConfig appConfig;
    String ip;
    private Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(ForgotPasswordActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("RESET PASSWORD");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }

        outlinedTextFieldEmail =findViewById(R.id.outlinedTextFieldEmail);
        outlinedTextFieldIDNum =findViewById(R.id.outlinedTextFieldIDNum);
        outlinedTextFieldNewPass =findViewById(R.id.outlinedTextFieldNewPass);
        outlinedTextFieldConfirmPass =findViewById(R.id.outlinedTextFieldConfirmPass);

        appConfig = (AppConfig) getApplication();
        ip = AppConfig.getIpAddress();


        findViewById(R.id.btnReset).setOnClickListener(view -> {

            String email = outlinedTextFieldEmail.getEditText().getText().toString();
            String idNumber = outlinedTextFieldIDNum.getEditText().getText().toString();
            String newPassword = outlinedTextFieldNewPass.getEditText().getText().toString();
            String confirmPassword = outlinedTextFieldConfirmPass.getEditText().getText().toString();


            if (email.equals("")) {
                outlinedTextFieldEmail.setError("Enter email");
            }
            else if (idNumber.equals("")){
                outlinedTextFieldIDNum.setError("Enter ID number");

            }
            else if (newPassword.equals("")){
                outlinedTextFieldNewPass.setError("Enter password");

            }
            else if (confirmPassword.equals("")){
                outlinedTextFieldConfirmPass.setError("Confirm password");

            }
            else if (!confirmPassword.equals(newPassword)){
                outlinedTextFieldConfirmPass.setError("Passwords do not match");
                outlinedTextFieldNewPass.setError("Passwords do not match");


            }
            else {
                outlinedTextFieldEmail.setErrorEnabled(false);
                outlinedTextFieldIDNum.setErrorEnabled(false);
                outlinedTextFieldNewPass.setErrorEnabled(false);
                outlinedTextFieldConfirmPass.setErrorEnabled(false);

                //Todo show progress bar
                Login login = new Login();
                login.execute(email, newPassword, idNumber);



            }

        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public class Login extends AsyncTask<String, Void, String> {
        String add_info_url;

        @Override
        protected void onPreExecute() {
            add_info_url = AppConfig.getFullMobileApiAddress().concat("/ResetPassword");
        }

        @Override
        protected String doInBackground(String... args) {
            String identification, password, id;
            identification = args[0];
            password = args[1];
            id = args[2];

            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(
                                new OutputStreamWriter(outputStream, "UTF-8"));

                String data_string =
                        URLEncoder.encode("email", "UTF-8") + "=" +
                                URLEncoder.encode(identification, "UTF-8")
                                + "&" + URLEncoder.encode("natId", "UTF-8") +
                                "=" + URLEncoder.encode(id, "UTF-8")
                                + "&" + URLEncoder.encode("newpass", "UTF-8") +
                                "=" + URLEncoder.encode(password, "UTF-8");
                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

//                reading from server
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("response " + response);
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }

        @Override
        protected void onPostExecute(String result) {
           /* if (progressDialog != null)
                progressDialog.dismiss();*/

           //Todo remove progress

            switch (result) {
                case "1":

                    new AlertDialog.Builder(ForgotPasswordActivity.this)
                            .setCancelable(false)
                            .setMessage("Password successfully changed. You can now login.")
                            .setPositiveButton("OK", (dialog, which) -> {
                                startActivity(new Intent(getApplicationContext(),
                                        LoginActivity2.class));
                                finish();
                            }).show();

                    break;
                case "2":

                    new AlertDialog.Builder(ForgotPasswordActivity.this)
                            .setCancelable(false)
                            .setMessage("Please enter a correct email address")
                            .setPositiveButton("OK", (dialog, which) -> {
                            }).show();

                    break;
                case "4":

                    new AlertDialog.Builder(ForgotPasswordActivity.this)
                            .setCancelable(false)
                            .setMessage("Please enter the correct national Id")
                            .setPositiveButton("OK", (dialog, which) -> {
                            }).show();
                    break;
                default:

                    new AlertDialog.Builder(ForgotPasswordActivity.this)
                            .setCancelable(false)
                            .setMessage("Something went wrong, please try again")
                            .setPositiveButton("OK", (dialog, which) -> {
                            }).show();
                    break;
            }
        }

        @Override
        protected void onProgressUpdate(Void... values) {
           /* if (progressDialog != null)
                progressDialog.dismiss();*/
            //Todo remove progress
            super.onProgressUpdate(values);
        }
    }

}