package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.view.ClubView;


public class MyClubsAdapter extends RecyclerView.Adapter {

    private final List<ClubModel> clubModelList;
    private final Context context;
    private final RecyclerView recyclerView;

    public MyClubsAdapter(List<ClubModel> clubModelList, Context context, RecyclerView recyclerView) {
        this.clubModelList = clubModelList;
        this.context = context;
        this.recyclerView = recyclerView;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.club_list_row;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView;
        itemView = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        itemView.setOnClickListener(v -> {
            ClubModel clubModel = clubModelList.get(recyclerView.getChildLayoutPosition(itemView));
            context.startActivity(new Intent(context, ClubView.class).putExtra("club",clubModel));
        });
        return new MyClubsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((MyClubsViewHolder)holder).bindData(clubModelList.get(position));
    }

    @Override
    public int getItemCount() {
        return clubModelList.size();
    }


    private class MyClubsViewHolder extends RecyclerView.ViewHolder{

        TextView club_name_tv,my_club_title_tv,last_updated_date_tv,notifications_count_tv;
        LinearLayout notDisplay;

        public MyClubsViewHolder(@NonNull View itemView) {
            super(itemView);

            club_name_tv = itemView.findViewById(R.id.cname_txt);
            my_club_title_tv = itemView.findViewById(R.id.ctitle_txt);
            last_updated_date_tv = itemView.findViewById(R.id.cdate_tv);
            notifications_count_tv = itemView.findViewById(R.id.cnot_txt);
            notDisplay = itemView.findViewById(R.id.not_display);
        }

        public void bindData(ClubModel clubModel){
            int count_not =  convertToInt(clubModel.getInvNote()) + convertToInt(clubModel.getMbNote())
                    + convertToInt(clubModel.getNbNote()) + convertToInt(clubModel.getContNote());
            if(count_not <= 0)notDisplay.setVisibility(View.GONE);
            String title = clubModel.isMember() ? "MEMBER" : "CHAIRMAN";
            club_name_tv.setText(clubModel.getClubName());
            my_club_title_tv.setText(title);
            notifications_count_tv.setText(String.valueOf(count_not));
            last_updated_date_tv.setText(clubModel.getLast_updated());

        }
        private int convertToInt(String s){
            int i;
            try{
                i = Integer.parseInt(s);
            }catch (Exception e){
                i = 0;
            }
            return i;
        }
    }
}
