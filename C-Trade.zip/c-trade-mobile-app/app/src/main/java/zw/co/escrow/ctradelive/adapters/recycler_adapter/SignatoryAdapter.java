package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Signatory;

public class SignatoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<Signatory> signatories;
    public SignatoryAdapter(List<Signatory> signatories) {
        this.signatories = signatories;
    }
    @Override
    public int getItemViewType(int position) {
        return R.layout.ctrade_universal_adapter_view;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new SignatoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((SignatoryViewHolder)holder).onBindData(signatories.get(position));
    }

    @Override
    public int getItemCount() {
        return signatories.size();
    }

    private class SignatoryViewHolder extends RecyclerView.ViewHolder {

        TextView signatoryDetailsTxt,signatoryNameTxt;

        public SignatoryViewHolder(@NonNull View itemView) {
            super(itemView);
            signatoryDetailsTxt = itemView.findViewById(R.id.right_tt);
            signatoryNameTxt = itemView.findViewById(R.id.left_tt);
        }

        public void onBindData(Signatory signatory){
            signatoryNameTxt.setText(signatory.getSignatoryName());
            String details = String.format("Phone : %s\nEmail : %s"
                    ,signatory.getSignatoryPhone()
                    ,signatory.getSignatoryEmail());
            signatoryDetailsTxt.setText(details);
        }
    }
}
