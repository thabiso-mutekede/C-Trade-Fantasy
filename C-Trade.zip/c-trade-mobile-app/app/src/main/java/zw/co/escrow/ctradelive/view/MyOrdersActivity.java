package zw.co.escrow.ctradelive.view;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.view.fragments.MyOrdersFragment;
import zw.co.escrow.ctradelive.view.fragments.OpenBuyOrdersFragment;
import zw.co.escrow.ctradelive.view.fragments.OpenSellOrdersFragment;

public class MyOrdersActivity extends AppCompatActivity {

    private Utils utils;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    private ExtendedFloatingActionButton fabAutoTrade;

    private Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_orders);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(MyOrdersActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("MY ORDERS");



        fabAutoTrade = findViewById(R.id.fabAutoTrade);

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }

        fabAutoTrade.setOnClickListener(view -> {

            startActivityForResult(new Intent(this, AutoTradePostingActivity.class), Constants.AUTO_TRADE_REQUEST_CODE);

        });





        setUpWatchList();


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpWatchList(){

        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("MY ORDERS", MyOrdersFragment.class,getIntent().getExtras())
                .add("MARKET SUPPLY", OpenSellOrdersFragment.class,getIntent().getExtras())
                .add("MARKET DEMAND", OpenBuyOrdersFragment.class,getIntent().getExtras())
                .create());
        watchListPager = findViewById(R.id.viewPagerWatchList);
        watchListPager.setAdapter(watchListPagerAdapter);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPagerTab.setViewPager(watchListPager);
    }

  /*  @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        switch (requestCode){
            case Constants.AUTO_TRADE_REQUEST_CODE:

                Intent i = new Intent(getActivity(), AutoTradingPosting.class);

                amount= data != null ? data.getStringExtra("AMOUNT") : null;
                Toast.makeText(this, "Converted "+amount, Toast.LENGTH_SHORT).show();
                ConvertFunds convertFunds = new ConvertFunds(this);
                if (amount != null) convertFunds.convertFunds(amount);

                break;
    }*/
}