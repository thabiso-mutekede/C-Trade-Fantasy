package zw.co.escrow.ctradelive.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Arrays;
import java.util.List;

import de.codecrafters.tableview.TableView;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;
import zw.co.escrow.ctradelive.view.dialogs.SearchClubDialog;


public class SearchClubs extends Fragment implements InvestmentClub.ICRefreshRefreshLister {

    public static final int COLUMN_SIZE = 6;
    public static int ROW_SIZE = 59;
    private List<String> headers = Arrays.asList("GROUP NAME","OPTION","DATE CREATED","MEMBERS","PORTFOLIO","CASH");
    private TableView m_iTableView;
    private InvestmentClub.ClubServicesListener clubServicesListener;
    FloatingActionButton floatingActionButton;
    private SearchClubDialog searchClubDialog;
    private SharedPreferences preferences;
    String cds_number;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_search_clubs_view,container,false);
        searchClubDialog = new SearchClubDialog(getContext(),this);
        floatingActionButton = view.findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(v -> searchClubDialog.show());
        clubServicesListener = new InvestmentClubService(getContext(), headers);
        preferences = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cds_number = preferences.getString("cds_number", "");
        clubServicesListener.onSearchCTradeClubs(cds_number);
        return view;
    }

    @Override
    public void doRefresh(String msg) {
        clubServicesListener = new InvestmentClubService(getContext(), headers);
        clubServicesListener.onSearchCTradeClubsByText(msg);
    }
}