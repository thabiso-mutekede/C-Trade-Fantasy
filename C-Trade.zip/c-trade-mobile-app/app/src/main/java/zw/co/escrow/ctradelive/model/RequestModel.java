package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class RequestModel implements Parcelable {

    private String clubname;
    private String cds;
    private String phone;
    private String name;
    private String email;
    private String date;
    private String token;

    public RequestModel() {
    }

    protected RequestModel(Parcel in) {
        clubname = in.readString();
        cds = in.readString();
        phone = in.readString();
        name = in.readString();
        email = in.readString();
        date = in.readString();
        token = in.readString();
    }

    public static final Creator<RequestModel> CREATOR = new Creator<RequestModel>() {
        @Override
        public RequestModel createFromParcel(Parcel in) {
            return new RequestModel(in);
        }

        @Override
        public RequestModel[] newArray(int size) {
            return new RequestModel[size];
        }
    };

    public String getClubname() {
        return clubname;
    }

    public void setClubname(String clubname) {
        this.clubname = clubname;
    }

    public String getCds() {
        return cds;
    }

    public void setCds(String cds) {
        this.cds = cds;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(clubname);
        parcel.writeString(cds);
        parcel.writeString(phone);
        parcel.writeString(name);
        parcel.writeString(email);
        parcel.writeString(date);
        parcel.writeString(token);
    }
}
