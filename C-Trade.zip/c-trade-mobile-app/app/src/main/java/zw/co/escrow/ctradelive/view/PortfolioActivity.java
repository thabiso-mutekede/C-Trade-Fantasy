package zw.co.escrow.ctradelive.view;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.Portfolio;
import zw.co.escrow.ctradelive.view.fragments.MarketWatchPlaceHolderFragment;
import zw.co.escrow.ctradelive.view.fragments.PortfolioCashTransFragment;

import static zw.co.escrow.ctradelive.Constants.convertToFloat;
import static zw.co.escrow.ctradelive.Constants.getThousandSep;
import static zw.co.escrow.ctradelive.Constants.roundToDecimalPrice;

public class PortfolioActivity extends AppCompatActivity {

    private Utils utils;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    Toolbar toolbar;
    private Bundle bundle;
    private String cdsnumber;
    private TextView txt1,txt2,txt3,txt4;
    private final String pdf_url = Constants.COMPLETE_URL("pdf/portfolio?cdsnumber=%s&type=equity");

    private String currentValue,previousValue,netMovement,ntm_percentage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portfolio);

        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        txt3 = findViewById(R.id.txt3);
        txt4 = findViewById(R.id.txt4);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(PortfolioActivity.this);
        utils = new Utils(this);
        bundle = getIntent().getExtras();
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Portfolio");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());

        cdsnumber = bundle.getString("cdsNumber");

        findViewById(R.id.pdfDownload).setOnClickListener(
                v -> {
                    Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format(pdf_url,cdsnumber)));
                    startActivity(myIntent);
                }
        );

        getPortFolio();

    }


    /*private void fetchPortfolio(){

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        ApiClubInterface api = ApiClubsClient.getApiService();
        Call<List<Portfolio>> portCall = api.getPortfolioListForMain(cdsnumber,"equity");
        portCall.enqueue(new Callback<List<Portfolio>>() {
            @Override
            public void onResponse(Call<List<Portfolio>> call, Response<List<Portfolio>> response) {

                List<Float> prevValueList = new ArrayList<>();
                List<Float> currValueList = new ArrayList<>();

                for (Portfolio p : response.body()){
                    Float prevValue = convertToFloat(p.getNumbershares()) * convertToFloat(p.getPrevprice());
                    Float todayValue = convertToFloat(p.getNumbershares()) * convertToFloat(p.getCurrentprice());

                    prevValueList.add(prevValue);
                    currValueList.add(todayValue);

                }

                Float todayValue = 0f;
                Float prevValue = 0f;

                for(Float f : prevValueList)prevValue+=f;
                for(Float f : currValueList)todayValue+=f;

                Float netMovement = todayValue - prevValue;

                Float percentage = (netMovement/todayValue)*100;

                txt1.setText(getThousandSep(todayValue));
                txt2.setText(getThousandSep(prevValue));
                txt3.setText(getThousandSep(netMovement));
                txt4.setText(String.valueOf(roundToDecimalPlace(percentage)));

                bundle.putParcelableArrayList("portfolioList", (ArrayList<? extends Parcelable>) response.body());
                setUpWatchList();
                progressDialog.dismiss();

            }
            @Override
            public void onFailure(Call<List<Portfolio>> call, Throwable t) {
                t.printStackTrace();
                progressDialog.dismiss();
            }
        });
    }*/

    private void getPortFolio(){
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        JSONObject job = new JSONObject();
        try{
            job.put("cdsNumber",cdsnumber);
            job.put("type","equity");
        }catch(Exception e){
            e.printStackTrace();
        }

        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(Request.Method.POST,Constants.COMPLETE_URL("account/portfolio"),
                job,
                response -> {
                    try{
                        /***
                         * {
                         *         "company": "TURN.ZW",
                         *         "cds_number": "0/50114",
                         *         "activeDate": "2021-01-27T09:29:00.503+00:00",
                         *         "shares": 100,
                         *         "prev_shares": 100,
                         *         "price": 4.0,
                         *         "prev_price": 3.9,
                         *         "uncleared": 0,
                         *         "net": 100,
                         *         "name": "Turnall Holdings Limited",
                         *         "instrument": "EQUITY"
                         *     }
                         */
                        List<Portfolio> portfolioList = new ArrayList<>();
                        for (int i = 0;i<response.length();i++){
                            JSONObject jo = response.getJSONObject(i);
                            Portfolio portfolio = new Portfolio();
                            portfolio.setCompanyFullName(jo.getString("name"));
                            portfolio.setCounter(jo.getString("company"));
                            portfolio.setCurrentprice(jo.getDouble("price"));
                            portfolio.setLastactivitydate(jo.getString("activeDate"));
                            portfolio.setNumbershares(jo.getDouble("shares"));
                            portfolio.setPrevprice(jo.getDouble("prev_price"));
                            portfolio.setNet(jo.getDouble("net"));
                            portfolio.setTotalportvalue(portfolio.getCurrentprice() * portfolio.getNumbershares());
                            portfolio.setTotalPrevPortValue(portfolio.getPrevprice() * jo.getDouble("prev_shares"));
                            //portfolio.setUncleared(jo.getString("uncleared"));
                            //portfolio.setReturns("returns");
                            portfolioList.add(portfolio);
                        }


                        List<Float> prevValueList = new ArrayList<>();
                        List<Float> currValueList = new ArrayList<>();

                        for (Portfolio p : portfolioList){
                            Float prevValue = convertToFloat(String.valueOf(p.getNumbershares())) * convertToFloat(String.valueOf(p.getPrevprice()));
                            Float todayValue = convertToFloat(String.valueOf(p.getNumbershares())) * convertToFloat(String.valueOf(p.getCurrentprice()));

                            prevValueList.add(prevValue);
                            currValueList.add(todayValue);

                        }

                        Float todayValue = 0f;
                        Float prevValue = 0f;

                        for(Float f : prevValueList)prevValue+=f;
                        for(Float f : currValueList)todayValue+=f;

                        Float netMovement = todayValue - prevValue;

                        Float percentage = (netMovement/todayValue)*100;

                        txt1.setText(Constants.getThousandSep(todayValue));
                        txt2.setText(Constants.getThousandSep(prevValue));
                        txt3.setText(Constants.getThousandSep(netMovement));
                        txt4.setText(String.valueOf(roundToDecimalPrice(percentage)));

                        bundle.putParcelableArrayList("portfolioList", (ArrayList<? extends Parcelable>) portfolioList);
                        setUpWatchList();
                        progressDialog.dismiss();

                    }catch (Exception e){
                        e.printStackTrace();
                        e.printStackTrace();
                    }
                },
                error -> {
                    error.printStackTrace();
                    progressDialog.dismiss();
                });

        jr.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return  5000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 5;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }


    private void setUpWatchList(){
        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("My Portfolio".toUpperCase(), PortfolioCashTransFragment.class,bundle)
                .add("FINSEC", MarketWatchPlaceHolderFragment.class)
                .add("CERTIFICATES", MarketWatchPlaceHolderFragment.class)
                .create());
        watchListPager = findViewById(R.id.viewPagerWatchList);
        watchListPager.setAdapter(watchListPagerAdapter);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPagerTab.setViewPager(watchListPager);
    }
}