package zw.co.escrow.ctradelive;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.AsyncTask;
import android.util.Log;

import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.view.LoginActivity2;
import zw.co.escrow.ctradelive.view_model.AppViewModel;


public class CustodianAsyncTask extends AsyncTask<String, Void, String> {
        String add_info_url;
        List<String> allBrokers = new ArrayList<>();
    private WeakReference<Activity> activityWeakReference; // To prevent memory leaks
    private static final String TAG = "CustodianAsyncTask";


    public CustodianAsyncTask(Activity activity) {
        activityWeakReference = new WeakReference<>(activity);
    }

    @Override
        protected void onPreExecute() {
            add_info_url = "https://" + Constants.APP_BASE_URL + "/GetCustodian";
        }

        @Override
        protected String doInBackground(String... args) {
            String company;
            company = args[0];
            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(
                                new OutputStreamWriter(outputStream, "UTF-8"));

                String data_string =
                        URLEncoder.encode("company", "UTF-8") + "="
                                + URLEncoder.encode(company, "UTF-8");

                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

//                reading from server
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }

        @Override
        protected void onPostExecute(String result) {
           /* if (progressDialog != null)
                progressDialog.dismiss();*/
            LoginActivity2 activity = (LoginActivity2) activityWeakReference.get();

            // todo  enableUserInteraction();
            try {
                JSONArray jsonArray = new JSONArray(result);

                if (jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String isin = jsonObject.optString("Code");
                        allBrokers.add(isin);
                    }

                    ViewModelProvider viewModelProvider = new ViewModelProvider((ViewModelStoreOwner) activity);
                    AppViewModel appViewModel = viewModelProvider.get(AppViewModel.class);

                    //post the data to AppViewModel
                    appViewModel.setBrokers(allBrokers);

                }
                else {
                    allBrokers.add("No brokers");
                }
            } catch (JSONException e) {
                Log.d(TAG, "onPostExecute: "+e.getMessage());
                new AlertDialog.Builder(activity)
                        .setCancelable(false)
                        .setMessage(activity.getResources().getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {
//                            activity.startActivity(new Intent(activity,
//                                    MainActivity.class));
//                            activity.finish();
                        })
                        .show();
            }
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            /*if (progressDialog != null)
                progressDialog.dismiss();*/
            super.onProgressUpdate(values);
        }
    }
