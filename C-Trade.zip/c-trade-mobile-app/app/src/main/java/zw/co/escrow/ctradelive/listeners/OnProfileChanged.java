package zw.co.escrow.ctradelive.listeners;

import android.app.Dialog;

import androidx.annotation.NonNull;

import zw.co.escrow.ctradelive.model.Profile;

public interface OnProfileChanged {
    void submit(@NonNull Dialog dialog, @NonNull Profile profile);
}
