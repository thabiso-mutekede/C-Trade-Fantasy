package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class ContributionStatement implements Parcelable {
    private String name;
    private String contribution_;
    private String cumulative;
    private String cdsnumber;
    private Boolean active;
    private String exit_date;

    public ContributionStatement() {
    }

    protected ContributionStatement(Parcel in) {
        name = in.readString();
        contribution_ = in.readString();
        cumulative = in.readString();
        cdsnumber = in.readString();
        byte tmpActive = in.readByte();
        active = tmpActive == 0 ? null : tmpActive == 1;
        exit_date = in.readString();
    }

    public static final Creator<ContributionStatement> CREATOR = new Creator<ContributionStatement>() {
        @Override
        public ContributionStatement createFromParcel(Parcel in) {
            return new ContributionStatement(in);
        }

        @Override
        public ContributionStatement[] newArray(int size) {
            return new ContributionStatement[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(contribution_);
        parcel.writeString(cumulative);
        parcel.writeString(cdsnumber);
        parcel.writeByte((byte) (active == null ? 0 : active ? 1 : 2));
        parcel.writeString(exit_date);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContribution_() {
        return contribution_;
    }

    public void setContribution_(String contribution_) {
        this.contribution_ = contribution_;
    }

    public String getCumulative() {
        return cumulative;
    }

    public void setCumulative(String cumulative) {
        this.cumulative = cumulative;
    }

    public String getCdsnumber() {
        return cdsnumber;
    }

    public void setCdsnumber(String cdsnumber) {
        this.cdsnumber = cdsnumber;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getExit_date() {
        return exit_date;
    }

    public void setExit_date(String exit_date) {
        this.exit_date = exit_date;
    }
}
