package zw.co.escrow.ctradelive.model;


import android.os.Parcel;
import android.os.Parcelable;

public class OpenSellOrder implements Parcelable {

    private String fullCompanyName, ticker, isin, bestAsk, currentPrice, askVolume, option;




    public OpenSellOrder() {
    }


    public OpenSellOrder(String fullCompanyName, String ticker, String isin, String bestAsk, String currentPrice, String askVolume, String option) {
        this.fullCompanyName = fullCompanyName;
        this.ticker = ticker;
        this.isin = isin;
        this.bestAsk = bestAsk;
        this.currentPrice = currentPrice;
        this.askVolume = askVolume;
        this.option = option;
    }

    public String getFullCompanyName() {
        return fullCompanyName;
    }

    public void setFullCompanyName(String fullCompanyName) {
        this.fullCompanyName = fullCompanyName;
    }

    public String getOption() {
        return option;
    }

    public void setOption(String option) {
        this.option = option;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public String getBestAsk() {
        return bestAsk;
    }

    public void setBestAsk(String bestAsk) {
        this.bestAsk = bestAsk;
    }

    public String getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public String getAskVolume() {
        return askVolume;
    }

    public void setAskVolume(String askVolume) {
        this.askVolume = askVolume;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

    }
}