package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Details implements Parcelable {
    private String accountType;

    private String surname;
    private String forenames;
    private String title;
    private String nationality;
    private String city;
    private String tel;
    private String mobile;
    private String idnoPP;
    private String dob;
    private String gender;
    private String add1;
    private String email;
    private String cashBank;
    private String cashBranch;
    private String cashAccountNo;
    private String custodian;
    private String createdBy;
    private String client_occupation;
    private String industry_of_profession;
    private String pep_status;
    private String cdc_number;

    public Details() {
    }

    protected Details(Parcel in) {
        accountType = in.readString();
        surname = in.readString();
        forenames = in.readString();
        title = in.readString();
        nationality = in.readString();
        city = in.readString();
        tel = in.readString();
        mobile = in.readString();
        idnoPP = in.readString();
        dob = in.readString();
        gender = in.readString();
        add1 = in.readString();
        email = in.readString();
        cashBank = in.readString();
        cashBranch = in.readString();
        cashAccountNo = in.readString();
        custodian = in.readString();
        createdBy = in.readString();
        client_occupation = in.readString();
        industry_of_profession = in.readString();
        pep_status = in.readString();
        cdc_number = in.readString();
    }

    public static final Creator<Details> CREATOR = new Creator<Details>() {
        @Override
        public Details createFromParcel(Parcel in) {
            return new Details(in);
        }

        @Override
        public Details[] newArray(int size) {
            return new Details[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(accountType);
        parcel.writeString(surname);
        parcel.writeString(forenames);
        parcel.writeString(title);
        parcel.writeString(nationality);
        parcel.writeString(city);
        parcel.writeString(tel);
        parcel.writeString(mobile);
        parcel.writeString(idnoPP);
        parcel.writeString(dob);
        parcel.writeString(gender);
        parcel.writeString(add1);
        parcel.writeString(email);
        parcel.writeString(cashBank);
        parcel.writeString(cashBranch);
        parcel.writeString(cashAccountNo);
        parcel.writeString(custodian);
        parcel.writeString(createdBy);
        parcel.writeString(client_occupation);
        parcel.writeString(industry_of_profession);
        parcel.writeString(pep_status);
        parcel.writeString(cdc_number);
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getForenames() {
        return forenames;
    }

    public void setForenames(String forenames) {
        this.forenames = forenames;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getIdnoPP() {
        return idnoPP;
    }

    public void setIdnoPP(String idnoPP) {
        this.idnoPP = idnoPP;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAdd1() {
        return add1;
    }

    public void setAdd1(String add1) {
        this.add1 = add1;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCashBank() {
        return cashBank;
    }

    public void setCashBank(String cashBank) {
        this.cashBank = cashBank;
    }

    public String getCashBranch() {
        return cashBranch;
    }

    public void setCashBranch(String cashBranch) {
        this.cashBranch = cashBranch;
    }

    public String getCashAccountNo() {
        return cashAccountNo;
    }

    public void setCashAccountNo(String cashAccountNo) {
        this.cashAccountNo = cashAccountNo;
    }

    public String getCustodian() {
        return custodian;
    }

    public void setCustodian(String custodian) {
        this.custodian = custodian;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getClient_occupation() {
        return client_occupation;
    }

    public void setClient_occupation(String client_occupation) {
        this.client_occupation = client_occupation;
    }

    public String getIndustry_of_profession() {
        return industry_of_profession;
    }

    public void setIndustry_of_profession(String industry_of_profession) {
        this.industry_of_profession = industry_of_profession;
    }

    public String getCdc_number() {
        return cdc_number;
    }

    public void setCdc_number(String cdc_number) {
        this.cdc_number = cdc_number;
    }

    public String getPep_status() {
        return pep_status;
    }

    public void setPep_status(String pep_status) {
        this.pep_status = pep_status;
    }
}
