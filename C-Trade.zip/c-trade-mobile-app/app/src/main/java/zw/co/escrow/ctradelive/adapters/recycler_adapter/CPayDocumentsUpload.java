package zw.co.escrow.ctradelive.adapters.recycler_adapter;
//
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.Toolbar;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//
//import android.Manifest;
//import android.app.Activity;
//import android.content.ContentResolver;
//import android.content.Intent;
//import android.content.pm.PackageManager;
//import android.database.Cursor;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Bundle;
//import android.provider.MediaStore;
//import android.provider.OpenableColumns;
//import android.view.View;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import java.io.File;
//
//import okhttp3.MediaType;
//import okhttp3.MultipartBody;
//import okhttp3.RequestBody;
//import zw.co.escrow.ctradelive.R;
//import zw.co.escrow.ctradelive.setup.listeners.Forex;
//import zw.co.escrow.ctradelive.setup.services.ForexService;
//
//public class CPayDocumentsUpload extends AppCompatActivity implements View.OnClickListener {
//
//    private Forex.ForexServicesListener forexServicesListener;
//    private String taxPath,c14Path,cdsnumber;
//    private TextView txt_cr14,txt_tax;
//    private final int REQUEST_CR14 = 500,REQUEST_TAX_C = 501,REQUEST_PERMISSION = 700;
//    private Bundle bundle;
//    private Toolbar toolbar;
//    private int type;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_c_pay_documents_upload);
//        forexServicesListener = new ForexService(this);
//
//        toolbar = findViewById(R.id.toolbar);
//        toolbar.setTitle("Auction Documents");
//        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
//        setSupportActionBar(toolbar);
//        toolbar.setNavigationOnClickListener(v -> finish());
//
//        txt_cr14 = findViewById(R.id.cr14_tv);
//        txt_tax = findViewById(R.id.txt_tax_c_);
//        bundle = getIntent().getExtras();
//        findViewById(R.id.upload_cr14_view).setOnClickListener(this);
//        findViewById(R.id.corporate_tax_).setOnClickListener(this);
//        findViewById(R.id.btnPost).setOnClickListener(this);
//
//        cdsnumber = bundle.getString("cdsnumber");
//        type = bundle.getInt("type");
//
//        checkPermissions();
//    }
//
//    private void checkPermissions() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
//                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
//                    REQUEST_PERMISSION);
//
//            return;
//        }
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        switch(requestCode){
//            case  REQUEST_CR14:
//                if (requestCode == REQUEST_CR14) {
//                    if (resultCode == Activity.RESULT_OK) {
//                        Uri uri = data.getData();
//                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
//                        // Get the cursor
//                        Cursor cursor = getContentResolver().query(uri, filePathColumn, null, null, null);
//                        // Move to first row
//                        cursor.moveToFirst();
//                        //Get the column index of MediaStore.Images.Media.DATA
//                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
//                        //Gets the String value in the column
//                        String imgDecodableString = cursor.getString(columnIndex);
//                        cursor.close();
//                        // Set the Image in ImageView after decoding the String
//                        //imageView.setImageBitmap(BitmapFactory.decodeFile(imgDecodableString));
//                        //uploadToServerPS(imgDecodableString);
//                        c14Path = imgDecodableString;
//                        String name = queryName(getContentResolver(),uri);
//                        txt_cr14.setText(name);
//                        //Toast.makeText(this, "uploadToServerPS" + imgDecodableString, Toast.LENGTH_LONG).show();
//                    }
//                }
//                break;
//
//            case REQUEST_TAX_C:
//                if (requestCode == REQUEST_TAX_C) {
//                    if (resultCode == Activity.RESULT_OK) {
//                        Uri uri = data.getData();
//                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
//                        // Get the cursor
//                        Cursor cursor = getContentResolver().query(uri, filePathColumn, null, null, null);
//                        // Move to first row
//                        cursor.moveToFirst();
//                        //Get the column index of MediaStore.Images.Media.DATA
//                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
//                        //Gets the String value in the column
//                        String imgDecodableString = cursor.getString(columnIndex);
//                        cursor.close();
//                        taxPath = imgDecodableString;
//                        String name = queryName(getContentResolver(),uri);
//                        txt_tax.setText(name);
//                    }
//                }
//                break;
//        }
//    }
//
//    private String queryName(ContentResolver resolver, Uri uri) {
//        Cursor returnCursor =
//                resolver.query(uri, null, null, null, null);
//        assert returnCursor != null;
//        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
//        returnCursor.moveToFirst();
//        String name = returnCursor.getString(nameIndex);
//        returnCursor.close();
//        return name;
//    }
//
//    private void attachDocumentsDocsCorp(String cdsNumber){
//        File taxFile = new File(taxPath);
//        File c14File = new File(c14Path);
//        RequestBody fileReqT = RequestBody.create(MediaType.parse("image/*"), taxFile);
//        MultipartBody.Part tax = MultipartBody.Part.createFormData("taxClearance", taxFile.getName(), fileReqT);
//        RequestBody fileReqC = RequestBody.create(MediaType.parse("image/*"), c14File);
//        MultipartBody.Part c14 = MultipartBody.Part.createFormData("cr14", c14File.getName(), fileReqC);
//        RequestBody cdsno = RequestBody.create(MediaType.parse("text/plain"),cdsNumber);
//        forexServicesListener.onAttachDocumentsCorp(cdsno,tax,c14);
//    }
//
//    private void makeToast(String msg){
//        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
//    }
//
//
//    @Override
//    public void onClick(View view) {
//        switch (view.getId()){
//            case R.id.upload_cr14_view:
//                Intent cr14 = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                startActivityForResult(cr14, REQUEST_CR14);
//                break;
//            case R.id.corporate_tax_:
//                Intent taxC = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                startActivityForResult(taxC, REQUEST_TAX_C);
//                break;
//
//            case R.id.btnPost:
//                if(taxPath == null )makeToast("Please Upload Tax Clrearance");
//                else if(c14Path == null )makeToast("Please Upload CR 14");
//                else attachDocumentsDocsCorp(cdsnumber);
//                break;
//        }
//    }
//}