package zw.co.escrow.ctradelive.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.github.mikephil.charting.charts.LineChart;
import com.github.ybq.android.spinkit.style.MultiplePulseRing;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zw.co.escrow.ctradelive.App;
import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.ChartDataAdapter;

public class OneDayGraphFragment extends Fragment {

    private View view;
    private static final String TAG = "OneDayGraphFragment";
    private static final String ARG_SECTION_NUMBER = "section_number";
    private ChartDataAdapter chartDataAdapter;
    LineChart historyChart;
    private RecyclerView mRecyclerView;
    AppConfig appConfig;
    String exchange, get_companies_url, ip;
    private String felloverip1, felloverip2, fellOverPhp, ticker;
    private String cdsNumber;
    private boolean onRetry = false;
    private ArrayList<Float> prices = new ArrayList<>();
    private ArrayList<String> dates = new ArrayList<>();
    private com.github.mikephil.charting.charts.LineChart chart;
    private ProgressBar loadingSpinner;
    private MultiplePulseRing multiplePulseRing;



    public static OneDayGraphFragment newInstance(int index) {
        OneDayGraphFragment fragment = new OneDayGraphFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            ticker = getArguments().getString(getString(R.string.EXCHANGE));

        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_one_day_graph,container,false);


        historyChart = view.findViewById(R.id.chart);
        chart=view.findViewById(R.id.chart);

        loadingSpinner=view.findViewById(R.id.loadingSpinner);
        multiplePulseRing = new MultiplePulseRing();
        loadingSpinner.setIndeterminateDrawable(multiplePulseRing);
        loadingSpinner.setVisibility(View.VISIBLE);



        chartDataAdapter = new ChartDataAdapter();

        exchange = "zse";

    /*    exchange = getActivity().getIntent().getExtras()
                .getString(getString(R.string.EXCHANGE));*/
        SharedPreferences sharedPreferences = getActivity()
                .getSharedPreferences(getString(R.string.CTRADE),
                        Context.MODE_PRIVATE);
        cdsNumber = sharedPreferences.getString(getString(R.string.cds_number),
                getString(R.string.empty));
        Log.d(getString(R.string.cds_number), cdsNumber);

        appConfig = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();


        fetchInitialCompanyData();




        return view;
    }

    private void fetchInitialCompanyData() {

        //TODO progress bar

        String initComp = ticker;
        Log.d(TAG, "fetchInitialCompanyData: "+initComp);

        String get_companies_url;

        if (onRetry) {
            //Todo put for finsec
            get_companies_url = fellOverPhp
                    .concat("/online.ctrade_php/getPricesMobile.php?company=" + initComp);
        } else {
            get_companies_url =
                    "https://online.ctrade.co.zw/ctrade/online.ctrade_php/getPricesMobile.php?company=" + initComp;
        }

        /*get_companies_url =
                getString(R.string.initial_company_url);*/
        StringRequest jsonObjRequest1 = new StringRequest(Request.Method.GET, get_companies_url,
                fetchInitialCompanyDataSuccessListener(),
                fetchInitialCompanyErrorListener()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("company", initComp);
                return params;
            }
        };

        jsonObjRequest1.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest1);
    }

    private Response.ErrorListener fetchInitialCompanyErrorListener() {
        loadingSpinner.setVisibility(View.GONE);
        chart.setVisibility(View.VISIBLE);
        return error -> {
            try {
                if (onRetry) {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            getActivity());
                    alertDialogBuilder.setTitle(R.string.result);
                    alertDialogBuilder
                            .setMessage(R.string.badnetwork)
                            .setCancelable(false)
                            .setPositiveButton("OK", (dialog, id) -> {

                            });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                    onRetry = false;
                } else {
                    onRetry = true;
                    fetchInitialCompanyData();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        };
    }

    private Response.Listener<String> fetchInitialCompanyDataSuccessListener() {
        loadingSpinner.setVisibility(View.GONE);
        chart.setVisibility(View.VISIBLE);
        return response -> {
         /*   if (progressDialog != null)
                progressDialog.dismiss();*/
            try {
                JSONArray jsonArray = new JSONArray(response);
                Log.d("Data in ChartActivity ", response);
                if (response.isEmpty() || jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String date = jsonObject.optString("date");
                        String price = jsonObject.optString("price");
                        prices.add(Float.valueOf(price));
                        dates.add(date);

                    }
                    Collections.reverse(dates);
                    Collections.reverse(prices);
                    try {
                        chartDataAdapter.setChartData(
                                dates,
                                prices,
                                getActivity(),
                                historyChart);

                    }
                    catch (Exception e){
                        Log.e(TAG, "fetchInitialCompanyDataSuccessListener: "+e.getMessage());
                    }

                    fetchCompanies();

                } else {
                    historyChart.clear();
                    Toast.makeText(getActivity(),
                            R.string.nodata, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }



    List<App> apps = new ArrayList<>();


    private void fetchCompanies() {

        try {

            String get_companies_url;

            if (onRetry) {
                get_companies_url = felloverip1
                        .concat(getActivity().getApplicationContext().getString(R.string.get_companies_list));
            } else {
                get_companies_url = getActivity().getApplicationContext().getString(R.string.https).
                        concat(ip).concat(getActivity().getApplicationContext().getString(R.string.get_companies_list));
            }

            Log.d("tavman Called url ", get_companies_url);
       /* get_companies_url = getString(R.string.https).
                concat(ip).concat(getString(R.string.get_companies_list));*/

            StringRequest getCompaniesJsonRequest =
                    new StringRequest(Request.Method.POST, get_companies_url,
                            getCompaniesSuccessListener(),
                            getCompaniesErrorListener()) {
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<>();
                            params.put(getString(R.string.exchange), exchange);
                            return params;
                        }
                    };
            getCompaniesJsonRequest.setRetryPolicy(new DefaultRetryPolicy(
                    AppConfig.REASONABLE_RETRY_MS,
                    0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            AppConfig.getInstance().addToRequestQueue(getCompaniesJsonRequest);
        }
        catch (Exception e){

            Log.d(TAG, "fetchCompanies: "+e.getMessage());

        }

    }

    private Response.ErrorListener getCompaniesErrorListener() {
        return error -> {
            error.printStackTrace();

            //Todo remove loading spinner

            try {
                if (onRetry) {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            getActivity());
                    alertDialogBuilder.setTitle(R.string.result);
                    alertDialogBuilder
                            .setMessage(R.string.badnetwork)
                            .setCancelable(false)
                            .setPositiveButton("OK", (dialog, id) -> {

                            });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                    onRetry = false;
                } else {
                    onRetry = true;
                    fetchCompanies();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }


    private Response.Listener<String> getCompaniesSuccessListener() {
        return response -> {
            //Todo remove loading spinner
            try {
                JSONArray jsonArray = new JSONArray(response);
                if (jsonArray.length() > 0) {
                    String price = "0.00", name = "";
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        name = jsonObject.optString("Name");
                        price = jsonObject.optString("InitialPrice");

                        //Set the companies recyclerview values
                        apps.add(new App(jsonObject.optString("Name"),
                                jsonObject.optString("Instrument"),
                                jsonObject.optString("Instrument"),
                                R.drawable.untu,
                                jsonObject.optString("InitialPrice")
                                , ""));
                    }

                    //TODO
    /*                symbolTextView.setText(name);
                    priceTextView.setText(price);
                    priceAbsoluteTextView.setText("");
                    pricePercentTextView.setText("");

                    //Passing controls on the snap adapter
                    GraphsSnapAdapter snapAdapter = new GraphsSnapAdapter(symbolTextView,
                            priceTextView, historyChart);

                    Log.d("Name in chart activity ", symbolTextView.getText().toString());
                    Log.d("Price in chart act ", priceTextView.getText().toString());*/

          /*          snapAdapter.addSnap(new Snap(Gravity.START, "Analysis: " +
                            getActivity().getIntent().getExtras()
                                    .getString(getString(R.string.EXCHANGE)), apps));
                    mRecyclerView.setAdapter(snapAdapter);*/

                } else {
                    Toast.makeText(getActivity().getApplicationContext(),
                            getString(R.string.badnetwork),
                            Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }
}