package zw.co.escrow.ctradelive;

import android.content.Context;
import android.util.Log;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.DecimalFormat;

public class MultiFormatter {

    public static String toTwoDecimalPlaces(String value) {
        float original = Float.valueOf(value);

        DecimalFormat decimalFormat = new DecimalFormat("###,###,###,##0.00");
        String formattedValue = decimalFormat.format(original);

        return String.valueOf(formattedValue);
    }

    public static Boolean inputIsDouble(String input) {
        try {
            double value = Double.parseDouble(input);
            double answer = value * 9 / 5 + 35;
            System.out.println(String.valueOf(answer));
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static void showDialog(String title, String message, Context context) {
        new AlertDialog.Builder(context)
                .setTitle(title)
                .setCancelable(false)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> {
                })
                .show();
    }

    public static boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().length() < 1;
    }

    public String thousandSeparator(String value) {
        float original = Float.valueOf(value);

        DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,###");
        String formattedValue = decimalFormat.format(original);

        return String.valueOf(formattedValue);
    }

    public static void showDialog(String message, Context context) {
        new AlertDialog.Builder(context)
                .setTitle(R.string.missing_field)
                .setCancelable(false)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> {
                })
                .show();
    }

    public String toLocateDate(String date) {

        try {

            if (date.charAt(4) == ' ') {
                StringBuilder formattedDate = new StringBuilder(date);
                formattedDate.setCharAt(4, '0');

                DateTimeFormatter formatter = DateTimeFormat.forPattern("MMM dd yyyy");
                org.joda.time.LocalDate dt = formatter.parseLocalDate(formattedDate.toString());
                return dt.toString();
            } else {
                DateTimeFormatter formatter = DateTimeFormat.forPattern("MMM dd yyyy");
                org.joda.time.LocalDate dt = formatter.parseLocalDate(date);
                return dt.toString();
            }

        } catch (Exception e) {
            System.out.println("Error is passing date is " + e.toString());
            return null;
        }
    }

    public String toStandardLocalDate(String date) {

        Log.d("Received date ", date);

        try {
            DateTimeFormatter formatter = DateTimeFormat.forPattern("d MMM yyyy");

            LocalDate dt = formatter.parseLocalDate(date);
            return dt.toString();
        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
    }

    public String capitalizeFirstLetter(String word) {
        String rawWordtoLowerCase = word.toLowerCase();
        String desiredWord = rawWordtoLowerCase.substring(0, 1)
                .toUpperCase() + rawWordtoLowerCase.substring(1);
        return desiredWord;
    }

}
