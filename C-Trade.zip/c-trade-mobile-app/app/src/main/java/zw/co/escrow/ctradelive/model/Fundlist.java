package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Fundlist implements Parcelable {

    private Integer ID;
    private String Company;
    private String FundType;
    private Double InitialPrice;
    private String IssueDate;
    private Double IssuePricePerUnit;
    private Boolean isInEvaluation;
    private String evaluationFrom;
    private String evaluationTo;

    public Fundlist() {
    }

    protected Fundlist(Parcel in) {
        if (in.readByte() == 0) {
            ID = null;
        } else {
            ID = in.readInt();
        }
        Company = in.readString();
        FundType = in.readString();
        if (in.readByte() == 0) {
            InitialPrice = null;
        } else {
            InitialPrice = in.readDouble();
        }
        IssueDate = in.readString();
        if (in.readByte() == 0) {
            IssuePricePerUnit = null;
        } else {
            IssuePricePerUnit = in.readDouble();
        }
        byte tmpIsInEvaluation = in.readByte();
        isInEvaluation = tmpIsInEvaluation == 0 ? null : tmpIsInEvaluation == 1;
        evaluationFrom = in.readString();
        evaluationTo = in.readString();
    }

    public static final Creator<Fundlist> CREATOR = new Creator<Fundlist>() {
        @Override
        public Fundlist createFromParcel(Parcel in) {
            return new Fundlist(in);
        }

        @Override
        public Fundlist[] newArray(int size) {
            return new Fundlist[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (ID == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(ID);
        }
        dest.writeString(Company);
        dest.writeString(FundType);
        if (InitialPrice == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(InitialPrice);
        }
        dest.writeString(IssueDate);
        if (IssuePricePerUnit == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(IssuePricePerUnit);
        }
        dest.writeByte((byte) (isInEvaluation == null ? 0 : isInEvaluation ? 1 : 2));
        dest.writeString(evaluationFrom);
        dest.writeString(evaluationTo);
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getCompany() {
        return Company;
    }

    public void setCompany(String company) {
        Company = company;
    }

    public String getFundType() {
        return FundType;
    }

    public void setFundType(String fundType) {
        FundType = fundType;
    }

    public Double getInitialPrice() {
        return InitialPrice;
    }

    public void setInitialPrice(Double initialPrice) {
        InitialPrice = initialPrice;
    }

    public String getIssueDate() {
        return IssueDate;
    }

    public void setIssueDate(String issueDate) {
        IssueDate = issueDate;
    }

    public Double getIssuePricePerUnit() {
        return IssuePricePerUnit;
    }

    public void setIssuePricePerUnit(Double issuePricePerUnit) {
        IssuePricePerUnit = issuePricePerUnit;
    }

    public Boolean getInEvaluation() {
        return isInEvaluation;
    }

    public void setInEvaluation(Boolean inEvaluation) {
        isInEvaluation = inEvaluation;
    }

    public String getEvaluationFrom() {
        return evaluationFrom;
    }

    public void setEvaluationFrom(String evaluationFrom) {
        this.evaluationFrom = evaluationFrom;
    }

    public String getEvaluationTo() {
        return evaluationTo;
    }

    public void setEvaluationTo(String evaluationTo) {
        this.evaluationTo = evaluationTo;
    }
}
