package zw.co.escrow.ctradelive.adapters.header_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import de.codecrafters.tableview.TableDataAdapter;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ContributionStatement;


public class ContributionStatementColumnAdapter extends TableDataAdapter {

    TextView textView;
    ImageView imageView;

    public ContributionStatementColumnAdapter(Context context, List data) {
        super(context, data);
    }


    @SuppressLint("ResourceAsColor")
    @Override
    public View getCellView(int rowIndex, int columnIndex, ViewGroup parentView) {

        View view = LayoutInflater.from(parentView.getContext()).inflate(R.layout.universal_column_adapter_view,parentView,false);
        textView = view.findViewById(R.id.text_id);
        imageView = view.findViewById(R.id.more_img);
        ContributionStatement contributionStatement = (ContributionStatement) getData().get(rowIndex);
        switch (columnIndex){
            case 0:
                //textView.setTextColor(Color.parseColor("#39ff14"));
                textView.setText(contributionStatement.getName());

                break;
            case 1:

                textView.setText("ZWL"+ Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(contributionStatement.getCumulative()))));
                break;
            case 2:
                //#FF4081
                textView.setText("ZWL"+Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(contributionStatement.getContribution_()))));
                break;
            case 3:

                if(contributionStatement.getActive())
                    textView.setText("Active");
                else textView.setText("Inactive");
                break;
        }

        return view;
    }
}
