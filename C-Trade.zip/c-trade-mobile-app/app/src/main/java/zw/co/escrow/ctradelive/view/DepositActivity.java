package zw.co.escrow.ctradelive.view;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;

public class DepositActivity extends AppCompatActivity {

    private Utils utils;

    private TextInputLayout outlinedTextFieldAmount, outlinedTextFieldMobileNumber, outlinedTextFieldCurrency, outlinedTextFieldPaymentMethod;
    private static final String TAG = "DepositActivity";
    private Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposit);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(DepositActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("DEPOSIT");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }

        outlinedTextFieldAmount=findViewById(R.id.outlinedTextFieldAmount);
        outlinedTextFieldMobileNumber=findViewById(R.id.outlinedTextFieldMobileNumber);
        outlinedTextFieldCurrency=findViewById(R.id.outlinedTextFieldCurrency);
        outlinedTextFieldPaymentMethod=findViewById(R.id.outlinedTextFieldPaymentMethod);


        String[] currencies = new String[] {"USD", "ZWL"};
        String[] paymentMethod = new String[] {"EcoCash", "PayNow", "International card"};

        utils.setDropdownBoxes(currencies, R.id.currency_dropdown_items);
        utils.setDropdownBoxes(paymentMethod, R.id.payment_method_dropdown_items);

        findViewById(R.id.btnDeposit).setOnClickListener(view -> {

            String amount = outlinedTextFieldAmount.getEditText().getText().toString();
            String mobileNumber = outlinedTextFieldMobileNumber.getEditText().getText().toString();
            String currency = outlinedTextFieldCurrency.getEditText().getText().toString();
            String methodOfPayment = outlinedTextFieldPaymentMethod.getEditText().getText().toString();


            if (amount.equals("") || amount.equals("0")) {
                outlinedTextFieldAmount.setError("Amount should be greater than 0");
            }
            else if (mobileNumber.equals("") || mobileNumber.equals("0") || mobileNumber.length()<10){
                outlinedTextFieldMobileNumber.setError("Please insert a mobile number");

            }
            else if (currency.equals("") || currency.equals("0")){
                outlinedTextFieldCurrency.setError("Please select a currency");

            }
            else if (methodOfPayment.equals("") || methodOfPayment.equals("0")){
                outlinedTextFieldPaymentMethod.setError("Please select payment method");

            }
            else {
                outlinedTextFieldAmount.setErrorEnabled(false);
                outlinedTextFieldMobileNumber.setErrorEnabled(false);
                outlinedTextFieldCurrency.setErrorEnabled(false);
                outlinedTextFieldPaymentMethod.setErrorEnabled(false);



                String[] depositDetails={amount, mobileNumber, currency, methodOfPayment};
                Log.d(TAG, "onCreate: "+depositDetails[1]);


                setResult(Constants.DEPOSIT_REQUEST_CODE, new Intent().putExtra("DEPOSIT_DETAILS", depositDetails));
                finish();
            }

        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}