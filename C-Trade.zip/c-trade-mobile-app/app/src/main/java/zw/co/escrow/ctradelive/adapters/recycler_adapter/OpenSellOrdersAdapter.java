package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnPlaceOrder;
import zw.co.escrow.ctradelive.model.OpenSellOrder;
import zw.co.escrow.ctradelive.model.OrderDetails;

public class OpenSellOrdersAdapter extends RecyclerView.Adapter<OpenSellOrdersAdapter.OpenSellOrdersViewHolder> {

    private final List<OpenSellOrder> openSellOrders;
    private Activity activity;
    private OnPlaceOrder onPlaceOrder;


    public void setOnPlaceOrder(OnPlaceOrder onPlaceOrder) {
        this.onPlaceOrder = onPlaceOrder;
    }

    public OpenSellOrdersAdapter(Activity activity, List<OpenSellOrder> openSellOrders) {
        this.openSellOrders = openSellOrders;
        this.activity = activity;
    }


    @Override
    public int getItemViewType(int position) {
        return R.layout.open_sell_orders_item;
    }


    @NonNull
    @Override
    public OpenSellOrdersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new OpenSellOrdersViewHolder(view);    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull OpenSellOrdersViewHolder holder, int position) {



        holder.txtTicker.setText(openSellOrders.get(position).getTicker());
        holder.txtCompanyName.setText(openSellOrders.get(position).getFullCompanyName());
        holder.txtBestAsk.setText(String.format("BEST ASK: %s", openSellOrders.get(position).getBestAsk()));
        holder.txtCurrentPrice.setText(openSellOrders.get(position).getCurrentPrice());
        holder.txtAskVolume.setText(String.format("ASK VOLUME: %s", openSellOrders.get(position).getAskVolume()));
        holder.txtPercentageChange.setText("[BUY]");


        holder.wl_change_indicator.setCardBackgroundColor(activity.getResources().getColor(R.color.colorDarkGreen));
        OpenSellOrder order = openSellOrders.get(position);


        holder.cardView.setOnClickListener(view -> {

            OrderDetails orderDetails = new OrderDetails();
            orderDetails.setCurrentPrice(order.getBestAsk());
            orderDetails.setFullCompanyName(order.getFullCompanyName());
            orderDetails.setMarket("ZSE");
            orderDetails.setCompany(order.getTicker());
            AlertDialog alertDialog = new AlertDialog.Builder(activity)
                    .setTitle("Open Sell Order")
                    .setMessage(order.getTicker().concat("\n")
                            .concat(order.getFullCompanyName()).concat("\n")
                            .concat("Best ask: "+ order.getBestAsk()).concat("\n")
                            .concat("Current price: "+order.getCurrentPrice()).concat("\n")
                            .concat("Ask volume: "+order.getAskVolume()))
                    .setCancelable(false)
                    .setPositiveButton("Buy", (dialogInterface, which) -> {
                        if(onPlaceOrder != null) onPlaceOrder.showDialog(orderDetails);
                    })
                    .setNegativeButton("Cancel", (dialogInterface, which) -> dialogInterface.dismiss())
                    .create();

            alertDialog.setOnShowListener(dialogInterface -> {
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(activity.getColor(R.color.colorAccent));
                alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(activity.getColor(R.color.red));
            });

            alertDialog.show();


        });

    }



    @Override
    public int getItemCount() {
        return openSellOrders.size();
    }



    public static class OpenSellOrdersViewHolder extends RecyclerView.ViewHolder{

        private TextView txtTicker, txtCompanyName, txtBestAsk, txtCurrentPrice, txtAskVolume, txtPercentageChange;
        private CardView cardView, wl_change_indicator;

        public OpenSellOrdersViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTicker = itemView.findViewById(R.id.txtTicker);
            txtCompanyName = itemView.findViewById(R.id.txtCompanyName);
            txtBestAsk = itemView.findViewById(R.id.txtBestAsk);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtAskVolume = itemView.findViewById(R.id.txtAskVolume);
            txtPercentageChange = itemView.findViewById(R.id.txtPercentageChange);
            cardView = itemView.findViewById(R.id.cardViewCompany);
            wl_change_indicator = itemView.findViewById(R.id.wl_change_indicator);
        }
    }
}