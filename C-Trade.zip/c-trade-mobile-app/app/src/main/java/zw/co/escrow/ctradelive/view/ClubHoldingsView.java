package zw.co.escrow.ctradelive.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Arrays;
import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;


public class ClubHoldingsView extends AppCompatActivity {

    private Toolbar toolbar;
    private List<String> headers = Arrays.asList("FULL NAME","COMPANY","SHARES","MOBILE");
    private InvestmentClub.ClubServicesListener clubServicesListener;
    private RecyclerView recyclerView;

    FloatingActionButton floatingActionButton;
    private ClubModel club;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_holdings_view);

        recyclerView = findViewById(R.id.recyclerView);
        club = getIntent().getParcelableExtra("club");

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Club Holdings".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });
        clubServicesListener =  new InvestmentClubService(
                this, recyclerView);
        InvestmentClub.ClubServicesListener clubServicesListener1 = new InvestmentClubService(
                this, recyclerView);
        clubServicesListener.onLoadClubTransCompanies(club.getClubCdsNumber(),clubServicesListener1);
        floatingActionButton = findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(v -> {
            InvestmentClub.ClubServicesListener clubServicesListener2 = new InvestmentClubService(
                    this,recyclerView);
            clubServicesListener.onLoadClubTransCompanies(club.getClubCdsNumber(),clubServicesListener2);
        });
    }
}