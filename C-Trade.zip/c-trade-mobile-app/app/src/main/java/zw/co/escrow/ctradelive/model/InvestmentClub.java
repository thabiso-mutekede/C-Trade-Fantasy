package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class InvestmentClub implements Parcelable {
    private String id;
   private String chairman_id;
    private int club_member_num;
    private String club_name;
    private String club_phone;
    private String created_date;
    private String phone;
    private String Active;

    public InvestmentClub() {
    }

    protected InvestmentClub(Parcel in) {
        id = in.readString();
        chairman_id = in.readString();
        club_member_num = in.readInt();
        club_name = in.readString();
        club_phone = in.readString();
        created_date = in.readString();
        phone = in.readString();
        Active = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(chairman_id);
        dest.writeInt(club_member_num);
        dest.writeString(club_name);
        dest.writeString(club_phone);
        dest.writeString(created_date);
        dest.writeString(phone);
        dest.writeString(Active);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<InvestmentClub> CREATOR = new Creator<InvestmentClub>() {
        @Override
        public InvestmentClub createFromParcel(Parcel in) {
            return new InvestmentClub(in);
        }

        @Override
        public InvestmentClub[] newArray(int size) {
            return new InvestmentClub[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChairman_id() {
        return chairman_id;
    }

    public void setChairman_id(String chairman_id) {
        this.chairman_id = chairman_id;
    }

    public int getClub_member_num() {
        return club_member_num;
    }

    public void setClub_member_num(int club_member_num) {
        this.club_member_num = club_member_num;
    }

    public String getClub_name() {
        return club_name;
    }

    public void setClub_name(String club_name) {
        this.club_name = club_name;
    }

    public String getClub_phone() {
        return club_phone;
    }

    public void setClub_phone(String club_phone) {
        this.club_phone = club_phone;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getActive() {
        return Active;
    }

    public void setActive(String active) {
        Active = active;
    }
}
