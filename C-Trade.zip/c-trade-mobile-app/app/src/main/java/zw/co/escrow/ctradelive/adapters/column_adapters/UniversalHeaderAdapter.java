package zw.co.escrow.ctradelive.adapters.column_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import de.codecrafters.tableview.TableHeaderAdapter;
import zw.co.escrow.ctradelive.R;;

public class UniversalHeaderAdapter extends TableHeaderAdapter {

    private final List<String> headers;
    TextView textView;
    public UniversalHeaderAdapter(Context context, int columnCount, List<String> headers) {
        super(context, columnCount);
        this.headers = headers;
    }

    @Override
    public View getHeaderView(int columnIndex, ViewGroup parentView) {
        View view = LayoutInflater.from(parentView.getContext()).inflate(R.layout.universal_header_adapter_view,parentView,false);
        textView = view.findViewById(R.id.text_id);
        try {
            textView.setText(headers.get(columnIndex ));
        }catch (Exception e){
            textView.setText(headers.get(columnIndex - 1));
        }

        return view;
    }
}
