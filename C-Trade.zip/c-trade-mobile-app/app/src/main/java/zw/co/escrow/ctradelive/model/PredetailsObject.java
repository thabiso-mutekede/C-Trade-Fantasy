package zw.co.escrow.ctradelive.model;

import java.util.List;


public class PredetailsObject {

    private List<Predetail> predetails;


    public List<Predetail> getPredetails() {
        return predetails;
    }

    public void setPredetails(List<Predetail> predetails) {
        this.predetails = predetails;
    }



}
