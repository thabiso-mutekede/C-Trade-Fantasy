package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.List;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.listeners.TableDataClickListener;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.column_adapters.UniversalHeaderAdapter;
import zw.co.escrow.ctradelive.adapters.header_adapters.MemberInvestmentsColumnAdapter;
import zw.co.escrow.ctradelive.model.MemberInvestments;

public class MemberInvestmentsDialog extends Dialog implements TableDataClickListener {

    private TableView tableView;
    private final List<String> table_headers = Arrays.asList("Group","Club Total","My Total","My %");
    private RecyclerView portfolioRecyclerView;
    private Toolbar toolbar;

    public MemberInvestmentsDialog(@NonNull Context context, List<MemberInvestments> memberInvestments, String thousandSep, String sep) {
        super(context);
        setContentView(R.layout.activity_my_cash_view);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("My Investments".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        tableView = findViewById(R.id.portfolio_table);
        tableView.setColumnCount(4);
        tableView.setHeaderAdapter(new UniversalHeaderAdapter(getContext(),table_headers.size(),table_headers));

        tableView.setDataAdapter(new MemberInvestmentsColumnAdapter(getContext(),memberInvestments));
        tableView.addDataClickListener(this);

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public void onDataClicked(int rowIndex, Object clickedData) {
        
    }
}