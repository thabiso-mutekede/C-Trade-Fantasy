package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class MarketWatchFINSEC implements Parcelable {

    private int id;
    private String market_company, details, FullCompanyName, Category;
    private double market_bbv, market_bp, market_va, market_ap, market_vwap, market_lp, market_lv, market_tv, market_to, market_open
            , market_low, market_high, market_change, market_per_change, bids, asks;

    public MarketWatchFINSEC() {
    }

    public MarketWatchFINSEC(int id, String market_company, String details, String fullCompanyName, String category, double market_bbv, double market_bp, double market_va, double market_ap, double market_vwap, double market_lp, double market_lv, double market_tv, double market_to, double market_open, double market_low, double market_high, double market_change, double market_per_change, double bids, double asks) {
        this.id = id;
        this.market_company = market_company;
        this.details = details;
        FullCompanyName = fullCompanyName;
        Category = category;
        this.market_bbv = market_bbv;
        this.market_bp = market_bp;
        this.market_va = market_va;
        this.market_ap = market_ap;
        this.market_vwap = market_vwap;
        this.market_lp = market_lp;
        this.market_lv = market_lv;
        this.market_tv = market_tv;
        this.market_to = market_to;
        this.market_open = market_open;
        this.market_low = market_low;
        this.market_high = market_high;
        this.market_change = market_change;
        this.market_per_change = market_per_change;
        this.bids = bids;
        this.asks = asks;
    }

    public MarketWatchFINSEC(MarketWatchFINSEC marketWatchFINSEC) {
        this.id = marketWatchFINSEC.getId();
        this.market_company = marketWatchFINSEC.getMarket_company();
        this.details = marketWatchFINSEC.getDetails();
        this.FullCompanyName = marketWatchFINSEC.getFullCompanyName();
        this.Category = marketWatchFINSEC.getCategory();
        this.market_bbv = marketWatchFINSEC.getMarket_bbv();
        this.market_bp = marketWatchFINSEC.getMarket_bp();
        this.market_va = marketWatchFINSEC.getMarket_va();
        this.market_ap = marketWatchFINSEC.getMarket_ap();
        this.market_vwap = marketWatchFINSEC.getMarket_vwap();
        this.market_lp = marketWatchFINSEC.getMarket_lp();
        this.market_lv = marketWatchFINSEC.getMarket_lv();
        this.market_tv = marketWatchFINSEC.getMarket_tv();
        this.market_to = marketWatchFINSEC.getMarket_to();
        this.market_open = marketWatchFINSEC.getMarket_open();
        this.market_low = marketWatchFINSEC.getMarket_low();
        this.market_high = marketWatchFINSEC.getMarket_low();;
        this.market_change = marketWatchFINSEC.getMarket_change();
        this.market_per_change = marketWatchFINSEC.getMarket_per_change();
        this.bids = marketWatchFINSEC.getBids();
        this.asks = marketWatchFINSEC.getAsks();

    }

    protected MarketWatchFINSEC(Parcel in) {
        id = in.readInt();
        market_company = in.readString();
        details = in.readString();
        FullCompanyName = in.readString();
        Category = in.readString();
        market_bbv = in.readDouble();
        market_bp = in.readDouble();
        market_va = in.readDouble();
        market_ap = in.readDouble();
        market_vwap = in.readDouble();
        market_lp = in.readDouble();
        market_lv = in.readDouble();
        market_tv = in.readDouble();
        market_to = in.readDouble();
        market_open = in.readDouble();
        market_low = in.readDouble();
        market_high = in.readDouble();
        market_change = in.readDouble();
        market_per_change = in.readDouble();
        bids = in.readDouble();
        asks = in.readDouble();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(market_company);
        dest.writeString(details);
        dest.writeString(FullCompanyName);
        dest.writeString(Category);
        dest.writeDouble(market_bbv);
        dest.writeDouble(market_bp);
        dest.writeDouble(market_va);
        dest.writeDouble(market_ap);
        dest.writeDouble(market_vwap);
        dest.writeDouble(market_lp);
        dest.writeDouble(market_lv);
        dest.writeDouble(market_tv);
        dest.writeDouble(market_to);
        dest.writeDouble(market_open);
        dest.writeDouble(market_low);
        dest.writeDouble(market_high);
        dest.writeDouble(market_change);
        dest.writeDouble(market_per_change);
        dest.writeDouble(bids);
        dest.writeDouble(asks);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<MarketWatchFINSEC> CREATOR = new Creator<MarketWatchFINSEC>() {
        @Override
        public MarketWatchFINSEC createFromParcel(Parcel in) {
            return new MarketWatchFINSEC(in);
        }

        @Override
        public MarketWatchFINSEC[] newArray(int size) {
            return new MarketWatchFINSEC[size];
        }
    };

    public double getMarket_high() {
        return market_high;
    }

    public void setMarket_high(double market_high) {
        this.market_high = market_high;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public double getMarket_to() {
        return market_to;
    }

    public void setMarket_to(double market_to) {
        this.market_to = market_to;
    }

    public double getMarket_open() {
        return market_open;
    }

    public void setMarket_open(double market_open) {
        this.market_open = market_open;
    }

    public double getMarket_low() {
        return market_low;
    }

    public void setMarket_low(double market_low) {
        this.market_low = market_low;
    }

    public double getMarket_change() {
        return market_change;
    }

    public void setMarket_change(double market_change) {
        this.market_change = market_change;
    }

    public double getMarket_per_change() {
        return market_per_change;
    }

    public void setMarket_per_change(double market_per_change) {
        this.market_per_change = market_per_change;
    }

    public double getBids() {
        return bids;
    }

    public void setBids(double bids) {
        this.bids = bids;
    }

    public double getAsks() {
        return asks;
    }

    public void setAsks(double asks) {
        this.asks = asks;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarket_company() {
        return market_company;
    }

    public void setMarket_company(String market_company) {
        this.market_company = market_company;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getFullCompanyName() {
        return FullCompanyName;
    }

    public void setFullCompanyName(String fullCompanyName) {
        this.FullCompanyName = fullCompanyName;
    }

    public double getMarket_bbv() {
        return market_bbv;
    }

    public void setMarket_bbv(double market_bbv) {
        this.market_bbv = market_bbv;
    }

    public double getMarket_bp() {
        return market_bp;
    }

    public void setMarket_bp(double market_bp) {
        this.market_bp = market_bp;
    }

    public double getMarket_va() {
        return market_va;
    }

    public void setMarket_va(double market_va) {
        this.market_va = market_va;
    }

    public double getMarket_ap() {
        return market_ap;
    }

    public void setMarket_ap(double market_ap) {
        this.market_ap = market_ap;
    }

    public double getMarket_vwap() {
        return market_vwap;
    }

    public void setMarket_vwap(double market_vwap) {
        this.market_vwap = market_vwap;
    }

    public double getMarket_lp() {
        return market_lp;
    }

    public void setMarket_lp(double market_lp) {
        this.market_lp = market_lp;
    }

    public double getMarket_lv() {
        return market_lv;
    }

    public void setMarket_lv(double market_lv) {
        this.market_lv = market_lv;
    }

    public double getMarket_tv() {
        return market_tv;
    }

    public void setMarket_tv(double market_tv) {
        this.market_tv = market_tv;
    }


}
