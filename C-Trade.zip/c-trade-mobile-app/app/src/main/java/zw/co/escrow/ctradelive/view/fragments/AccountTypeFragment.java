package zw.co.escrow.ctradelive.view.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.Details;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.model.RegistrationSession;
import zw.co.escrow.ctradelive.view.fragments.company_create_account.CompanyDetailsFragment;
import zw.co.escrow.ctradelive.view.fragments.individual_create_account.PersonalDetailsFragment;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class AccountTypeFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "DETAILS";

    private LoginViewModel loginViewModel;
    private Utils utils;
    private TextInputLayout outlinedTextFieldAccountType, outlinedTextFieldCDSNumber, outlinedTextFieldATPNumber;
    private RadioGroup radioGroup;



    public static AccountTypeFragment newInstance(int index) {
        AccountTypeFragment fragment = new AccountTypeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_account_type, container, false);

        utils = new Utils(getActivity());


        outlinedTextFieldAccountType=root.findViewById(R.id.outlinedTextFieldAccountType);
        outlinedTextFieldCDSNumber=root.findViewById(R.id.outlinedTextFieldCDSNumber);
        outlinedTextFieldATPNumber=root.findViewById(R.id.outlinedTextFieldATPNumber);
        radioGroup=root.findViewById(R.id.radioGroup);


        String[] type = new String[] {getActivity().getResources().getString(R.string.individual), getActivity().getResources().getString(R.string.company)};


        utils.setDropdownBoxes(type, R.id.custodian_dropdown_items, root);


        radioGroup.setOnCheckedChangeListener((radioGroup, radioButtonID) -> {

            switch (radioButtonID){
                case R.id.radio_button_no:
                    outlinedTextFieldCDSNumber.setVisibility(View.GONE);
                    outlinedTextFieldATPNumber.setVisibility(View.GONE);
                    break;
                case R.id.radio_button_yes:
                    outlinedTextFieldCDSNumber.setVisibility(View.VISIBLE);
                    //outlinedTextFieldATPNumber.setVisibility(View.VISIBLE);
                    break;

            }

        });


        root.findViewById(R.id.btnNext).setOnClickListener(v->{


            RegistrationData registrationData = new RegistrationData();
            registrationData.setRegistrationSession(new RegistrationSession());
            Details details = new Details();

            String accountType = outlinedTextFieldAccountType.getEditText().getText().toString();
            String cdsNumber = outlinedTextFieldCDSNumber.getEditText().getText().toString();


            if (accountType.equals("")) {
                outlinedTextFieldAccountType.setError("Please select account type");
            }if(outlinedTextFieldCDSNumber.getVisibility() == View.VISIBLE
                    && outlinedTextFieldCDSNumber.getEditText().getText().toString() == ""){
                outlinedTextFieldCDSNumber.setError("Please Enter A CDC Number");
            }
            else {
                if (accountType.equals(getActivity().getResources().getString(R.string.individual))){

                    //TODO should proceed to individual reg page

                    details.setAccountType(getString(R.string.account_type_individual));
                    if(!cdsNumber.equalsIgnoreCase("")){
                        details.setCdc_number(cdsNumber);
                    }
                    registrationData.setDetails(details);
                    utils.startNewFragment(root, AccountTypeFragment.this, PersonalDetailsFragment.newInstance(registrationData) );

                }
                else {
                    details.setAccountType(getString(R.string.account_type_corporate));
                    registrationData.setDetails(details);
                    if(outlinedTextFieldCDSNumber.getEditText().getText().toString() != ""){
                        details.setCdc_number(outlinedTextFieldCDSNumber.getEditText().getText().toString());
                    }
                    utils.startNewFragment(root, AccountTypeFragment.this, CompanyDetailsFragment.newInstance(registrationData) );
                }
            }
        });






        return root;
    }
}