package zw.co.escrow.ctradelive.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;

public class WithdrawActivity extends AppCompatActivity {

    private Utils utils;
    private TextInputLayout outlinedTextFieldAmount;
    private Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(WithdrawActivity.this);

        utils = new Utils(this);

        outlinedTextFieldAmount=findViewById(R.id.outlinedTextFieldAmount);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("WITHDRAW");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }



        findViewById(R.id.btnWithdraw).setOnClickListener(view -> {
           String amount = outlinedTextFieldAmount.getEditText().getText().toString();

           if (amount.equals("") || amount.equals("0")) {
               outlinedTextFieldAmount.setError("Amount should be greater than 0");
           }
           else {
               outlinedTextFieldAmount.setErrorEnabled(false);
               setResult(Constants.WITHDRAW_REQUEST_CODE, new Intent().putExtra("AMOUNT", amount));
               finish();
           }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}