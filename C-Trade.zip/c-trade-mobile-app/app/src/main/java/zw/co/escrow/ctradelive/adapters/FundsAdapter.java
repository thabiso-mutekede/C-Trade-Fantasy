package zw.co.escrow.ctradelive.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Fundlist;
import zw.co.escrow.ctradelive.view.UnitTrustAnalysisActivity;


public class FundsAdapter extends RecyclerView.Adapter<FundsAdapter.MyViewHolder> {
    private Context context;
    private List<Fundlist> fundlists;
    private int accountColor= R.color.colorAccent;

    public FundsAdapter(Context context, List<Fundlist> fundlists ) {
        this.context = context;
        this.fundlists = fundlists;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView;
        itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.funds_list_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Fundlist fundlist = fundlists.get(position);
        holder.txtCompany.setText(fundlist.getCompany());
        holder.txtFundType.setText(fundlist.getFundType());
        holder.txtInitialPrice.setText("ZWL "+fundlist.getInitialPrice());
        //int colorCode = accountColor == null ? Color.TRANSPARENT : Color.parseColor(accountColor);
       // holder.colorStripView.setBackgroundColor(Color.GREEN);
        holder.cardView.setOnClickListener(view -> {

            Bundle bundle = new Bundle();
            bundle.putParcelable("fundlist", fundlist);
            Intent intent =new Intent(context, UnitTrustAnalysisActivity.class);

            intent.putExtras(bundle);

            context.startActivity(intent);


        });

    }

    @Override
    public int getItemCount() {
        return fundlists.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder  {
        View view,colorStripView;
        CardView wl_change_indicator, cardView;
        TextView txtCompany, txtFundType, txtInitialPrice, IssueDate, IssuePricePerUnit;


        public MyViewHolder(View itemView) {
            super(itemView);
            view = itemView;
            txtCompany = itemView.findViewById(R.id.txtCompany);
            txtFundType = itemView.findViewById(R.id.txtFundType);
            txtInitialPrice = itemView.findViewById(R.id.txtInitialPrice);
            wl_change_indicator= itemView.findViewById(R.id.wl_change_indicator);
            cardView= itemView.findViewById(R.id.cardView);

            // IssueDate, IssuePricePerUnit;

        }
    }

}
