package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.listeners.TableDataClickListener;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.column_adapters.UniversalHeaderAdapter;
import zw.co.escrow.ctradelive.adapters.header_adapters.CpayCashColumnAdapter;
import zw.co.escrow.ctradelive.model.CPAYTransaction;
import zw.co.escrow.ctradelive.model.MyCashData;

public class CPayCashDialog extends Dialog implements TableDataClickListener {

    private TableView tableView;
    private final String cdsNumber;
    private final List<String> table_headers = Arrays.asList("Date","Type","Currency","Amount");
    List<MyCashData> myCashDataList;
    private RecyclerView portfolioRecyclerView;
    private Toolbar toolbar;

    public CPayCashDialog(@NonNull Context context, String cdsNumber) {
        super(context);
        this.cdsNumber = cdsNumber;
        setContentView(R.layout.activity_my_cash_view);
        myCashDataList = new ArrayList<>();

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("My Transactions".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        fetchTransactions();

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public void onDataClicked(int rowIndex, Object clickedData) {
        
    }

    private void fetchTransactions(){
//        ApiClubInterface clubInterface = CtradeApiClient.getApiService();
//        Call<List<CPAYTransaction>> transCall = clubInterface.getMyForexStatement(cdsNumber);
//        transCall.enqueue(new Callback<List<CPAYTransaction>>() {
//            @Override
//            public void onResponse(Call<List<CPAYTransaction>> call, Response<List<CPAYTransaction>> response) {
//                Log.d("lloda trans",response.body().toString());
//                tableView = findViewById(R.id.portfolio_table);
//                tableView.setColumnCount(4);
//                tableView.setHeaderAdapter(new UniversalHeaderAdapter(getContext(),table_headers.size(),table_headers));
//                tableView.setDataAdapter(new CpayCashColumnAdapter(getContext(),response.body()));
//                tableView.addDataClickListener(CPayCashDialog.this::onDataClicked);
//            }
//            @Override
//            public void onFailure(Call<List<CPAYTransaction>> call, Throwable t) {
//
//            }
//        });
    }

}