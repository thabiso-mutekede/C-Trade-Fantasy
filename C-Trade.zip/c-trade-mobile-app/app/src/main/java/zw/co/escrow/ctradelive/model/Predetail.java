package zw.co.escrow.ctradelive.model;

public class Predetail {

    private Integer id;
    private Double shareholder;
    private String name;
    private Double shares;
    private Double gross;
    private String tax;
    private Double offerShares;
    private Double nett;
    private String add_1;
    private String add_2;
    private String add_3;
    private String add_4;
    private String add5;
    private String Country;
    private String industry;
    private String taxCode;
    private Double taxRate;
    private String bank;
    private String Bank_Ac;
    private String Bank_Branch;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getShareholder() {
        return shareholder;
    }

    public void setShareholder(Double shareholder) {
        this.shareholder = shareholder;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getShares() {
        return shares;
    }

    public void setShares(Double shares) {
        this.shares = shares;
    }

    public Double getGross() {
        return gross;
    }

    public void setGross(Double gross) {
        this.gross = gross;
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }

    public Double getOfferShares() {
        return offerShares;
    }

    public void setOfferShares(Double offerShares) {
        this.offerShares = offerShares;
    }

    public Double getNett() {
        return nett;
    }

    public void setNett(Double nett) {
        this.nett = nett;
    }

    public String getAdd_1() {
        return add_1;
    }

    public void setAdd_1(String add_1) {
        this.add_1 = add_1;
    }

    public String getAdd_2() {
        return add_2;
    }

    public void setAdd_2(String add_2) {
        this.add_2 = add_2;
    }

    public String getAdd_3() {
        return add_3;
    }

    public void setAdd_3(String add_3) {
        this.add_3 = add_3;
    }

    public String getAdd_4() {
        return add_4;
    }

    public void setAdd_4(String add_4) {
        this.add_4 = add_4;
    }

    public String getAdd5() {
        return add5;
    }

    public void setAdd5(String add5) {
        this.add5 = add5;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    public Double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(Double taxRate) {
        this.taxRate = taxRate;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getBank_Ac() {
        return Bank_Ac;
    }

    public void setBank_Ac(String bank_Ac) {
        Bank_Ac = bank_Ac;
    }

    public String getBank_Branch() {
        return Bank_Branch;
    }

    public void setBank_Branch(String bank_Branch) {
        Bank_Branch = bank_Branch;
    }
}
