package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class RegistrationData implements Parcelable {
    private String password;
    private Details details;
    private List<Signatory> signatories;
    private RegistrationSession registrationSession;
    private String book;
    private String motherName;
    private String road;

    public RegistrationData() {
    }

    protected RegistrationData(Parcel in) {
        password = in.readString();
        details = in.readParcelable(Details.class.getClassLoader());
        signatories = in.createTypedArrayList(Signatory.CREATOR);
        registrationSession = in.readParcelable(RegistrationSession.class.getClassLoader());
        book = in.readString();
        motherName = in.readString();
        road = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(password);
        dest.writeParcelable(details, flags);
        dest.writeTypedList(signatories);
        dest.writeParcelable(registrationSession, flags);
        dest.writeString(book);
        dest.writeString(motherName);
        dest.writeString(road);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<RegistrationData> CREATOR = new Creator<RegistrationData>() {
        @Override
        public RegistrationData createFromParcel(Parcel in) {
            return new RegistrationData(in);
        }

        @Override
        public RegistrationData[] newArray(int size) {
            return new RegistrationData[size];
        }
    };

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        this.details = details;
    }

    public List<Signatory> getSignatories() {
        return signatories;
    }

    public void setSignatories(List<Signatory> signatories) {
        this.signatories = signatories;
    }

    public RegistrationSession getRegistrationSession() {
        return registrationSession;
    }

    public void setRegistrationSession(RegistrationSession registrationSession) {
        this.registrationSession = registrationSession;
    }

    public String getBook() {
        return book;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getRoad() {
        return road;
    }

    public void setRoad(String road) {
        this.road = road;
    }
}
