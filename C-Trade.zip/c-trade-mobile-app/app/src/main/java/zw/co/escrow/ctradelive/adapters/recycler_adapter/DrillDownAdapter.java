package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.DrillDown;


public class DrillDownAdapter extends RecyclerView.Adapter {

    private Context context;
    private List<DrillDown> groupHoldings;
    private RecyclerView rv;
    private String cdsNumber_group;
    private String company;

    public DrillDownAdapter(Context context, List<DrillDown> groupHoldings) {
        this.context = context;
        this.groupHoldings = groupHoldings;
        this.rv = rv;
        this.cdsNumber_group = cdsNumber_group;
        this.company = company;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.view_all_statements;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(viewType,parent,false);

        return new HoldingsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((HoldingsViewHolder)holder).onBindData(groupHoldings.get(position));
    }

    @Override
    public int getItemCount() {
        return groupHoldings.size();
    }


    private class HoldingsViewHolder extends RecyclerView.ViewHolder {

        private TextView main_text,sub_text;

        public HoldingsViewHolder(@NonNull View itemView) {
            super(itemView);
            main_text = itemView.findViewById(R.id.main_text);
            sub_text = itemView.findViewById(R.id.side_text);

        }

        public void onBindData(DrillDown groupHoldings){
            main_text.setText(groupHoldings.getDate());
            sub_text.setText(groupHoldings.getShares());

        }
    }
}
