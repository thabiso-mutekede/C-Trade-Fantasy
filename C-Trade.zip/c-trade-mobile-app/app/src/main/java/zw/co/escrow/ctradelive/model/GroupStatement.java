package zw.co.escrow.ctradelive.model;

public class GroupStatement {
    private String fullName;
    private String company;
    private String shares;
    private String cdsNumber;

    public GroupStatement(String fullName, String company, String shares, String cdsNumber) {
        this.fullName = fullName;
        this.company = company;
        this.shares = shares;
        this.cdsNumber = cdsNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getShares() {
        return shares;
    }

    public void setShares(String shares) {
        this.shares = shares;
    }

    public String getCdsNumber() {
        return cdsNumber;
    }

    public void setCdsNumber(String cdsNumber) {
        this.cdsNumber = cdsNumber;
    }
}
