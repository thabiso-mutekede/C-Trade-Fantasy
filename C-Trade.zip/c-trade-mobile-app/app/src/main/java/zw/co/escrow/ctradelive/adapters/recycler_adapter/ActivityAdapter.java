package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.CTradeActivity;

public class ActivityAdapter extends RecyclerView.Adapter {

    private List<CTradeActivity> cTradeActivityList;

    public ActivityAdapter(List<CTradeActivity> cTradeActivityList) {
        this.cTradeActivityList = cTradeActivityList;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.activity_list_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View activity = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new ActivityHolder(activity);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ActivityHolder)holder).onBindData(cTradeActivityList.get(position));
    }
    @Override
    public int getItemCount() {
        return cTradeActivityList.size();
    }


    private class ActivityHolder extends RecyclerView.ViewHolder {

        private TextView type_txt,date_txt,message_txt;

        public ActivityHolder(@NonNull View itemView) {
            super(itemView);

            type_txt = itemView.findViewById(R.id.activity_type);
            date_txt = itemView.findViewById(R.id.time_txt);
            message_txt = itemView.findViewById(R.id.txt_description);
        }

        private void onBindData(CTradeActivity cTradeActivity){

            type_txt.setText(cTradeActivity.getType());
            date_txt.setText(cTradeActivity.getAct_date());
            message_txt.setText(cTradeActivity.getDescription());

        }
    }
}
