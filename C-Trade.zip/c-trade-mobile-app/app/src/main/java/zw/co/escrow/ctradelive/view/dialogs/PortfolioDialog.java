package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.PortfolioData;

public class PortfolioDialog extends Dialog {

    private RecyclerView portfolioRecyclerView;
    private Toolbar toolbar;

    private  List<PortfolioData> portfolioDataList;
    public PortfolioDialog(@NonNull Context context) {
        super(context);
        setContentView(R.layout.portfolio_dialog_view);
        portfolioDataList = new ArrayList<>();

        portfolioRecyclerView = findViewById(R.id.portfolio_recycler);
        portfolioRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        portfolioRecyclerView.setHasFixedSize(true);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Portfolio".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);

    }

}
