package zw.co.escrow.ctradelive.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;


public class MyClubs extends Fragment {
    private InvestmentClub.ClubServicesListener investmentClub;
    private RecyclerView recyclerView;
    private String cds_number;
    private SharedPreferences preferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my_clubs_view,container,false);
        preferences = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        recyclerView = view.findViewById(R.id.my_clubs_rv);
        investmentClub = new InvestmentClubService(getContext(),recyclerView);
        cds_number = preferences.getString("cds_number", "");
        investmentClub.onLoadMyClubs(cds_number);
        return view;
    }

}