package zw.co.escrow.ctradelive.view;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;

public class TermsAndConditionsView extends AppCompatActivity {

    private Toolbar toolbar;
    private WebView webView;
    private InvestmentClub.ClubServicesListener clubServicesListener;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_and_conditions_view);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Loading Disclaimer.....");
        progressDialog.show();
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Disclaimer");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());

        webView = findViewById(R.id.terms_view);
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);

            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressDialog.dismiss();
            }
        });
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);

        String url ="";
        try {
            url = URLEncoder.encode("https://ctrade.co.zw/online/docs/investment_clubs_disclaimer.pdf", "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Log.d("lloda",url);
        String path = "http://docs.google.com/gview?embedded=true&url=".concat(url);
        webView.loadUrl(path);
        clubServicesListener = new InvestmentClubService(this);

        SharedPreferences prfs = getSharedPreferences(getString(R.string.CTRADE),
                MODE_PRIVATE);
        String cdsnumber = prfs.getString("cds_number", "");

        findViewById(R.id.terms_back).setVisibility(View.GONE);
        findViewById(R.id.terms_back).setOnClickListener(v ->
            clubServicesListener.onAcceptTermsAndConditions(cdsnumber));
        findViewById(R.id.terms_accept).setOnClickListener(v -> {
            finish();
        });

    }
}