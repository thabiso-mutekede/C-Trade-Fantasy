package zw.co.escrow.ctradelive.view.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MarketWatchFINSECAdapter;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.setup.listeners.CTradeDataListener;
import zw.co.escrow.ctradelive.setup.services.CTradeDataServices;
import zw.co.escrow.ctradelive.view.MainActivity;

public class MarketWatchFINSECFragment extends Fragment {

    private View view;
    private RecyclerView watchListRecyclerView;
    private static final String TAG = "MarketWatchFINSECFragme";
    MarketWatchFINSECAdapter marketWatchFINSECAdapter;
    private CTradeDataListener cTradeDataListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        watchListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        cTradeDataListener = new CTradeDataServices(getActivity(),watchListRecyclerView);
        ClubModel clubModel = getArguments().getParcelable("club");
        cTradeDataListener.getFINSECMarketWatch(clubModel);




        return view;
    }
}