package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.FXPortfolio;

public class AuctionPortfolioAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<FXPortfolio> fxPortfolioList;
    private Context activity;
    private FXPortfolio fxPortfolio;
    private String cdsNumber;
    private final RecyclerView recyclerView;

    public AuctionPortfolioAdapter(Context activity, List<FXPortfolio> fxPortfolioList, RecyclerView recyclerView) {
        this.fxPortfolioList = fxPortfolioList;
        this.activity = activity;
        this.recyclerView = recyclerView;

        SharedPreferences sharedPreferences = activity.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = sharedPreferences.getString("cds_number", "");
    }


    @Override
    public int getItemViewType(int position) {
        return R.layout.auction_portfolio_adapter_view;
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @NonNull
    @Override
    public FXPortfolioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new FXPortfolioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((FXPortfolioViewHolder)holder).bindData(fxPortfolioList.get(position));
    }

    @Override
    public int getItemCount() {
        return fxPortfolioList.size();
    }



    public static class FXPortfolioViewHolder extends RecyclerView.ViewHolder{

        private TextView txtAmount, txtAuctionId, txtDate, txtCurrency, txtState,txtPurpose;
        private CardView cardView, wl_change_indicator;

        public FXPortfolioViewHolder(@NonNull View itemView) {
            super(itemView);

            txtPurpose = itemView.findViewById(R.id.txtPurpose);
            txtAmount = itemView.findViewById(R.id.amount_txt);
            txtAuctionId = itemView.findViewById(R.id.txtAuctionId);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtCurrency = itemView.findViewById(R.id.txtCurrency);
            txtState = itemView.findViewById(R.id.txtDescription);
            cardView = itemView.findViewById(R.id.cardView);
            wl_change_indicator = itemView.findViewById(R.id.wl_change_indicator);
        }

        public void bindData(FXPortfolio fxPortfolio){
            txtAmount.setText("$"+fxPortfolio.getAmount());
            txtAuctionId.setText(fxPortfolio.getAuctionId());
            txtDate.setText(fxPortfolio.getDatePosted());
            txtCurrency.setText(fxPortfolio.getCurrency());
            txtState.setText(fxPortfolio.getState());
            txtPurpose.setText(fxPortfolio.getPurpose());

        }
    }
}