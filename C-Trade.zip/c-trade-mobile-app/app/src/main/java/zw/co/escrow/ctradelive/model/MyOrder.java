package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class MyOrder implements Parcelable {
    private String type;
    private String status;
    private String quantity;
    private String price;
    private String value;
    private String description;
    private String date;
    private String id;
    private String Counter;
    private String rej_message;


    public MyOrder() {
    }

    public MyOrder(String type, String status, String quantity, String price, String value, String description, String date, String id,String counter,String rej_message) {
        this.type = type;
        this.status = status;
        this.quantity = quantity;
        this.price = price;
        this.value = value;
        this.description = description;
        this.date = date;
        this.id = id;
        this.Counter = counter;
        this.rej_message = rej_message;
    }


    protected MyOrder(Parcel in) {
        type = in.readString();
        status = in.readString();
        quantity = in.readString();
        price = in.readString();
        value = in.readString();
        description = in.readString();
        date = in.readString();
        id = in.readString();
        Counter = in.readString();
        rej_message = in.readString();
    }

    public static final Creator<MyOrder> CREATOR = new Creator<MyOrder>() {
        @Override
        public MyOrder createFromParcel(Parcel in) {
            return new MyOrder(in);
        }

        @Override
        public MyOrder[] newArray(int size) {
            return new MyOrder[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(type);
        parcel.writeString(status);
        parcel.writeString(quantity);
        parcel.writeString(price);
        parcel.writeString(value);
        parcel.writeString(description);
        parcel.writeString(date);
        parcel.writeString(id);
        parcel.writeString(Counter);
        parcel.writeString(rej_message);
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCounter() {
        return Counter;
    }

    public void setCounter(String counter) {
        Counter = counter;
    }

    public String getRej_message() {
        return rej_message;
    }

    public void setRej_message(String rej_message) {
        this.rej_message = rej_message;
    }
}