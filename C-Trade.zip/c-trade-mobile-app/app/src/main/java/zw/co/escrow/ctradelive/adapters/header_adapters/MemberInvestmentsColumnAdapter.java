package zw.co.escrow.ctradelive.adapters.header_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import de.codecrafters.tableview.TableDataAdapter;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.MemberInvestments;


public class MemberInvestmentsColumnAdapter extends TableDataAdapter {

    TextView textView;
    ImageView imageView;

    public MemberInvestmentsColumnAdapter(Context context, List data) {
        super(context, data);
    }


    @SuppressLint("ResourceAsColor")
    @Override
    public View getCellView(int rowIndex, int columnIndex, ViewGroup parentView) {

        View view = LayoutInflater.from(parentView.getContext()).inflate(R.layout.universal_column_adapter_view,parentView,false);
        textView = view.findViewById(R.id.text_id);
        imageView = view.findViewById(R.id.more_img);
        MemberInvestments mi = (MemberInvestments) getData().get(rowIndex);
        switch (columnIndex){
            case 0:
                textView.setText(mi.getGroup());
                break;
            case 1:
                textView.setText(mi.getClubTotal());
                break;
            case 2:
                textView.setText(mi.getMyTotal());
                break;
            case 3:
                textView.setText(mi.getMyPercentage());
                break;
        }

        return view;
    }
}
