package zw.co.escrow.ctradelive.model;

public class MDisp {

    private String title;
    private String currencyDisplay;
    private String amount;
    private String rate;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCurrencyDisplay() {
        return currencyDisplay;
    }

    public void setCurrencyDisplay(String currencyDisplay) {
        this.currencyDisplay = currencyDisplay;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    @Override
    public String toString() {
        return "MDisp{" +
                "title='" + title + '\'' +
                ", currencyDisplay='" + currencyDisplay + '\'' +
                ", amount='" + amount + '\'' +
                ", rate='" + rate + '\'' +
                '}';
    }
}
