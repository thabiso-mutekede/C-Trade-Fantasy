package zw.co.escrow.ctradelive.view;

import static zw.co.escrow.ctradelive.R.color.colorAccent;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.developer.kalert.KAlertDialog;
import com.github.ybq.android.spinkit.style.MultiplePulseRing;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.chip.Chip;
import com.google.android.material.snackbar.Snackbar;
import com.mikepenz.materialdrawer.holder.StringHolder;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.SecondaryDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IProfile;
import com.mikepenz.materialdrawer.widget.AccountHeaderView;
import com.mikepenz.materialdrawer.widget.MaterialDrawerSliderView;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import kotlin.Unit;
import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.ConvertFunds;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.listeners.OnProductSelected;
import zw.co.escrow.ctradelive.listeners.ProductListener;
import zw.co.escrow.ctradelive.model.CTradeActivity;
import zw.co.escrow.ctradelive.view.dialogs.AutoTradeDialog;
import zw.co.escrow.ctradelive.view.dialogs.MyCashDialog;
import zw.co.escrow.ctradelive.view.dialogs.RecentActivityDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradeDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradeDialogFantasy;
import zw.co.escrow.ctradelive.view.dialogs.TradeDialogETF;
import zw.co.escrow.ctradelive.view.fragments.AvailableTrustFragment;
import zw.co.escrow.ctradelive.view.fragments.MarketAnalysis;
import zw.co.escrow.ctradelive.view.fragments.MarketWatchFINSECFragment;
import zw.co.escrow.ctradelive.view.fragments.MarketWatchPlaceHolderFragment;
import zw.co.escrow.ctradelive.view.fragments.ProductsContainerFantasyFragment;
import zw.co.escrow.ctradelive.view.fragments.individual_create_account.IPOsFragment;
import zw.co.escrow.ctradelive.view_model.AppViewModel;

public class FantasyView extends AppCompatActivity implements View.OnClickListener, ProductListener {

    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    private MaterialDrawerSliderView cTradeDrawerSlider;
    private DrawerLayout cTradeDrawerLayout;
    private RelativeLayout viewsLayout;
    private CoordinatorLayout dashboard_menu;
    private AppBarLayout appBarLayout;
    private BottomAppBar bottomAppBar;
    private NestedScrollView nestedScrollView;
    //private SwipeRefreshLayout swipeRefreshLayout;
    private AccountHeaderView c_tradeDrawerHeader;
    private static final String TAG = "MainActivity";
    private static final Integer ENTEROTPFORWITHDRAWAL = 1111;

    private TextView txtCount,txtUnclearedCash,txtClearedCash, txtCashBalance, txtMyPortfolio, txtTotalAccount, txtNetPerfomance, txtForexWallerBalance, txtOutStandingCharges;
    private Chip chipBuy, chipSell, chipDeposit, chipWithdraw, chipViewTxn, chipConvert, chipPortfolio, chipMyOrders, chipUnitTrust, chipNewsFeed ;
    private String cdsNumber, email, cashBalance,user_names;
    private SharedPreferences sharedPreferences;

    private ProgressBar loadingSpinner;
    private MultiplePulseRing multiplePulseRing;
    private KAlertDialog alertDialog;
    private AppViewModel appViewModel;
    private Toolbar toolbar;
    private ProgressDialog progressDialog;
    private List<CTradeActivity> cTradeActivityList;
    private Runnable refresh;
    private Handler handler;
    private OnProductSelected productSelected;
    private String current_market;
    private String current_product;
    //private Bitmap profileBitmap;

//    private void setProfileBitmap(byte[] profileByteArray,Bundle savedInstanceState){
//        profileBitmap = BitmapFactory.decodeByteArray(profileByteArray, 0,profileByteArray.length);
//        setUpDrawer(savedInstanceState);
//    }



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fantasy);
        //Change the status bar color to black to match the app's theme and should be in every activity
        progressDialog= new ProgressDialog(this);
        progressDialog.setCancelable(false);
        Utils.setStatusBarColor(FantasyView.this);

        initWidgets();

        //swipeRefreshLayout = findViewById(R.id.swipe_refresh);
        /*swipeRefreshLayout.setOnRefreshListener(() -> {
            recreate();
            swipeRefreshLayout.setRefreshing(false);
        });*/

        toolbar=findViewById(R.id.home_toolbar);



        setSupportActionBar(toolbar);

        /*ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }*/


        findViewById(R.id.drawer_option).setOnClickListener(this);
        findViewById(R.id.notification_option).setOnClickListener(this);


        chipPortfolio.setOnClickListener(this);
        chipWithdraw.setOnClickListener(this);
        chipViewTxn.setOnClickListener(this);

        chipBuy.setOnClickListener(this);
        chipSell.setOnClickListener(this);
        chipMyOrders.setOnClickListener(this);

        chipNewsFeed.setOnClickListener(this);

        nestedScrollView.setOnScrollChangeListener((View.OnScrollChangeListener) (view, i, i1, i2, i3) -> {
            Log.d(TAG, "onScrollChange: "+"hek");

            nestedScrollView.onNestedFling(nestedScrollView, 0,0,true);


            if (i1 > i2) {
                bottomAppBar.setHideOnScroll(false);
            }
            else {
                bottomAppBar.setHideOnScroll(true);

            }
            if (i1 < i2) {
                bottomAppBar.setHideOnScroll(false);
            }
            else {
                bottomAppBar.setHideOnScroll(true);

            }
            if (i2 == 0) {
                bottomAppBar.setHideOnScroll(false);
            }
            else {
                bottomAppBar.setHideOnScroll(true);

            }

            if (i1 == 0) {
                bottomAppBar.setHideOnScroll(false);
            }
            else {
                bottomAppBar.setHideOnScroll(true);

            }


        });



        sharedPreferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = sharedPreferences.getString("cds_number", "");
        user_names = sharedPreferences.getString("fullname", "");
        email = sharedPreferences.getString("email", "");

        Log.d(TAG, "cdsNumber: "+cdsNumber);
        //getForexBalance(cdsNumber);

        setUpView();
        //Read my cash and populate the view if cds number is not empty
        if (!cdsNumber.equals("")){
            getCashBalances();
        }
        setUpWatchList();
        //getProfileImage(savedInstanceState);
        getActivityNotifications();

        setUpDrawer(savedInstanceState);
        //Toast.makeText(this,"Swipe Down To Refresh",Toast.LENGTH_SHORT).show();
    }


    private void getCashBalances(){
        JsonObjectRequest jr = new JsonObjectRequest(
                Constants.COMPLETE_URL("fantasy/cash"),
                Constants.cdsNumberJSON(cdsNumber),
                response -> {

                    try {
                        txtUnclearedCash.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("virtualCashBal")))))));
                        txtClearedCash.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("actualCashBal")))))));
                        txtCashBalance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("actualCashBal")))))));
                        txtMyPortfolio.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("potValue")))))));
                        txtTotalAccount.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("totalAccount")))))));
                        txtNetPerfomance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("profitLoss")))))));
                        //txtForexWallerBalance.setText(String.format("$ %s","0.00"));
                        txtForexWallerBalance.setText(String.format("$ %s", Constants.getThousandSep(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf(response.getDouble("forexBalance")))))));
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                },
                error -> {

                    error.printStackTrace();
                }

        );
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    /**
     @Override
     public boolean onOptionsItemSelected(@NonNull MenuItem item) {
     switch (item.getItemId()){
     case android.R.id.home:
     if (cdsNumber.equals("")) {
     startActivity(new Intent(this, LoginActivity2.class));
     finish();
     }else {
     cTradeDrawerLayout.open();
     }
     break;
     case R.id.action_search:
     startActivity(new Intent(this, SearchActivity.class));
     break;

     }
     return super.onOptionsItemSelected(item);
     }

     @Override
     public boolean onCreateOptionsMenu(Menu menu) {

     MenuInflater menuInflater = getMenuInflater();
     menuInflater.inflate(R.menu.home_menu, menu);


     return true;
     }**/



    private void initWidgets(){

        cTradeDrawerSlider = findViewById(R.id.slider);
        cTradeDrawerLayout = findViewById(R.id.root);
        dashboard_menu = findViewById(R.id.dashboard_menu);
        appBarLayout = findViewById(R.id.appbar);
        bottomAppBar = findViewById(R.id.bottom_app_bar);
        nestedScrollView = findViewById(R.id.nestedScrollView);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPager = findViewById(R.id.viewPagerWatchList);
        txtUnclearedCash = findViewById(R.id.txtUnclearedCashFantasy);
        txtClearedCash = findViewById(R.id.txtClearedCashFantasy);
        txtCashBalance = findViewById(R.id.txtCashBalanceFantasy);
        txtMyPortfolio = findViewById(R.id.txtMyPortfolioFantasy);
        txtTotalAccount = findViewById(R.id.txtTotalAccountFantasy);
        txtNetPerfomance = findViewById(R.id.txtNetPerfomance);
        txtForexWallerBalance = findViewById(R.id.txtForexWallerBalance);
        txtOutStandingCharges = findViewById(R.id.txtOutStandingCharges);



        chipBuy = findViewById(R.id.chipBuy);
        chipSell = findViewById(R.id.chipSell);

        chipWithdraw = findViewById(R.id.chipWithdraw);
        chipViewTxn = findViewById(R.id.chipViewTxn);

        chipPortfolio = findViewById(R.id.chipPortfolio);
        chipMyOrders = findViewById(R.id.chipMyOrders);

        chipNewsFeed = findViewById(R.id.chipNewsFeed);


        loadingSpinner = findViewById(R.id.loadingSpinner);
        multiplePulseRing = new MultiplePulseRing();
        loadingSpinner.setIndeterminateDrawable(multiplePulseRing);
        loadingSpinner.setVisibility(View.VISIBLE);


    }

    private void setUpWatchList(){
        Bundle bundle = new Bundle();
        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("ZSE", ProductsContainerFantasyFragment.class,bundle)
                .add("FINSEC", MarketWatchFINSECFragment.class,bundle)
                .create());
        current_market = Constants.ZSE;
        SharedPreferences sh = getSharedPreferences(Constants.PRODUCTS_PREF,MODE_PRIVATE);
        SharedPreferences.Editor editor = sh.edit();
        editor.putString(Constants.PRODUCT,Constants.NONE);
        editor.apply();
        watchListPager.setAdapter(watchListPagerAdapter);
        watchListPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position){
                    case 0:
                        current_market = Constants.ZSE;
                        orderButtonsVisible(false);
                        break;
                    case 1:
                        current_market = Constants.FINSEC;
                        orderButtonsVisible(true);
                        break;
                    default:
                        break;
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        watchListPagerTab.setViewPager(watchListPager);
    }
    @SuppressLint("ResourceAsColor")
    private void setUpDrawer(Bundle savedInstanceState){

        SecondaryDrawerItem home = new SecondaryDrawerItem();
        home.setName(setTitle("HOME".toUpperCase()));
        SecondaryDrawerItem profile = new SecondaryDrawerItem();
        profile.setName(setTitle("Profile".toUpperCase()));
        profile.setOnDrawerItemClickListener(
                ((view, iDrawerItem, integer) ->
                {
                    startActivity(new Intent(FantasyView.this,ProfileView.class));
                    return true;
                }));

        SecondaryDrawerItem ctradelive = new SecondaryDrawerItem();
        ctradelive.setName(setTitle("CTRADE LIVE TRADING".toUpperCase(Locale.ROOT)));
        ctradelive.setOnDrawerItemClickListener(
                ((view, iDrawerItem, integer) -> {
                    startActivity(new Intent(FantasyView.this, MainActivity.class));
                    return  true;
                })
        );

        SecondaryDrawerItem exit = new SecondaryDrawerItem();
        exit.setName(setTitle("Logout".toUpperCase()));
        exit.setOnDrawerItemClickListener(((view, iDrawerItem, integer) -> {
            if(sharedPreferences.edit().clear().commit()){
                Toast.makeText(this,"You've Successfully Logged Out.",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity2.class));
                finish();
            }
            return true;
        }));

        cTradeDrawerSlider.getItemAdapter().add(
                home,
                profile,
                ctradelive,
                exit);
        cTradeDrawerLayout.setStatusBarBackground(colorAccent);
        c_tradeDrawerHeader = new AccountHeaderView(this).apply((v)->{
            IProfile iProfile = new ProfileDrawerItem();
            iProfile.setName(setTitle(user_names));
            iProfile.setDescription(setTitle(cdsNumber));
            v.attachToSliderView(cTradeDrawerSlider);
            //iProfile.setIcon(new ImageHolder(profileBitmap));
            v.addProfiles(iProfile);
            return Unit.INSTANCE;
        });
    }
    @Override
    public void onClick(View view) {
        if (cdsNumber.equals("")) {
            startActivity(new Intent(this, LoginActivity2.class));
            finish();
        }else {
            switch (view.getId()){
                case R.id.chipPortfolio:
                    startActivity(new Intent(this, PortfolioActivityFantasy.class)
                            .putExtra("cdsNumber",cdsNumber)
                            .putExtra("","main"));
                    break;
                case R.id.linearLayoutShares:
                    break;
                case R.id.chipBuy:
                    String prod =  getSharedPreferences(Constants.PRODUCTS_PREF,MODE_PRIVATE).getString(Constants.PRODUCT,Constants.NONE);
                    if(current_market.equalsIgnoreCase(Constants.ZSE)
                            && prod.equalsIgnoreCase(Constants.ETF)){
                        TradeDialogETF dialogBuy = TradeDialogETF.newInstance("BUY",cdsNumber);
                        FragmentTransaction ftBuy = getSupportFragmentManager().beginTransaction();
                        dialogBuy.show(ftBuy, TradeDialog.TAG);
                    }else {
                        TradeDialogFantasy dialogBuy = TradeDialogFantasy.newInstance(current_market, "BUY", cdsNumber);
                        FragmentTransaction ftBuy = getSupportFragmentManager().beginTransaction();
                        dialogBuy.show(ftBuy, TradeDialog.TAG);

                    }
                    break;
                case R.id.chipSell:
                    String produ =  getSharedPreferences(Constants.PRODUCTS_PREF,MODE_PRIVATE).getString(Constants.PRODUCT,Constants.NONE);
                    if(current_market.equalsIgnoreCase(Constants.ZSE) && produ.equalsIgnoreCase(Constants.ETF)){
                        TradeDialogETF dialogSell = TradeDialogETF.newInstance( "SELL", cdsNumber);
                        FragmentTransaction ftSell = getSupportFragmentManager().beginTransaction();
                        dialogSell.show(ftSell, TradeDialog.TAG);
                    }else {
                        TradeDialogFantasy dialogSell = TradeDialogFantasy.newInstance(current_market, "SELL", cdsNumber);
                        FragmentTransaction ftSell = getSupportFragmentManager().beginTransaction();
                        dialogSell.show(ftSell, TradeDialog.TAG);
                    }
                    break;
                case R.id.chipAutoTrade:
                    String produi =  getSharedPreferences(Constants.PRODUCTS_PREF,MODE_PRIVATE).getString(Constants.PRODUCT,Constants.NONE);
                    if(current_market.equalsIgnoreCase(Constants.ZSE) && produi.equalsIgnoreCase(Constants.ETF)){
                        AutoTradeDialog dialogSell = AutoTradeDialog.newInstance(current_market, "Auto Trade", cdsNumber);
                        FragmentTransaction ftSell = getSupportFragmentManager().beginTransaction();
                        dialogSell.show(ftSell, AutoTradeDialog.TAG);
                    }else {
                        AutoTradeDialog dialogSell = AutoTradeDialog.newInstance(current_market, "Auto Trade", cdsNumber);
                        FragmentTransaction ftSell = getSupportFragmentManager().beginTransaction();
                        dialogSell.show(ftSell, TradeDialogFantasy.TAG);
                    }
                    break;
                case R.id.chipDeposit:
                    startActivityForResult(new Intent(this, DepositActivity.class), Constants.DEPOSIT_REQUEST_CODE);
                    break;

                case R.id.chipWithdraw:
                    startActivityForResult(new Intent(this, WithdrawActivity.class), Constants.WITHDRAW_REQUEST_CODE);
                    break;
                case R.id.chipNews:
                    //if(Double.parseDouble(txtForexWallerBalance.getText().toString())>0){
                    startActivityForResult(new Intent(this, ConvertActivity.class), Constants.CONVERT_REQUEST_CODE);
                    //}
//                    else{
//                        Snackbar snackbar = Snackbar.make(view, "Your Forex Balance is below Required Amount", Snackbar.LENGTH_LONG);
//                        View snackbarView = snackbar.getView();
//                        snackbarView.setBackgroundColor(getResources().getColor(R.color.colorRed));
//                        snackbar.show();
//                        //getForexBalance(cdsNumber);
//                    }
                    break;
                case R.id.chipMyOrders:
                    startActivity(new Intent(this, MyOrdersActivity.class).putExtra("cdsnumber",cdsNumber).putExtra("isClub",false));
                    break;
                case R.id.chipAuction:
                    //startActivity(new Intent(this, AuctionView.class).putExtra("cdsnumber",cdsNumber));
                    Toast.makeText(this,"Coming Soon..",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.chipUnitTrust:
                    startActivity(new Intent(this, UnitTrustMainDashBoard.class).putExtra("cdsNumber",cdsNumber));
                    break;
                case R.id.chipNewsFeed:
                    startActivity(new Intent(this, NewsFeedsActivity.class));
                    break;

                case R.id.chipViewTxn:
                    new MyCashDialog(this,cdsNumber,1).show();
                    break;

                case R.id.drawer_option:
                    cTradeDrawerLayout.open();;
                    break;

                case R.id.notification_option:
                    if(cTradeActivityList != null){
                        if(cTradeActivityList.size() > 0){
                            new RecentActivityDialog(this,cdsNumber,cTradeActivityList).show();
                        }else{
                            showToast("You Do Not Have Notifications Yet");
                        }
                    }else{
                        showToast("You Do Not Have Notifications Yet");
                    }
                    break;

                case R.id.chipClub:
                    startActivity(new Intent(this,InvestmentClubsMainView.class));

                    finish();
                    break;
                case R.id.chipIssuer:
                    showToast("You Are Not A Registered Issuer");
                    break;
                case R.id.chipIpo:
                    showToast("No IPOs");
                    break;
                case R.id.chipCommodities:
                    showToast("Coming Soon..");
                    break;
            }
        }
    }

    private StringHolder setTitle(String title){
        return new StringHolder(title);
    }

    private void setUpView(){
        //viewsLayout.setVisibility(View.GONE);
        //c_tradeMainDashboard.setVisibility(View.VISIBLE);
        loadingSpinner.setVisibility(View.GONE);
        appBarLayout.setVisibility(View.VISIBLE);
        watchListPagerTab.setVisibility(View.VISIBLE);
        watchListPager.setVisibility(View.VISIBLE);
        bottomAppBar.setVisibility(View.VISIBLE);
        cTradeDrawerLayout.setVisibility(View.VISIBLE);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        String amount,add_info_url = AppConfig.getIp() + "/PaynowPayments";

        float limit= sharedPreferences.getFloat("WITHDRAW",100);
        float depositLimit= sharedPreferences.getFloat("DEPOSIT",100);
        AppConfig appConfig;
        switch (requestCode){
            case Constants.CONVERT_REQUEST_CODE:
                amount= data != null ? data.getStringExtra("AMOUNT") : null;
                Toast.makeText(this, "Converted "+amount, Toast.LENGTH_SHORT).show();
                ConvertFunds convertFunds = new ConvertFunds(this);
                if (amount != null) convertFunds.convertFunds(amount);
                break;
            case Constants.WITHDRAW_REQUEST_CODE:
                amount= data != null ? data.getStringExtra("AMOUNT") : null;
                if (amount != null) {
                    if (Double.parseDouble(amount) > limit -1) {

                        //TODO show progress bar

                        progressDialog.setMessage("Processing...");
                        progressDialog.show();
                        add_info_url = AppConfig.getIp() + "/Widthdraw";


                        final String cds_no = sharedPreferences.getString("cds_number", "");
                        JsonObjectRequest jsonObjRequest = new JsonObjectRequest(Constants.COMPLETE_URL("cash/withdraw"),
                                Constants.amountIndividualJSON(cds_no,Float.parseFloat(amount)),
                                response -> {
                                    try {
                                        progressDialog.dismiss();
                                        //TODO dismis progress dialog and show ok dialog
                                        new AlertDialog.Builder(this)
                                                .setMessage(response.getString("message"))
                                                .setPositiveButton("ok",null)
                                                .show();

                                    } catch (Exception e) {
                                        progressDialog.dismiss();
                                        e.printStackTrace();
                                    }
                                },
                                loginErrorListener());
                        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);


                    } else {
                        Snackbar snackbar = Snackbar.make(this.chipWithdraw, "Please minimum withdrawal amount should be ZWL"+limit, Snackbar.LENGTH_LONG);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(getResources().getColor(R.color.colorOrange));
                        snackbar.show();
                        //Toast.makeText(WithdrawCash.this, "Please minimum withdrawal amount should be ZWL 10.", Toast.LENGTH_SHORT).show();
                    }
                }


                break;
            case Constants.DEPOSIT_REQUEST_CODE:

                String[] depositDetails = data != null ? data.getStringArrayExtra("DEPOSIT_DETAILS") : null;

                if (depositDetails != null){

                    if (Double.parseDouble(depositDetails[0]) > depositLimit - 1) {


                        if (depositDetails[3].equalsIgnoreCase("EcoCash")) {

                            attemptEcocashDeposit(cdsNumber, depositDetails[0], depositDetails[1]);

                        }
                        else if (depositDetails[3].equalsIgnoreCase("International Card")){

                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.APP_BASE_FULL_URL+"/DirectPayonline"+ "?amount=" + depositDetails[0] + "&cdsnumber=" + cdsNumber + "&email=" + email + ""));
                            startActivity(browserIntent);
                            finish();

                        }
                        else {

                            if(depositDetails[2].equalsIgnoreCase("USD")){
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.APP_BASE_FULL_URL+"PaynowPaymentsUSD"+ "?cdsNumber=" + cdsNumber + "&price=" + depositDetails[0] + "&quantity=1&email=" + email + "&Currency=USD"));
                                startActivity(browserIntent);
                                finish();
                            }
                            else if(depositDetails[2].equalsIgnoreCase("ZWL")){

                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(add_info_url + "?cdsNumber=" + cdsNumber + "&price=" + depositDetails[0] + "&quantity=1&email=" + email + "&Currency=ZWL"));
                                startActivity(browserIntent);
                            }
                        }

                    } else {
                        //Toast.makeText(DepositCash.this, "Please minimum deposit amount allowed is "+limit, Toast.LENGTH_LONG).show();
                        Snackbar snackbar = Snackbar.make(this.chipDeposit, "Please minimum deposit amount allowed is ZWL "+limit, Snackbar.LENGTH_LONG);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(getResources().getColor(R.color.colorOrange));
                        snackbar.show();

                        //Toast.makeText(this, "Please minimum deposit amount allowed is ZWL "+limit, Toast.LENGTH_SHORT).show();
                    }
                }
                break;
        }

    }


    private com.android.volley.Response.ErrorListener loginErrorListener() {
        return error -> {
            error.printStackTrace();

            progressDialog.dismiss();
            new AlertDialog.Builder(this)
                    .setMessage("Network unavailable")
                    .setPositiveButton("ok",null)
                    .show();
        };
    }


    private void attemptEcocashDeposit(String cdsNumber, @NonNull String amount, String phone) {

        //TODO show loading spinner
        alertDialog = new KAlertDialog(this, KAlertDialog.PROGRESS_TYPE);
        alertDialog.setContentText("Please wait").show();
        String url;
        JSONObject jo = new JSONObject();
        try{

            jo.put("cdsNumber",cdsNumber);
            jo.put("amount",Float.parseFloat(amount));
            jo.put("phone",phone);

        }catch (Exception e){
            e.printStackTrace();
        }
        Log.d("em",jo.toString());

        JsonObjectRequest jsonObjRequest = new JsonObjectRequest(Constants.COMPLETE_URL("cash/deposit/ecocash"),
                jo,
                response -> {
                    try{
                        alertDialog.dismiss();
                        alertDialog= new KAlertDialog(this, KAlertDialog.SUCCESS_TYPE);
                        alertDialog.setContentText(response.getString("message")).setConfirmClickListener(kAlertDialog -> {
                            alertDialog.dismissWithAnimation();

                        }).setConfirmText("Ok").show();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                },
                ecocashErrorListener()) {
        };

        jsonObjRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest);
    }

    private Response.ErrorListener ecocashErrorListener() {
        return error -> {

            //TODO REMOVE LOADING SPINNER and return to main activity
            alertDialog.dismiss();
            alertDialog= new KAlertDialog(this, KAlertDialog.ERROR_TYPE);
            alertDialog.setContentText("An unknown error has occurred").setConfirmClickListener(kAlertDialog -> {
                alertDialog.dismissWithAnimation();

            }).setConfirmText("Ok").show();
            try {
                error.printStackTrace();

            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }

    @Override
    public void onResume() {
        super.onResume();
        //getForexBalance(cdsNumber);
        //getCashBalances();
        getActivityNotifications();
    }

    private void showToast(String msg){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    private void getActivityNotifications(){

        String url = AppConfig.getIp().concat("getUserActivity?cdsnumber=").concat(cdsNumber);
        JsonArrayRequest jre = new JsonArrayRequest(url, response -> {
            this.cTradeActivityList = new ArrayList<>();
            try{
                if(response.length() > 0){
                    TextView txt = findViewById(R.id.count_txt);
                    findViewById(R.id.card_view_count).setVisibility(View.VISIBLE);
                    for(int i = 0;i < response.length();i++){
                        JSONObject jo = response.getJSONObject(i);
                        CTradeActivity cTradeActivity = new CTradeActivity();
                        cTradeActivity.setAct_date(jo.getString("date"));
                        cTradeActivity.setDescription(jo.getString("description"));
                        cTradeActivity.setType(jo.getString("type"));

                        this.cTradeActivityList.add(cTradeActivity);

                        txt.setText(String.valueOf(this.cTradeActivityList.size()));

                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }

        },error -> error.printStackTrace());

        AppConfig.getInstance().addToRequestQueue(jre);
    }

    public void setProductSelected(OnProductSelected productSelected) {
        this.productSelected = productSelected;
    }

    @Override
    public void onBackPressed() {
        productSelected.click(Constants.NONE);
    }

   // @Override
    public void productChanged(String product) {

        if(product.equalsIgnoreCase(Constants.NONE))
            orderButtonsVisible(false );
        else orderButtonsVisible(true );

        getSharedPreferences(Constants.PRODUCTS_PREF,MODE_PRIVATE)
                .edit().remove(Constants.PRODUCT)
                .putString(Constants.PRODUCT,product)
                .apply();

    }
    private void orderButtonsVisible(boolean b){

        Log.d("trimo ","---"+b);
        if(b){
            findViewById(R.id.chipBuy).setVisibility(View.VISIBLE);
            findViewById(R.id.chipSell).setVisibility(View.VISIBLE);
            findViewById(R.id.chipBuy).setVisibility(View.VISIBLE);
            return;
        }
        findViewById(R.id.chipBuy).setVisibility(View.GONE);
        findViewById(R.id.chipSell).setVisibility(View.GONE);

    }
    /*private void getProfileImage(Bundle savedInstanceState){
        ApiClubInterface api = CTradeAccountApiClient.getApiService();
        Call<ResponseBody> imageCall = api.getPro(cdsNumber,"Photo");
        imageCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, retrofit2.Response<ResponseBody> response) {
                try {
                    setProfileBitmap(response.body().bytes(),savedInstanceState);
                    Log.d("image","This is the image"+response.body().bytes());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("image error",t.getMessage());
                t.printStackTrace();
            }
        });

    }*/

}
