package zw.co.escrow.ctradelive.view;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;
import zw.co.escrow.ctradelive.view.dialogs.AddANewMemberDialog;


public class MembershipView extends AppCompatActivity implements View.OnClickListener {
    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private InvestmentClub.ClubServicesListener  clubServicesListener;
    private ClubModel club;
    private CoordinatorLayout mlay;
    private TextView cname,cphone,cId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership_view);
        club = getIntent().getParcelableExtra("club");
        recyclerView = findViewById(R.id.members_rec_view);
        cname = findViewById(R.id.chairman_name_tv);
        cphone = findViewById(R.id.chairman_mobile_tv);
        cId = findViewById(R.id.chairman_id_tv);
        toolbar = findViewById(R.id.toolbar);
        mlay = findViewById(R.id.mlay);
        toolbar.setTitle("MEMBERSHIP");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(cl);
        clubServicesListener = new InvestmentClubService(this,recyclerView);
        clubServicesListener.onLoadMembership(club.getClubCdsNumber());
        findViewById(R.id.fab).setOnClickListener(this);
        cname.setText(club.getChairman().getName());
        cphone.setText(club.getChairman().getPhoneNumber());
        cId.setText(club.getChairman().getIdNumber());

        Snackbar.make(findViewById(R.id.mlay), "Swipe Down To Refresh Page",
                BaseTransientBottomBar.LENGTH_LONG).show();
    }
    private View.OnClickListener cl = v -> finish();


    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.fab){
            if(club.isMember()){
                Snackbar.make(mlay, "Members Cannot Add Other Members",
                        BaseTransientBottomBar.LENGTH_SHORT).show();
            }else {
                AddANewMemberDialog a = new AddANewMemberDialog(this,club);
                a.show();
            }
        }
    }
}