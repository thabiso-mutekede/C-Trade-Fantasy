package zw.co.escrow.ctradelive.setup.services;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.data_repository.VolleyMultipartRequest;
import zw.co.escrow.ctradelive.model.DataPart;
import zw.co.escrow.ctradelive.setup.listeners.Registration;

public class RegistrationService implements Registration.DataListener {

    private final Context context;
    private final ProgressDialog progressDialog;

    public RegistrationService(Context context) {
        this.context = context;
        this.progressDialog = new ProgressDialog(context);
    }
    private void showDialog(String message){
        new AlertDialog.Builder(context)
                .setMessage(message)
                .setPositiveButton("ok",(
                        (dialogInterface, i) -> {
                }))
                .create()
                .show();
    }

    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    @Override
    public void createCTradeAccount(Context context,String client,final Bitmap photo,final Bitmap id) {

        Log.d("lloda",client);
        progressDialog.setMessage("Creating A CTrade Account");
        progressDialog.setCancelable(false);
        progressDialog.show();
            VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, Constants.COMPLETE_URL("client/create"),
                    response -> {
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));
                            progressDialog.dismiss();
                            showDialog(obj.getString("message"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                            showDialog("Failed To Read Data.Please Try Again Later");
                            e.printStackTrace();
                        }
                    },
                    error -> {
                   error.printStackTrace();
                    progressDialog.dismiss();
                    showDialog("Failed To Read Data.Please Try Again Later");
                    }) {
                @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> params = new HashMap<>();
                    long imagename = System.currentTimeMillis();
                    params.put("image_1", new DataPart(imagename + ".png", getFileDataFromDrawable(photo)));
                    params.put("image_2", new DataPart(imagename + ".png", getFileDataFromDrawable(id)));
                    return params;
                }

                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("registration",client);
                    return params;
                }

                @Override
             public RetryPolicy getRetryPolicy() {
                 return new RetryPolicy() {
                     @Override
                     public int getCurrentTimeout() {
                         return 500000;
                     }

                             @Override
                     public int getCurrentRetryCount() {
                         return 0;
                     }

                             @Override
                     public void retry(VolleyError error) throws VolleyError {

                     }
                 };
             }
            };
        AppConfig.getInstance().addToRequestQueue(volleyMultipartRequest);
    }
}

/**
 * {
 *             @Override
 *             public RetryPolicy getRetryPolicy() {
 *                 return new RetryPolicy() {
 *                     @Override
 *                     public int getCurrentTimeout() {
 *                         return 500000;
 *                     }
 *
 *                     @Override
 *                     public int getCurrentRetryCount() {
 *                         return 0;
 *                     }
 *
 *                     @Override
 *                     public void retry(VolleyError error) throws VolleyError {
 *
 *                     }
 *                 };
 *             }
 *         }
 */
