package zw.co.escrow.ctradelive.listeners;

import zw.co.escrow.ctradelive.model.OrderDetails;

public interface OnPlaceOrder {
    void showDialog(OrderDetails orderDetails);
}
