package zw.co.escrow.ctradelive;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class CancelOrderAsyncTask extends AsyncTask<String, Void, String> {
    String cancel_order_url;

    private WeakReference<Activity> activityWeakReference; // To prevent memory leaks


    public CancelOrderAsyncTask(Activity activity) {
        activityWeakReference = new WeakReference<>(activity);
    }




    @Override
    protected void onPreExecute() {
        cancel_order_url =
                AppConfig.getApiV2() + "/UpdateCancelOrder";
    }

    @Override
    protected String doInBackground(String... args) {
        String cdsNumber, orderNumber, type;

        cdsNumber = args[0];
        orderNumber = args[1];
        type = args[2];

        try {
            URL url = new URL(cancel_order_url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
            httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter =
                    new BufferedWriter(
                            new OutputStreamWriter(outputStream, "UTF-8"));

            String data_string =
                    URLEncoder.encode("cdsnumber", "UTF-8") + "=" +
                            URLEncoder.encode(cdsNumber, "UTF-8")
                            + "&" + URLEncoder.encode("ordernumber", "UTF-8") + "=" +
                            URLEncoder.encode(orderNumber, "UTF-8")
                            + "&" + URLEncoder.encode("orderType", "UTF-8") + "="
                            + URLEncoder.encode(type, "UTF-8");
            bufferedWriter.write(data_string);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
//                reading from server
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader =
                    new BufferedReader(
                            new InputStreamReader(inputStream, "iso-8859-1"));
            String response = "";
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                response += line;
            }

            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
            return response;
        } catch (MalformedURLException e) {
            return "Bad Url " + e.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return "Cant Reach " + e.toString();
        }
    }

    @Override
    protected void onPostExecute(String result) {

        Activity activity = activityWeakReference.get();


        new AlertDialog.Builder(activity)
                .setTitle("Result")
                .setCancelable(true)
                .setMessage(result)
                .setPositiveButton("OK", (dialog, which) -> activity.finish())
                .show();
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

}

