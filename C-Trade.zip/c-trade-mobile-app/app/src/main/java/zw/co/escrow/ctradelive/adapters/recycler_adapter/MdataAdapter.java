package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.MDisp;


public class MdataAdapter extends RecyclerView.Adapter {

    List<MDisp> mDispList;

    public MdataAdapter(List<MDisp> mDispList) {
        this.mDispList = mDispList;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.mdata_adapter;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);

        return new MDataDispVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Log.d("lloda anl",mDispList.toString());
        Log.d("lloda an",mDispList.get(position).toString());
        ((MDataDispVH)holder).onDataBind(mDispList.get(position));
    }

    private int resourceType(String per, TextView textView, TextView title){

        double percentage;
        try{
            percentage = Double.parseDouble(per);
        }catch (Exception e){
            percentage = 0.0;
            e.printStackTrace();
        }

        if(percentage > 0){
            textView.setTextColor(Color.parseColor("#1C980E"));
            title.setBackgroundColor(Color.parseColor("#32CD32"));
            textView.setText(String.valueOf(percentage));

            return R.drawable.trend_up_ic;
        }
        else if (percentage == 0){
            textView.setText(String.valueOf(percentage));
            textView.setTextColor(Color.parseColor("#FFC61D"));
            title.setBackgroundColor(Color.parseColor("#F0E68C"));
            return R.drawable.trend_flat_ic;
        }else{
            textView.setText(String.valueOf(percentage));
            title.setBackgroundColor(Color.parseColor("#DC143C"));
            textView.setTextColor(Color.parseColor("#FF3011"));
            return R.drawable.trend_down_ic;
        }

    }

    @Override
    public int getItemCount() {
        return mDispList.size();
    }

    private class MDataDispVH extends RecyclerView.ViewHolder {

        private ImageView trendIcon;
        private TextView rate,amount,title,currency;
        public MDataDispVH(@NonNull View itemView) {
            super(itemView);
            rate = itemView.findViewById(R.id.rate);
            amount = itemView.findViewById(R.id.amount);
            title = itemView.findViewById(R.id.title);
            trendIcon = itemView.findViewById(R.id.trend_icon);
            currency = itemView.findViewById(R.id.currency);
        }
        public  void onDataBind(MDisp mDisp){

            trendIcon.setImageResource(resourceType(mDisp.getRate(),rate,title));
            amount.setText(mDisp.getAmount());
            title.setText(mDisp.getTitle());
            currency.setText(mDisp.getCurrencyDisplay());

        }
    }
}
