package zw.co.escrow.ctradelive.view.fragments;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;


import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.UnitOrdersAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.MyOrder;
import zw.co.escrow.ctradelive.model.WatchListData;


/**
 * A simple {@link Fragment} subclass.
 */
public class UnitTrustOrdersFragment extends Fragment {

    private View view;
    private RecyclerView watchListRecyclerView;
    private List<WatchListData> watchListDataList;
    private static final String TAG = "UnitTrustOrdersFragment";
    private  List<MyOrder> myOrderList = new ArrayList<>();
    private String mobileip, felloverip1, felloverip2, ip, cds_number;
    private AppConfig appConfig;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        watchListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        appConfig = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();
        mobileip = AppConfig.getMobileApiAddress();

        /*SharedPreferences prfs = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cds_number = prfs.getString("cds_number", "");*/
        cds_number = getActivity().getIntent().getExtras().getString("cdsNumber");
        Log.d(TAG, "onCreateView: "+cds_number);
        myOrderList.clear();

        fetchMyOrders();



        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);



    }

    private void fetchMyOrders() {

        JSONObject jo = new JSONObject();
        try{
            jo.put("cdsNumber",cds_number);
            jo.put("type","unitTrust");
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject zseJsonRequest = new JSONArrayRequestWithObject(Request.Method.POST, Constants.COMPLETE_URL("account/orders"),
                jo,
                loginSuccessListenerMyOrders(),
                loginErrorListenerMyOrders());
        zseJsonRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(zseJsonRequest);
    }

    private com.android.volley.Response.ErrorListener loginErrorListenerMyOrders() {
        return error -> {
            try {
               /* if (progressDialog != null)
                    progressDialog.dismiss();*/
                //Todo progress


                new AlertDialog.Builder(Objects.requireNonNull(getActivity()))
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                Log.d("Exception in orders ", e.getMessage());
            }
        };
    }


    private com.android.volley.Response.Listener<JSONArray> loginSuccessListenerMyOrders() {
        return response -> {
            try {

                JSONArray array = response;
                System.out.print(array.toString());
                ArrayList<String> orderNumbersList = new ArrayList<>();

                ArrayList<String> companyFullnamesList = new ArrayList<>();


                Log.d(TAG, "loginSuccessListenerMyOrders: "+array.length());

                for (int i = 0; i < array.length(); i++) {

                    Log.d(TAG, "loginSuccessListenerMyOrders: 2");

                    JSONObject responses = array.getJSONObject(i);
                    // Log.d(TAG, "loginSuccessListenerMyOrders: "+array.getJSONArray(i));


                    //String secType = responses.getString("security_type");



                    String counter = responses.getString("company");


                    orderNumbersList.add(responses.getString("orderNo"));
                    companyFullnamesList.add(responses.getString("company"));

                    String status = responses.getString("orderstatus");
                    String type = responses.getString("ordertype").equalsIgnoreCase("BUY") ? "Invest" : "De - Invest";
                    String currentPrice = responses.getString("baseprice");
                    String rawAskVolume = responses.getString("value");
                    //String rawBidVolume = responses.getString("bidvolume");

                    if (rawAskVolume.equals("")){
                        rawAskVolume="0";
                    }

                    if (status.equalsIgnoreCase("open")) {
                        status = "1";
                    }



                    double value = Double.parseDouble(rawAskVolume)* Double.parseDouble(currentPrice);
                    MyOrder myOrder = new MyOrder(type, status, rawAskVolume, currentPrice
                            , Constants.getThousandSep(Constants.roundToDecimalPlaceShare(Constants.convertToFloat(String.valueOf(value)))), "responses.getString"
                            , responses.getString("date"),responses.getString("orderNo"),counter,"");

                    myOrderList.add(myOrder);

                }

                watchListRecyclerView.setAdapter(new UnitOrdersAdapter(getActivity(), myOrderList, watchListRecyclerView));

            } catch (Exception e) {
                e.printStackTrace();
                Log.d(TAG, "loginSuccessListenerMyOrders: 5"+e.getMessage());
            }

        };
    }
}
