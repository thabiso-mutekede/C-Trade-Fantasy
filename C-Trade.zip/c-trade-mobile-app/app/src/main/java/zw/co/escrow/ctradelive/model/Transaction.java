package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Transaction implements Parcelable {

    private Long id;
    private String desc;
    private String type;
    private Float ammount;
    private String date;
    private String status;
    private String balance;

    public Transaction() {
    }

    protected Transaction(Parcel in) {
        if (in.readByte() == 0) {
            id = null;
        } else {
            id = in.readLong();
        }
        desc = in.readString();
        type = in.readString();
        if (in.readByte() == 0) {
            ammount = null;
        } else {
            ammount = in.readFloat();
        }
        date = in.readString();
        status = in.readString();
        balance = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (id == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeLong(id);
        }
        dest.writeString(desc);
        dest.writeString(type);
        if (ammount == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(ammount);
        }
        dest.writeString(date);
        dest.writeString(status);
        dest.writeString(balance);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Transaction> CREATOR = new Creator<Transaction>() {
        @Override
        public Transaction createFromParcel(Parcel in) {
            return new Transaction(in);
        }

        @Override
        public Transaction[] newArray(int size) {
            return new Transaction[size];
        }
    };

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Float getAmmount() {
        return ammount;
    }

    public void setAmmount(Float ammount) {
        this.ammount = ammount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", desc='" + desc + '\'' +
                ", type='" + type + '\'' +
                ", ammount=" + ammount +
                ", date='" + date + '\'' +
                ", status='" + status + '\'' +
                ", balance='" + balance + '\'' +
                '}';
    }
}
