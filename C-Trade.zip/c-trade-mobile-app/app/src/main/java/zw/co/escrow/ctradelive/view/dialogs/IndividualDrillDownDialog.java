package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.DrillDownAdapter;
import zw.co.escrow.ctradelive.model.DrillDown;


public class IndividualDrillDownDialog extends Dialog {
    private RecyclerView ddRv;
    private Toolbar toolbar;

    public IndividualDrillDownDialog(@NonNull Context context, List<DrillDown> drillDownList, String title) {
        super(context);
        setContentView(R.layout.drill_down_on_holdings_view);
        findViewById(R.id.drill_down_rv);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> dismiss());
        toolbar.setTitle(title);
        ddRv = findViewById(R.id.drill_down_rv);
        ddRv.setLayoutManager(new LinearLayoutManager(getContext()));
        ddRv.setHasFixedSize(true);

        DrillDownAdapter dd = new DrillDownAdapter(context,drillDownList);
        ddRv.setAdapter(dd);

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }
}
