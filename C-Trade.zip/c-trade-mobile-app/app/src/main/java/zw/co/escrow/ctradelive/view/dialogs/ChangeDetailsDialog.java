package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.android.material.textfield.TextInputEditText;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnProfileChanged;
import zw.co.escrow.ctradelive.model.Profile;

public class ChangeDetailsDialog extends Dialog implements View.OnClickListener {

    private OnProfileChanged onProfileChanged;
    private final Profile profile;
    private Toolbar toolbar;
    private CardView contact_cv,bank_cv;
    private TextInputEditText phone_et,address_et,email_et,bankname_et,accountnum_et,branch_et;
    public ChangeDetailsDialog(@NonNull Context context, @NonNull Profile profile) {
        super(context);
        setContentView(R.layout.dialog_change_account_details);
        this.profile = profile;
        toolbar = findViewById(R.id.toolbar);
        phone_et = findViewById(R.id.phone_e_txt);
        address_et = findViewById(R.id.home_e_txt);
        email_et = findViewById(R.id.email_e_txt);
        bankname_et = findViewById(R.id.bank_name_e_txt);
        branch_et = findViewById(R.id.branch_e_txt);
        accountnum_et = findViewById(R.id.bank_number_e_txt);

        findViewById(R.id.btnPost).setOnClickListener(this);

        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());
        contact_cv = findViewById(R.id.contact_details_edit);
        bank_cv = findViewById(R.id.bank_details_edit);
        switch (profile.getType()){
            case 1:
                toolbar.setTitle("Edit Contact Details".toUpperCase());
                bank_cv.setVisibility(View.GONE);
                email_et.setText(profile.getEmail());
                phone_et.setText(profile.getMobile());
                address_et.setText(profile.getAddress());
                break;
            case 2:
                toolbar.setTitle("Edit Bank Details".toUpperCase());
                contact_cv.setVisibility(View.GONE);
                branch_et.setText(profile.getBranch());
                bankname_et.setText(profile.getBankName());
                accountnum_et.setText(profile.getBankAccountNumber());
                break;
        }

        Log.d("lloda",profile.toString());
        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    public void setOnProfileChanged(OnProfileChanged onProfileChanged) {
        this.onProfileChanged = onProfileChanged;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnPost:
                profile.setBankName(bankname_et.getText().toString());
                profile.setBankAccountNumber(accountnum_et.getText().toString());
                profile.setBranch(branch_et.getText().toString());
                onProfileChanged.submit(this,profile);
                break;
        }
    }
}
