package zw.co.escrow.ctradelive.view.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.PortfolioAdapter;
import zw.co.escrow.ctradelive.model.Portfolio;
import zw.co.escrow.ctradelive.model.PortfolioData;
import zw.co.escrow.ctradelive.model.WatchListData;

public class PortfolioCashTransFragment extends Fragment {

    private View view;
    private RecyclerView watchListRecyclerView;
    private List<WatchListData> watchListDataList;
    private static final String TAG = "PortfolioCashTransFragm";
    private  List<PortfolioData> portfolioDataList = new ArrayList<>();
    private ProgressDialog progressDialog;

    private String cdsNumber;
    private String type;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        watchListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        progressDialog = new ProgressDialog(getContext());

        //SharedPreferences sharedPreferences =getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        //cdsNumber = sharedPreferences.getString("cds_number", "");

        cdsNumber = getArguments().getString("cdsNumber");
        type = getArguments().getString("type");
        List<Portfolio> portfolioList = getArguments().getParcelableArrayList("portfolioList");

        PortfolioAdapter portfolioAdapter = new PortfolioAdapter(portfolioList);
        watchListRecyclerView.setAdapter(portfolioAdapter);
        progressDialog.dismiss();

        return view;
    }

}