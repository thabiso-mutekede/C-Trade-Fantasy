package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Statement implements Parcelable {
    private String cds_number;
    private String fullName;
    private String company;
    private String shares;
    private String mobile;

    public Statement() {
    }

    public String getCds_number() {
        return cds_number;
    }

    public void setCds_number(String cds_number) {
        this.cds_number = cds_number;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getShares() {
        return shares;
    }

    public void setShares(String shares) {
        this.shares = shares;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    protected Statement(Parcel in) {
        cds_number = in.readString();
        fullName = in.readString();
        company = in.readString();
        shares = in.readString();
        mobile = in.readString();
    }

    public static final Creator<Statement> CREATOR = new Creator<Statement>() {
        @Override
        public Statement createFromParcel(Parcel in) {
            return new Statement(in);
        }

        @Override
        public Statement[] newArray(int size) {
            return new Statement[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(cds_number);
        parcel.writeString(fullName);
        parcel.writeString(company);
        parcel.writeString(shares);
        parcel.writeString(mobile);
    }
}
