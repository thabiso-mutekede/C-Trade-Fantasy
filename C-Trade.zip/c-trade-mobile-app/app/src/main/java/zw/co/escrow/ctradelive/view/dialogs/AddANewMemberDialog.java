package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;


public class AddANewMemberDialog extends Dialog {

    private final String clubCDSNumber;
    private final String clubName;
    private RecyclerView recyclerView;
    private InvestmentClub.ClubServicesListener clubServicesListener;
    private Toolbar toolbar;
    private EditText searchText;
    private TextInputEditText name_txt,surname_txt,email_txt,mobile_txt;
    private TextInputLayout searchLayout;
    private RadioGroup investorTypeRadG;

    public AddANewMemberDialog(@NonNull Context context, ClubModel clubModel) {
        super(context);
        this.clubName = clubModel.getClubName();
        setContentView(R.layout.add_new_club_member_view);
        this.clubCDSNumber = clubModel.getClubCdsNumber();
        name_txt = findViewById(R.id.er_forename_txt);
        surname_txt = findViewById(R.id.surname);
        email_txt = findViewById(R.id.et_email_txt);
        mobile_txt = findViewById(R.id.et_mobile_txt);

        searchLayout = findViewById(R.id.search_layout);
        investorTypeRadG = findViewById(R.id.member_type_grp);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Add Investor");
        searchText = findViewById(R.id.search_text);
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());
        recyclerView = findViewById(R.id.ctrade_users_rv);
        clubServicesListener = new InvestmentClubService(context,recyclerView);

        findViewById(R.id.existing_m_add).setVisibility(View.GONE);

        investorTypeRadG.setOnCheckedChangeListener((group, checkedId) -> {
            if(checkedId == R.id.existing_rd){
                findViewById(R.id.existing_m_add).setVisibility(View.VISIBLE);
                findViewById(R.id.none_existing_m_add).setVisibility(View.GONE);
                searchText.requestFocus();
            }else {
                findViewById(R.id.existing_m_add).setVisibility(View.GONE);
                findViewById(R.id.none_existing_m_add).setVisibility(View.VISIBLE);
            }
        });

        searchLayout.setEndIconOnClickListener(v ->
                clubServicesListener.onLoadCTradeUsers(searchText.getText().toString(),clubCDSNumber,clubName));

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);


        findViewById(R.id.btnPost).setOnClickListener(v -> {
            if(name_txt.getText().toString().length() <= 0){
                name_txt.setError("Enter Forename");
                return;
            }
            if(surname_txt.getText().toString().length() <= 0){
                surname_txt.setError("Enter Surname");
                return;
            }
            if(email_txt.getText().toString().length() <= 0){
                email_txt.setError("Enter Email Address");
                return;
            }

            if(mobile_txt.getText().toString().length() <= 0){
                mobile_txt.setError("Enter Mobile Number");
                return;
            }

            clubServicesListener.onAddClubRequestsURC(clubCDSNumber, name_txt.getText().toString(), surname_txt.getText().toString(), email_txt.getText().toString(), mobile_txt.getText().toString(), "", clubName,clubModel);

            mobile_txt.setText("");
            surname_txt.setText("");
            name_txt.setText("");
            email_txt.setText("");
        });
    }
}
