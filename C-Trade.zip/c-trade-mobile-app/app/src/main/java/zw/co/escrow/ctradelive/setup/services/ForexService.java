package zw.co.escrow.ctradelive.setup.services;

//import android.app.AlertDialog;
//import android.app.Dialog;
//import android.app.ProgressDialog;
//import android.content.Context;
//import android.content.Intent;
//import android.util.Log;
//import android.widget.ArrayAdapter;
//import android.widget.Spinner;
//import android.widget.TextView;
//
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.android.volley.Request;
//import com.android.volley.toolbox.JsonArrayRequest;
//import com.android.volley.toolbox.StringRequest;
//import com.google.gson.Gson;
//import com.google.gson.JsonObject;
//
//import org.json.JSONObject;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import de.codecrafters.tableview.TableView;
//import okhttp3.MultipartBody;
//import okhttp3.RequestBody;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//import zw.co.escrow.ctradelive.ApiClubInterface;
//import zw.co.escrow.ctradelive.AppConfig;
//import zw.co.escrow.ctradelive.R;
//import zw.co.escrow.ctradelive.adapters.recycler_adapter.AuctionOrdersAdapter;
//import zw.co.escrow.ctradelive.adapters.recycler_adapter.AuctionPortfolioAdapter;
//import zw.co.escrow.ctradelive.adapters.recycler_adapter.CPayDocumentsUpload;
//import zw.co.escrow.ctradelive.model.FXOrders;
//import zw.co.escrow.ctradelive.model.FXPortfolio;
//import zw.co.escrow.ctradelive.setup.listeners.Forex;
//import zw.co.escrow.ctradelive.view.AuctionTradeView;
//
//
//public class ForexService implements Forex.ForexServicesListener {
//    public   int COLUMN_SIZE;
//    public static int ROW_SIZE = 59;
//    private final String ip  = AppConfig.getIp();
//    ApiClubInterface apinPhp = ApiClubsClientNPHP.getApiService();
//    ApiClubInterface clientIp = CtradeApiClient.getApiService();
//    private final ProgressDialog progressDialog;
//    private final Context context;
//    private List<String> headers;
//    private TableView m_iTableView;
//    private RecyclerView recyclerView;
//    public ForexService(Context context) {
//        this.context = context;
//        this.progressDialog = new ProgressDialog(this.context);
//        this.progressDialog.setCancelable(false);
//    }
//
//    public ForexService(Context context, RecyclerView recyclerView){
//        this.context = context;
//        this.progressDialog = new ProgressDialog(context);
//
//        this.recyclerView = recyclerView;
//        this.recyclerView.setHasFixedSize(true);
//        this.recyclerView.setLayoutManager(new LinearLayoutManager(context));
//
//    }
//    @Override
//    public void onAttachDocumentsCorp(RequestBody cdsNumber,MultipartBody.Part taxClearance, MultipartBody.Part c14) {
//        progressDialog.setMessage("Posting Documents ....");
//        progressDialog.show();
//        Call<JsonObject> api = apinPhp.attachDocumentsCorp(cdsNumber,taxClearance,c14);
//        api.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
//                try{
//                    Log.d("lloda",response.toString());
//                    //JSONObject j = new JSONObject(response.body());
//                    progressDialog.dismiss();
//                    showDialog(response.body().get("message").toString());
//                    //showDialog(j.getString("message"));
//                }catch (Exception e){
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//                    showDialog("Failed To Read Data.Please Try Again Later");
//                }
//            }
//            @Override
//            public void onFailure(Call<JsonObject> call, Throwable t) {
//                progressDialog.dismiss();
//                showDialog(t.toString());
//                t.printStackTrace();
//            }
//        });
//    }
//
//    @Override
//    public void onPostBid(RequestBody cds, RequestBody type, RequestBody amount, RequestBody purpose,
//                          RequestBody prefrate,
//                          RequestBody sector,
//                          RequestBody bpno,
//                          MultipartBody.Part invoices) {
//        progressDialog.setMessage("Posting Bid ....");
//        progressDialog.show();
//        Call<JsonObject> api = apinPhp.postForexBid(cds, type, amount, purpose, prefrate,bpno,sector,invoices);
//        api.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
//                try{
//                    Log.d("lloda",response.toString());
//                    //JSONObject j = new JSONObject(response.body());
//                    progressDialog.dismiss();
//                    showDialog(response.body().get("message").toString());
//                    //showDialog(j.getString("message"));
//                }catch (Exception e){
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//                    showDialog("Failed To Read Data.Please Try Again Later");
//                }
//            }
//            @Override
//            public void onFailure(Call<JsonObject> call, Throwable t) {
//                progressDialog.dismiss();
//                showDialog(t.toString());
//                t.printStackTrace();
//            }
//        });
//    }
//
//    @Override
//    public void checkRegDocumentsForCPay(String cdsnumber) {
//        Call<Integer> res = clientIp.checkCPayDocuments(cdsnumber);
//        res.enqueue(new Callback<Integer>() {
//            @Override
//            public void onResponse(Call<Integer> call, Response<Integer> response) {
//                try {
//                    int i = response.body();
//                    if(i==1)context.startActivity(new Intent(context,AuctionTradeView.class));
//                    else context.startActivity(
//                            new Intent(context, CPayDocumentsUpload.class)
//                                    .putExtra("cdsnumber",cdsnumber)
//                                    .putExtra("type",i));
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//            }
//            @Override
//            public void onFailure(Call<Integer> call, Throwable t) {
//                t.printStackTrace();
//            }
//        });
//    }
//
//    @Override
//    public void onGetBidPurpose(Spinner spBidSpinner) {
//        progressDialog.setMessage("Loading ...");
//        progressDialog.show();
//        String url = ip.concat("/getForexBidPurpose");
//        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url,
//                response -> {
//            try{
//                List<String> purposes = new ArrayList<>();
//                for(int i = 0;i<response.length();i++){
//                    purposes.add(response.getJSONObject(i).getString("name"));
//                }
//                ArrayAdapter<String> adapterCompaniesSearchable =
//                        new ArrayAdapter<>(context,
//                                R.layout.spinner_item, purposes);
//                spBidSpinner.setAdapter(adapterCompaniesSearchable);
//                progressDialog.dismiss();
//            }catch (Exception e){
//                progressDialog.dismiss();
//                e.printStackTrace();
//                showDialog("Failed To Read.");
//            }
//        },error ->
//        {
//            progressDialog.dismiss();
//            error.printStackTrace();
//            showDialog("Connection Error Please Try Again");
//        });
//
//        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
//    }
//    @Override
//    public void onGetBidOrders(String cdsnumber) {
//        Call<List<FXOrders>> fxOrdersCall = clientIp.getMyForexOrders(cdsnumber);
//        fxOrdersCall.enqueue(new Callback<List<FXOrders>>() {
//            @Override
//            public void onResponse(Call<List<FXOrders>> call, Response<List<FXOrders>> response) {
//                AuctionOrdersAdapter auctionPortfolioAdapter = new AuctionOrdersAdapter(context,response.body(),recyclerView);
//                recyclerView.setAdapter(auctionPortfolioAdapter);
//            }
//            @Override
//            public void onFailure(Call<List<FXOrders>> call, Throwable t) {
//                t.printStackTrace();
//            }
//        });
//    }
//
//    @Override
//    public void onGetBidOrdersHistory(String cdsnumber) {
//        Call<List<FXOrders>> fxOrdersCall = clientIp.getMyForexOrdersHistory(cdsnumber);
//        fxOrdersCall.enqueue(new Callback<List<FXOrders>>() {
//            @Override
//            public void onResponse(Call<List<FXOrders>> call, Response<List<FXOrders>> response) {
//                AuctionOrdersAdapter auctionPortfolioAdapter = new AuctionOrdersAdapter(context,response.body(),recyclerView);
//                recyclerView.setAdapter(auctionPortfolioAdapter);
//            }
//            @Override
//            public void onFailure(Call<List<FXOrders>> call, Throwable t) {
//                t.printStackTrace();
//            }
//        });
//    }
//
//    @Override
//    public void onGetForexBalances(String cdsnumber, TextView txt1, TextView txt2, TextView txt3, TextView txt4) {
//        Call<JsonObject> call = apinPhp.getCpayBalances(cdsnumber);
//        call.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
//                try{
//                    Log.d("lloda",response.body().toString());
//                    JSONObject j = new JSONObject(new Gson().toJson(response.body()));
//                    txt2.setText(j.getString("cleared"));
//                    txt1.setText(j.getString("uncleared"));
//                    txt3.setText(j.getString("balance"));
//                    txt4.setText(j.getString("forex"));
//                }catch (Exception e){
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//                    showDialog("Failed To Read Data.Please Try Again Later");
//                }
//            }
//            @Override
//            public void onFailure(Call<JsonObject> call, Throwable t) {
//            }
//        });
//    }
//    @Override
//    public void onGetMyStatement(String cdsnumber) {
//        String url = ip + "getMyForexStatement?cdsnumber="+cdsnumber;//"allClubMembers?cdsNumber="+cdsnumber;
//        StringRequest clubJson = new StringRequest(Request.Method.POST, url,
//                response ->
//                {
//                    try{
//                    }catch (Exception e){
//                        showDialog(e.getMessage());
//                    }
//                },
//                error ->
//                {
//                    progressDialog.dismiss();
//                    showDialog(error.getMessage());
//
//                });
//        AppConfig.getInstance().addToRequestQueue(clubJson);
//    }
//    @Override
//    public void onPostWithdrawCash(String cdsnumber, String amount, Dialog dialog) {
//        dialog.dismiss();
//        String url = "https://demo.ctrade.co.zw/ctrade_v4/online.ctrade_php/cpaywalletwithdraw.php?cdsnumber="+cdsnumber+"&amount="+amount;
//        Log.d("lloda",url);
//        StringRequest stringRequest = new StringRequest(url,
//                response -> {
//            try{
//                JSONObject j = new JSONObject(response);
//                showDialog(j.getString("message"));
//            }catch (Exception e){
//                e.printStackTrace();
//                showDialog("An Error Occurred While Processing Your Request");
//            }
//
//        },error -> {
//            error.printStackTrace();
//            showDialog("An Error Occurred While Processing Your Request");
//        });
//
//        AppConfig.getInstance().addToRequestQueue(stringRequest);
//    }
//    @Override
//    public void onLoadPortfolio(String cdsnumber){
//        Call<List<FXPortfolio>> fxPortfolioCall = clientIp.getMyForeportfolio(cdsnumber);
//        fxPortfolioCall.enqueue(new Callback<List<FXPortfolio>>() {
//            @Override
//            public void onResponse(Call<List<FXPortfolio>> call, Response<List<FXPortfolio>> response) {
//                AuctionPortfolioAdapter auctionPortfolioAdapter = new AuctionPortfolioAdapter(context,response.body(),recyclerView);
//                recyclerView.setAdapter(auctionPortfolioAdapter);
//            }
//            @Override
//            public void onFailure(Call<List<FXPortfolio>> call, Throwable t) {
//                t.printStackTrace();
//            }
//        });
//    }
//
//    private void showDialog(String message){
//        new AlertDialog.Builder(context)
//                .setMessage(message)
//                .setPositiveButton("ok",null)
//                .create()
//                .show();
//    }
//    private void reloadableDialog(){
//
//    }
//}
