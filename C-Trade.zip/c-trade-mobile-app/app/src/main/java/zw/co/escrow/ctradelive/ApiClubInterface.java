package zw.co.escrow.ctradelive;
/*
import com.google.gson.JsonObject;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import zw.co.escrow.ctradelive.model.CPAYTransaction;
import zw.co.escrow.ctradelive.model.CTradeLimits;
import zw.co.escrow.ctradelive.model.Certificate;
import zw.co.escrow.ctradelive.model.ClubList;
import zw.co.escrow.ctradelive.model.ContributionStatement;
import zw.co.escrow.ctradelive.model.FXOrders;
import zw.co.escrow.ctradelive.model.FXPortfolio;
import zw.co.escrow.ctradelive.model.FileResponse;
import zw.co.escrow.ctradelive.model.Forex;
import zw.co.escrow.ctradelive.model.FundlistObject;
import zw.co.escrow.ctradelive.model.HighLow;
import zw.co.escrow.ctradelive.model.IPO;
import zw.co.escrow.ctradelive.model.Investment;
import zw.co.escrow.ctradelive.model.KYCResponse;
import zw.co.escrow.ctradelive.model.MarketWatchETF;
import zw.co.escrow.ctradelive.model.MarketWatchFINSEC;
import zw.co.escrow.ctradelive.model.MarketWatchZSE;
import zw.co.escrow.ctradelive.model.MyClubsAsMember;
import zw.co.escrow.ctradelive.model.Portfolio;
import zw.co.escrow.ctradelive.model.PredetailsObject;
import zw.co.escrow.ctradelive.model.ShareList;
import zw.co.escrow.ctradelive.model.Statement;
import zw.co.escrow.ctradelive.model.Transaction;
import zw.co.escrow.ctradelive.model.User;
import zw.co.escrow.ctradelive.model.VersionProperty;


public interface ApiClubInterface {


    @GET("ClublistMember")
    Call<List<User>> getAllDetails(@Query("cdsno") String cdsno);

    @GET("ClublistMember")
    Call<MyClubsAsMember> getMyMemberClubs(@Query("cdsno") String cdsno);

    @GET("Clublist")
    Call<ClubList> getMyClub(@Query("cdsno") String cdsno);

    @GET("ClublistById")
    Call<ClubList> ClublistById(@Query("id") String id);

    @GET("CreateClubID")
    Call<String> CreateClubID(@Query("chairmain") String chairmain,
                              @Query("clubnumber") int clubnumber,
                              @Query("clubname") String clubname,
                              @Query("clubphone") String clubphone,
                              @Query("phone") String phone);



    @GET("ClubMemberAdd")
    Call<ResponseBody> ClubMemberAdd(@Query("clubphone") String clubphone,
                                     @Query("clubcds") String clubcds,
                                     @Query("phone") String phone,
                                     @Query("email") String email,
                                     @Query("surname") String surname,
                                     @Query("firstname") String firstname,
                                     @Query("club_id") String club_id);

    @GET("WidthdrawForex")
    Call<ResponseBody> postConvert(@Query("cdsnumber") String cds_no, @Query("ammount") String amount);

    @GET("androidversion")
    Call<List<VersionProperty>> getAppVersion();

    @GET("getCashBalanceForex")
    Call<List<Forex>> getCashBalanceForex(@Query("cdsnumber") String cds_no);

    @GET("ctradelimits")
    Call<List<CTradeLimits>> getAppLimits();

    @GET("Equiry")
    Call<ResponseBody> getSendEnquery(@Query("cdsnumber") String cds_no);

    @GET("cdcmast")
    Call<List<ShareList>> getMyShareTrans(@Query("cdsnumber") String cds_number);

    @GET("Certificates")
    Call<List<Certificate>> getMyCertificates(@Query("cdsnumber") String cds_number);

    @GET("FinsecSharess")
    Call<List<Certificate>> getMyFinsecSharess(@Query("cdsnumber") String cds_number);

    @GET("PreshareHolder")
    Call<PredetailsObject> PreshareHolder(@Query("cdsnumber") String cds_no);

    @GET("CheckAttachments")
    Call<String> verify_kyc(@Query("cdsnumber") String cds_no);


    @Multipart
    @POST("upfile.php")
    Call<FileResponse> uploadFile(@Part MultipartBody.Part file, @Part("type") RequestBody type, @Part("CDSNumber") RequestBody CDSNumber);

    @Multipart
    @POST("uploadernew-formobile.php")
    Call<String> uploadCorpFiles(@Part MultipartBody.Part board,
                                 @Part MultipartBody.Part corp,
                                 @Part MultipartBody.Part tax,
                                 @Part("email") RequestBody email,
                                 @Part("type") RequestBody type, @Part("CDSNumber") RequestBody CDSNumber);
    @GET("OrderPostingMakeNewMe")
    Call<ResponseBody> OrderPostingMakeNew(@Query("company") String company,
                                           @Query("security")  String security,
                                           @Query("tif") String tif,
                                           @Query("orderTrans") String orderTrans,
                                           @Query("orderType") String orderType,
                                           @Query("quantity")String quantity,
                                           @Query("price") String price,
                                           @Query("cdsNumber") String cdsNumber,
                                           @Query("broker") String broker,
                                           @Query("amountValue") String amountValue,
                                           @Query("source") String source,
                                           @Query("date_")String date,
                                           @Query("reason")String roi,
                                           @Query("source_name")String soi);
    @Multipart
    @POST("reg_upload.php")
    Call<String> uploadOnRegistrationCorp(@Part MultipartBody.Part board,
                                          @Part MultipartBody.Part corp,
                                          @Part MultipartBody.Part tax,
                                          @Part("type") RequestBody type,
                                          @Part("email") RequestBody email);
    @Multipart
    @POST("reg_upload.php")
    Call<String> uploadOnRegistrationIndividual(@Part MultipartBody.Part profile,
                                                @Part MultipartBody.Part nationalId,
                                                @Part("type") RequestBody type,
                                                @Part("email") RequestBody email);

    @Multipart
    @POST("upfile.php")
    Call<KYCResponse> saveToDB(@Part("CDSNumber") RequestBody CDSNumber, @Part MultipartBody.Part file, @Part MultipartBody.Part file1, @Part MultipartBody.Part file2);

    @GET("update_kyc.php")
    Call<ResponseBody> updateKYC(@Query("cdsnumber") String cds_number);

    @GET("addClubRequests")
    Call<JsonObject> addClubRequests(@Query("gcdsnum") String gcdsnum,
                                     @Query("mcdsnum") String mcdsnum,
                                     @Query("gphone") String gphone,
                                     @Query("gname") String gname,
                                     @Query("type") String type,
                                     @Query("reqBy") String reqBy,
                                     @Query("mphone") String mphone);

    @GET("acceptTermsAndCs")
    Call<JsonObject> acceptTerms(@Query("cdsnumber") String cdsnumber);

    //(string gcdsnumber,string fname, string sname, string email, string phone, string clubphone,string clubname,string chcdsnumber)
    @GET("addClubRequestsURC")
    Call<JsonObject> addClubRequestsURC(@Query("gcdsnumber") String gcdsnumber, @Query("fname") String fname, @Query("sname") String sname, @Query("email") String email, @Query("phone") String phone, @Query("clubphone") String clubphone, @Query("clubname") String clubname, @Query("chcdsnumber") String chcdsnumber);

    @GET("checkTermsAndConditionsClubs")
    Call<JsonObject> checkTerms(@Query("cdsnumber") String cdsnumber);
    @GET("exitInvestmentClub")
    Call<JsonObject> exitInvestmentClub(@Query("gcdsnumber") String gcdsnumber, @Query("mcdsnumber") String cdsnumber);

    //(string club_cdsnumber,string ex_chairman_cds_number,string chairman_cds_number)
    @GET("chairmanHandover")
    Call<JsonObject> handoverChairman(@Query("club_cdsnumber") String gcdsnumber,
                                      @Query("ex_chairman_cds_number") String xcdsnumber,
                                      @Query("chairman_cds_number") String cdsnumber);



    @GET("WidthdrawToClub")
    Call<ResponseBody> postDepositToGroup(@Query("cdsnumber") String cds_no, @Query("groupcdsnumber") String groupcdsnumber, @Query("ammount") String amount);


    @GET("moveCashFromClub")
    Call<ResponseBody> withdrawFromGroup(@Query("cdsnumber") String cds_no, @Query("groupcdsnumber") String groupcdsnumber, @Query("ammount") String amount);

    @GET("acceptRequests")
    Call<JsonObject> acceptRequests(@Query("gcdsnum") String gcdsnum,
                                    @Query("mcdsnum") String mcdsnum,
                                    @Query("gphone") String gphone,
                                    @Query("mphone") String mphone,
                                    @Query("confirm") String confirm,
                                    @Query("gname") String gname
            , @Query("spercial") String spercial, @Query("email") String email);

    @GET("getIPOISSUES")
    Call<List<IPO>> getIPOISSUES();

    @GET("CashTransWithBalance")
    Call<List<Transaction>> getTransactions(@Query("cdsnumber") String cdsnumber);
    @GET("getMyForeportfolio")
    Call<List<FXPortfolio>> getMyForeportfolio(@Query("cdsNumber") String cdsnumber);

    //portfoliobytype?cdsNumber=180625032933-0001/24642288&type=equity
    @GET("portfoliobytype")
    Call<List<Portfolio>> getPortfolioListForMain(@Query("cdsNumber") String cdsnumber,@Query("type") String type);
    @GET("getMyForexStatement")
    Call<List<CPAYTransaction>> getMyForexStatement(@Query("cdsnumber") String cdsnumber);
    @GET("getClubContributionList")
    Call<List<ContributionStatement>> getClubContributionList(@Query("gcdsnumber") String gcdsnumber,@Query("gcdsnumber") String mcdsnumber);




    @GET("LoadFunds")
    Call<FundlistObject> LoadFunds(@Query("isin") String isin);
    @GET("createANewInvestmentClub")
    Call<JsonObject>
    createANewInvestmentClub(@Query("creatorCds") String creatorCds,
                             @Query("creatorPhone") String creatorPhone,
                             @Query("cname") String cname,
                             @Query("cwelcomeMessagwe") String cwelcomeMessagwe,
                             @Query("isPublic") String isPublic,
                             @Query("creatorEmail") String creatorEmail);

    @GET("cpaywalletbalances.php")
    Call<JsonObject>getCpayBalances(@Query("cdsnumber") String cdsnum);
    @GET("getMyForexOrders")
    Call<List<FXOrders>> getMyForexOrders(@Query("cdsNumber") String cdsnumber);

    @GET("getMyForexOrdersHistory")
    Call<List<FXOrders>> getMyForexOrdersHistory(@Query("cdsNumber") String cdsnumber);

    @GET("getClubInvestments")
    Call<List<Investment>> getClubInvestments(@Query("gcdsnumber") String gcdsnumber,@Query("mcdsnumber") String mcdsnumber);

    @GET("checkRegDocumentsForCpay")
    Call<Integer> checkCPayDocuments(@Query("cdsnumber") String cdsnumber);

    @GET("UpdateCancelOrder")
    Call<ResponseBody> cancelOrder(@Query("cdsnumber") String cdsnumber,@Query("ordernumber") String orderNumber,@Query("orderType") String orderType);

    @Multipart
    @POST("post_forex_invoice.php")
    Call<JsonObject> postForexBid(@Part("cdsnumber") RequestBody cds,
                                  @Part("ordertype") RequestBody type,
                                  @Part("amount") RequestBody amount,
                                  @Part("purpose") RequestBody purpose,
                                  @Part("prefrate") RequestBody prefrate,
                                  @Part("BpNo") RequestBody bpno,
                                  @Part("sector") RequestBody sector,
                                  @Part MultipartBody.Part invoices);

    @GET("Holdings")
    Call<List<Statement>>clubStatement(@Query("groupid") String cdsnumber,
                                            @Query("company") String amount);


    @Multipart
    @POST("cpay_reg_documents_upload.php")
    Call<JsonObject> attachDocumentsCorp(@Part("cdsnumber") RequestBody cds,@Part MultipartBody.Part taxClearance,
                                         @Part MultipartBody.Part c14);


    @Multipart
    @POST("create_account")
    Call<JsonObject> createCTradeAccount(@Part("registration") RequestBody user,@Part MultipartBody.Part image_1,
                                         @Part MultipartBody.Part image_2);

    @GET("getImage")
    Call<ResponseBody> getPro(@Query("cdsNumber") String cdsNumber,@Query("type") String type);

    @Multipart
    @POST("c_trade_registration_documents_upload.php")
    Call<JsonObject> attachDocumentsCorporate(@Part("cdsnumber") RequestBody cds,@Part("type") RequestBody type,@Part MultipartBody.Part taxClearance,
                                         @Part MultipartBody.Part corporateId);

    @Multipart
    @POST("c_trade_registration_documents_upload.php")
    Call<JsonObject> attachDocumentsIndividual(@Part("cdsnumber") RequestBody cds,@Part("type") RequestBody type,@Part MultipartBody.Part profile,
                                         @Part MultipartBody.Part nationalId);

    @POST("marketwatchzsenew")
    Call<List<MarketWatchZSE>> getMarketWatchZSE();

    @POST("etfmarketwatch")
    Call<List<MarketWatchETF>> getMarketWatchETF();

    @POST("MarketWatchbidoffer")
    Call<List<MarketWatchFINSEC>> getMarketWatchFINSEC();
    @POST("getHighLow")
    Call<List<HighLow>> getHighLow(@Query("company") String company,@Query("period") int period);
}
*/