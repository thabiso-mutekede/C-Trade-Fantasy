package zw.co.escrow.ctradelive.model;

import java.util.List;


public class ClubList {

    List<InvestmentClub> clublist;

    public List<InvestmentClub> getClublist() {
        return clublist;
    }

    public void setClublist(List<InvestmentClub> clublist) {
        this.clublist = clublist;
    }
}
