package zw.co.escrow.ctradelive.view.fragments.individual_create_account;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.textfield.TextInputLayout;
import com.redmadrobot.inputmask.MaskedTextChangedListener;
import com.redmadrobot.inputmask.helper.AffinityCalculationStrategy;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class PersonalDetailsFragment extends Fragment implements View.OnClickListener {

    private static final String ARG_SECTION_NUMBER = "DETAILS";
    private DatePickerDialog fromDatePickerDialog;
    private LoginViewModel loginViewModel;
    private Utils utils;
    private Date real_date;
    private TextView dobTXT;
    private RegistrationData registrationData;
    private SimpleDateFormat dateFormatter,dateValidatorFormatter;
    private TextInputLayout outlinedTextFieldMR, outlinedTextFieldGender, outlinedTextFieldSurname, outlinedTextFieldName, outlinedTextFieldIDNumber
    ,outlinedTextFieldPhone, outlinedTextFieldAddress, outlinedTextFieldNationality;

    public static PersonalDetailsFragment newInstance(RegistrationData registrationData) {

        PersonalDetailsFragment fragment = new PersonalDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER,registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;

        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_personal_details, container, false);


        initWidgets(root);
        setDateTimeField();
        utils = new Utils(getActivity());

        dobTXT = root.findViewById(R.id.date_of_birth_e_txt);

        dateFormatter = new SimpleDateFormat("dd MMM yyyy", Locale.US);
        dateValidatorFormatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        String[] items = new String[] {"Mr", "Mrs", "Ms", "Miss"};
        String[] gender = new String[] {"Female", "Male", "Other"};

        utils.setDropdownBoxes(items, R.id.mr_dropdown_items, root);
        utils.setDropdownBoxes(gender, R.id.gender_dropdown_items, root);
        Map<String, String> detailsMap = new HashMap<>();


        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }

        final List<String> affineFormats = new ArrayList<>();
        affineFormats.add("[00]-[00000999]-[A]-[00]");
        MaskedTextChangedListener.Companion.installOn(
                outlinedTextFieldIDNumber.getEditText(),
                "[00]-[00000999]-[A]-[00]",
                affineFormats,
                AffinityCalculationStrategy.WHOLE_STRING,
                (maskFilled, extractedValue, formattedText) ->
                        logValueListener(maskFilled, extractedValue, formattedText)
        );

        if(registrationData.getRegistrationSession().isDetailsDone())setUpFields();
        root.findViewById(R.id.btnNext).setOnClickListener(v->{

            String male_or_female = outlinedTextFieldMR.getEditText().getText().toString()
                    ,genderType = outlinedTextFieldGender.getEditText().getText().toString()
                    ,surname = outlinedTextFieldSurname.getEditText().getText().toString()
                    ,name = outlinedTextFieldName.getEditText().getText().toString()
                    ,id_number = outlinedTextFieldIDNumber.getEditText().getText().toString()
                    ,dob = dateValidatorFormatter.format(real_date)
                    ,phone = outlinedTextFieldPhone.getEditText().getText().toString()
                    ,address = outlinedTextFieldAddress.getEditText().getText().toString()
                    ,nationality = outlinedTextFieldNationality.getEditText().getText().toString();


            if (male_or_female.equals("")) {
                outlinedTextFieldMR.setError("Select");
            }
            else if (genderType.equals("")) {
                outlinedTextFieldGender.setError("Please select gender");

            }
            else if (surname.equals("")) {
                outlinedTextFieldSurname.setError("Please enter your surname");

            }
            else if (name.equals("")){
                outlinedTextFieldName.setError("Please enter your name");

            }
            else if (id_number.equals("")){
                outlinedTextFieldIDNumber.setError("Please enter your id number");

            }
            else if (dob.equals("")){

            }
            else if (phone.equals("")){
                outlinedTextFieldPhone.setError("Please enter phone number");

            }
            else if (address.equals("")){
                outlinedTextFieldAddress.setError("Please enter your address");

            }
            else if (nationality.equals("")){
                outlinedTextFieldAddress.setError("Please select nationality");

            }
            else {
                registrationData.getDetails().setTitle(male_or_female);
                registrationData.getDetails().setGender(genderType);
                registrationData.getDetails().setSurname(surname);
                registrationData.getDetails().setForenames(name);
                registrationData.getDetails().setIdnoPP(id_number);
                registrationData.getDetails().setDob(dob);
                registrationData.getDetails().setMobile(phone);
                registrationData.getDetails().setAdd1(address);
                registrationData.getDetails().setNationality(nationality);

                utils.startNewFragment(root, PersonalDetailsFragment.this, CustodianDetailsFragment.newInstance(registrationData) );

            }


        });






        return root;
    }

    private void logValueListener(boolean maskFilled, @NonNull String extractedValue, @NonNull String formattedText) {
        final String className = "lloda";
        Log.d(className, extractedValue);
        Log.d(className, String.valueOf(maskFilled));
        Log.d(className, formattedText);
    }

    private void setUpFields() {
        outlinedTextFieldMR.getEditText().setText(registrationData.getDetails().getTitle());
        outlinedTextFieldGender.getEditText().setText(registrationData.getDetails().getGender());
        outlinedTextFieldSurname.getEditText().setText(registrationData.getDetails().getSurname());
        outlinedTextFieldName.getEditText().setText(registrationData.getDetails().getForenames());
        outlinedTextFieldIDNumber.getEditText().setText(registrationData.getDetails().getIdnoPP());
        //outlinedTextFieldDOB=view.findViewById(R.id.outlinedTextFieldDOB);
        outlinedTextFieldPhone.getEditText().setText(registrationData.getDetails().getMobile());
        outlinedTextFieldAddress.getEditText().setText(registrationData.getDetails().getAdd1());
        outlinedTextFieldNationality.getEditText().setText(registrationData.getDetails().getNationality());
        dobTXT.setText(registrationData.getDetails().getDob());
    }

    private void initWidgets(View view){
        outlinedTextFieldMR=view.findViewById(R.id.outlinedTextFieldMR);
        outlinedTextFieldGender=view.findViewById(R.id.outlinedTextFieldGender);
        outlinedTextFieldSurname=view.findViewById(R.id.outlinedTextFieldSurname);
        outlinedTextFieldName=view.findViewById(R.id.outlinedTextFieldName);
        outlinedTextFieldIDNumber=view.findViewById(R.id.outlinedTextFieldIDNumber);
        //outlinedTextFieldDOB=view.findViewById(R.id.outlinedTextFieldDOB);
        outlinedTextFieldPhone=view.findViewById(R.id.outlinedTextFieldPhone);
        outlinedTextFieldAddress=view.findViewById(R.id.outlinedTextFieldAddress);
        outlinedTextFieldNationality=view.findViewById(R.id.outlinedTextFieldNationality);

        view.findViewById(R.id.date_of_birth_e_txt).setOnClickListener(this);

    }

    @SuppressLint("ResourceAsColor")
    private void setDateTimeField() {
        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(getContext(),
                (view, year, monthOfYear, dayOfMonth) -> {
                    Calendar newDate = Calendar.getInstance();
                    newDate.set(year, monthOfYear, dayOfMonth);
                    dobTXT.setText(dateFormatter.format(newDate.getTime()));
                    real_date = newDate.getTime();
                }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH),
                newCalendar.get(Calendar.DAY_OF_MONTH));



    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.date_of_birth_e_txt){
            Log.d("lloda","posted _ ");
            fromDatePickerDialog.show();
            fromDatePickerDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.WHITE);
            fromDatePickerDialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(Color.WHITE);
            fromDatePickerDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.WHITE);
        }
    }
}