package zw.co.escrow.ctradelive.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.OpenSellOrdersAdapter;
import zw.co.escrow.ctradelive.listeners.OnPlaceOrder;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.OpenSellOrder;
import zw.co.escrow.ctradelive.model.OrderDetails;
import zw.co.escrow.ctradelive.model.WatchListData;
import zw.co.escrow.ctradelive.view.dialogs.TradeClubPreloadedDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradeDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradePreloadedDialog;

public class OpenSellOrdersFragment extends Fragment implements OnPlaceOrder {

    private View view;
    private RecyclerView watchListRecyclerView;
    private List<WatchListData> watchListDataList;
    private static final String TAG = "OpenSellOrdersFragment";
    private  List<OpenSellOrder> openSellOrders = new ArrayList<>();
    private String mobileip, felloverip1, felloverip2, ip, cds_number;
    private AppConfig appConfig;
    private OpenSellOrder openSellOrder;
    private Boolean isClub;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        watchListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

/*
        MarketWatchFINSECAsync marketWatchFINSECAsync = new MarketWatchFINSECAsync(getActivity() ,new DataRepository());
        marketWatchFINSECAsync.execute();

        ViewModelProvider viewModelProvider = new ViewModelProvider(getActivity());
        AppViewModel appViewModel = viewModelProvider.get(AppViewModel.class);

        //Observe date from https://demo.ctrade.co.zw/mobileapi/MarketWatchZSE and render on UI

        appViewModel.getMarketWatchFINSEC().observe(requireActivity(), marketWatchFINSECS -> {

            MarketWatchFINSECAdapter marketWatchFINSECAdapter = new MarketWatchFINSECAdapter(getActivity(), marketWatchFINSECS);
            watchListRecyclerView.setAdapter(marketWatchFINSECAdapter);

        });*/






        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        appConfig = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();
        SharedPreferences prfs = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cds_number = getArguments().getString("cdsnumber");
        isClub = getArguments().getBoolean("isClub");

        final String zse_url = "https://" + ip + "/marketwatchzsenewbuys";
        StringRequest zseJsonRequest = new StringRequest(Request.Method.POST, zse_url,
                loginSuccessListenerZSE(),
                loginErrorListenerZSE()) {
        };

        zseJsonRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(zseJsonRequest);


    }



    private com.android.volley.Response.Listener<String> loginSuccessListenerZSE() {
        return response -> {
            try {
                //progressDialog.dismiss();
                //Todo remove progress
                JSONArray array = new JSONArray(response);
                System.out.print(array.toString());


                for (int i = 0; i < array.length(); i++) {

                    JSONObject responses = array.getJSONObject(i);

                    String ticker = responses.getString("Ticker");
                    Log.d(TAG, "ticker: "+ticker);

                    String isin = responses.getString("ISIN");
                    Log.d(TAG, "isin: "+isin);

                    String fullCompanyName = responses.getString("FullCompanyName");
                    Log.d(TAG, "fullCompanyName: "+fullCompanyName);

                    String option = "[SELL]";
                    Log.d(TAG, "option: "+option);


                    String bestAsk = responses.getString("Best_Ask");
                    Log.d(TAG, "bestBid: "+bestAsk);

                    String askVolume = responses.getString("Ask_Volume");
                    Log.d(TAG, "bestBid: "+askVolume);



                    String currentPrice = responses.getString("Current_price");
                    Log.d(TAG, "currentPrice: "+currentPrice);

                    String more = "More";
                    Log.d(TAG, "more: "+more);

                    openSellOrder = new OpenSellOrder(fullCompanyName, ticker, isin, bestAsk, currentPrice, askVolume, option);
                    openSellOrders.add(openSellOrder);

                }

                ///String type = getArguments().getString("type");
                //boolean isMain = type.equalsIgnoreCase("main")?true:false;
                OpenSellOrdersAdapter openSellOrdersAdapter = new OpenSellOrdersAdapter(getActivity(), openSellOrders);
                openSellOrdersAdapter.setOnPlaceOrder(this);
                watchListRecyclerView.setAdapter(openSellOrdersAdapter);



            } catch (Exception e) {
                e.printStackTrace();
            }

        };
    }

    private com.android.volley.Response.ErrorListener loginErrorListenerZSE() {
        return error -> {

            try {
                error.printStackTrace();
                //progressDialog.dismiss();
                //Todo remove progress
                new AlertDialog.Builder(Objects.requireNonNull(getActivity()))
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
                e.printStackTrace();
            }

        };
    }


    @Override
    public void showDialog(OrderDetails orderDetails) {

        if(isClub){
            ClubModel clubModel = getArguments().getParcelable("club");
            TradeClubPreloadedDialog dialogBuy = TradeClubPreloadedDialog.newInstance("BUY",clubModel,orderDetails);
            FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
            dialogBuy.show(ftBuy, TradeDialog.TAG);
        }else
        {
            TradePreloadedDialog dialogBuy = TradePreloadedDialog.newInstance("BUY",cds_number,orderDetails);
            FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
            dialogBuy.show(ftBuy, TradeDialog.TAG);
        }
    }
}