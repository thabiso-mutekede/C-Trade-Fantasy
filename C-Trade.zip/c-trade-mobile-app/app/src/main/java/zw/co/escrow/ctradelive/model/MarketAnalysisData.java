package zw.co.escrow.ctradelive.model;

public class MarketAnalysisData {
    
    private String indexpercentage;
    private String SecurityType;
    private String DateCapture;
    private String MarkertCapZWL;
    private String MarkertCapUSD;
    private String MarkertPercentageIncr_DecreZWL;
    private String MarkertPercentageIncr_DecreUSD;
    private String TurnOverPercentageIncrease_DecrZWL;
    private String TurnOverPercentageIncrease_DecrUSD;
    private String Index;
    private String VolumeTrade;
    private String SecuritySubType;
    private String OMIR;
    private String BlackMarketZWL;
    private String BlackMarketRTGS;
    private String BlackMarketBond;
    private String PriceUSD;
    private String PriceZWL;
    private String Rate;
    private String OMIRPercentage;
    private String blackmarkertBondPercentage;
    private String blackmarkertRTSPercentage;
    private String blackmarkertZWLPercentage;
    private String turnoverZWL;
    private String turnoverUSD;

    public String getTurnoverZWL() {
        return turnoverZWL;
    }

    public void setTurnoverZWL(String turnoverZWL) {
        this.turnoverZWL = turnoverZWL;
    }

    public String getTurnoverUSD() {
        return turnoverUSD;
    }

    public void setTurnoverUSD(String turnoverUSD) {
        this.turnoverUSD = turnoverUSD;
    }

    public String getIndexpercentage() {
        return indexpercentage;
    }

    public void setIndexpercentage(String indexpercentage) {
        this.indexpercentage = indexpercentage;
    }

    public String getSecurityType() {
        return SecurityType;
    }

    public void setSecurityType(String securityType) {
        SecurityType = securityType;
    }

    public String getDateCapture() {
        return DateCapture;
    }

    public void setDateCapture(String dateCapture) {
        DateCapture = dateCapture;
    }

    public String getMarkertCapZWL() {
        return MarkertCapZWL;
    }

    public void setMarkertCapZWL(String markertCapZWL) {
        MarkertCapZWL = markertCapZWL;
    }

    public String getMarkertCapUSD() {
        return MarkertCapUSD;
    }

    public void setMarkertCapUSD(String markertCapUSD) {
        MarkertCapUSD = markertCapUSD;
    }

    public String getMarkertPercentageIncr_DecreZWL() {
        return MarkertPercentageIncr_DecreZWL;
    }

    public void setMarkertPercentageIncr_DecreZWL(String markertPercentageIncr_DecreZWL) {
        MarkertPercentageIncr_DecreZWL = markertPercentageIncr_DecreZWL;
    }

    public String getMarkertPercentageIncr_DecreUSD() {
        return MarkertPercentageIncr_DecreUSD;
    }

    public void setMarkertPercentageIncr_DecreUSD(String markertPercentageIncr_DecreUSD) {
        MarkertPercentageIncr_DecreUSD = markertPercentageIncr_DecreUSD;
    }

    public String getTurnOverPercentageIncrease_DecrZWL() {
        return TurnOverPercentageIncrease_DecrZWL;
    }

    public void setTurnOverPercentageIncrease_DecrZWL(String turnOverPercentageIncrease_DecrZWL) {
        TurnOverPercentageIncrease_DecrZWL = turnOverPercentageIncrease_DecrZWL;
    }

    public String getTurnOverPercentageIncrease_DecrUSD() {
        return TurnOverPercentageIncrease_DecrUSD;
    }

    public void setTurnOverPercentageIncrease_DecrUSD(String turnOverPercentageIncrease_DecrUSD) {
        TurnOverPercentageIncrease_DecrUSD = turnOverPercentageIncrease_DecrUSD;
    }

    public String getIndex() {
        return Index;
    }

    public String getOMIRPercentage() {
        return OMIRPercentage;
    }

    public void setOMIRPercentage(String OMIRPercentage) {
        this.OMIRPercentage = OMIRPercentage;
    }

    public String getBlackmarkertBondPercentage() {
        return blackmarkertBondPercentage;
    }

    public void setBlackmarkertBondPercentage(String blackmarkertBondPercentage) {
        this.blackmarkertBondPercentage = blackmarkertBondPercentage;
    }

    public String getBlackmarkertRTSPercentage() {
        return blackmarkertRTSPercentage;
    }

    public void setBlackmarkertRTSPercentage(String blackmarkertRTSPercentage) {
        this.blackmarkertRTSPercentage = blackmarkertRTSPercentage;
    }

    public String getBlackmarkertZWLPercentage() {
        return blackmarkertZWLPercentage;
    }

    public void setBlackmarkertZWLPercentage(String blackmarkertZWLPercentage) {
        this.blackmarkertZWLPercentage = blackmarkertZWLPercentage;
    }

    public void setIndex(String index) {
        Index = index;
    }

    public String getVolumeTrade() {
        return VolumeTrade;
    }

    public void setVolumeTrade(String volumeTrade) {
        VolumeTrade = volumeTrade;
    }

    public String getSecuritySubType() {
        return SecuritySubType;
    }

    public void setSecuritySubType(String securitySubType) {
        SecuritySubType = securitySubType;
    }

    public String getOMIR() {
        return OMIR;
    }

    public void setOMIR(String OMIR) {
        this.OMIR = OMIR;
    }

    public String getBlackMarketZWL() {
        return BlackMarketZWL;
    }

    public void setBlackMarketZWL(String blackMarketZWL) {
        BlackMarketZWL = blackMarketZWL;
    }

    public String getBlackMarketRTGS() {
        return BlackMarketRTGS;
    }

    public void setBlackMarketRTGS(String blackMarketUSD) {
        BlackMarketRTGS = blackMarketUSD;
    }

    public String getPriceUSD() {
        return PriceUSD;
    }

    public void setPriceUSD(String priceUSD) {
        PriceUSD = priceUSD;
    }

    public String getPriceZWL() {
        return PriceZWL;
    }

    public void setPriceZWL(String priceZWL) {
        PriceZWL = priceZWL;
    }

    public String getRate() {
        return Rate;
    }

    public String getBlackMarketBond() {
        return BlackMarketBond;
    }

    public void setBlackMarketBond(String blackMarketBond) {
        BlackMarketBond = blackMarketBond;
    }

    public void setRate(String rate) {
        Rate = rate;
    }
}
