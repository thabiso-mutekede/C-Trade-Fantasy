package zw.co.escrow.ctradelive.view.fragments.individual_create_account;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.textfield.TextInputLayout;

import java.util.Objects;

import zw.co.escrow.ctradelive.BranchAsyncTask;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.view_model.AppViewModel;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class CustodianDetailsFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "DETAILS";

    private LoginViewModel loginViewModel;
    private Utils utils;
    private static final String TAG = "CustodianDetailsFragmen";
    private AppViewModel appViewModel;
    private RegistrationData registrationData;
    private TextInputLayout outlinedTextFieldCustodian, outlinedTextFieldBank, outlinedTextFieldBranch, outlinedTextFieldAccountNumber;



    public static CustodianDetailsFragment newInstance(RegistrationData registrationData) {
        CustodianDetailsFragment fragment = new CustodianDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
        ViewModelProvider viewModelProvider = new ViewModelProvider(requireActivity());
        appViewModel = viewModelProvider.get(AppViewModel.class);
    }



    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_custodian_details, container, false);

        initWidgets(root);


        utils = new Utils(getActivity());


        appViewModel.getBrokers().observe(requireActivity(), brokers->{
            Log.d(TAG, "onCreateView: "+brokers.size());

            for (String s:brokers) {
                Log.d(TAG, "onCreateView: "+s);
            }

            utils.setDropdownBoxes(brokers.toArray(new String[0]), R.id.custodian_dropdown_items, root);

        });

        appViewModel.getBanks().observe(requireActivity(), banks->{

            Log.d(TAG, "onCreateView: "+banks.size());


            for (String s:banks) {
                Log.d(TAG, "onCreateView: "+s);
            }

            utils.setDropdownBoxes(banks.toArray(new String[0]), R.id.bank_dropdown_items, root);

        });

        Objects.requireNonNull(outlinedTextFieldBank.getEditText()).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                BranchAsyncTask branchAsyncTask = new BranchAsyncTask(CustodianDetailsFragment.this);
                branchAsyncTask.execute(charSequence.toString());
                Log.d(TAG, "onTextChanged1: "+charSequence);




            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        ViewModelProvider viewModelProvider = new ViewModelProvider(CustodianDetailsFragment.this);
        AppViewModel appViewModel = viewModelProvider.get(AppViewModel.class);


        appViewModel.getBranches().observe(requireActivity(), branches->{

            for (String s:branches) {
                Log.d(TAG, "onTextChanged: "+s);
            }

            utils.setDropdownBoxes(branches.toArray(new String[0]), R.id.branch_dropdown_items, root);

        });




        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
            registrationData.getRegistrationSession().setDetailsDone(true);
        }

        if(registrationData.getRegistrationSession().isCustodianDone())setUpFields();


        root.findViewById(R.id.btnLogin).setOnClickListener(v->{

            String custodian = outlinedTextFieldCustodian.getEditText().getText().toString()
                    ,bank = outlinedTextFieldBank.getEditText().getText().toString()
                    ,branchBank = outlinedTextFieldBranch.getEditText().getText().toString()
                    ,accountNumber = outlinedTextFieldAccountNumber.getEditText().getText().toString();

            if (custodian.equals("")) {
                outlinedTextFieldCustodian.setError("Please select custodian");
            }
            else if (bank.equals("")) {
                outlinedTextFieldBank.setError("Please select bank");

            }
            else if (branchBank.equals("")) {
                outlinedTextFieldBranch.setError("Please select branch");

            }
            else if (accountNumber.equals("")){
                outlinedTextFieldAccountNumber.setError("Please enter account number");

            }
            else {
                registrationData.getDetails().setCustodian(custodian);
                registrationData.getDetails().setCashBank(bank);
                registrationData.getDetails().setCashBranch(branchBank);
                registrationData.getDetails().setCashAccountNo(accountNumber);


                utils.startNewFragment(root, CustodianDetailsFragment.this, LoginDetailsFragment.newInstance(registrationData) );
            }
        });
        return root;
    }

    private void setUpFields() {
        outlinedTextFieldCustodian.getEditText().setText(registrationData.getDetails().getCustodian());
        outlinedTextFieldBank.getEditText().setText(registrationData.getDetails().getCashBank());
        outlinedTextFieldBranch.getEditText().setText(registrationData.getDetails().getCashBranch());
        outlinedTextFieldAccountNumber.getEditText().setText(registrationData.getDetails().getCashAccountNo());
    }

    private void initWidgets(View view){
        outlinedTextFieldCustodian=view.findViewById(R.id.outlinedTextFieldCustodian);
        outlinedTextFieldBank=view.findViewById(R.id.outlinedTextFieldBank);
        outlinedTextFieldBranch=view.findViewById(R.id.outlinedTextFieldBranch);
        outlinedTextFieldAccountNumber=view.findViewById(R.id.outlinedTextFieldAccountNumber);



    }
}