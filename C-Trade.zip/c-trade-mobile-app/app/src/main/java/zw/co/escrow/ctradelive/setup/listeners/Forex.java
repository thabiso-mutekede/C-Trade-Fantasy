package zw.co.escrow.ctradelive.setup.listeners;

import android.app.Dialog;
import android.widget.Spinner;
//
//public class Forex {
//
//    public interface ForexServicesListener{
//        void onPostBid(RequestBody cds,
//                       RequestBody type,
//                       RequestBody amount,
//                       RequestBody purpose,
//                       RequestBody prefrate,
//                       RequestBody sector,
//                       RequestBody bpno,
//                       MultipartBody.Part invoices
//        );
//        void checkRegDocumentsForCPay(String cdsnumber);
//        void onAttachDocumentsCorp(RequestBody cdsNumber, MultipartBody.Part taxClearance, MultipartBody.Part c14);
//        void onGetBidPurpose(Spinner spBidSpinner);
//        void onGetBidOrders(String cdsnumber);
//        void onGetBidOrdersHistory(String cdsnumber);
//        void onGetForexBalances(String cdsnumber, TextView txt1, TextView txt2, TextView txt3, TextView txt4);
//        void onGetMyStatement(String cdsnumber);
//        void onPostWithdrawCash(String cdsnumber, String amount, Dialog dialog);
//        void onLoadPortfolio(String cdsnumber);
//
//    }
//}
