package zw.co.escrow.ctradelive;

/**
 * Created by tinah on 8/11/2017.
 */

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.github.mikephil.charting.charts.LineChart;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zw.co.escrow.ctradelive.adapters.GraphSectionsPagerAdapter;


public class GraphsAdapter extends RecyclerView.Adapter<GraphsAdapter.ViewHolder> {

    private List<App> mApps;
    private boolean mHorizontal;
    private boolean mPager;
    private TextView IssueInformationPrice, IssueInformation;
    private LineChart displayLineChart;
    private ArrayList<Float> prices = new ArrayList<>();
    private ArrayList<String> dates = new ArrayList<>();
    private float latestSharePrice;
    private GraphSectionsPagerAdapter.ChartDataAdapter chartDataAdapter;
    private AppConfig app;
    String trader;

    //    TextView behavior;
    public GraphsAdapter(boolean horizontal,
                         boolean pager, List<App> apps,
                         TextView tv,
                         TextView tvprice,
                         LineChart displayLineChart) {
        mHorizontal = horizontal;
        mApps = apps;
        mPager = pager;
        IssueInformation = tv;
        IssueInformationPrice = tvprice;
        this.displayLineChart = displayLineChart;
        app = new AppConfig();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (mPager) {
            return new ViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.adapter_pager, parent, false));
        } else {
            return mHorizontal ? new ViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.adapter, parent, false)) :
                    new ViewHolder(LayoutInflater.from(parent.getContext())
                            .inflate(R.layout.adapter_vertical, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        App app = mApps.get(position);
        ColorGenerator generator = ColorGenerator.MATERIAL; // or use DEFAULT
        int color1 = generator.getRandomColor();
        TextDrawable.IBuilder builder = TextDrawable.builder()
                .beginConfig()
                .withBorder(4)
                .endConfig()
                .rect();

        TextDrawable ic1 = builder.build(app.getName().length() < 4 ?
                app.getName() : app.getName().substring(0, 4), color1);
        holder.imageView.setImageDrawable(ic1);
        holder.nameTextView.setText(app.getName());
        holder.nameTextView1.setText(app.getCate());
        holder.ratingTextView.setText(String.valueOf(app.getRating()));
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        return mApps.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView imageView;
        public TextView nameTextView;
        public TextView nameTextView1;
        public TextView ratingTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);

            imageView = itemView.findViewById(R.id.imageView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            nameTextView1 = itemView.findViewById(R.id.nameTextView1);
            ratingTextView = itemView.findViewById(R.id.ratingTextView);
        }

        @Override
        public void onClick(View view) {
            Log.d("App", mApps.get(getAdapterPosition()).getName());
            dates.clear();
            prices.clear();
            trader = mApps.get(getAdapterPosition()).getName();

            IssueInformation.setText(trader);
            //IssueInformationPrice.setText("" + currentPrice);
            progressDialogc = new ProgressDialog(view.getContext());
            progressDialogc.setMessage("Loading companies, please wait...");
            progressDialogc.show();
            progressDialogc.setCancelable(false);
            progressDialogc.setCanceledOnTouchOutside(false);

            String clicked_company_url =
                    "https://ctrade.co.zw/online/online.ctrade_php/getPricesMobile.php?company="
                            + trader;
            StringRequest clickedCompanyJsonRequest = new StringRequest(Request.Method.GET,
                    clicked_company_url,
                    clickedCompanySuccessListener(view.getContext(), displayLineChart),
                    clickedCompanyErrorListener(view.getContext())) {
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("company", trader);
                    return params;
                }
            };

            clickedCompanyJsonRequest.setRetryPolicy(new DefaultRetryPolicy(
                    AppConfig.REASONABLE_RETRY_MS,
                    0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            AppConfig.getInstance().addToRequestQueue(clickedCompanyJsonRequest);
        }
    }

    ProgressDialog progressDialogc;

    private Response.ErrorListener clickedCompanyErrorListener(Context context) {
        return error -> {
            error.printStackTrace();
            progressDialogc.dismiss();
            new AlertDialog.Builder(context)
                    .setCancelable(false)
                    .setMessage("Network unavailable to load graphs . Please try again later")
                    .setPositiveButton("OK", (dialog, which) -> {

                    })
                    .show();
        };
    }

    private Response.Listener<String> clickedCompanySuccessListener(Context context,
                                                                    LineChart lineChart) {
        return response -> {
            if (progressDialogc != null)
                progressDialogc.dismiss();
            try {
                JSONArray jsonArray = new JSONArray(response);
                Log.d("Data in GraphsAdapter ", response);
                Log.d("The company is ", trader);
                if (response.isEmpty() || jsonArray.length() > 0) {
                    String date;
                    Float price;
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        date = jsonObject.optString("date");
                        price = Float.valueOf(jsonObject.optString("price"));
                        prices.add(price);
                        dates.add(date);
                    }
                    latestSharePrice = prices.get(prices.size() - 1);
                    IssueInformationPrice.setText(String.valueOf(latestSharePrice));
                    Log.d("Latest share price is ", "" + latestSharePrice);
                    try {
                        Collections.reverse(dates);
                        Collections.reverse(prices);
                        chartDataAdapter = new GraphSectionsPagerAdapter.ChartDataAdapter();
                        chartDataAdapter.setChartData(dates, prices, context, lineChart);

                    } catch (Exception e) {

                    }
                } else {
                    lineChart.clear();
                    Toast.makeText(context,
                            "No market data available.", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }

}
