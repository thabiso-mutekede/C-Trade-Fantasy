package zw.co.escrow.ctradelive.view.fragments.company_create_account;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.features.ReturnMode;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.Details;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.model.Signatory;
import zw.co.escrow.ctradelive.setup.listeners.Registration;
import zw.co.escrow.ctradelive.setup.services.RegistrationService;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class UploadCompanyParticularsFragment extends Fragment implements View.OnClickListener {

    private static final String ARG_SECTION_NUMBER = "DETAILS";
    private static final String TAG = "UploadCompanyParticular";

    private LoginViewModel loginViewModel;

    private RegistrationData registration;
    private CardView cardViewTaxClearance, cardViewBoardResDocs, cardViewCertIncorp;
    private Utils utils;

    private Registration.DataListener dataListener;
    public static final int REQUEST_PERMISSION = 700;
    private String taxClearancePath,corporateIdPath;
    private TextView taxClearanceTXT,corporateIdTXT;
    private Button submitButton;

    public static UploadCompanyParticularsFragment newInstance(RegistrationData registration) {
        UploadCompanyParticularsFragment fragment = new UploadCompanyParticularsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registration);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            registration = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_upload_company_particulars, container, false);

        initWidgets(root);

        checkPermissions();
        verifyStoragePermissions(getActivity());

        dataListener = new RegistrationService(getContext());
        cardViewTaxClearance.setOnClickListener(this);
        cardViewBoardResDocs.setOnClickListener(this);
        cardViewCertIncorp.setOnClickListener(this);

        if (getArguments() != null) {
            registration = getArguments().getParcelable(ARG_SECTION_NUMBER);
            registration.getRegistrationSession().setCustodianDone(true);
        }

        utils = new Utils(getActivity());

        root.findViewById(R.id.btnBack).setOnClickListener(v->
            utils.startNewFragment(root, UploadCompanyParticularsFragment.this, CompanyCustodianDetailsFragment.newInstance(registration))
        );

        root.findViewById(R.id.btnSubmit).setOnClickListener(v->{
            submitButton.setEnabled(false);
            try {
                JSONObject body = getClientBody(getString(R.string.account_type_corporate));
                if(body != null){
                    Log.d("lloda",body.toString());
                    createACTradeAccount(body.toString());
                }else{
                    submitButton.setEnabled(true);
                }


            } catch (Exception e) {
                e.printStackTrace();
                submitButton.setEnabled(true);
                new AlertDialog.Builder(getActivity())
                        .setTitle("Result")
                        .setCancelable(false)
                        .setMessage(R.string.error_while_compiling_account_details)
                        .setPositiveButton("OK", (dialog, which) -> {
                        })
                        .show();
            }

        });

        return root;
    }

    private void initWidgets(View view){
        cardViewTaxClearance =view.findViewById(R.id.cardViewTaxClearence);
        cardViewBoardResDocs =view.findViewById(R.id.cardViewBoardResDocs);
        cardViewCertIncorp =view.findViewById(R.id.cardViewCertIncorp);
        corporateIdTXT = view.findViewById(R.id.corporateIdTXT);
        taxClearanceTXT = view.findViewById(R.id.taxClearanceTXT);
        submitButton = view.findViewById(R.id.btnSubmit);
    }

    @Override
    public void onClick(View view) {

        Intent pickPhoto = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);


        switch (view.getId()){
            case R.id.cardViewTaxClearence:

                startActivityForResult(pickPhoto, Constants.REQUEST_FILE_TAX);

                break;

            case R.id.cardViewBoardResDocs:

                startActivityForResult(pickPhoto, Constants.REQUEST_FILE_BOARD);


                break;

            case R.id.cardViewCertIncorp:

                startActivityForResult(pickPhoto, Constants.REQUEST_FILE_CORP);

                break;



        }

    }

    private void uploadImage(String message){
        ImagePicker.create(getActivity())
                .returnMode(ReturnMode.GALLERY_ONLY)
                .folderMode(true)
                .toolbarFolderTitle(message)
                .toolbarImageTitle("Tap to select")
                .toolbarArrowColor(getActivity().getResources().getColor(R.color.colorWhite))
                .includeVideo(false)
                .includeAnimation(false)
                .single()
                .limit(1)
                .showCamera(true)
                .imageDirectory("Camera")
                .theme(R.style.AppTheme)
                .enableLog(true)
                .start();
    }


    private JSONObject getClientBody(String type) throws Exception{
        JSONObject jo = new JSONObject();
        JSONObject regJo = new JSONObject();


        JSONArray repJa = new JSONArray();
        try{
            if(uploadCompanyDocuments()) {
                String  companyName, companyRegNo, companyAddress,
                        companyEmail, phone, cellphone, city,  dob, companyPass, country,
                        custodian, bank, branch, accountNumber,cdc_number;


                //cdsNumber = details.get(1);
                //atpNumber = details.get(2);

                Details details = registration.getDetails();

                companyName = details.getForenames();
                companyAddress =  details.getAdd1();
                companyRegNo = details.getIdnoPP();
                companyEmail = details.getEmail();
                cellphone =  details.getMobile();
                city = details.getCity();
                phone = details.getTel();
                dob =  details.getDob();
                companyPass =  registration.getPassword();
                country = details.getNationality();

                custodian = details.getCustodian();
                bank = details.getCashBank();
                branch = details.getCashBranch();
                accountNumber = details.getCashAccountNo();
                cdc_number = details.getCdc_number();


                jo.put("accountType",type);
                jo.put("surname", companyName);
                jo.put("forenames", "");
                jo.put("title", "");
                jo.put("nationality", country);
                jo.put("city", city);
                jo.put("tel", phone);
                jo.put("mobile", cellphone);
                jo.put("idnoPP", companyRegNo);
                jo.put("dob", dob);

                //TODO DATE VALIDATOR
                //  jo.put("dob", dateValidatorFormatter.format(real_date));
                jo.put("gender", "N");
                jo.put("add1", companyAddress);
                jo.put("email", companyEmail);
                jo.put("cashBank", bank);
                jo.put("cashBranch", branch);
                jo.put("cashAccountNo", accountNumber);
                jo.put("custodian", custodian);
                jo.put("createdBy", "ANDROID");
                jo.put("cdcNumber",cdc_number);

                regJo.put("password", companyPass);
                regJo.put("accountsClientsWeb",jo);

                for (Signatory signatory : registration.getSignatories()) {
                    Log.d(TAG, "getClientBody: "+signatory.getSignatoryName());
                    JSONObject repJo = new JSONObject();
                    repJo.put("names", signatory.getSignatoryName());
                    repJo.put("email", signatory.getSignatoryEmail());
                    repJo.put("mobile", signatory.getSignatoryPhone());
                    repJo.put("password", signatory.getSignatoryPassword());
                    repJo.put("initiator", signatory.getInitiator());
                    repJo.put("authorizer", signatory.getAuthoriser());
                    repJa.put(repJo);
                }
                regJo.put("representatives",repJa);
                return regJo;
            }
            return null;

        }catch (Exception e){
            e.printStackTrace();
            throw new Exception();
        }
    }

    private boolean uploadCompanyDocuments() {
        if(taxClearancePath == null) {
            Toast.makeText(getContext(), "Upload Tax Clearance", Toast.LENGTH_SHORT).show();
            return false;
        }else if(corporateIdPath == null){
            Toast.makeText(getContext(), "Upload Corporate Id", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }


    private void createACTradeAccount(String body){
        if(corporateIdPath != null && taxClearancePath != null){
            File corporateId = new File(corporateIdPath);
            File taxFile = new File(taxClearancePath);

            Bitmap corp_id = BitmapFactory.decodeFile(corporateId.getAbsolutePath());
            Bitmap tax_bit = BitmapFactory.decodeFile(taxFile.getAbsolutePath());
            dataListener.createCTradeAccount(getContext(),body,corp_id,tax_bit);

        }else{
            showDialog("Something Is Wrong With The Image You Are Trying To Submit,Please Try Selecting An Image From Your 'Gallery'");
        }
    }


    private void showAlert(String msg){
        new AlertDialog.Builder(getActivity())
                .setPositiveButton("Ok",(dialog, which) -> {
                    // startActivity(new Intent(CdsAccount.this, ActivityTradingAccount.class));
                })
                .setMessage(msg).show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {


            case Constants.REQUEST_FILE_CORP:
                if (requestCode == Constants.REQUEST_FILE_CORP) {
                    //docPaths = new ArrayList<>();
                    //docPaths.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                    if (requestCode == Constants.REQUEST_FILE_CORP && resultCode == getActivity().RESULT_OK) {

                        if (resultCode == Activity.RESULT_OK) {
                            //Uri uri = data.getParcelableExtra("path");
                            Uri uri = data.getData();
                            String[] filePathColumn = {MediaStore.Images.Media.DATA};
                            // Get the cursor
                            Cursor cursor = getActivity().getContentResolver().query(uri, filePathColumn, null, null, null);
                            // Move to first row
                            cursor.moveToFirst();
                            //Get the column index of MediaStore.Images.Media.DATA
                            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                            //Gets the String value in the column
                            String imgDecodableString = cursor.getString(columnIndex);
                            cursor.close();
                            // Set the Image in ImageView after decoding the String
                            //imageView.setImageBitmap(BitmapFactory.decodeFile(imgDecodableString));
                            //uploadToServerID(imgDecodableString);
                            corporateIdPath= imgDecodableString;
                            String name = queryName(getActivity().getContentResolver(),uri);
                            corporateIdTXT.setText(name);
                        }

                    }
                }
                break;

            case Constants.REQUEST_FILE_BOARD:
                if (requestCode == Constants.REQUEST_FILE_BOARD) {
                    //docPaths = new ArrayList<>();
                    //docPaths.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                    if (requestCode == Constants.REQUEST_FILE_BOARD && resultCode == getActivity().RESULT_OK) {

                        if (resultCode == Activity.RESULT_OK) {
                            //Uri uri = data.getParcelableExtra("path");
                            Uri uri = data.getData();
                            String[] filePathColumn = {MediaStore.Images.Media.DATA};
                            // Get the cursor
                            Cursor cursor = getActivity().getContentResolver().query(uri, filePathColumn, null, null, null);
                            // Move to first row
                            cursor.moveToFirst();
                            //Get the column index of MediaStore.Images.Media.DATA
                            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                            //Gets the String value in the column
                            String imgDecodableString = cursor.getString(columnIndex);
                            cursor.close();
                            // Set the Image in ImageView after decoding the String
                            //imageView.setImageBitmap(BitmapFactory.decodeFile(imgDecodableString));
                            //compDocs.put("BOARD",imgDecodableString);

                        }

                    }
                }
                break;
            case Constants.REQUEST_FILE_TAX:
                if (requestCode == Constants.REQUEST_FILE_TAX) {
                    //docPaths = new ArrayList<>();
                    //docPaths.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                    if (requestCode == Constants.REQUEST_FILE_TAX && resultCode == getActivity().RESULT_OK) {

                        if (resultCode == Activity.RESULT_OK) {
                            //Uri uri = data.getParcelableExtra("path");
                            Uri uri = data.getData();
                            String[] filePathColumn = {MediaStore.Images.Media.DATA};
                            // Get the cursor
                            Cursor cursor = getActivity().getContentResolver().query(uri, filePathColumn, null, null, null);
                            // Move to first row
                            cursor.moveToFirst();
                            //Get the column index of MediaStore.Images.Media.DATA
                            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                            //Gets the String value in the column
                            String imgDecodableString = cursor.getString(columnIndex);
                            cursor.close();
                            // Set the Image in ImageView after decoding the String
                            //imageView.setImageBitmap(BitmapFactory.decodeFile(imgDecodableString));

                            taxClearancePath= imgDecodableString;
                            String name = queryName(getActivity().getContentResolver(),uri);
                            taxClearanceTXT.setText(name);
                        }

                    }
                }
                break;
            default:
                Toast.makeText(getActivity(), " fall down", Toast.LENGTH_LONG).show();

        }
    }

    private String queryName(ContentResolver resolver, Uri uri) {
        Cursor returnCursor =
                resolver.query(uri, null, null, null, null);
        assert returnCursor != null;
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        returnCursor.moveToFirst();
        String name = returnCursor.getString(nameIndex);
        returnCursor.close();
        return name;
    }

    private void showDialog(String message){
        new android.app.AlertDialog.Builder(getContext())
                .setMessage(message)
                .setPositiveButton("ok",(
                        (dialogInterface, i) -> {
                        }))
                .create()
                .show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkPermissions(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_PERMISSION);

            return;
        }
    }

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

}