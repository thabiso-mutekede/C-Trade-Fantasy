package zw.co.escrow.ctradelive.view.fragments.individual_create_account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class ClientStatusFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "DETAILS";

    private LoginViewModel loginViewModel;
    private Utils utils;
    private RegistrationData registrationData;
    private TextInputLayout outlinedTextFieldFavBook, outlinedTextFieldMotherMaidenName, outlinedTextFieldRoad;



    public static ClientStatusFragment newInstance(RegistrationData registrationData) {
        ClientStatusFragment fragment = new ClientStatusFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_client_status, container, false);

        initWidgets(root);

        utils = new Utils(getActivity());


        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
            registrationData.getRegistrationSession().setCredentialsDone(true);
        }
        if(registrationData.getRegistrationSession().isQnaDone())setUpFields();
        root.findViewById(R.id.btnNext).setOnClickListener(v->{

            String occupation = outlinedTextFieldFavBook.getEditText().getText().toString()
                    ,industry = outlinedTextFieldMotherMaidenName.getEditText().getText().toString()
                    ,pep_status = outlinedTextFieldRoad.getEditText().getText().toString();



            if (occupation.equals("")) {
                outlinedTextFieldFavBook.setError("Please Enter Occupation");
            }
            else if (industry.equals("")) {
                outlinedTextFieldMotherMaidenName.setError("Please Enter Industry");

            }
            else if (pep_status.equals("")) {
                outlinedTextFieldRoad.setError("Please Enter Your PEP Status");

            }
            else {
                registrationData.getDetails().setClient_occupation(occupation);
                registrationData.getDetails().setIndustry_of_profession(industry);
                registrationData.getDetails().setPep_status(pep_status);

                utils.startNewFragment(root, ClientStatusFragment.this, SecurityDetailsFragment.newInstance(registrationData) );
            }
        });
        return root;
    }

    private void setUpFields() {
        outlinedTextFieldFavBook.getEditText().setText(registrationData.getDetails().getClient_occupation());
        outlinedTextFieldMotherMaidenName.getEditText().setText(registrationData.getDetails().getIndustry_of_profession());
        outlinedTextFieldRoad.getEditText().setText(registrationData.getDetails().getPep_status());
    }

    private void initWidgets(View view){
        outlinedTextFieldFavBook =view.findViewById(R.id.outlinedTextFieldFavBook);
        outlinedTextFieldMotherMaidenName =view.findViewById(R.id.outlinedTextFieldMotherMaidenName);
        outlinedTextFieldRoad =view.findViewById(R.id.outlinedTextFieldRoad);

    }
}