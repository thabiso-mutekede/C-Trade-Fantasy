package zw.co.escrow.ctradelive.view.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.Group;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.JsonArrayRequest;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.ButterKnife;
import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.MarketWatchETF;
import zw.co.escrow.ctradelive.model.MarketWatchFINSEC;
import zw.co.escrow.ctradelive.model.MarketWatchZSE;
import zw.co.escrow.ctradelive.model.OrderDetails;
import zw.co.escrow.ctradelive.setup.listeners.CTradeDataListener;
import zw.co.escrow.ctradelive.setup.services.CTradeDataServices;
import zw.co.escrow.ctradelive.view.LoginActivity2;
import zw.co.escrow.ctradelive.view.dialogs.TradeClubPreloadedDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradeDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradePreloadedDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradePreloadedETF;
import zw.co.escrow.ctradelive.view.fragments.graph.EquityFSContainer;
import zw.co.escrow.ctradelive.view.fragments.graph.MarketFSContainer;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CompanyAnalysisFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CompanyAnalysisFragment extends Fragment implements RadioGroup.OnCheckedChangeListener, View.OnClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private CTradeDataListener dataListener;


/*
    @SuppressWarnings("WeakerAccess")
    @BindView(R.id.chart_symbol)
    TextView symbolTextView;

    @SuppressWarnings("WeakerAccess")
    @BindView(R.id.chart_price)
    TextView priceTextView;


    @SuppressWarnings("WeakerAccess")
    @BindView(R.id.chart_price_change_absolute)
    TextView priceAbsoluteTextView;

    @SuppressWarnings("WeakerAccess")
    @BindView(R.id.chart_price_change_percent)
    TextView pricePercentTextView;

    @Nullable
    @BindView(R.id.toolBarTvAtChart)
    TextView toolbarTextView;
*/

    private RecyclerView mRecyclerView;
    AppConfig appConfig;
    String exchange, get_companies_url, ip;
    private String felloverip1, felloverip2, fellOverPhp, ticker;
    private String cdsNumber;
    private boolean onRetry = false;
    private ArrayList<Float> prices = new ArrayList<>();
    private ArrayList<String> dates = new ArrayList<>();

    private ViewPager viewPager;
    private SmartTabLayout smartTabLayout;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private CardView descLayout;
    private TextView  descText;

    private static final String TAG = "CompanyAnalysisFragment";
    private TextView txtBestAsk, txtAskVolume, txtBestBid, txtBidVolume,txtCurrentPrice,
            txtPreviousPrice, txtChangePrice, txtPercentageChange, txtISIN,txtLastVolume,txtTradedVolume,
            txtTurnOver,txtOpen,txtHigh,txtLow;
    Group group2;
    private OrderDetails orderDetails;
    private String[] companyDetails;
    private MarketWatchZSE marketWatchZSE;
    private MarketWatchETF marketWatchETF;
    private MarketWatchFINSEC marketWatchFINSEC;
    private RadioGroup graphSwitch;
    private Boolean isClub;


    TextView
            one_week,
            one_month,
            three_months,
            ytd,
            one_year,
            three_years,
            five_years,
            one_w_high_low,
            one_m_high_low,
            six_w_high_low,
            six_m_high_low,
            high_ytd_,
            low_ytd_,
            ftwo_high,
            ftwo_low,
            avg_p_one_w,
            avg_p_one_m,
            avg_p_six_m,
            avg_p_one_y,
            avg_v_one_w,
            avg_v_one_m,
            avg_v_six_m,
            avg_v_one_y,
            volatality_three_w,
            volatality_one_m,
            volatality_six_m,
            volatality_one_y;



    public CompanyAnalysisFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CompanyAnalysisFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CompanyAnalysisFragment newInstance(String param1, String param2) {
        CompanyAnalysisFragment fragment = new CompanyAnalysisFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            try {
                marketWatchZSE = getArguments().getParcelable(getString(R.string.EXCHANGE));
            }
            catch (Exception e){

            }
            try {
                marketWatchETF = getArguments().getParcelable(Constants.ETF);
            }
            catch (Exception e){

            }
            try {
                marketWatchFINSEC = getArguments().getParcelable(getString(R.string.EXCHANGE));
            }
            catch (Exception e){

            }
            isClub = getArguments().getBoolean("isClub");
            cdsNumber = getArguments().getString("cdsnumber");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_company_analysis, container, false);
        ButterKnife.bind(this, view);
        initWidgets(view);
        initPerformanceWidgets(view);
        dataListener = new CTradeDataServices(getActivity());
        setUpMarketGraph();

        graphSwitch.setOnCheckedChangeListener(this);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }





    private void setUpWatchEquity(MarketWatchZSE marketWatchZSE){

        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.EXCHANGE),marketWatchZSE.getTicker());

        getChildFragmentManager().beginTransaction()
                .replace(R.id.graph_container_layout,new EquityFSContainer(bundle))
                .commit();
    }
    private void setUpWatchEquity(MarketWatchFINSEC marketWatchFINSEC){

        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.EXCHANGE),marketWatchFINSEC.getMarket_company());
        getChildFragmentManager().beginTransaction()
                .replace(R.id.graph_container_layout,new EquityFSContainer(bundle))
                .commit();
    }


    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        switch (i){
            case R.id.market_id:
                setUpMarketGraph();
                break;
            case R.id.equity_id:
                if (marketWatchZSE != null){
                    setUpWatchEquity(marketWatchZSE);

                }
                else {
                    setUpWatchEquity(marketWatchFINSEC);
                }
                break;
        }
    }
    private void setUpMarketGraph(){
        if (marketWatchZSE != null){

            txtISIN.setText(marketWatchZSE.getISIN());

            txtBestAsk.setText(String.format("%s", marketWatchZSE.getBest_Ask()));
            txtAskVolume.setText(String.format("%s", marketWatchZSE.getAsk_Volume()));
            txtBestBid.setText(String.format("%s", marketWatchZSE.getBest_bid()));
            txtBidVolume.setText(String.format("%s", marketWatchZSE.getBid_Volume()));
            txtCurrentPrice.setText(String.format("%s", marketWatchZSE.getCurrent_price()));
            txtPreviousPrice.setText(String.format("%s", marketWatchZSE.getPrevPrice()));
            //txtChangePrice.setText();
            double price_change = marketWatchZSE.getCurrent_price() - marketWatchZSE.getPrevPrice();
            double percentageChange = (price_change / marketWatchZSE.getPrevPrice() ) * 100;

            txtPercentageChange.setText(String.valueOf(Constants.roundToDecimalPlaceShare(Constants.convertToFloat(String.valueOf(percentageChange)))).concat("%"));
            txtChangePrice.setText(String.format("%s", marketWatchZSE.getPrevChange()));
            setUpWatchList(marketWatchZSE);
            getCompanyDescription(marketWatchZSE.getTicker());
            setWidgetValues(marketWatchZSE.getTicker());
            orderDetails = new OrderDetails();
            orderDetails.setCompany(marketWatchZSE.getTicker());
            orderDetails.setMarket("ZSE");
            orderDetails.setFullCompanyName(marketWatchZSE.getFullCompanyName());
            orderDetails.setCurrentPrice(String.valueOf(marketWatchZSE.getCurrent_price()));

        }

        else if (marketWatchETF != null){

            txtISIN.setText(marketWatchETF.getISIN());

            txtBestAsk.setText(String.format("%s", marketWatchETF.getBest_Ask()));
            txtAskVolume.setText(String.format("%s", marketWatchETF.getAsk_Volume()));
            txtBestBid.setText(String.format("%s", marketWatchETF.getBest_bid()));
            txtBidVolume.setText(String.format("%s", marketWatchETF.getBid_Volume()));
            txtCurrentPrice.setText(String.format("%s", marketWatchETF.getCurrent_price()));
            txtPreviousPrice.setText(String.format("%s", marketWatchETF.getPrevPrice()));
            //txtChangePrice.setText();
            double price_change = marketWatchETF.getCurrent_price() - marketWatchETF.getPrevPrice();
            double percentageChange = (price_change / marketWatchETF.getPrevPrice() ) * 100;

            txtPercentageChange.setText(String.valueOf(Constants.roundToDecimalPlaceShare(Constants.convertToFloat(String.valueOf(percentageChange)))).concat("%"));
            txtChangePrice.setText(String.format("%s", marketWatchETF.getPrevChange()));
            setUpWatchList(marketWatchETF);
            getCompanyDescription(marketWatchETF.getTicker());
            setWidgetValues(marketWatchETF.getTicker());
            orderDetails = new OrderDetails();
            orderDetails.setCompany(marketWatchETF.getTicker());
            orderDetails.setMarket("ZSE");
            orderDetails.setFullCompanyName(marketWatchETF.getFullCompanyName());
            orderDetails.setCurrentPrice(String.valueOf(marketWatchETF.getCurrent_price()));

        }
        else if (marketWatchFINSEC != null){
            txtAskVolume.setText("0");
            txtBidVolume.setText("0");
            txtPreviousPrice.setText("0");
            //txtChangePrice.setText();
            double price_change = marketWatchFINSEC.getMarket_vwap()-marketWatchFINSEC.getMarket_lp();
            double percentageChange =   (price_change  / marketWatchFINSEC.getMarket_lp())* 100;
            txtPercentageChange.setText(String.valueOf(Constants.roundToDecimalPlaceShare(Constants.convertToFloat(String.valueOf(percentageChange)))).concat("%"));

            group2.setVisibility(View.VISIBLE);


            txtBestAsk.setText(String.format("%s", marketWatchFINSEC.getMarket_ap()));
            txtAskVolume.setText(String.format("%s", marketWatchFINSEC.getMarket_va()));
            txtBestBid.setText(String.format("%s", marketWatchFINSEC.getMarket_bp()));
            txtBidVolume.setText(String.format("%s", marketWatchFINSEC.getMarket_bbv()));
            txtCurrentPrice.setText(String.format("%s", marketWatchFINSEC.getMarket_vwap()));
            txtPreviousPrice.setText(String.format("%s", marketWatchFINSEC.getMarket_lp()));

            txtLastVolume.setText(String.format("%s", marketWatchFINSEC.getMarket_lv()));
            txtTradedVolume.setText(String.format("%s", marketWatchFINSEC.getMarket_tv()));
            txtTurnOver.setText(String.format("%s", marketWatchFINSEC.getMarket_to()));
            txtOpen.setText(String.format("%s", marketWatchFINSEC.getMarket_open()));
            txtHigh.setText(String.format("%s", marketWatchFINSEC.getMarket_high()));
            txtLow.setText(String.format("%s", marketWatchFINSEC.getMarket_low()));

            txtChangePrice.setText(String.format("%s", marketWatchFINSEC.getMarket_change()));

            txtPercentageChange.setText(String.format("%s%%", marketWatchFINSEC.getMarket_per_change()));
            txtISIN.setText(marketWatchFINSEC.getFullCompanyName());
            txtBestBid.setText(String.format("%s", marketWatchFINSEC.getMarket_bp()));
            txtBestAsk.setText(String.format("%s", marketWatchFINSEC.getMarket_ap()));
            txtCurrentPrice.setText(String.format("%s", marketWatchFINSEC.getMarket_vwap()));
            setUpWatchList(marketWatchFINSEC);
            getCompanyDescription(marketWatchFINSEC.getMarket_company());
            setWidgetValues(marketWatchFINSEC.getMarket_company());

            orderDetails = new OrderDetails();
            orderDetails.setCompany(marketWatchFINSEC.getMarket_company());
            orderDetails.setMarket("FINSEC");
            orderDetails.setFullCompanyName(marketWatchFINSEC.getFullCompanyName());
            orderDetails.setCurrentPrice(String.valueOf(marketWatchFINSEC.getMarket_bp()));

        }




    }


    private void initWidgets(View view){

        smartTabLayout = view.findViewById(R.id.viewpagertab);
        viewPager = view.findViewById(R.id.viewPagerWatchList);

        txtBestAsk = view.findViewById(R.id.txtBestAsk);
        txtAskVolume = view.findViewById(R.id.txtAskVolume);
        txtBestBid = view.findViewById(R.id.txtBestBid);
        txtBidVolume = view.findViewById(R.id.txtBidVolume);
        txtCurrentPrice = view.findViewById(R.id.txtCurrentPrice);
        txtPreviousPrice = view.findViewById(R.id.txtPreviousPrice);
        txtChangePrice = view.findViewById(R.id.txtChangePrice);
        txtPercentageChange = view.findViewById(R.id.txtPercentageChange);
        txtISIN = view.findViewById(R.id.txtISIN);

        txtLastVolume = view.findViewById(R.id.txtLastVolume);
        txtTradedVolume = view.findViewById(R.id.txtTradedVolume);
        txtTurnOver = view.findViewById(R.id.txtTurnOver);
        txtOpen = view.findViewById(R.id.txtOpen);
        txtHigh = view.findViewById(R.id.txtHigh);
        txtLow = view.findViewById(R.id.txtLow);
        group2 = view.findViewById(R.id.group2);

        smartTabLayout = view.findViewById(R.id.viewpagertab);
        viewPager = view.findViewById(R.id.viewPagerWatchList);
        txtBestAsk = view.findViewById(R.id.txtBestAsk);
        txtAskVolume = view.findViewById(R.id.txtAskVolume);
        txtBestBid = view.findViewById(R.id.txtBestBid);
        txtBidVolume = view.findViewById(R.id.txtBidVolume);
        txtCurrentPrice = view.findViewById(R.id.txtCurrentPrice);
        txtPreviousPrice = view.findViewById(R.id.txtPreviousPrice);
        txtChangePrice = view.findViewById(R.id.txtChangePrice);
        txtPercentageChange = view.findViewById(R.id.txtPercentageChange);
        txtISIN = view.findViewById(R.id.txtISIN);
        graphSwitch = view.findViewById(R.id.graph_group);
        descText = view.findViewById(R.id.desc_text);
        descLayout = view.findViewById(R.id.cardViewCompanyDescription);

        view.findViewById(R.id.chipBuy).setOnClickListener(this);
        view.findViewById(R.id.chipSell).setOnClickListener(this);

    }

    private void setUpWatchList(MarketWatchETF marketWatchETF){

        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.EXCHANGE),marketWatchETF.getTicker());

        getChildFragmentManager().beginTransaction()
                .replace(R.id.graph_container_layout,new MarketFSContainer(bundle))
                .commit();
    }

    private void setUpWatchList(MarketWatchZSE marketWatchZSE){

        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.EXCHANGE),marketWatchZSE.getTicker());

        getChildFragmentManager().beginTransaction()
                .replace(R.id.graph_container_layout,new MarketFSContainer(bundle))
                .commit();
    }
    private void setUpWatchList(MarketWatchFINSEC marketWatchFINSEC){

        Bundle bundle = new Bundle();
        bundle.putString(getString(R.string.EXCHANGE),marketWatchFINSEC.getMarket_company());
        getChildFragmentManager().beginTransaction()
                .replace(R.id.graph_container_layout,new MarketFSContainer(bundle))
                .commit();
    }

    private void setViewPager(Bundle  bundle){

        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getChildFragmentManager(), FragmentPagerItems.with(getActivity())
                .add("1 Day", OneDayGraphFragment.class, bundle)
                .add("1 Week", OneWeekGraphFragment.class)
                .add("1 Month", OneWeekGraphFragment.class)
                .add("6 Months", OneWeekGraphFragment.class)
                .add("1 Year", OneWeekGraphFragment.class)
                .create());
        viewPager.setAdapter(watchListPagerAdapter);

        smartTabLayout.setViewPager(viewPager);

    }

    private void getCompanyDescription(String company){
        String url = AppConfig.getIp().concat("getCompanyPerfomanceFeeds?company=").concat(company);
        Log.d("lloda",url);
        JsonArrayRequest jr = new JsonArrayRequest(url,response -> {
            try {
                if(response.length() > 0){
                    JSONObject o = response.getJSONObject(0);
                    descText.setText(o.getString("message"));
                    descLayout.setVisibility(View.VISIBLE);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        },error -> error.printStackTrace());
        AppConfig.getInstance().addToRequestQueue(jr);
    }

    private void initPerformanceWidgets(View view){
        one_week = view.findViewById(R.id.tv_one_week);
        one_month = view.findViewById(R.id.tv_one_month);
        three_months = view.findViewById(R.id.tv_three_months);
        ytd = view.findViewById(R.id.tv_ytd);
        one_year = view.findViewById(R.id.tv_one_year);
        three_years = view.findViewById(R.id.tv_three_years);
        five_years = view.findViewById(R.id.tv_five_years);
        one_w_high_low = view.findViewById(R.id.tv_1wh1wl);
        one_m_high_low = view.findViewById(R.id.tv_1mh1ml);
        six_w_high_low = view.findViewById(R.id.tv_6wh6wl);
        six_m_high_low = view.findViewById(R.id.tv_6mh_6ml);
        high_ytd_ = view.findViewById(R.id.tv_hytd);
        low_ytd_ = view.findViewById(R.id.tv_lytd);
        ftwo_high = view.findViewById(R.id.tv_52wh);
        ftwo_low = view.findViewById(R.id.tv_52W_low);
        avg_p_one_w = view.findViewById(R.id.AVG_price_one_w);
        avg_p_one_m = view.findViewById(R.id.tv_avg_price_one_m);
        avg_p_six_m = view.findViewById(R.id.tv_avg_price_6_month);
        avg_p_one_y = view.findViewById(R.id.tv_price_one_year);
        avg_v_one_w = view.findViewById(R.id.tv_avg_volume_one_w);
        avg_v_one_m = view.findViewById(R.id.tv_avg_volume_one_m);
        avg_v_six_m = view.findViewById(R.id.tv_avg_volume_6_months);
        avg_v_one_y = view.findViewById(R.id.tv_avg_volume_1_year);
        volatality_three_w = view.findViewById(R.id.tv_volatility_3w);
        volatality_one_m = view.findViewById(R.id.tv_volatility_1m);
        volatality_six_m = view.findViewById(R.id.tv_volatility_6m);
        volatality_one_y = view.findViewById(R.id.tv_volatility_1y);
    }

    private void setWidgetValues(String company){
        String url = AppConfig.getIp() +"getCompanyPerfomance?company="+company;
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, response
                ->
        {
            try{
                JSONObject jo = response.getJSONObject(0);
                one_week.setText(displayString(jo.getString("one_week")));
                one_month.setText(displayString(jo.getString("one_month")));
                three_months.setText(displayString(jo.getString("three_months")));
                ytd.setText(displayString(jo.getString("ytd")));
                one_year.setText(displayString(jo.getString("one_year")));
                three_years.setText(displayString(jo.getString("three_years")));
                five_years.setText(displayString(jo.getString("five_years")));
                one_w_high_low.setText(displayString(jo.getString("one_w_high_low")));
                one_m_high_low.setText(displayString(jo.getString("one_m_high_low")));
                six_w_high_low.setText(displayString(jo.getString("six_w_high_low")));
                six_m_high_low.setText(displayString(jo.getString("six_m_high_low")));
                high_ytd_.setText(displayString(jo.getString("high_ytd_")));
                low_ytd_.setText(displayString(jo.getString("low_ytd_")));
                ftwo_high.setText(displayString(jo.getString("ftwo_high")));
                ftwo_low.setText(displayString(jo.getString("ftwo_low")));
                avg_p_one_w.setText(displayString(jo.getString("avg_p_one_w")));
                avg_p_one_m.setText(displayString(jo.getString("avg_p_one_m")));
                avg_p_six_m.setText(displayString(jo.getString("avg_p_six_m")));
                avg_p_one_y.setText(displayString(jo.getString("avg_p_one_y")));
                avg_v_one_w.setText(displayString(jo.getString("avg_v_one_w")));
                avg_v_one_m.setText(displayString(jo.getString("avg_v_one_m")));
                avg_v_six_m.setText(displayString(jo.getString("avg_v_six_m")));
                avg_v_one_y.setText(displayString(jo.getString("avg_v_one_y")));
                volatality_three_w.setText(displayString(jo.getString("volatality_three_w")));
                volatality_one_m.setText(displayString(jo.getString("volatality_one_m")));
                volatality_six_m.setText(displayString(jo.getString("volatality_six_m")));
                volatality_one_y.setText(displayString(jo.getString("volatality_one_y")));

            }catch (Exception e){
                e.printStackTrace();
            }

        },error -> error.printStackTrace());

        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
    }

    private String displayString(String s){
        String a = "ZWL ";
        if(s.equals("")) a = "---";
        else a = a.concat(s);
        return a;
    }

    @Override
    public void onClick(View view) {
        if (cdsNumber == null) {
            getActivity().startActivity(new Intent(getContext(), LoginActivity2.class));
            getActivity().finish();
        }
        if(view.getId() == R.id.chipBuy){
            if(isClub){
                ClubModel clubModel = getArguments().getParcelable("club");
                if(clubModel.isMember()){
                    showDialog("Only Admins Can Post.");
                    return;
                }
                TradeClubPreloadedDialog dialogBuy = TradeClubPreloadedDialog.newInstance("BUY",clubModel,orderDetails);
                FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
                dialogBuy.show(ftBuy, TradeDialog.TAG);
            }else
            {
                if(marketWatchETF != null){
                    TradePreloadedETF dialogBuy = TradePreloadedETF.newInstance("BUY",cdsNumber,orderDetails);
                    FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
                    dialogBuy.show(ftBuy, TradeDialog.TAG);
                    return;
                }
                TradePreloadedDialog dialogBuy = TradePreloadedDialog.newInstance("BUY",cdsNumber,orderDetails);
                FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
                dialogBuy.show(ftBuy, TradeDialog.TAG);
            }
        }else if (view.getId() == R.id.chipSell){
            if(isClub){
                ClubModel clubModel = getArguments().getParcelable("club");
                if(clubModel.isMember()){
                    showDialog("Only Admins Can Post.");
                    return;
                }
                TradeClubPreloadedDialog dialogBuy = TradeClubPreloadedDialog.newInstance("SELL",clubModel,orderDetails);
                FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
                dialogBuy.show(ftBuy, TradeDialog.TAG);
            }else
            {
                if(marketWatchETF != null){
                    TradePreloadedETF dialogBuy = TradePreloadedETF.newInstance("SELL",cdsNumber,orderDetails);
                    FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
                    dialogBuy.show(ftBuy, TradeDialog.TAG);
                }
                TradePreloadedDialog dialogBuy = TradePreloadedDialog.newInstance("SELL",cdsNumber,orderDetails);
                FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
                dialogBuy.show(ftBuy, TradeDialog.TAG);
            }
        }
    }
    private void showDialog(String message){
        new android.app.AlertDialog.Builder(getContext())
                .setMessage(message)
                .setPositiveButton("ok",null)
                .create()
                .show();
    }
}