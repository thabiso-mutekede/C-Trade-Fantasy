package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.github.mikephil.charting.charts.LineChart;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.ChartDataAdapter;
import zw.co.escrow.ctradelive.model.MDataContaner;

public class MarketDataAdapter extends RecyclerView.Adapter {

    private Context context;
    private RecyclerView recyclerView;
    private List<MDataContaner> marketDataList;
    private boolean onRetry = false;

    private ArrayList<Float> prices = new ArrayList<>();
    private ArrayList<String> dates = new ArrayList<>();
    private ChartDataAdapter chartDataAdapter;
    LineChart historyChart;
    private RecyclerView mdata_rec;


    TextView volume_trade,stockExchange_data;

    public MarketDataAdapter(Context context, RecyclerView recyclerView, List<MDataContaner> marketDataList) {
        this.context = context;
        this.recyclerView = recyclerView;
        this.marketDataList = marketDataList;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.market_data_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(viewType,parent,false);

        chartDataAdapter = new ChartDataAdapter();

        view.setOnClickListener(v -> {
            MDataContaner marketAnalysisData = marketDataList.get(recyclerView.getChildLayoutPosition(view));
            showDialog();
        });

        return new MarketDataVH(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        ((MarketDataVH)holder).bindData(marketDataList.get(position));

    }

    @Override
    public int getItemCount() {
        return marketDataList.size();
    }

    private class MarketDataVH extends RecyclerView.ViewHolder {


        public MarketDataVH(@NonNull View itemView) {
            super(itemView);


            mdata_rec = itemView.findViewById(R.id.mdata_rec);
            mdata_rec.setHasFixedSize(true);
            mdata_rec.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL,false));
            stockExchange_data = itemView.findViewById(R.id.stock_exchange_text);

        }



        public void bindData(MDataContaner marketAnalysisData){

            Log.d("lloda mc",marketAnalysisData.toString());
            String se = marketAnalysisData.getTitle();
            stockExchange_data.setText(se);
            MdataAdapter mdataAdapter = new MdataAdapter(marketAnalysisData.getmDispList());
            mdata_rec.setAdapter(mdataAdapter);
            Log.d("lloda mc","ndapedza rec view");
        }


    }

    private void showDialog(){
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.market_analysis_chart_view);
        historyChart = dialog.findViewById(R.id.chart);

        fetchInitialCompanyData();

        Window window = dialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        dialog.show();

    }

    private void fetchInitialCompanyData() {

        String initComp = "AFSUN";
        String get_companies_url = AppConfig.getIp()+"sharePrice?Company="+initComp;

        /*get_companies_url =
                getString(R.string.initial_company_url);*/
        StringRequest jsonObjRequest1 = new StringRequest(Request.Method.GET, get_companies_url,
                fetchInitialCompanyDataSuccessListener(),
                fetchInitialCompanyErrorListener()) {
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("company", initComp);
                return params;
            }
        };

        jsonObjRequest1.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest1);
    }

    private Response.ErrorListener fetchInitialCompanyErrorListener() {
        return error -> {
            try {
                if (onRetry) {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            context);
                    alertDialogBuilder.setTitle(R.string.result);
                    alertDialogBuilder
                            .setMessage(R.string.badnetwork)
                            .setCancelable(false)
                            .setPositiveButton("OK", (dialog, id) -> {

                            });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                    onRetry = false;
                } else {
                    onRetry = true;
                    fetchInitialCompanyData();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        };
    }

    private Response.Listener<String> fetchInitialCompanyDataSuccessListener() {
        return response -> {
         /*   if (progressDialog != null)
                progressDialog.dismiss();*/
            try {
                JSONArray jsonArray = new JSONArray(response);
                Log.d("Data in ChartActivity ", response);
                if (response.isEmpty() || jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        if(i == 5)break;
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String date = jsonObject.optString("DateToday");
                        String price = jsonObject.optString("PricePerShare");
                        prices.add(Float.valueOf(price));
                        dates.add(date);

                    }
                    Collections.reverse(dates);
                    Collections.reverse(prices);
                    chartDataAdapter.setChartData(
                            dates,
                            prices,
                            context,
                            historyChart);

                } else {
                    historyChart.clear();
                    Toast.makeText(context,
                            R.string.nodata, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        };
    }
}
