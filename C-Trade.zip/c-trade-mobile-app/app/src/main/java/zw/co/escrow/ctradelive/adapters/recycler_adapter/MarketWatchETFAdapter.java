package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.MarketWatchETF;
import zw.co.escrow.ctradelive.view.CompanyAnalysisActivity;

public class MarketWatchETFAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<MarketWatchETF> marketWatchETF;
    private Activity activity;
    private static final String TAG = "MarketWatchETFAdapter";
    private final RecyclerView recyclerView;
    private SharedPreferences sharedPreferences;

    public MarketWatchETFAdapter(Activity activity, List<MarketWatchETF> marketWatchETF, RecyclerView recyclerView) {
        this.marketWatchETF = marketWatchETF;
        this.activity = activity;
        this.recyclerView = recyclerView;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.watch_list_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        view.setOnClickListener(v-> {

            Intent intent = new Intent(activity, CompanyAnalysisActivity.class);

            MarketWatchETF etf = marketWatchETF.get(recyclerView.getChildAdapterPosition(view));
            intent.putExtra("etf", etf);
            sharedPreferences = activity.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
            intent.putExtra("cdsnumber",sharedPreferences.getString("cds_number",""));
            activity.startActivity(intent);

        });

        return new WatchListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((WatchListViewHolder)holder).onBindData(marketWatchETF.get(position),activity);
    }


    @Override
    public int getItemCount() {
        return marketWatchETF.size();
    }

    static class WatchListViewHolder extends RecyclerView.ViewHolder{

        private TextView txtTicker, txtCompanyName, txtBestBid, txtBestAsk, txtCurrentPrice, txtPercentageChange;
        private CardView cardView, cardViewCompany;

        public WatchListViewHolder(@NonNull View itemView) {
            super(itemView);

            txtTicker = itemView.findViewById(R.id.txtTicker);
            txtCompanyName = itemView.findViewById(R.id.txtCompanyName);
            txtBestBid = itemView.findViewById(R.id.txtBestBid);
            txtBestAsk = itemView.findViewById(R.id.txtBestAsk);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtPercentageChange = itemView.findViewById(R.id.txtPercentageChange);
            cardView = itemView.findViewById(R.id.wl_change_indicator);
            cardViewCompany = itemView.findViewById(R.id.cardViewCompany);
        }
        public void onBindData(MarketWatchETF MarketWatchETF,Activity activity){
            txtTicker.setText(MarketWatchETF.getTicker());
            txtCompanyName.setText(MarketWatchETF.getFullCompanyName());
            txtBestBid.setText(String.format("BEST BID: %s", MarketWatchETF.getBest_bid()));
            txtBestAsk.setText(String.format("BEST ASK: %s", MarketWatchETF.getBest_Ask()));
            txtCurrentPrice.setText(String.valueOf(MarketWatchETF.getCurrent_price()));

            txtPercentageChange.setText(String.format("%s%%", MarketWatchETF.getPrevPer()));

            if (MarketWatchETF.getPrevChange() > 0){
                cardView.setCardBackgroundColor(activity.getResources().getColor(R.color.colorDarkGreen));
            }
        }
    }
}