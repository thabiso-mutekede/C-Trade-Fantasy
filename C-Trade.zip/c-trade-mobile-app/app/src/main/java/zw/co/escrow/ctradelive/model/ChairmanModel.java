package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class ChairmanModel implements Parcelable {

    private String name;
    private String idNumber;
    private String phoneNumber;
    private String cdsNumber;

    public ChairmanModel() {
    }

    protected ChairmanModel(Parcel in) {
        name = in.readString();
        idNumber = in.readString();
        phoneNumber = in.readString();
        cdsNumber = in.readString();
    }

    public static final Creator<ChairmanModel> CREATOR = new Creator<ChairmanModel>() {
        @Override
        public ChairmanModel createFromParcel(Parcel in) {
            return new ChairmanModel(in);
        }

        @Override
        public ChairmanModel[] newArray(int size) {
            return new ChairmanModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(idNumber);
        dest.writeString(phoneNumber);
        dest.writeString(cdsNumber);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCdsNumber() {
        return cdsNumber;
    }

    public void setCdsNumber(String cdsNumber) {
        this.cdsNumber = cdsNumber;
    }
}
