package zw.co.escrow.ctradelive.listeners;

import android.app.Dialog;

public interface OnHandOverDone {
    void handOverChairman(Dialog dialog,String gcdsnumber, String ccdsnumber, String mcdsnumber);
}
