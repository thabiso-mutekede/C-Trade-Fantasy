package zw.co.escrow.ctradelive.view.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnProductSelected;
import zw.co.escrow.ctradelive.view.FantasyView;
import zw.co.escrow.ctradelive.view.MarketWatchETFFragment;

public class ProductsContainerFantasyFragment  extends Fragment implements OnProductSelected {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.container_fragment,container,false);
        ProductsFragment productsFragment = new ProductsFragment();
        productsFragment.setOnProductSelected(this);
        ((FantasyView)getActivity()).productChanged("NONE");
        ((FantasyView)getActivity()).setProductSelected(this);
        getChildFragmentManager().beginTransaction().add(R.id.container,productsFragment).commit();
        return view;
    }

    @Override
    public void click(String product) {
        switch (product){
            case Constants.EQUITY:
                ((FantasyView)getActivity()).productChanged(Constants.EQUITY);
                getChildFragmentManager().beginTransaction().replace(R.id.container,MarketWatchZSEFragment.class,getArguments()).commit();
                break;
            case Constants.ETF:
                ((FantasyView)getActivity()).productChanged(Constants.ETF);
                getChildFragmentManager().beginTransaction().replace(R.id.container, MarketWatchETFFragment.class,getArguments()).commit();
                break;
            default:
                ((FantasyView)getActivity()).productChanged("NONE");
                ProductsFragment productsFragment = new ProductsFragment();
                productsFragment.setOnProductSelected(this);
                getChildFragmentManager().beginTransaction().replace(R.id.container,productsFragment).commit();
                break;
        }

    }
}
