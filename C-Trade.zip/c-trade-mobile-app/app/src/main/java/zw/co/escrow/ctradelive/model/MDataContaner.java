package zw.co.escrow.ctradelive.model;

import java.util.List;

public class MDataContaner {

    private String title;
    private List<MDisp> mDispList;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<MDisp> getmDispList() {
        return mDispList;
    }

    public void setmDispList(List<MDisp> mDispList) {
        this.mDispList = mDispList;
    }

    @Override
    public String toString() {
        return "MDataContaner{" +
                "title='" + title + '\'' +
                ", mDispList=" + mDispList +
                '}';
    }
}
