package zw.co.escrow.ctradelive;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.Group;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import zw.co.escrow.ctradelive.view.MainActivity;
import zw.co.escrow.ctradelive.view.PineView;

public class Login {

    private Activity activity;
    private AppConfig appConfig;
    private boolean onRetry = false;
    private String add_info_url, pin = "", email, emailSubject, emailBody, ip, mobileapi, fellOverIp1, fellOverIp2, ids, id, pass;
    private static final String TAG = "Login";
    private Group constraintLayoutGroup;
    private ProgressBar loadingSpinner;


    public Login(Activity activity) {
        this.activity = activity;
        appConfig = (AppConfig) activity.getApplication();
        ip = AppConfig.getIpAddress();
        mobileapi = AppConfig.getMobileApiAddress();

    }

    public void checkIdAndPassword(String emailAddress, String password) {

        if (onRetry) {
            add_info_url = fellOverIp2 + "/InvestorRegTest";
        } else {
            add_info_url = AppConfig.getFullMobileApiAddress() + "/InvestorRegTest";
        }


        StringRequest jsonObjRequest1 =
                new StringRequest(Request.Method.POST, add_info_url,
                        loginSuccessListenerAFTER(),
                        loginErrorListenerAFTER(emailAddress, password)) {
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<>();
                        params.put("idNumber", emailAddress);
                        params.put("pass", password);
                        return params;
                    }
                };

        jsonObjRequest1.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest1);
    }

    private Response.Listener<String> loginSuccessListenerAFTER() {

        Log.d("tavman success after", " here");


        return response -> {
            Log.d("response ", "" + response);



            try {
                System.out.println(response);

                if (response.equals("0")) {
                    constraintLayoutGroup.setVisibility(View.VISIBLE);
                    loadingSpinner.setVisibility(View.GONE);
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            activity);
                    alertDialogBuilder.setTitle(R.string.result);
                    alertDialogBuilder
                            .setMessage(R.string.invalid_credentials)
                            .setCancelable(false)
                            .setPositiveButton("OK", (dialog, id) -> {
                            });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                    Toast.makeText(activity, R.string.invalid_credentials, Toast.LENGTH_SHORT).show();


                }
                else if (response.equals("8")) {
                    constraintLayoutGroup.setVisibility(View.VISIBLE);
                    loadingSpinner.setVisibility(View.GONE);
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            activity);
                    alertDialogBuilder.setTitle(activity.getString(R.string.account_blocked_title));
                    alertDialogBuilder
                            .setMessage(R.string.account_blocked)
                            .setCancelable(false)
                            .setPositiveButton("OK", (dialog, id) -> {
                            });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
                else if (response.contains(activity.getString(R.string.otp_error))) {
                    constraintLayoutGroup.setVisibility(View.VISIBLE);
                    loadingSpinner.setVisibility(View.GONE);
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
                    alertDialogBuilder
                            .setMessage("Your OTP could not be sent at the moment, please try again.")
                            .setCancelable(false)
                            .setPositiveButton("OK", (dialog, id) -> {
                            });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
                else {

                    try {

                        JSONArray jsonArray = new JSONArray(response);

                        if (jsonArray.length() > 0) {

                            Log.d("Json array size ", " is " + jsonArray.length());

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                System.out.println("Json object " + jsonObject);
                                email = jsonObject.optString("email").trim().
                                        toLowerCase();
                                String name = jsonObject.optString("name");
                                String cds = jsonObject.optString("cds");
                                pin = jsonObject.optString("pin");
                                String broker = jsonObject.optString("broker");
                                boolean hasCompany = jsonObject.getBoolean("has_company");

                                String haveCompany;

                                if (hasCompany) haveCompany = activity.getString(android.R.string.yes);
                                else haveCompany = activity.getString(android.R.string.no);

                                Log.d("have company ", haveCompany);

                                emailSubject = "CTrabile login pin";
                                emailBody = "Your login pin is " + pin;
                                SharedPreferences pref = activity.getSharedPreferences(activity.getString(R.string.CTRADE), Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = pref.edit();
                                editor.putString("cds_number", cds);
                                editor.putString("email", email);
                                editor.putString("fullname", name);
                                editor.putString("mypin", pin);
                                long timestamp = Calendar.getInstance().getTime().getTime();
                                Log.e("timestamp :",timestamp+"") ;
                                editor.putLong("timestamp", timestamp);
                                editor.putBoolean("verified", false);
                                editor.putString("broker", broker);
                                editor.putString("version_code", "1");
                                editor.putString(activity.getString(R.string.has_company), haveCompany);
                                editor.apply();
                                appConfig.setCdsNumber(cds);
                                appConfig.setEmail(email);
                                appConfig.setName(name);

                                Log.d("Done", "Preferences set");

                            }

                            final String send_email_url = activity.getString(R.string.https).concat(mobileapi).concat("/sendmail");

                            Log.d("url", send_email_url);

                            startPineViewIntent();

                        } else {
                            Toast.makeText(activity,
                                    R.string.incorrect_password,
                                    Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(activity,
                                R.string.incorrect_password,
                                Toast.LENGTH_LONG).show();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                ;
    }

    private Response.ErrorListener loginErrorListenerAFTER(String emailAddress, String password) {

        return error -> {


            try {
                if (onRetry) {
                    constraintLayoutGroup.setVisibility(View.VISIBLE);
                    loadingSpinner.setVisibility(View.GONE);

                    new AlertDialog.Builder(activity)
                            .setTitle(R.string.result)
                            .setCancelable(false)
                            .setMessage(R.string.badnetwork)
                            .setPositiveButton("OK", (dialog, which) -> {

                            })
                            .show();
                    onRetry = false;
                } else {
                    onRetry = true;
                    checkIdAndPassword(emailAddress, password);
                }
            } catch (Exception e) {
            }
        };
    }





    private void startPineViewIntent() {

        activity.finish();
        activity.startActivity(new Intent(activity, PineView.class));

    }

}
