package zw.co.escrow.ctradelive;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.util.Log;

import com.android.volley.toolbox.JsonObjectRequest;
import com.developer.kalert.KAlertDialog;

import org.json.JSONObject;

public class ConvertFunds {

    private Activity activity;
    private KAlertDialog alertDialog;

    public ConvertFunds(Activity activity) {
        this.activity = activity;
    }

    public void convertFunds(String amount){
        alertDialog= new KAlertDialog(activity, KAlertDialog.SUCCESS_TYPE);
        alertDialog.setContentText("Please wait...").show();
        SharedPreferences prfs = activity.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        String cdsNumber = prfs.getString("cds_number", "");
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Constants.COMPLETE_URL("cash/convert"),Constants.amountIndividualJSON(cdsNumber,Float.parseFloat(amount)),
                response -> {
            try{
                alertDialog.dismiss();
                alertDialog= new KAlertDialog(activity, KAlertDialog.SUCCESS_TYPE);
                alertDialog.setContentText(response.getString("message")).setConfirmClickListener(kAlertDialog -> {
                    alertDialog.dismissWithAnimation();

                }).setConfirmText("Ok").show();
            }catch (Exception e){
                alertDialog.dismiss();
                alertDialog= new KAlertDialog(activity, KAlertDialog.SUCCESS_TYPE);
                alertDialog.setContentText("Done").setConfirmClickListener(kAlertDialog -> {
                    alertDialog.dismissWithAnimation();

                }).setConfirmText("Ok").show();
                updateBalance();
            }
        },error -> {
            error.printStackTrace();
            alertDialog = new KAlertDialog(activity, KAlertDialog.PROGRESS_TYPE);
            alertDialog.setContentText("Failed now, trying again").show();
            alertDialog.dismiss();
            alertDialog = new KAlertDialog(activity, KAlertDialog.SUCCESS_TYPE);
            alertDialog.setContentText("Done").setConfirmClickListener(kAlertDialog -> {
                alertDialog.dismissWithAnimation();
            });
        });
        AppConfig.getInstance().addToRequestQueue(jsonObjectRequest);
    }
    private void updateBalance() {

    }


}
