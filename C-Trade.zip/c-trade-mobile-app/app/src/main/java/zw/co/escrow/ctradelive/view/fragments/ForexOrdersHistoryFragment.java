package zw.co.escrow.ctradelive.view.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.fragment.app.Fragment;
//import androidx.recyclerview.widget.RecyclerView;
//
//import zw.co.escrow.ctradelive.R;
//import zw.co.escrow.ctradelive.setup.listeners.Forex;
//import zw.co.escrow.ctradelive.setup.services.ForexService;
//
//public class ForexOrdersHistoryFragment extends Fragment {
//
//
//    private Forex.ForexServicesListener forexServicesListener;
//    private RecyclerView recyclerView;
//    private String cdsnumber;
//
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//
//        View view = inflater.inflate(R.layout.forex_list_view,container,false);
//        recyclerView = view.findViewById(R.id.recyclerView);
//        forexServicesListener = new ForexService(getContext(),recyclerView);
//        cdsnumber = getActivity().getIntent().getExtras().getString("cdsnumber");
//        forexServicesListener.onGetBidOrdersHistory(cdsnumber);
//        return view;
//    }
//}
