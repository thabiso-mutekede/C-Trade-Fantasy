package zw.co.escrow.ctradelive.model;

public class MemberContribution {

    private String group;
    private String clubTotal;
    private String myTotal;
    private String myPercentage;

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getClubTotal() {
        return clubTotal;
    }

    public void setClubTotal(String clubTotal) {
        this.clubTotal = clubTotal;
    }

    public String getMyTotal() {
        return myTotal;
    }

    public void setMyTotal(String myTotal) {
        this.myTotal = myTotal;
    }

    public String getMyPercentage() {
        return myPercentage;
    }

    public void setMyPercentage(String myPercentage) {
        this.myPercentage = myPercentage;
    }
}
