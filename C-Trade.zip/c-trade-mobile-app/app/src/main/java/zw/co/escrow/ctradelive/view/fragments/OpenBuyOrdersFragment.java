package zw.co.escrow.ctradelive.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.OpenBuyOrdersAdapter;
import zw.co.escrow.ctradelive.listeners.OnPlaceOrder;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.OpenBuyOrder;
import zw.co.escrow.ctradelive.model.OrderDetails;
import zw.co.escrow.ctradelive.model.WatchListData;
import zw.co.escrow.ctradelive.view.dialogs.TradeClubPreloadedDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradeDialog;
import zw.co.escrow.ctradelive.view.dialogs.TradePreloadedDialog;

public class OpenBuyOrdersFragment extends Fragment implements OnPlaceOrder {

    private View view;
    private RecyclerView watchListRecyclerView;
    private List<WatchListData> watchListDataList;
    private static final String TAG = "OpenBuyOrdersFragment";
    private  List<OpenBuyOrder> openBuyOrders = new ArrayList<>();
    private String mobileip, felloverip1, felloverip2, ip, cds_number;
    private AppConfig appConfig;
    private OpenBuyOrder openBuyOrder;
    private Boolean isClub;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        watchListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

/*
        MarketWatchFINSECAsync marketWatchFINSECAsync = new MarketWatchFINSECAsync(getActivity() ,new DataRepository());
        marketWatchFINSECAsync.execute();

        ViewModelProvider viewModelProvider = new ViewModelProvider(getActivity());
        AppViewModel appViewModel = viewModelProvider.get(AppViewModel.class);

        //Observe date from https://demo.ctrade.co.zw/mobileapi/MarketWatchZSE and render on UI

        appViewModel.getMarketWatchFINSEC().observe(requireActivity(), marketWatchFINSECS -> {

            MarketWatchFINSECAdapter marketWatchFINSECAdapter = new MarketWatchFINSECAdapter(getActivity(), marketWatchFINSECS);
            watchListRecyclerView.setAdapter(marketWatchFINSECAdapter);

        });*/





        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        appConfig = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();
        SharedPreferences prfs = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cds_number = getArguments().getString("cdsnumber");
        isClub = getArguments().getBoolean("isClub");

        final String zse_url = "https://" + ip + "/marketwatchzsenewsells";
        StringRequest zseJsonRequest = new StringRequest(Request.Method.POST, zse_url,
                loginSuccessListenerZSE(),
                loginErrorListenerZSE()) {
        };
        zseJsonRequest.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        AppConfig.getInstance().addToRequestQueue(zseJsonRequest);
    }



    private com.android.volley.Response.Listener<String> loginSuccessListenerZSE() {
        return response -> {
            try {
                //Todo remove progress
                //progressDialog.dismiss();
                JSONArray array = new JSONArray(response);
                System.out.print(array.toString());
                for (int i = 0; i < array.length(); i++) {
                    JSONObject responses = array.getJSONObject(i);
                    String ticker = responses.getString("Ticker");
                    Log.d(TAG, "ticker: "+ticker);
                    String isin = responses.getString("ISIN");
                    Log.d(TAG, "isin: "+isin);
                    String fullCompanyName = responses.getString("FullCompanyName");
                    Log.d(TAG, "fullCompanyName: "+fullCompanyName);
                    String option = "[BUY]";
                    Log.d(TAG, "option: "+option);
                    String bestBid = responses.getString("Best_bid");
                    Log.d(TAG, "bestBid: "+bestBid);
                    String bidVolume = responses.getString("Bid_Volume");
                    Log.d(TAG, "bestBid: "+bestBid);
                    String currentPrice = responses.getString("Current_price");
                    Log.d(TAG, "currentPrice: "+currentPrice);
                    String more = "More";
                    Log.d(TAG, "more: "+more);
                    openBuyOrder = new OpenBuyOrder(fullCompanyName,ticker, isin, bestBid, currentPrice, bidVolume, option);
                    openBuyOrders.add(openBuyOrder);
                }

                OpenBuyOrdersAdapter openBuyOrdersAdapter  = new OpenBuyOrdersAdapter(getActivity(), openBuyOrders);
                openBuyOrdersAdapter.setOnPlaceOrder(this);
                watchListRecyclerView.setAdapter(openBuyOrdersAdapter);

            } catch (Exception e) {
                e.printStackTrace();
            }

        };
    }

    private com.android.volley.Response.ErrorListener loginErrorListenerZSE() {
        return error -> {
            error.printStackTrace();
            //progressDialog.dismiss();
            //Todo remove loading spinner
            new AlertDialog.Builder(Objects.requireNonNull(getActivity()))
                    .setCancelable(false)
                    .setMessage(getString(R.string.badnetwork))
                    .setPositiveButton("OK", (dialog, which) -> {

                    })
                    .show();
        };
    }

    @Override
    public void showDialog(OrderDetails orderDetails) {
        if(isClub){
            ClubModel clubModel = getArguments().getParcelable("club");
            TradeClubPreloadedDialog dialogBuy = TradeClubPreloadedDialog.newInstance("SELL",clubModel,orderDetails);
            FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
            dialogBuy.show(ftBuy, TradeDialog.TAG);
        }else {
            TradePreloadedDialog dialogBuy = TradePreloadedDialog.newInstance("SELL", cds_number,orderDetails);
            FragmentTransaction ftBuy = getActivity().getSupportFragmentManager().beginTransaction();
            dialogBuy.show(ftBuy, TradeDialog.TAG);
        }
    }
}