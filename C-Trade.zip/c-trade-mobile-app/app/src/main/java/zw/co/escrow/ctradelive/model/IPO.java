package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

public class IPO implements Parcelable {

    private Long ID_;
    private String Category;
    private String Issuer_Code;
    private String Debt_Type;
    private String Security_Description;
    private Date Date_Created;
    private Date CreatedBy;
    private Float GlobalLimit;
    private Float IndividualLimit;
    private Float DailyLimit;
    private String emailFrom;
    private String SMTPClient;
    private String NetworkCredUsername;
    private String NetworkCredPassword;
    private String SMTPport;
    private Float BidRatio;
    private String AirtelBidUsername;
    private String AirtelBidPassword;
    private String AirTelMarchantBillerCode;
    private Integer IPOSTATUS;
    private Float globLowerlimit;
    private Float firstlimit;
    private Float multiples;
    private Float InterestRate;
    private Date IPOClosedDate;
    private Float Transaction_Limit;
    private String NewIssuerCode;
    private Date Listing_Date;
    private String Issuer;


    protected IPO(Parcel in) {
        if (in.readByte() == 0) {
            ID_ = null;
        } else {
            ID_ = in.readLong();
        }
        Category = in.readString();
        Issuer_Code = in.readString();
        Debt_Type = in.readString();
        Security_Description = in.readString();
        if (in.readByte() == 0) {
            GlobalLimit = null;
        } else {
            GlobalLimit = in.readFloat();
        }
        if (in.readByte() == 0) {
            IndividualLimit = null;
        } else {
            IndividualLimit = in.readFloat();
        }
        if (in.readByte() == 0) {
            DailyLimit = null;
        } else {
            DailyLimit = in.readFloat();
        }
        emailFrom = in.readString();
        SMTPClient = in.readString();
        NetworkCredUsername = in.readString();
        NetworkCredPassword = in.readString();
        SMTPport = in.readString();
        if (in.readByte() == 0) {
            BidRatio = null;
        } else {
            BidRatio = in.readFloat();
        }
        AirtelBidUsername = in.readString();
        AirtelBidPassword = in.readString();
        AirTelMarchantBillerCode = in.readString();
        if (in.readByte() == 0) {
            IPOSTATUS = null;
        } else {
            IPOSTATUS = in.readInt();
        }
        if (in.readByte() == 0) {
            globLowerlimit = null;
        } else {
            globLowerlimit = in.readFloat();
        }
        if (in.readByte() == 0) {
            firstlimit = null;
        } else {
            firstlimit = in.readFloat();
        }
        if (in.readByte() == 0) {
            multiples = null;
        } else {
            multiples = in.readFloat();
        }
        if (in.readByte() == 0) {
            InterestRate = null;
        } else {
            InterestRate = in.readFloat();
        }
        if (in.readByte() == 0) {
            Transaction_Limit = null;
        } else {
            Transaction_Limit = in.readFloat();
        }
        NewIssuerCode = in.readString();
        Issuer = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (ID_ == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeLong(ID_);
        }
        dest.writeString(Category);
        dest.writeString(Issuer_Code);
        dest.writeString(Debt_Type);
        dest.writeString(Security_Description);
        if (GlobalLimit == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(GlobalLimit);
        }
        if (IndividualLimit == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(IndividualLimit);
        }
        if (DailyLimit == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(DailyLimit);
        }
        dest.writeString(emailFrom);
        dest.writeString(SMTPClient);
        dest.writeString(NetworkCredUsername);
        dest.writeString(NetworkCredPassword);
        dest.writeString(SMTPport);
        if (BidRatio == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(BidRatio);
        }
        dest.writeString(AirtelBidUsername);
        dest.writeString(AirtelBidPassword);
        dest.writeString(AirTelMarchantBillerCode);
        if (IPOSTATUS == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(IPOSTATUS);
        }
        if (globLowerlimit == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(globLowerlimit);
        }
        if (firstlimit == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(firstlimit);
        }
        if (multiples == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(multiples);
        }
        if (InterestRate == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(InterestRate);
        }
        if (Transaction_Limit == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeFloat(Transaction_Limit);
        }
        dest.writeString(NewIssuerCode);
        dest.writeString(Issuer);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<IPO> CREATOR = new Creator<IPO>() {
        @Override
        public IPO createFromParcel(Parcel in) {
            return new IPO(in);
        }

        @Override
        public IPO[] newArray(int size) {
            return new IPO[size];
        }
    };

    public Long getID_() {
        return ID_;
    }

    public void setID_(Long ID_) {
        this.ID_ = ID_;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getIssuer_Code() {
        return Issuer_Code;
    }

    public void setIssuer_Code(String issuer_Code) {
        Issuer_Code = issuer_Code;
    }

    public String getDebt_Type() {
        return Debt_Type;
    }

    public void setDebt_Type(String debt_Type) {
        Debt_Type = debt_Type;
    }

    public String getSecurity_Description() {
        return Security_Description;
    }

    public void setSecurity_Description(String security_Description) {
        Security_Description = security_Description;
    }

    public Date getDate_Created() {
        return Date_Created;
    }

    public void setDate_Created(Date date_Created) {
        Date_Created = date_Created;
    }

    public Date getCreatedBy() {
        return CreatedBy;
    }

    public void setCreatedBy(Date createdBy) {
        CreatedBy = createdBy;
    }

    public Float getGlobalLimit() {
        return GlobalLimit;
    }

    public void setGlobalLimit(Float globalLimit) {
        GlobalLimit = globalLimit;
    }

    public Float getIndividualLimit() {
        return IndividualLimit;
    }

    public void setIndividualLimit(Float individualLimit) {
        IndividualLimit = individualLimit;
    }

    public Float getDailyLimit() {
        return DailyLimit;
    }

    public void setDailyLimit(Float dailyLimit) {
        DailyLimit = dailyLimit;
    }

    public String getEmailFrom() {
        return emailFrom;
    }

    public void setEmailFrom(String emailFrom) {
        this.emailFrom = emailFrom;
    }

    public String getSMTPClient() {
        return SMTPClient;
    }

    public void setSMTPClient(String SMTPClient) {
        this.SMTPClient = SMTPClient;
    }

    public String getNetworkCredUsername() {
        return NetworkCredUsername;
    }

    public void setNetworkCredUsername(String networkCredUsername) {
        NetworkCredUsername = networkCredUsername;
    }

    public String getNetworkCredPassword() {
        return NetworkCredPassword;
    }

    public void setNetworkCredPassword(String networkCredPassword) {
        NetworkCredPassword = networkCredPassword;
    }

    public String getSMTPport() {
        return SMTPport;
    }

    public void setSMTPport(String SMTPport) {
        this.SMTPport = SMTPport;
    }

    public Float getBidRatio() {
        return BidRatio;
    }

    public void setBidRatio(Float bidRatio) {
        BidRatio = bidRatio;
    }

    public String getAirtelBidUsername() {
        return AirtelBidUsername;
    }

    public void setAirtelBidUsername(String airtelBidUsername) {
        AirtelBidUsername = airtelBidUsername;
    }

    public String getAirtelBidPassword() {
        return AirtelBidPassword;
    }

    public void setAirtelBidPassword(String airtelBidPassword) {
        AirtelBidPassword = airtelBidPassword;
    }

    public String getAirTelMarchantBillerCode() {
        return AirTelMarchantBillerCode;
    }

    public void setAirTelMarchantBillerCode(String airTelMarchantBillerCode) {
        AirTelMarchantBillerCode = airTelMarchantBillerCode;
    }

    public Integer getIPOSTATUS() {
        return IPOSTATUS;
    }

    public void setIPOSTATUS(Integer IPOSTATUS) {
        this.IPOSTATUS = IPOSTATUS;
    }

    public Float getGlobLowerlimit() {
        return globLowerlimit;
    }

    public void setGlobLowerlimit(Float globLowerlimit) {
        this.globLowerlimit = globLowerlimit;
    }

    public Float getFirstlimit() {
        return firstlimit;
    }

    public void setFirstlimit(Float firstlimit) {
        this.firstlimit = firstlimit;
    }

    public Float getMultiples() {
        return multiples;
    }

    public void setMultiples(Float multiples) {
        this.multiples = multiples;
    }

    public Float getInterestRate() {
        return InterestRate;
    }

    public void setInterestRate(Float interestRate) {
        InterestRate = interestRate;
    }

    public Date getIPOClosedDate() {
        return IPOClosedDate;
    }

    public void setIPOClosedDate(Date IPOClosedDate) {
        this.IPOClosedDate = IPOClosedDate;
    }

    public Float getTransaction_Limit() {
        return Transaction_Limit;
    }

    public void setTransaction_Limit(Float transaction_Limit) {
        Transaction_Limit = transaction_Limit;
    }

    public String getNewIssuerCode() {
        return NewIssuerCode;
    }

    public void setNewIssuerCode(String newIssuerCode) {
        NewIssuerCode = newIssuerCode;
    }

    public Date getListing_Date() {
        return Listing_Date;
    }

    public void setListing_Date(Date listing_Date) {
        Listing_Date = listing_Date;
    }

    public String getIssuer() {
        return Issuer;
    }

    public void setIssuer(String issuer) {
        Issuer = issuer;
    }

    public static Creator<IPO> getCREATOR() {
        return CREATOR;
    }

    @Override
    public String toString() {
        return "IPO{" +
                "ID_=" + ID_ +
                ", Category='" + Category + '\'' +
                ", Issuer_Code='" + Issuer_Code + '\'' +
                ", Debt_Type='" + Debt_Type + '\'' +
                ", Security_Description='" + Security_Description + '\'' +
                ", Date_Created=" + Date_Created +
                ", CreatedBy=" + CreatedBy +
                ", GlobalLimit=" + GlobalLimit +
                ", IndividualLimit=" + IndividualLimit +
                ", DailyLimit=" + DailyLimit +
                ", emailFrom='" + emailFrom + '\'' +
                ", SMTPClient='" + SMTPClient + '\'' +
                ", NetworkCredUsername='" + NetworkCredUsername + '\'' +
                ", NetworkCredPassword='" + NetworkCredPassword + '\'' +
                ", SMTPport='" + SMTPport + '\'' +
                ", BidRatio=" + BidRatio +
                ", AirtelBidUsername='" + AirtelBidUsername + '\'' +
                ", AirtelBidPassword='" + AirtelBidPassword + '\'' +
                ", AirTelMarchantBillerCode='" + AirTelMarchantBillerCode + '\'' +
                ", IPOSTATUS=" + IPOSTATUS +
                ", globLowerlimit=" + globLowerlimit +
                ", firstlimit=" + firstlimit +
                ", multiples=" + multiples +
                ", InterestRate=" + InterestRate +
                ", IPOClosedDate=" + IPOClosedDate +
                ", Transaction_Limit=" + Transaction_Limit +
                ", NewIssuerCode='" + NewIssuerCode + '\'' +
                ", Listing_Date=" + Listing_Date +
                ", Issuer='" + Issuer + '\'' +
                '}';
    }
}
