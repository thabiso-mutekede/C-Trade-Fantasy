package zw.co.escrow.ctradelive.adapters;

import android.app.Activity;
import android.os.Build;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.NewsFeed;


/**
 * @author Godwin Tavirimirwa
 */
public class NewsFeedsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<NewsFeed> newsFeedList;
    private Activity activity;
    private final RecyclerView recyclerView;


    @Override
    public int getItemViewType(int position) {
        return R.layout.news_feed_item;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView heading, counterInitial, change;
        public CardView cardViewNews;

        public MyViewHolder(View view) {
            super(view);
            heading = view.findViewById(R.id.tv_heading);
//            counterInitial = view.findViewById(R.id.tv_company_initial);
            change = view.findViewById(R.id.tv_change);
            cardViewNews = view.findViewById(R.id.cardViewNews);
        }

        public void bindData(NewsFeed newsFeed){
            heading.setText(newsFeed.getHeading());
            change.setText(newsFeed.getChange());
        }
    }

    public NewsFeedsAdapter(Activity activity, List<NewsFeed> newsFeedList, RecyclerView recyclerView) {
        this.newsFeedList = newsFeedList;
        this.activity = activity;
        this.recyclerView = recyclerView;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        view.setOnClickListener(v->{
            final TextView messageTextView = new TextView(activity);
            messageTextView.setTextColor(activity.getColor(R.color.white));
            messageTextView.setTextSize(15);

            NewsFeed newsFeed = newsFeedList.get(recyclerView.getChildAdapterPosition(view));
            String message = newsFeed.getTitle() + "\n";

            String title = newsFeed.getHeading();

            final SpannableString s =
                    new SpannableString(message);
            Linkify.addLinks(s, Linkify.WEB_URLS);
            messageTextView.setGravity(Gravity.CENTER);

            messageTextView.setText(s);
            messageTextView.setMovementMethod(LinkMovementMethod.getInstance());

            AlertDialog.Builder alert =
                    new AlertDialog.Builder(activity);
            alert.setTitle(title);
            alert.setView(messageTextView);

            alert.show();
        });



        return new MyViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((MyViewHolder)holder).bindData(newsFeedList.get(position));
    }

    @Override
    public int getItemCount() {
        return newsFeedList.size();
    }
}
