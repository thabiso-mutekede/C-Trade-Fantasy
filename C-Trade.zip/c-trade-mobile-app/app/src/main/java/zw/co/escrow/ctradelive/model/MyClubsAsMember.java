package zw.co.escrow.ctradelive.model;

import java.util.List;

public class MyClubsAsMember {
    List<MyClub> clublist ;

    public List<MyClub> getClublist() {
        return clublist;
    }

    public void setClublist(List<MyClub> clublist) {
        this.clublist = clublist;
    }
}
