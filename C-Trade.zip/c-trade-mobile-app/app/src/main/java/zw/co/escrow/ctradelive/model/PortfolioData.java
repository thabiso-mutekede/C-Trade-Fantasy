package zw.co.escrow.ctradelive.model;

public class PortfolioData {
    private String counter;
    private String type;
    private String quantity;
    private String price;

    public PortfolioData() {
    }

    public PortfolioData(String counter, String type, String quantity, String price) {
        this.counter = counter;
        this.type = type;
        this.quantity = quantity;
        this.price = price;
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}