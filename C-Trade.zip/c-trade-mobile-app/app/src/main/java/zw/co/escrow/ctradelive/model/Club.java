package zw.co.escrow.ctradelive.model;

import android.os.Parcelable;

public  abstract class Club implements Parcelable {

}
