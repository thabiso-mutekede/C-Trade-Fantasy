package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class CTradeActivity implements Parcelable {

    private String type;
    private String description;
    private String act_date;

    public CTradeActivity() {
    }

    protected CTradeActivity(Parcel in) {
        type = in.readString();
        description = in.readString();
        act_date = in.readString();
    }

    public static final Creator<CTradeActivity> CREATOR = new Creator<CTradeActivity>() {
        @Override
        public CTradeActivity createFromParcel(Parcel in) {
            return new CTradeActivity(in);
        }

        @Override
        public CTradeActivity[] newArray(int size) {
            return new CTradeActivity[size];
        }
    };

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAct_date() {
        return act_date;
    }

    public void setAct_date(String act_date) {
        this.act_date = act_date;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(type);
        parcel.writeString(description);
        parcel.writeString(act_date);
    }
}
