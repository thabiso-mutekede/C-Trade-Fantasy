package zw.co.escrow.ctradelive.model;


import android.os.Parcel;
import android.os.Parcelable;

public class OpenBuyOrder implements Parcelable {

    private String fullCompanyName, ticker, isin, bestBid, currentPrice, bidVolume, option;




    public OpenBuyOrder() {
    }


    public OpenBuyOrder(String fullCompanyName, String ticker, String isin, String bestBid, String currentPrice, String bidVolume, String option) {
        this.fullCompanyName = fullCompanyName;
        this.ticker = ticker;
        this.isin = isin;
        this.bestBid = bestBid;
        this.currentPrice = currentPrice;
        this.bidVolume = bidVolume;
        this.option = option;
    }

    protected OpenBuyOrder(Parcel in) {
        fullCompanyName = in.readString();
        ticker = in.readString();
        isin = in.readString();
        bestBid = in.readString();
        currentPrice = in.readString();
        bidVolume = in.readString();
        option = in.readString();
    }

    public static final Creator<OpenBuyOrder> CREATOR = new Creator<OpenBuyOrder>() {
        @Override
        public OpenBuyOrder createFromParcel(Parcel in) {
            return new OpenBuyOrder(in);
        }

        @Override
        public OpenBuyOrder[] newArray(int size) {
            return new OpenBuyOrder[size];
        }
    };

    public String getFullCompanyName() {
        return fullCompanyName;
    }

    public void setFullCompanyName(String fullCompanyName) {
        this.fullCompanyName = fullCompanyName;
    }

    public String getOption() {
        return option;
    }

    public void setOption(String option) {
        this.option = option;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public String getBestBid() {
        return bestBid;
    }

    public void setBestBid(String bestBid) {
        this.bestBid = bestBid;
    }

    public String getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public String getBidVolume() {
        return bidVolume;
    }

    public void setBidVolume(String bidVolume) {
        this.bidVolume = bidVolume;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(fullCompanyName);
        parcel.writeString(ticker);
        parcel.writeString(isin);
        parcel.writeString(bestBid);
        parcel.writeString(currentPrice);
        parcel.writeString(bidVolume);
        parcel.writeString(option);
    }
}