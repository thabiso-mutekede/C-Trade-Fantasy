package zw.co.escrow.ctradelive.adapters.header_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import de.codecrafters.tableview.TableDataAdapter;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.CPAYTransaction;


public class CpayCashColumnAdapter extends TableDataAdapter {

    TextView textView;
    ImageView imageView;

    public CpayCashColumnAdapter(Context context, List data) {
        super(context, data);
    }


    @SuppressLint("ResourceAsColor")
    @Override
    public View getCellView(int rowIndex, int columnIndex, ViewGroup parentView) {

        View view = LayoutInflater.from(parentView.getContext()).inflate(R.layout.universal_column_adapter_view,parentView,false);
        textView = view.findViewById(R.id.text_id);
        imageView = view.findViewById(R.id.more_img);
        CPAYTransaction cpayTransaction = (CPAYTransaction) getData().get(rowIndex);
        Float am = Float.parseFloat(cpayTransaction.getAmount());
        switch (columnIndex){
            case 0:
                //textView.setTextColor(Color.parseColor("#39ff14"));
                textView.setText(cpayTransaction.getDate_created());
                break;
            case 1:
                if(am>0)
                    textView.setTextColor(Color.parseColor("#39ff14"));
                else
                    textView.setTextColor(Color.parseColor("#FF4233"));

                textView.setText(cpayTransaction.getTransaction_type());
                break;
            case 2:
                //#FF4081
                textView.setText(cpayTransaction.getCurrency());
                break;
            case 3:
                if(am>0)
                    textView.setTextColor(Color.parseColor("#39ff14"));
                else
                    textView.setTextColor(Color.parseColor("#FF4233"));
                //textView.setTextColor(Color.parseColor("#FF4081"));
                textView.setText(Constants.getThousandSep(am));
                break;
        }
        return view;
    }

}
