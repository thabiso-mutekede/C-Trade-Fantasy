package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Portfolio implements Parcelable {
    
    private String counter;
    private Double numbershares;
    private String lastactivitydate;
    private Double currentprice;
    private Double prevprice;
    private Double totalportvalue;
    private String uncleared;
    private Double net;
    private Double totalPrevPortValue;
    private String returns;
    private String companyFullName;

    public Portfolio() {
    }

    protected Portfolio(Parcel in) {
        counter = in.readString();
        if (in.readByte() == 0) {
            numbershares = null;
        } else {
            numbershares = in.readDouble();
        }
        lastactivitydate = in.readString();
        if (in.readByte() == 0) {
            currentprice = null;
        } else {
            currentprice = in.readDouble();
        }
        if (in.readByte() == 0) {
            prevprice = null;
        } else {
            prevprice = in.readDouble();
        }
        if (in.readByte() == 0) {
            totalportvalue = null;
        } else {
            totalportvalue = in.readDouble();
        }
        uncleared = in.readString();
        if (in.readByte() == 0) {
            net = null;
        } else {
            net = in.readDouble();
        }
        if (in.readByte() == 0) {
            totalPrevPortValue = null;
        } else {
            totalPrevPortValue = in.readDouble();
        }
        returns = in.readString();
        companyFullName = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(counter);
        if (numbershares == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(numbershares);
        }
        dest.writeString(lastactivitydate);
        if (currentprice == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(currentprice);
        }
        if (prevprice == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(prevprice);
        }
        if (totalportvalue == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(totalportvalue);
        }
        dest.writeString(uncleared);
        if (net == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(net);
        }
        if (totalPrevPortValue == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(totalPrevPortValue);
        }
        dest.writeString(returns);
        dest.writeString(companyFullName);
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public Double getNumbershares() {
        return numbershares;
    }

    public void setNumbershares(Double numbershares) {
        this.numbershares = numbershares;
    }

    public String getLastactivitydate() {
        return lastactivitydate;
    }

    public void setLastactivitydate(String lastactivitydate) {
        this.lastactivitydate = lastactivitydate;
    }

    public Double getCurrentprice() {
        return currentprice;
    }

    public void setCurrentprice(Double currentprice) {
        this.currentprice = currentprice;
    }

    public Double getPrevprice() {
        return prevprice;
    }

    public void setPrevprice(Double prevprice) {
        this.prevprice = prevprice;
    }

    public Double getTotalportvalue() {
        return totalportvalue;
    }

    public void setTotalportvalue(Double totalportvalue) {
        this.totalportvalue = totalportvalue;
    }

    public String getUncleared() {
        return uncleared;
    }

    public void setUncleared(String uncleared) {
        this.uncleared = uncleared;
    }

    public Double getNet() {
        return net;
    }

    public void setNet(Double net) {
        this.net = net;
    }

    public Double getTotalPrevPortValue() {
        return totalPrevPortValue;
    }

    public void setTotalPrevPortValue(Double totalPrevPortValue) {
        this.totalPrevPortValue = totalPrevPortValue;
    }

    public String getReturns() {
        return returns;
    }

    public void setReturns(String returns) {
        this.returns = returns;
    }

    public String getCompanyFullName() {
        return companyFullName;
    }

    public void setCompanyFullName(String companyFullName) {
        this.companyFullName = companyFullName;
    }

    public static Creator<Portfolio> getCREATOR() {
        return CREATOR;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Portfolio> CREATOR = new Creator<Portfolio>() {
        @Override
        public Portfolio createFromParcel(Parcel in) {
            return new Portfolio(in);
        }

        @Override
        public Portfolio[] newArray(int size) {
            return new Portfolio[size];
        }
    };
}
