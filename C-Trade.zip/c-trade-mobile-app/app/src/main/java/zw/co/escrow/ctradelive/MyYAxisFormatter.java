package zw.co.escrow.ctradelive;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;


public class MyYAxisFormatter implements IAxisValueFormatter {

    @Override
    public String getFormattedValue(float v, AxisBase axisBase) {
        return StringUtils.getPrice(v);
    }
}
