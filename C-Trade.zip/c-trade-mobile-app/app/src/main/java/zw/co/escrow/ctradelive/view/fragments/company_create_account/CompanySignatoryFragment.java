package zw.co.escrow.ctradelive.view.fragments.company_create_account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.SignatoryAdapter;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.model.Signatory;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class CompanySignatoryFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "DETAILS";
    private LoginViewModel loginViewModel;
    private Utils utils;
    //TODO details to object
    private TextInputLayout outlinedTextFieldSignatoryName, outlinedTextFieldSignatoryEmail, outlinedTextFieldSignatoryPhone, outlinedTextFieldSignatoryPassword;
    private MaterialCheckBox checkbox_initiator, checkbox_authoriser;
    private boolean initiator, authoriser;
    private FloatingActionButton floating_action_button;
    private Signatory signatory;
    private boolean isSignatoryComplete = false;
    private RegistrationData registrationData;
    private RecyclerView signatory_rv;





    public static CompanySignatoryFragment newInstance(RegistrationData registrationData) {
        CompanySignatoryFragment fragment = new CompanySignatoryFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;

        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_company_signatory_details, container, false);

        initWidgets(root);

        utils = new Utils(getActivity());


        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
            registrationData.getRegistrationSession().setDetailsDone(true);
        }
        loadSignatories();
        checkbox_authoriser.setOnCheckedChangeListener((compoundButton, b) -> {
            authoriser=b;
        });

        checkbox_initiator.setOnCheckedChangeListener((compoundButton, b) -> {
            initiator=b;

        });


        floating_action_button.setOnClickListener(view -> {



            if (!checkbox_initiator.isChecked() && !checkbox_authoriser.isChecked()){

                Toast.makeText(getActivity(), "At least one permission is required", Toast.LENGTH_LONG).show();

            }
            else {

                String signatoryName = outlinedTextFieldSignatoryName.getEditText().getText().toString()
                        ,signatoryEmail = outlinedTextFieldSignatoryEmail.getEditText().getText().toString()
                        ,signatoryPhone = outlinedTextFieldSignatoryPhone.getEditText().getText().toString()
                        ,signatoryPassword = outlinedTextFieldSignatoryPassword.getEditText().getText().toString();




                if (signatoryName.equals("")) {
                    outlinedTextFieldSignatoryName.setError("Please enter full name");
                }
                else if (signatoryEmail.equals("")) {
                    outlinedTextFieldSignatoryEmail.setError("Please enter email");

                }
                else if (signatoryPhone.equals("")) {
                    outlinedTextFieldSignatoryPhone.setError("Please enter phone number");

                }
                else if (signatoryPassword.equals("")){
                    outlinedTextFieldSignatoryPassword.setError("Please enter password");

                }
                else {
                    signatory = new Signatory(signatoryName, signatoryEmail, signatoryPhone, signatoryPassword, initiator, authoriser);
                    if(registrationData.getSignatories() == null)
                        registrationData.setSignatories(new ArrayList<>());
                    registrationData.getSignatories().add(signatory);
                    Toast.makeText(getActivity(), "Added " + signatoryName, Toast.LENGTH_LONG).show();
                    loadSignatories();
                    outlinedTextFieldSignatoryName.getEditText().setText("");
                    outlinedTextFieldSignatoryEmail.getEditText().setText("");
                    outlinedTextFieldSignatoryPhone.getEditText().setText("");
                    outlinedTextFieldSignatoryPassword.getEditText().setText("");

                    checkbox_initiator.setChecked(false);
                    checkbox_authoriser.setChecked(false);
                }
            }
        });

        root.findViewById(R.id.btnBack).setOnClickListener(v->
            utils.startNewFragment(root, CompanySignatoryFragment.this, CompanyDetailsFragment.newInstance(registrationData))
        );
        root.findViewById(R.id.btnNext).setOnClickListener(v->{
            if (registrationData.getSignatories() != null && registrationData.getSignatories().size() > 0){
                utils.startNewFragment(root, CompanySignatoryFragment.this, CompanyCustodianDetailsFragment.newInstance(registrationData));
            }
            else {
                Toast.makeText(getActivity(), "Please complete all fields", Toast.LENGTH_LONG).show();
            }
        });
        return root;
    }
    private void initWidgets(View view){
        outlinedTextFieldSignatoryName =view.findViewById(R.id.outlinedTextFieldSignatoryName);
        outlinedTextFieldSignatoryEmail =view.findViewById(R.id.outlinedTextFieldSignatoryEmail);
        outlinedTextFieldSignatoryPhone =view.findViewById(R.id.outlinedTextFieldSignatoryPhone);
        outlinedTextFieldSignatoryPassword =view.findViewById(R.id.outlinedTextFieldSignatoryPassword);
        checkbox_initiator=view.findViewById(R.id.checkbox_initiator);
        checkbox_authoriser=view.findViewById(R.id.checkbox_authoriser);
        floating_action_button=view.findViewById(R.id.floating_action_button);

        signatory_rv = view.findViewById(R.id.signatory_rv);
        signatory_rv.setHasFixedSize(true);
        signatory_rv.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void loadSignatories(){
        if(registrationData.getSignatories() != null
                &&registrationData.getSignatories().size() > 0)
            signatory_rv.setAdapter(new SignatoryAdapter(registrationData.getSignatories()));
    }
}