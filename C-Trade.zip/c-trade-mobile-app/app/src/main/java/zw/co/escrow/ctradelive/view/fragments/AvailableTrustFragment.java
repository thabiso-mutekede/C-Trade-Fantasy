package zw.co.escrow.ctradelive.view.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.TrustCounterAdapter;
import zw.co.escrow.ctradelive.model.Counter;
import zw.co.escrow.ctradelive.model.WatchListData;

public class AvailableTrustFragment extends Fragment {

    private View view;
    private RecyclerView watchListRecyclerView;
    private List<WatchListData> watchListDataList;
    private static final String TAG = "AvailableTrustFragment";
    private String mobileip, felloverip1, felloverip2, ip, cds_number;
    private AppConfig appConfig;

    private List<Counter> counterList = new ArrayList<>();




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = LayoutInflater.from(getContext()).inflate(R.layout.watch_list_view,container,false);
        watchListRecyclerView = view.findViewById(R.id.watch_list_recycler_id);
        watchListRecyclerView.setHasFixedSize(true);
        watchListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        appConfig = (AppConfig) getActivity().getApplication();
        ip = AppConfig.getIpAddress();
        mobileip = AppConfig.getMobileApiAddress();

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        counterList.clear();
        getTrusts();

        SharedPreferences prfs = getActivity().
                getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cds_number = prfs.getString("cds_number", "");


    }

    private void getTrusts() {

        StringRequest jsonObjRequest1 =
                new StringRequest(Constants.COMPLETE_URL("data/unit_trusts"),
                        trustsSuccessListener(),
                        trustsErrorListener());

        jsonObjRequest1.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest1);
    }

    private Response.Listener<String> trustsSuccessListener() {

        Log.d("tavman success listener", " trusts");

        return response -> {
            Log.d("tavman response trusts", "" + response);


            //Todo remove progress

            try {
                System.out.println(response);

                if (response.equals(getString(R.string.no_data_was_found))) {
                   // showDialog(getString(R.string.no_data_was_found));
                } else {

                    try {

                        JSONArray jsonArray = new JSONArray(response);

                        if (jsonArray.length() > 0) {

                            Log.d("Json array size ", " is " + jsonArray.length());

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                System.out.println("Json object " + jsonObject);

                                String fullname = jsonObject.optString("fullName");
                                String company = jsonObject.optString("company");
                                String initialPrice = jsonObject.optString("initialPrice");
                                String issuedShares = jsonObject.optString("issuedUnits");
                                Log.d(TAG, "trustsSuccessListener: "+fullname);

                                counterList.add(new Counter(company, fullname, initialPrice, issuedShares));

                            }

                            watchListRecyclerView.setAdapter(new TrustCounterAdapter(getActivity(), counterList));


                        } else {
                        //    showDialog(getString(R.string.no_data_was_found));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                       // showDialog(getString(R.string.no_data_was_found));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        };

    }

    private Response.ErrorListener trustsErrorListener() {

        return error -> {

            Log.d("tavman error listener", error.toString());
            //Dismis dialog

            try {

                new AlertDialog.Builder(getContext())
                        .setTitle(R.string.result)
                        .setCancelable(false)
                        .setMessage(R.string.no_data_was_found)
                        .setPositiveButton("OK", (dialog, which) -> {
                            //getActivity().finish();
                            // startActivity(new Intent(getActivity(),
                            //  AvailableTrusts.class));
                        })
                        .show();
            } catch (Exception e) {
            }
        };
    }



}