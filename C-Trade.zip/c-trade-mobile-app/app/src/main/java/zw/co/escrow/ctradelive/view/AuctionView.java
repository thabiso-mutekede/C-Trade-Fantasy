package zw.co.escrow.ctradelive.view;
//
//import android.app.Dialog;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.View;
//import android.widget.ProgressBar;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.Toolbar;
//import androidx.lifecycle.ViewModelProvider;
//import androidx.viewpager.widget.ViewPager;
//
//import com.github.ybq.android.spinkit.style.MultiplePulseRing;
//import com.google.android.material.appbar.AppBarLayout;
//import com.google.android.material.bottomappbar.BottomAppBar;
//import com.google.gson.Gson;
//import com.google.gson.JsonObject;
//import com.mikepenz.materialdrawer.holder.StringHolder;
//import com.ogaclejapan.smarttablayout.SmartTabLayout;
//import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
//import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;
//
//import org.json.JSONObject;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//import zw.co.escrow.ctradelive.ApiClubInterface;
//import zw.co.escrow.ctradelive.Constants;
//import zw.co.escrow.ctradelive.R;
//import zw.co.escrow.ctradelive.Utils;
//import zw.co.escrow.ctradelive.setup.listeners.Forex;
//import zw.co.escrow.ctradelive.setup.services.ForexService;
//import zw.co.escrow.ctradelive.view.dialogs.CPayCashDialog;
//import zw.co.escrow.ctradelive.view.dialogs.CreateClubDialog;
//import zw.co.escrow.ctradelive.view.fragments.ForexOrdersFragment;
//import zw.co.escrow.ctradelive.view.fragments.ForexOrdersHistoryFragment;
//import zw.co.escrow.ctradelive.view.fragments.ForexPortfolioFragment;
//import zw.co.escrow.ctradelive.view_model.AppViewModel;
//
//public class AuctionView extends AppCompatActivity implements View.OnClickListener , CreateClubDialog.OnSubmitListener {
//
//    private FragmentPagerItemAdapter watchListPagerAdapter;
//    private ViewPager watchListPager;
//    private SmartTabLayout watchListPagerTab;
//    private AppBarLayout appBarLayout;
//    private BottomAppBar bottomAppBar;
//    private static final String TAG = "MainActivity";
//    private Forex.ForexServicesListener forexServicesListener;
//
//    private String cds_number;
//    private String phone_number;
//    private String email;
//
//    private TextView txtUnclearedCash,txtClearedCash, txtCashBalance, txtMyPortfolio, txtTotalAccount, txtNetPerfomance, txtForexWallerBalance, txtOutStandingCharges;
//    private String cdsNumber;
//    private SharedPreferences sharedPreferences;
//
//    private ProgressBar loadingSpinner;
//    private MultiplePulseRing multiplePulseRing;
//    private Toolbar toolbar;
//    private SharedPreferences preferences;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.auction_view_main);
//        //Change the status bar color to black to match the app's theme and should be in every activity
//        Utils.setStatusBarColor(AuctionView.this);
//        initWidgets();
//
//        findViewById(R.id.chipBid).setOnClickListener(this);
//        findViewById(R.id.chipTxn).setOnClickListener(this);
//        forexServicesListener = new ForexService(this);
//
//        toolbar = findViewById(R.id.toolbar);
//        toolbar.setTitle("FX Auction");
//        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
//        toolbar.setNavigationOnClickListener(v -> finish());
//        sharedPreferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
//        cdsNumber = sharedPreferences.getString("cds_number", "");
//
//        preferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
//        cdsNumber = preferences.getString("cds_number", "");
//        cds_number = preferences.getString("cds_number", "");
//        email = preferences.getString("email","");
//
//        //Read my cash and populate the view if cds number is not empty
//        if (!cdsNumber.equals("")){
//            MyCashAsyncTask myCashAsyncTask = new MyCashAsyncTask(this ,new DataRepository());
//            myCashAsyncTask.execute(cdsNumber);
//            ViewModelProvider viewModelProvider = new ViewModelProvider(this);
//            AppViewModel appViewModel = viewModelProvider.get(AppViewModel.class);
//            //Observe data from https://demo.ctrade.co.zw/mobileapi/ and render on UI
//            appViewModel.getMyCash().observe(this, myCashList -> {
//
//                if (myCashList.size() == 0){
//                    Toast.makeText(this, "Check network connection", Toast.LENGTH_SHORT).show();
//                    loadingSpinner.setVisibility(View.GONE);
//                    appBarLayout.setVisibility(View.VISIBLE);
//                    watchListPagerTab.setVisibility(View.VISIBLE);
//                    watchListPager.setVisibility(View.VISIBLE);
//                    bottomAppBar.setVisibility(View.VISIBLE);
//
//                }
//                else {
//                    loadingSpinner.setVisibility(View.GONE);
//                    appBarLayout.setVisibility(View.VISIBLE);
//                    watchListPagerTab.setVisibility(View.VISIBLE);
//                    watchListPager.setVisibility(View.VISIBLE);
//                    bottomAppBar.setVisibility(View.VISIBLE);
//                    txtUnclearedCash.setText(String.format("$ %s", myCashList.get(0).getVirtCashBal()));
//                    txtClearedCash.setText(String.format("$ %s", myCashList.get(0).getCashBal()));
//                    txtCashBalance.setText(String.format("$ %s", myCashList.get(0).getActualCashBal()));
//                    txtMyPortfolio.setText(String.format("$ %s", myCashList.get(0).getMyPotValue()));
//                    txtTotalAccount.setText(String.format("$ %s", myCashList.get(0).getTotalAccount()));
//                    txtNetPerfomance.setText(String.format("$ %s", myCashList.get(0).getMyProfitLoss()));
//                    txtForexWallerBalance.setText(String.format("$ %s", "0.00"));
//                    txtOutStandingCharges.setText(String.format("$ %s", myCashList.get(0).getMyProfitLoss()));
//                }
//            });
//
//        }
//        else {
//            loadingSpinner.setVisibility(View.GONE);
//            appBarLayout.setVisibility(View.VISIBLE);
//            watchListPagerTab.setVisibility(View.VISIBLE);
//            watchListPager.setVisibility(View.VISIBLE);
//            bottomAppBar.setVisibility(View.VISIBLE);
//        }
//
//
//
//        setUpWatchList();
//        setUpView();
//    }
//
//    private void initWidgets(){
//        appBarLayout = findViewById(R.id.appbar);
//        bottomAppBar = findViewById(R.id.bottom_app_bar);
//
//        watchListPagerTab = findViewById(R.id.viewpagertab);
//        watchListPager = findViewById(R.id.viewPagerWatchList);
//
//        txtUnclearedCash = findViewById(R.id.txtUnclearedCash);
//        txtClearedCash = findViewById(R.id.txtClearedCash);
//        txtCashBalance = findViewById(R.id.txtCashBalance);
//        txtMyPortfolio = findViewById(R.id.txtMyPortfolio);
//        txtTotalAccount = findViewById(R.id.txtTotalAccount);
//        txtNetPerfomance = findViewById(R.id.txtNetPerfomance);
//        txtForexWallerBalance = findViewById(R.id.txtForexWallerBalance);
//        txtOutStandingCharges = findViewById(R.id.txtOutStandingCharges);
//        loadingSpinner = findViewById(R.id.loadingSpinner);
//        multiplePulseRing = new MultiplePulseRing();
//        loadingSpinner.setIndeterminateDrawable(multiplePulseRing);
//        loadingSpinner.setVisibility(View.VISIBLE);
//    }
//
//    private void setUpWatchList(){
//
//
//        watchListPagerAdapter = new FragmentPagerItemAdapter(
//                getSupportFragmentManager(), FragmentPagerItems.with(this)
//                .add("Recent Orders", ForexOrdersFragment.class)
//                .add("Processed Orders", ForexOrdersHistoryFragment.class)
//                .add("Auction Portfolio",ForexPortfolioFragment.class)
//                .create());
//        watchListPager.setAdapter(watchListPagerAdapter);
//        watchListPagerTab.setViewPager(watchListPager);
//    }
//
//
//    @Override
//    public void onClick(View view) {
//
//        switch (view.getId()) {
//            case R.id.chipTxn:
//                new CPayCashDialog(this, cdsNumber).show();
//                break;
//            case R.id.chipBid:
//                forexServicesListener.checkRegDocumentsForCPay(cdsNumber);
//                break;
//        }
//
//    }
//
//    private StringHolder setTitle(String title){
//        return new StringHolder(title);
//    }
//
//    private void setUpView(){
//        //viewsLayout.setVisibility(View.GONE);
//        //c_tradeMainDashboard.setVisibility(View.VISIBLE);
//
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        String amount;
//        switch (requestCode){
//            case Constants.CONVERT_REQUEST_CODE:
//                amount= data != null ? data.getStringExtra("AMOUNT") : null;
//                Toast.makeText(this, "Converted "+amount, Toast.LENGTH_SHORT).show();
//                break;
//            case Constants.WITHDRAW_REQUEST_CODE:
//                amount= data != null ? data.getStringExtra("AMOUNT") : null;
//                Toast.makeText(this, "Withdrew "+amount, Toast.LENGTH_SHORT).show();
//                break;
//            case Constants.DEPOSIT_REQUEST_CODE:
//
//                Toast.makeText(this, "Yah", Toast.LENGTH_LONG).show();
//
//  /*              String[] depositDetails =  data.getStringArrayExtra("DEPOSIT_DETAILS");
//
//                for (String depositDetail : depositDetails) {
//                    Log.d(TAG, "onActivityResult: " + depositDetail);
//                }*/
//                break;
//        }
//    }
//
//    @Override
//    public void createGroup(String groupName, String welcomeMessage, String isPublic, Dialog dialog) {
//        dialog.dismiss();
//        ApiClubInterface api = CtradeApiClient.getApiService();
//        Call<JsonObject> call = api.createANewInvestmentClub(cds_number,phone_number,groupName,welcomeMessage,isPublic,email);
//        call.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
//                try{
//
//                    Log.d("lloda",response.body().toString());
//                    JSONObject j = new JSONObject(new Gson().toJson(response.body()));
//                    boolean b = j.getBoolean("status");
//                    if(b){
//                        new android.app.AlertDialog.Builder(AuctionView.this)
//                                .setMessage(j.getString("message"))
//                                .setPositiveButton("ok",null)//((dialog1, which) ->int i = 0
//                                       // startActivity(new Intent(this,MyInvestmentClubsView.class))
//                                //))
//                                .create()
//                                .show();
//                    }else{
//                        showDialog(j.getString("message"));
//                    }
//                }catch (Exception e){
//                    e.printStackTrace();
//                    showDialog("Failed To Read Data.Please Try Again Later");
//                }
//            }
//            @Override
//            public void onFailure(Call<JsonObject> call, Throwable t) {
//                showDialog("Error On Connecting.Please Try Again Later");
//                t.printStackTrace();
//            }
//        });
//    }
//    private void showDialog(String message){
//        new android.app.AlertDialog.Builder(this)
//                .setMessage(message)
//                .setPositiveButton("ok",null)
//                .create()
//                .show();
//    }
//}