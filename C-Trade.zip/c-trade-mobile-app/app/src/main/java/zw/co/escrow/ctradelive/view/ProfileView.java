package zw.co.escrow.ctradelive.view;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.github.ybq.android.spinkit.SpinKitView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnProfileChanged;
import zw.co.escrow.ctradelive.model.Profile;
import zw.co.escrow.ctradelive.view.dialogs.ChangeDetailsDialog;
import zw.co.escrow.ctradelive.view.dialogs.SecurityQuestions;


public class ProfileView extends AppCompatActivity implements View.OnClickListener , OnProfileChanged, SecurityQuestions.Complete {

    private TextView names, broker, bank, branch, bankAccountNumber, custodian, idNumber, mobileNumber,my_email,my_cds_no,address;
    private SpinKitView spinKitView;
    private SharedPreferences sharedPreferences;
    private String cdsNumber;
    private ProgressDialog progressDialog;
    private Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_main);
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        broker = findViewById(R.id.broker);
        names = findViewById(R.id.names);
        bank = findViewById(R.id.bank);
        branch = findViewById(R.id.branch);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Profile");
        toolbar.setNavigationIcon(R.drawable.ef_ic_arrow_back);
        toolbar.setNavigationOnClickListener(view -> finish());
        bankAccountNumber = findViewById(R.id.bank_account_number);
        custodian = findViewById(R.id.custodian);
        idNumber = findViewById(R.id.id_number);
        mobileNumber = findViewById(R.id.mobile_number);
        my_email = findViewById(R.id.my_email);
        my_cds_no = findViewById(R.id.cds_no);
        address = findViewById(R.id.address);
        findViewById(R.id.reset_secQBtn).setOnClickListener(view -> {
            SecurityQuestions securityQuestions =
                    new SecurityQuestions(this,my_cds_no.getText().toString(),false,null);
            securityQuestions.setComplete(this);
            securityQuestions.show();
        });
        findViewById(R.id.edit_banking_details).setOnClickListener(this);
        findViewById(R.id.edit_contact_details).setVisibility(View.GONE);//.setOnClickListener(this);
        spinKitView = findViewById(R.id.loadingSpinner);
        sharedPreferences = sharedPreferences = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = sharedPreferences.getString("cds_number", "");
        searchProfile(cdsNumber);
    }

    private void searchProfile(String cds_number) {

        String url = Constants.COMPLETE_URL("client/profile");

        JsonObjectRequest jsonRequestProfileData =
                new JsonObjectRequest(url,
                        Constants.cdsNumberJSON(cds_number),
                        getProfileDataSuccessListener(),
                        getProfileDataErrorListener()) {
                };

        jsonRequestProfileData.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonRequestProfileData);
    }

    private Response.Listener<JSONObject> getProfileDataSuccessListener() {
        return response -> {
            try {
                    JSONObject jsonObject = response;
                    System.out.println("Json object " + jsonObject);

                    String account_no, address, mobile;

                    account_no = jsonObject.optString("cashAccountNo");
                    my_email.setText(jsonObject.optString("email"));
                    my_cds_no.setText(jsonObject.optString("cdsNumber"));
                    address = jsonObject.optString("add1");
                    this.address.setText(address);
                    mobile = jsonObject.optString("mobile");
                    names.setText(jsonObject.optString("forenames").concat(" ").concat(jsonObject.optString("surname")));
                    idNumber.setText(jsonObject.optString("iDNoPP"));
                    mobileNumber.setText(mobile);
                    bank.setText(jsonObject.optString("cashBank"));
                    branch.setText(jsonObject.optString("cashBranch"));
                    bankAccountNumber.setText(account_no);
                    //broker.setText(jsonObject.optString("BrokerCode"));
                    //String custodianValue = jsonObject.optString("custodian");
                    custodian.setText(jsonObject.optString("custodian"));

            } catch (Exception e) {
                e.printStackTrace();
            }
        };

    }

    private Response.ErrorListener getProfileDataErrorListener() {
        return error -> {
            spinKitView.setVisibility(View.GONE);
            Log.d("Error", "Error in sending mail " + error.getMessage());
            error.printStackTrace();

            new AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setMessage(getString(R.string.badnetwork))
                    .setPositiveButton("OK", (dialog, which) -> {

                    })
                    .show();
        };
    }

    @Override
    public void onClick(View view) {

        Profile profile = new Profile();
        ChangeDetailsDialog changeDetailsDialog;
        switch (view.getId()){
            case R.id.edit_banking_details:
                profile.setType(2);
                profile.setBankName(bank.getText().toString());
                profile.setBankAccountNumber(bankAccountNumber.getText().toString());
                profile.setBranch(branch.getText().toString());
                changeDetailsDialog =new ChangeDetailsDialog(this,profile);
                changeDetailsDialog.setOnProfileChanged(this);
                changeDetailsDialog.show();
                break;
            case R.id.edit_contact_details:
                profile.setType(1);
                profile.setMobile(mobileNumber.getText().toString());
                profile.setEmail(my_email.getText().toString());
                profile.setAddress(address.getText().toString());
                changeDetailsDialog =new ChangeDetailsDialog(this,profile);
                changeDetailsDialog.setOnProfileChanged(this);
                changeDetailsDialog.show();

                break;
        }
    }

    @Override
    public void submit(@NonNull Dialog dialog, @NonNull Profile profile) {
        dialog.dismiss();

        JSONObject body = new JSONObject();
        try {
            body.put("cdsNumber",my_cds_no.getText().toString());
            body.put("change1",profile.getBankName());
            body.put("change3",profile.getBankAccountNumber());
            body.put("change2",profile.getBranch());
        }catch (Exception e){
            e.printStackTrace();
        }

        SecurityQuestions securityQuestions =
                new SecurityQuestions(this,my_cds_no.getText().toString(),true,body);
        securityQuestions.setComplete(this);
        securityQuestions.show();

    }

    @Override
    public void go(JSONObject jsonObject) {
        Log.d("jo",jsonObject.toString());
        String url = Constants.COMPLETE_URL("client/profile/edit");
        JsonObjectRequest jr = new JsonObjectRequest(
               url,
                jsonObject,
                response -> {
                    try {
                        Constants.showDialog(this,
                                response.getString("message"));
                    }catch (Exception e){
                        e.printStackTrace();
                        Constants.showDialog(this,
                                "Failed To Read Data.");
                    }
                },
                error -> {
                    error.printStackTrace();
                    Constants.showDialog(this, Constants.ERROR_MESSAGE);
                }){
            @Override
            public RetryPolicy getRetryPolicy() {
                return new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 500000;
                    }

                    @Override
                    public int getCurrentRetryCount() {
                        return 0;
                    }

                    @Override
                    public void retry(VolleyError error) throws VolleyError {

                    }
                };
            }
        };

        AppConfig.getInstance().addToRequestQueue(jr);
    }

    @Override
    public void otp(String otp,Dialog dialog) {
        dialog.dismiss();
        progressDialog.setMessage("Verifying Token....");
        progressDialog.show();
        JSONObject jo = new JSONObject();
        try{
            jo.put("token",otp);
        }catch (Exception e){
            e.printStackTrace();
        }

        JsonObjectRequest jr = new JsonObjectRequest(
                Constants.COMPLETE_URL("client/sq/update/auth"),
                jo,
                response -> {
                    progressDialog.dismiss();
                    try {
                        Constants.showDialog(this,
                                response.getString("message"));
                    }catch (Exception e){
                        progressDialog.dismiss();
                        e.printStackTrace();
                        Constants.showDialog(this,
                                "Failed To Read Data.");
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    error.printStackTrace();
                    Constants.showDialog(this, Constants.ERROR_MESSAGE);
                }){
            @Override
            public RetryPolicy getRetryPolicy() {
                return new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 500000;
                    }

                    @Override
                    public int getCurrentRetryCount() {
                        return 0;
                    }

                    @Override
                    public void retry(VolleyError error) throws VolleyError {

                    }
                };
            }
        };

        AppConfig.getInstance().addToRequestQueue(jr);
    }
}
