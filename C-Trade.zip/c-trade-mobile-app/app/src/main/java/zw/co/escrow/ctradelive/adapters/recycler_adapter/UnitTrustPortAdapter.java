package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.shreyaspatil.MaterialDialog.MaterialDialog;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.UnitTrustPortfolio;

public class UnitTrustPortAdapter extends RecyclerView.Adapter<UnitTrustPortAdapter.MyOrdersViewHolder> {

    private final List<UnitTrustPortfolio> unitTrustPortfolioList;
    private Activity activity;
    private UnitTrustPortfolio unitTrustPortfolio;

    public UnitTrustPortAdapter(Activity activity, List<UnitTrustPortfolio> unitTrustPortfolioList) {
        this.unitTrustPortfolioList = unitTrustPortfolioList;
        this.activity = activity;
    }


    @Override
    public int getItemViewType(int position) {
        return R.layout.unit_trust_portfolio_item;
    }


    @NonNull
    @Override
    public MyOrdersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new MyOrdersViewHolder(view);    }

    @Override
    public void onBindViewHolder(@NonNull MyOrdersViewHolder holder, int position) {



        holder.txtType.setText(unitTrustPortfolioList.get(position).getInstrument());
        holder.txtDate.setText(unitTrustPortfolioList.get(position).getLastActivityDate());
        holder.txtCurrentPrice.setText(unitTrustPortfolioList.get(position).getCurrentPrice());
        holder.txtPreviousPrice.setText(unitTrustPortfolioList.get(position).getPrevPrice());
        holder.txtNetMovement.setText(unitTrustPortfolioList.get(position).getNet());
        holder.txtPreviousPortValue.setText(unitTrustPortfolioList.get(position).getPreviousPortfolioValue());
        holder.txtPortfolioValue.setText(unitTrustPortfolioList.get(position).getPortfolioValue());
        holder.txtSell.setText(unitTrustPortfolioList.get(position).getUncleared());


            unitTrustPortfolio = unitTrustPortfolioList.get(position);

            holder.cardView.setOnClickListener(view -> {


                new MaterialDialog.Builder(activity)
                        .setTitle("My order")
                        .setMessage(unitTrustPortfolio.getInstrument().concat("\n")
                                .concat(unitTrustPortfolio.getLastActivityDate()).concat("\n"))
                        .setCancelable(false)
                        .setPositiveButton("Edit order", (dialogInterface, which) -> {

                            //todo


                        })
                        .setNegativeButton("Cancel order", (dialogInterface, which) -> dialogInterface.dismiss())
                        .build()
                        .show();


            });

    }



    @Override
    public int getItemCount() {
        return unitTrustPortfolioList.size();
    }




    public static class MyOrdersViewHolder extends RecyclerView.ViewHolder{

        private TextView txtType, txtPreviousPrice, txtNetMovement, txtPreviousPortValue, txtPortfolioValue, txtSell,
                txtDate, txtCurrentPrice;
        private CardView cardView, wl_change_indicator;

        public MyOrdersViewHolder(@NonNull View itemView) {
            super(itemView);


            cardView = itemView.findViewById(R.id.cardViewCompany);
            wl_change_indicator = itemView.findViewById(R.id.wl_change_indicator);
            txtType = itemView.findViewById(R.id.txtType);

            txtDate = itemView.findViewById(R.id.txtLastActivityDate);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtPreviousPrice = itemView.findViewById(R.id.txtPreviousPrice);

            txtNetMovement = itemView.findViewById(R.id.txtNetMovement);
            txtPreviousPortValue = itemView.findViewById(R.id.txtPreviousPortValue);
            txtPortfolioValue = itemView.findViewById(R.id.txtPortfolioValue);

            txtSell = itemView.findViewById(R.id.txtSell);


        }
    }


}