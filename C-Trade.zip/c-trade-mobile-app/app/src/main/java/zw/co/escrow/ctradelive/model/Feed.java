package zw.co.escrow.ctradelive.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Feed implements Parcelable {

    private Long id;
    private String message;
    private String date;
    private String sender;
    private String cdsnumber;
    private String type;
    private String title;

    public Feed() {
    }

    protected Feed(Parcel in) {
        if (in.readByte() == 0) {
            id = null;
        } else {
            id = in.readLong();
        }
        message = in.readString();
        date = in.readString();
        sender = in.readString();
        cdsnumber = in.readString();
        type = in.readString();
        title = in.readString();
    }

    public static final Creator<Feed> CREATOR = new Creator<Feed>() {
        @Override
        public Feed createFromParcel(Parcel in) {
            return new Feed(in);
        }

        @Override
        public Feed[] newArray(int size) {
            return new Feed[size];
        }
    };

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getCdsnumber() {
        return cdsnumber;
    }

    public void setCdsnumber(String cdsnumber) {
        this.cdsnumber = cdsnumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Feed{" +
                "id=" + id +
                ", message='" + message + '\'' +
                ", date='" + date + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        if (id == null) {
            parcel.writeByte((byte) 0);
        } else {
            parcel.writeByte((byte) 1);
            parcel.writeLong(id);
        }
        parcel.writeString(message);
        parcel.writeString(date);
        parcel.writeString(sender);
        parcel.writeString(cdsnumber);
        parcel.writeString(type);
        parcel.writeString(title);
    }
}
