package zw.co.escrow.ctradelive.view;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputLayout;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.Fundlist;

public class PostInvestmentActivity extends AppCompatActivity {

    private Utils utils;

    private TextInputLayout outlinedTextFieldAmount, outlinedTextFieldInvest;
    private static final String TAG = "PostInvestmentActivity";
    private TextView txtCompanyName, txtSecurityName, txtFundName, txtPrice;
    private DateFormat formatter;
    private String cds_number,heading,title;
    private Fundlist fundlist;
    private ProgressDialog progressDialog;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_investment);

        cds_number = getSharedPreferences("CTRADE",MODE_PRIVATE).getString("cds_number","");

        initWidgets();
        progressDialog = new ProgressDialog(this);

        Bundle mArgs = getIntent().getExtras();

        fundlist = mArgs.getParcelable("fundlist");


        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(PostInvestmentActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("INVEST/DE-INVEST");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }




        txtCompanyName.setText(fundlist.getCompany());
        txtSecurityName.setText(fundlist.getFundType());

        formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = (Date)formatter.parse(fundlist.getIssueDate());

        } catch (ParseException e) {
            e.printStackTrace();
        }

        SimpleDateFormat d= new SimpleDateFormat("dd MMM yyyy");

        txtPrice.setText("Indicative Unit Price ZWL$"+fundlist.getIssuePricePerUnit()+" As Per " +d.format(date));





        String[] options = new String[] {"Invest", "De-Invest"};

        utils.setDropdownBoxes(options, R.id.invest_dropdown_items);

        /****findViewById(R.id.btnInvest).setOnClickListener(view -> {

            String amount = outlinedTextFieldAmount.getEditText().getText().toString();
            String selectedOption = outlinedTextFieldInvest.getEditText().getText().toString();
            String type;

            if (selectedOption.equals("Invest")){
                type="BUY";
            }
            else {
                type="SELL";
            }


            if (amount.equals("") || amount.equals("0")) {
                outlinedTextFieldAmount.setError("Amount should be greater than 0");
            }
            else if (selectedOption.equals("") || selectedOption.equals("0") || selectedOption.length() == 0){
                outlinedTextFieldInvest.setError("Please select option");

            }
            else {
                outlinedTextFieldAmount.setErrorEnabled(false);
                outlinedTextFieldInvest.setErrorEnabled(false);


                ApiClubInterface api = ApiClubsClient.getApiService();

                progressDialog.setTitle("Posting..");
                progressDialog.setMessage("Please wait ");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();
                double postAmount=0;
                int units=0;


                postAmount=  Double.parseDouble(amount) / fundlist.getInitialPrice();
                units = (int) postAmount;

                String today = formatter.format(new Date());
                Call<ResponseBody> call = api.OrderPostingMakeNew(fundlist.getCompany(),"UNIT TRUST","GOOD TILL CANCELLED (GTC) ",type,type,units+"",fundlist.getInitialPrice()+"",cds_number,fundlist.getCompany().substring(0,2),amount,"mobile",today);
                Log.e("TAG","postInvest");
                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        progressDialog.setTitle("Posting..");
                        String res;
                        try {
                            res = response.body().string();
                            if(res.contains("1")){
                                progressDialog.setMessage("Successfully submitted");
                            }else{
                                progressDialog.setMessage(res);
                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                        progressDialog.show();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                progressDialog.dismiss();
                                finish();
                            }
                        },2000);

                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("TAG error ",t.getMessage());

                    }
                });

            }

        });********/


        findViewById(R.id.btnDeInvest).setOnClickListener(view -> {

            String amount = outlinedTextFieldAmount.getEditText().getText().toString();
            String selectedOption = outlinedTextFieldInvest.getEditText().getText().toString();


            if (amount.equals("") || amount.equals("0")) {
                outlinedTextFieldAmount.setError("Amount should be greater than 0");
            }
            else if (selectedOption.equals("") || selectedOption.equals("0") || selectedOption.length()<10){
                outlinedTextFieldInvest.setError("Please select option");

            }
            else {
                outlinedTextFieldAmount.setErrorEnabled(false);
                outlinedTextFieldInvest.setErrorEnabled(false);
                Log.d(TAG, "onCreate: "+amount);
                Log.d(TAG, "onCreate: "+selectedOption);


                String[] depositDetails={amount, selectedOption,};
                Log.d(TAG, "onCreate: "+depositDetails[1]);


                setResult(Constants.DEPOSIT_REQUEST_CODE, new Intent().putExtra("DEPOSIT_DETAILS", depositDetails));
                finish();
            }

        });



    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initWidgets(){

        outlinedTextFieldAmount=findViewById(R.id.outlinedTextFieldAmount);
        outlinedTextFieldInvest=findViewById(R.id.outlinedTextFieldInvest);

        txtCompanyName=findViewById(R.id.txtCompanyName);
        txtSecurityName=findViewById(R.id.txtSecurityName);
        txtFundName=findViewById(R.id.txtFundName);
        txtPrice=findViewById(R.id.txtPrice);

    }


    private void postInvest( View view) {


    }


}