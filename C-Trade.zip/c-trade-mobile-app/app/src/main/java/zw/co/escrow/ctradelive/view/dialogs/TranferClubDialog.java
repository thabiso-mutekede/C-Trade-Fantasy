package zw.co.escrow.ctradelive.view.dialogs;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.DialogFragment;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.io.IOException;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.view.ClubView;


public class TranferClubDialog extends DialogFragment {

    public static final String TAG = TranferClubDialog.class.getSimpleName();
    private ClubView.ContributionListener contributionListener;
    String cds_number,phone;

    String title="";
    String group_cds="";
    //SearchableSpinner spGroup;
    TextInputEditText amountInput;

    public static TranferClubDialog newInstance(String sell, String gCds, String gName) {
        Bundle args = new Bundle();
        args.putString("title", sell);
        args.putString("cds",gCds);
        args.putString("name",gName);

        TranferClubDialog userPopUp = new TranferClubDialog();
        userPopUp.setArguments(args);
        return userPopUp;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prfs = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        String whatsSelected = prfs.getString(getString(R.string.entity_type), "");
        Bundle mArgs = getArguments();
        title = mArgs.getString("title");
        group_cds = mArgs.getString("cds");


        if (whatsSelected.equalsIgnoreCase(getString(R.string.company)))
            cds_number = prfs.getString(getString(R.string.corp_cds_number), "");
        else cds_number = prfs.getString("cds_number", "");

        phone = prfs.getString("phone", " ");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_transfer_club_dialog, container, false);
        TextView toolbar = v.findViewById(R.id.title_dialod);
        toolbar.setText("Contribute".toUpperCase());
        //ButterKnife.bind(getActivity());

        v.findViewById(R.id.button_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
        amountInput = v.findViewById(R.id.amount);
        //spGroup = v.findViewById(R.id.spClubSearchable);
        //spGroup.setVisibility(View.GONE);
        SharedPreferences prfs = getActivity().getSharedPreferences("CTRADE", Context.MODE_PRIVATE);


        v.findViewById(R.id.btnPost).setOnClickListener(view -> {
            boolean isValide= true;
            float limit= 0.1f;
            if(amountInput.getText().toString().isEmpty()){
                Snackbar snackbar = Snackbar.make(view, "Please fill out these field", Snackbar.LENGTH_LONG);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(getResources().getColor(R.color.red));
                snackbar.show();
                isValide = false;

            }else if (Double.valueOf(amountInput.getText().toString()) <limit) {
                Snackbar snackbar = Snackbar.make(view, "Please minimum withdrawal amount should be ZWL "+limit, Snackbar.LENGTH_LONG);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(getResources().getColor(R.color.red));
                snackbar.show();

                    isValide = false;
            }

            /*if(spGroup.getSelectedItem().toString().equalsIgnoreCase("No Club to Select")){
                Snackbar snackbar = Snackbar.make(view, "No Club to Select", Snackbar.LENGTH_LONG);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(getResources().getColor(R.color.red));
                snackbar.show();
                isValide = false;
            }

            if(spGroup.getSelectedItem().toString().equalsIgnoreCase("Select club")){
                Snackbar snackbar = Snackbar.make(view, "Please Select club", Snackbar.LENGTH_LONG);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(getResources().getColor(R.color.red));
                snackbar.show();
                isValide = false;
            }*/



            if(isValide) {
                ProgressDialog progressDialog = new ProgressDialog(getActivity());
                progressDialog.setTitle("Transferring ...");
                progressDialog.setMessage("Please wait ");
                progressDialog.setIndeterminate(false);
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.setCancelable(false);
                progressDialog.show();
                //TODO CHANGE API
                //InvestmentClub grup = ( InvestmentClub ) spGroup.getSelectedItem();
//                ApiClubInterface api = CtradeApiClient.getApiService();
//                Call<ResponseBody> call = api.postDepositToGroup(cds_number,group_cds,amountInput.getText().toString());
//                call.enqueue(new Callback<ResponseBody>() {
//                    @Override
//                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//                        progressDialog.setTitle("Transferring ...");
//                        try {
//                            progressDialog.setMessage(String.format("Transferring,%s", response.body().string()));
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                        progressDialog.show();
//                        progressDialog.setCancelable(true);
//                        progressDialog.setCanceledOnTouchOutside(false);
//                        new Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                progressDialog.dismiss();
//                                if(contributionListener != null)
//                                    contributionListener.onContributionDialogClosedListener(TranferClubDialog.this);
//                                dismiss();
//                            }
//                        },2000);
//
//
//
//                    }
//
//                    @Override
//                    public void onFailure(Call<ResponseBody> call, Throwable t) {
//                        Log.e("onFailure",t.getMessage());
//                        progressDialog.setMessage("Failed  to Transfer, Try Again...");
//                        progressDialog.show();
//                        progressDialog.setCancelable(false);
//                        progressDialog.setCanceledOnTouchOutside(false);
//                        new Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                if(contributionListener != null)
//                                    contributionListener.onContributionDialogClosedListener(TranferClubDialog.this);
//                                progressDialog.dismiss();
//                            }
//                        },2000);
//                    }
//                });


           // }else{
             //   Snackbar snackbar = Snackbar.make(view, "Please fill out these field", Snackbar.LENGTH_LONG);
             //   View snackbarView = snackbar.getView();
             //   snackbarView.setBackgroundColor(getResources().getColor(R.color.red));
             //   snackbar.show();

            }
        });



        return v;
    }



    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
        }
    }


    public void setContributionListener(ClubView.ContributionListener contributionListener) {
        this.contributionListener = contributionListener;
    }
}
