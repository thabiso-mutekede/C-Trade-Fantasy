package zw.co.escrow.ctradelive.setup.services;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.CTradeUserAdapter;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.ClubInvestmentAdapter;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.ContributionAdapter;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MemberAdapter;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MyClubsAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.CTradeUserModel;
import zw.co.escrow.ctradelive.model.ChairmanModel;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.ClubTransCompany;
import zw.co.escrow.ctradelive.model.Contribution;
import zw.co.escrow.ctradelive.model.DrillDown;
import zw.co.escrow.ctradelive.model.Investment;
import zw.co.escrow.ctradelive.model.Member;
import zw.co.escrow.ctradelive.model.MemberContribution;
import zw.co.escrow.ctradelive.model.MemberInvestments;
import zw.co.escrow.ctradelive.model.RequestModel;
import zw.co.escrow.ctradelive.model.Statement;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.view.ClubView;
import zw.co.escrow.ctradelive.view.InvestmentClubsMainView;
import zw.co.escrow.ctradelive.view.InvestmentClubsRequest;
import zw.co.escrow.ctradelive.view.MyInvestmentClubsView;
import zw.co.escrow.ctradelive.view.TermsAndConditionsView;
import zw.co.escrow.ctradelive.view.dialogs.ClubTransCompaniesDialog;
import zw.co.escrow.ctradelive.view.dialogs.IndividualDrillDownDialog;
import zw.co.escrow.ctradelive.view.dialogs.MemberContributionDialog;
import zw.co.escrow.ctradelive.view.dialogs.MemberInvestmentsDialog;

public class InvestmentClubService implements InvestmentClub.ClubServicesListener {
    private InvestmentClub.ICRefreshRefreshLister icRefreshRefreshLister;
    private  int COLUMN_SIZE;
    private static int ROW_SIZE = 59;
    private JsonArrayRequest jsonArrayRequest;
    private final String ip = AppConfig.getIp();
    private String url;
    private final ProgressDialog progressDialog;
    private List<String> headers;
    private final Context context;
    private RecyclerView recyclerView;

    public InvestmentClubService(Context context) {
        this.context = context;
        this.progressDialog = new ProgressDialog(context);
    }
    public InvestmentClubService(Context context, RecyclerView recyclerView) {
        this.context = context;
        this.progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        this.recyclerView = recyclerView;

        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setHasFixedSize(true);
    }
    @SuppressLint("ResourceAsColor")
    public InvestmentClubService(Context context, List<String> headers) {
        this.progressDialog = new ProgressDialog(context);
        this.headers = headers;
        this.context = context;
        this.COLUMN_SIZE = headers.size();
    }
    @Override
    public void onLoadMembership( String cdsNumber) {
        progressDialog.setMessage("loading members");
        progressDialog.show();
       String mcdsnumber = context.getSharedPreferences("CTRADE", Context.MODE_PRIVATE).getString("cds_number","");
        JSONArrayRequestWithObject clubJson = new JSONArrayRequestWithObject(Request.Method.POST,Constants.COMPLETE_URL("clubs/members"),Constants.cdsNumberJSON(cdsNumber,mcdsnumber),
                response ->
                {
                    try{

                        List<Member> memberList = new ArrayList<>();
                        JSONArray array = response;
                        Log.d("Array size ", "" + ROW_SIZE);
                        for (int i = 0; i < array.length(); i++) {

                            JSONObject responses = array.getJSONObject(i);
                            Member member = new Member();
                            member.setName(responses.getString("names"));
                            member.setPhone(responses.getString("phone"));
                            member.setContribution(Constants.getThousandSep(Constants.convertToFloat(String.valueOf(responses.getDouble("amount")))));
                            member.setInvestment(Constants.getThousandSep(Constants.convertToFloat(String.valueOf(responses.getDouble("portfolio")))));
                            memberList.add(member);
                        }


                        MemberAdapter memberAdapter = new MemberAdapter(memberList,context,recyclerView);
                        recyclerView.setAdapter(memberAdapter);
                        progressDialog.dismiss();

                    }catch (Exception e){
                        progressDialog.dismiss();
                        e.printStackTrace();
                    }
                },
                error ->
                {
                    progressDialog.dismiss();
                    error.printStackTrace();

                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }
    @Override
    public void onLoadMyClubs(String cdsNumber) {
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        JSONArrayRequestWithObject jsonArrayRequest = new JSONArrayRequestWithObject(
                Request.Method.POST
                ,Constants.COMPLETE_URL("clubs/list"),Constants.cdsNumberJSON(cdsNumber)
                ,response -> {
            try {
                List<ClubModel> clubModels = new ArrayList<>();
                for(int i = 0;i<response.length();i++){
                    JSONObject jsonObject = response.getJSONObject(i);

                    ClubModel clubModel = new ClubModel();

                    ChairmanModel chairmanModel = new  ChairmanModel();
                    try{
                        JSONObject chairman = jsonObject.getJSONObject("chairman");
                        chairmanModel.setCdsNumber(chairman.getString("cdsNumber"));
                        chairmanModel.setIdNumber(chairman.getString("idNumber"));
                        chairmanModel.setName(chairman.getString("name"));
                        chairmanModel.setPhoneNumber(chairman.getString("phone"));
                        clubModel.setChairman(chairmanModel);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    String title = jsonObject.getString("member_title");

                    if(title.equalsIgnoreCase("MEMBER"))clubModel.setMember(true);
                    else clubModel.setMember(false);
                    clubModel.setClubName(jsonObject.getString("forenames"));
                    clubModel.setClubCdsNumber(jsonObject.getString("cdsNumber"));
                    clubModel.setContNote(jsonObject.getString("contributions_noti"));
                    clubModel.setInvNote(jsonObject.getString("investments_noti"));
                    clubModel.setMbNote(String.valueOf(
                            convertToInt(jsonObject.getString("exiting_noti"))+
                                    convertToInt(jsonObject.getString("joining_noti"))
                    ));
                    clubModel.setLast_updated(jsonObject.getString("createdOn"));
                    clubModel.setMessage(jsonObject.getString("wMessage"));
                    clubModel.setReadMessage(jsonObject.getBoolean("readMessage"));
                    clubModel.setNbNote(jsonObject.getString("group_feed_noti"));
                    clubModels.add(clubModel);
                }
                MyClubsAdapter myClubsAdapter = new MyClubsAdapter(clubModels,context,recyclerView);
                recyclerView.setAdapter(myClubsAdapter);
                progressDialog.dismiss();
            }catch (Exception e){
                progressDialog.dismiss();
                e.printStackTrace();
                showDialog("Failed To Read Data.Try Again Later");
            }
        },error -> {
            error.printStackTrace();
            progressDialog.dismiss();
            showDialog("Failed To Connect Please Try Again Later");
        });
        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);

    }
    @Override
    public void onLoadContribution(String cdsNumber, TextView txt1, TextView txt2) {
        progressDialog.setMessage("Load Contribution");
        progressDialog.show();
        String url = ip + "clubsAvailableOnCtrade?cdsNumber="+cdsNumber;
        StringRequest clubJson = new StringRequest(Request.Method.POST, url,
                response ->
                {

                },
                error ->
                {
                    progressDialog.dismiss();
                    showDialog(error.getMessage());
                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }

    @Override
    public void onLoadInvestments(String isMember, boolean isInGroup , TextView txt1, TextView txt2) {
        progressDialog.setMessage("loading investments");
        progressDialog.show();
        JSONObject jsonObject = new  JSONObject();
        try {
            jsonObject.put("type","client");
            jsonObject.put("cdsNumber",context.getSharedPreferences("CTRADE",Context.MODE_PRIVATE).getString("cds_number",""));
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject clubJson = new JSONArrayRequestWithObject(Request.Method.POST
                ,Constants.COMPLETE_URL("clubs/investments")
                ,jsonObject, response ->
                {
                    try{

                        Log.d("do",response.toString());

                        JSONArray array = response;
                        List<MemberInvestments> memberInvestments = new ArrayList<>();
                        List<Double> mytotal = new ArrayList<>();
                        List<Double> clubtotal = new ArrayList<>();
                        Log.d("Array size ", "" + ROW_SIZE);
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject responses = array.getJSONObject(i);
                            MemberInvestments memberInvestment = new MemberInvestments();
                            Double f = responses.getDouble("clubTotal");
                            Double f2 = responses.getDouble("myTotal");
                            clubtotal.add(f);
                            mytotal.add(f2);
                            String percentage = String.valueOf(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf((f2/f)*100))));
                            memberInvestment.setGroup(responses.getString("clubName"));
                            memberInvestment.setClubTotal(responses.getString("clubTotal"));
                            memberInvestment.setMyTotal(responses.getString("myTotal"));
                            memberInvestment.setMyPercentage(percentage);
                            memberInvestments.add(memberInvestment);
                        }
                        Double sumClub = 0.0;
                        for(Double a : clubtotal){
                            sumClub += a;
                        }
                        Double sumMine = 0.0;
                        for(double a : mytotal){
                            sumMine += a;
                        }

                        if(memberInvestments.size() >0)
                            new MemberInvestmentsDialog(context,memberInvestments
                                    ,Constants.getThousandSep(Constants.convertToFloat(String.valueOf(sumClub)))
                                    ,Constants.getThousandSep(Constants.convertToFloat(String.valueOf(sumMine)))).show();
                        else
                            Toast.makeText(context,"You Haven't Made Any Investments Yet",Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();

                    }catch (Exception e){
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                },
                error ->
                {
                    progressDialog.dismiss();
                    showDialog(error.getMessage());

                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }
    @Override
    public void onLoadClubInvestments(String gcdsnumber, String mcdsnumba, TextView txt1, TextView txt2) {

        progressDialog.setMessage("loading investments");
        progressDialog.show();
        JSONObject jsonObject = new  JSONObject();
        try {
            jsonObject.put("type","club");
            jsonObject.put("cdsNumber",context.getSharedPreferences("CTRADE",Context.MODE_PRIVATE).getString("cds_number",""));
            jsonObject.put("clubCdsNumber",gcdsnumber);
        }catch (Exception e){
            e.printStackTrace();
        }

        JSONArrayRequestWithObject clubJson = new JSONArrayRequestWithObject(Request.Method.POST,Constants.COMPLETE_URL("clubs/investments"),jsonObject
                ,response -> {
            try{
                Log.d("resp",response.toString());
                List<Investment> investments = new ArrayList<>();
                for (int i = 0; i < response.length(); i++) {
                    JSONObject object = response.getJSONObject(i);
                    Investment investment = new Investment();
                    investment.setCounter(object.getString("company"));
                    investment.setMyshare(String.valueOf(object.getDouble("myShare")));
                    investment.setPrice(String.valueOf(object.getDouble("initialPrice")));
                    investment.setType("EQUITY");
                    investment.setValue(String.valueOf(object.getDouble("value")));
                    investment.setUnits(String.valueOf(object.getDouble("units")));

                    investments.add(investment);

                }
                recyclerView.setAdapter(new ClubInvestmentAdapter(investments));
                Float sumMine = 0f;
                Float sumClub = 0f;
                for (Investment i : investments){
                    sumClub += Constants.convertToFloat(i.getValue());
                    sumMine += Constants.convertToFloat(i.getMyshare()) * Constants.convertToFloat(i.getPrice());
                }
                txt1.setText("ZWL "+Constants.getThousandSep((Constants.roundToDecimalPrice(sumMine))));
                txt2.setText("ZWL "+Constants.getThousandSep((Constants.roundToDecimalPrice(sumClub))));
                progressDialog.dismiss();
            }catch (Exception e){
                progressDialog.dismiss();
                e.printStackTrace();
            }

        },
                error -> {
                    progressDialog.dismiss();
            error.printStackTrace();
                }
        );

        AppConfig.getInstance().addToRequestQueue(clubJson);
    }
    @Override
    public void onSearchCTradeClubs(String cdsNumber) {
        progressDialog.setMessage("loading c-trade clubs");
        progressDialog.show();
        String url = ip + "clubsAvailableOnCtrade?cdsnumber="+cdsNumber;
        Log.d("lloda",url);
        StringRequest clubJson = new StringRequest(Request.Method.POST, url,
                response ->
                {

                },
                error ->
                {
                    progressDialog.dismiss();
                    showDialog(error.getMessage());

                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }
    @Override
    public void onLoadMyContribution(String cdsNumber, TextView txt1, TextView txt2) {
        progressDialog.setMessage("loading Contributions");
        progressDialog.show();
        String url = ip + "getMyContributions?cdsNumber="+cdsNumber;
        Log.d("lloda",url);
        StringRequest clubJson = new StringRequest(Request.Method.POST, url,
                response ->
                {
                    try{
                        JSONArray array = new JSONArray(response);
                        List<MemberContribution> memberContributions = new ArrayList<>();
                        List<Float> mytotal = new ArrayList<>();
                        List<Float> clubtotal = new ArrayList<>();
                        Log.d("Array size ", "" + ROW_SIZE);
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject responses = array.getJSONObject(i);
                            MemberContribution memberContribution = new MemberContribution();
                            Float f = Constants.convertToFloat(responses.getString("clubTotal"));
                            Float f2 = Constants.convertToFloat(responses.getString("myTotal"));
                            clubtotal.add(f);
                            mytotal.add(f2);
                            String percentage = String.valueOf(Constants.roundToDecimalPrice(Constants.convertToFloat(String.valueOf((f2/f)*100))));
                            memberContribution.setGroup(responses.getString("group"));
                            memberContribution.setClubTotal(responses.getString("clubTotal"));
                            memberContribution.setMyTotal(responses.getString("myTotal"));
                            memberContribution.setMyPercentage(percentage);
                            memberContributions.add(memberContribution);
                        }


                        Float sumClub = 0F;
                        for(float a : clubtotal){
                            sumClub += a;
                        }
                        Float sumMine = 0F;
                        for(float a : mytotal){
                            sumMine += a;
                        }
                        if(memberContributions.size() >0)
                            new MemberContributionDialog(context, cdsNumber, memberContributions, Constants.getThousandSep(sumClub), Constants.getThousandSep(sumMine)).show();
                        else
                            Toast.makeText(context,"You Have'nt Made Any Contributions Yet",Toast.LENGTH_SHORT).show();

                        progressDialog.dismiss();

                    }catch (Exception e){
                        progressDialog.dismiss();
                        showDialog(e.getMessage());
                    }
                },
                error ->
                {
                    progressDialog.dismiss();
                    showDialog(error.getMessage());

                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }
    @Override
    public void onLoadCTradeUsers(String name, String clubCdsNumber, String clubname) {
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        url = ip.concat("searchCtradeUser?email=").concat(name);
        Log.d("lloda",url);
        jsonArrayRequest = new JsonArrayRequest(url, response -> {
            try {
                List<CTradeUserModel> cTradeUserModels = new ArrayList<>();
                for(int i = 0;i<response.length();i++){
                    JSONObject jsonObject = response.getJSONObject(i);
                    CTradeUserModel cTradeUserModel = new CTradeUserModel();
                    cTradeUserModel.setCdsnumber(jsonObject.getString("cdsnumber"));
                    cTradeUserModel.setName(jsonObject.getString("name"));
                    cTradeUserModel.setEmail(jsonObject.getString("email"));
                    cTradeUserModel.setPhone(jsonObject.getString("phone"));

                    cTradeUserModels.add(cTradeUserModel);
                }
                CTradeUserAdapter cTradeUserAdapter = new CTradeUserAdapter(context,cTradeUserModels,clubCdsNumber, recyclerView,clubname);
                recyclerView.setAdapter(cTradeUserAdapter);
                progressDialog.dismiss();
            }catch (Exception e){
                progressDialog.dismiss();
                e.printStackTrace();
                showDialog("Failed To Read Data.Try Again Later");
            }
        },error -> {
            error.printStackTrace();
            progressDialog.dismiss();
            showDialog("Failed To Connect Please Try Again Later");
        });
        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
    }
    @Override
    public void onSendRequest(String gcdsnum, String mcdsnum, String gphone, String gname, String type, String reqBy, String mphone) {
//        progressDialog.setMessage("Sending Request..");
//        progressDialog.show();
//        Call<JsonObject> sendRequest = api.addClubRequests(gcdsnum,mcdsnum,gphone,gname,type,reqBy,mphone);
//        sendRequest.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
//                try{
//
//                    Log.d("lloda",response.body().toString());
//                    JSONObject j = new JSONObject(new Gson().toJson(response.body()));
//                    progressDialog.dismiss();
//                    showDialog(j.getString("message"));
//                }catch (Exception e){
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//                    showDialog("Failed To Read Data.Please Try Again Later");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<JsonObject> call, Throwable t) {
//                showDialog("Error On Connecting.Please Try Again Later");
//                t.printStackTrace();
//            }
//        });
    }
    @Override
    public void onLoadRequest(String cdsnumber, String type, String sp, String em) {

        JSONObject jo = new JSONObject();
        try{
            jo.put("cdsNumber",cdsnumber);
            jo.put("email",em);
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(Request.Method.POST,Constants.COMPLETE_URL("clubs/invitation"),jo, response -> {
            try {
                if(response.length() <= 0){
                    progressDialog.dismiss();
                }else{

                    List<RequestModel> requestModels = new ArrayList<>();
                    for(int i = 0;i < response.length();i++){
                        JSONObject j = response.getJSONObject(i);
                        RequestModel requestModel = new RequestModel();
                        requestModel.setClubname(j.getString("name"));
                        //requestModel.setCds(j.getString("cds"));
                        requestModel.setEmail(j.getString("email"));
                        //requestModel.setPhone(j.getString("phone"));
                        //requestModel.setDate(j.getString("date"));
                        //requestModel.setName(j.getString("name"));
                        requestModels.add(requestModel);
                    }

                    context.startActivity(new Intent(context, InvestmentClubsRequest.class)
                            .putParcelableArrayListExtra("requests",
                                    (ArrayList<? extends Parcelable>) requestModels)
                            .putExtra("cdsnumber",cdsnumber)
                            .putExtra("email", em));
                }
                progressDialog.dismiss();
            }catch (Exception e){
                progressDialog.dismiss();
                e.printStackTrace();
                showDialog("Failed To Read Data.Try Again Later");
            }
        },error -> {
            error.printStackTrace();
            progressDialog.dismiss();
            showDialog("Failed To Connect Please Try Again Later");
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    @Override
    public void onAcceptRequests(Context context, String token,Boolean accepted) {
        progressDialog.setMessage("Processing Please Wait...");
        progressDialog.show();
        JSONObject jsonObject = new JSONObject();
        try{
            jsonObject.put("token",token);
            jsonObject.put("accepted",accepted);
        }catch (Exception e){

        }

        JsonObjectRequest jr = new JsonObjectRequest(Constants.COMPLETE_URL("clubs/invitation/confirmation"),jsonObject,
                response -> {
            try
            {
                showDialog(response.getString("message"));
                progressDialog.dismiss();
            }catch (Exception e){
                progressDialog.dismiss();
                e.printStackTrace();
            }

                },error -> {
            showDialog("Error On Connecting.Please Try Again Later");
            progressDialog.dismiss();
            error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    @Override
    public void onLoadContribution(String cdsnumber) {}
    @Override
    public void onLoadClubContributions(String cdsnumber, String mcdsnumber, TextView txt1, TextView txt2) {
        progressDialog.setMessage("loading contributions ....");
        progressDialog.show();
        String mycdsnumber = context.getSharedPreferences("CTRADE", Context.MODE_PRIVATE).getString("cds_number","");
        String body = String.format("getClubContributionList?gcdsnumber=").concat(cdsnumber).concat("&mcdsnumber=").concat(mcdsnumber);
        url = ip.concat(body);
        Log.d("lloda",url);
        jsonArrayRequest = new JsonArrayRequest(url, response -> {
            try {
                if(response.length() <= 0){
                    progressDialog.dismiss();
                }else{
                    List<Contribution> contributions  = new ArrayList<>();
                    List<Float> club_contribution = new ArrayList<>();
                    for(int i = 0;i < response.length();i++){
                        JSONObject j = response.getJSONObject(i);
                        club_contribution.add(Constants.convertToFloat(j.getString("contribution_")));
                        Contribution requestModel = new Contribution();
                        requestModel.setName(j.getString("name"));
                        requestModel.setAmount(Constants.getThousandSep(Constants.convertToFloat(j.getString("contribution_"))));
                        requestModel.setActive(j.getBoolean("active"));
                        requestModel.setExit_date(j.getString("exit_date"));
                        Log.d("lloda compare cdsnumber"," --mine "+mycdsnumber+" ---api "+j.getString("cdsnumber"));
                        if(j.getString("cdsnumber").equalsIgnoreCase(mycdsnumber)) txt2.setText(Constants.getThousandSep(Constants.convertToFloat(j.getString("contribution_"))));
                        contributions.add(requestModel);
                    }
                    Log.d("lloda contri",contributions.toString());
                    recyclerView.setAdapter(new ContributionAdapter(contributions));
                    Float sumClub = 0F;
                    for(float a : club_contribution){
                        sumClub += a;
                    }
                    txt1.setText(Constants.getThousandSep(sumClub));

                }
                progressDialog.dismiss();
            }catch (Exception e){
                progressDialog.dismiss();
                e.printStackTrace();
                showDialog("Failed To Read Data.Try Again Later");
            }
        },error -> {
            error.printStackTrace();
            progressDialog.dismiss();
            showDialog("Failed To Connect Please Try Again Later");
        });
        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
    }
    @Override
    public void onSearchCTradeClubsByText(String text) {
        progressDialog.setMessage("loading c-trade clubs");
        progressDialog.show();
        String url = ip + "getClubsAvailableOnCtradeByText?text="+text;
        Log.d("lloda",url);
        StringRequest clubJson = new StringRequest(Request.Method.POST, url,
                response ->
                {
                },
                error ->
                {
                    progressDialog.dismiss();
                    showDialog(error.getMessage());
                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }
    @Override
    public void onExitClub(String clubCdsNumber, String cdsnumber) {
        progressDialog.setMessage("Please Wait A Moment....");
        progressDialog.show();
        JsonObjectRequest jr = new JsonObjectRequest(Constants.COMPLETE_URL("clubs/exit"),
                Constants.cdsNumberJSON(clubCdsNumber,cdsnumber),
                response -> {
                    try {
                        if(response.getBoolean("status")) {
                            new AlertDialog.Builder(context)
                                    .setMessage(response.getString("message"))
                                    .setPositiveButton("ok",(dialog, which)
                                            -> {
                                        context.startActivity(new Intent(context, MyInvestmentClubsView.class));
                                        ((ClubView)context).finish();
                                    })
                                    .create()
                                    .show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                        showDialog("Failed To Read Data.Please Try Again Later");
                    }
                },

                error -> {
                    progressDialog.dismiss();
                    error.printStackTrace();
                    showDialog("Error On Connecting.Please Try Again Later");
                });

        AppConfig.getInstance().addToRequestQueue(jr);
    }
    @Override
    public void onCheckInvestmentTermsAndConditions(String cdsnumber) {
//        progressDialog.setMessage("Please Wait A Moment..");
//        progressDialog.show();
//        Call<JsonObject> accept = api.checkTerms(cdsnumber);
//        accept.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
//                try{
//
//                    Log.d("lloda",response.body().toString());
//                    JSONObject j = new JSONObject(new Gson().toJson(response.body()));
//                    if(j.getBoolean("status"))
//                        context.startActivity(new Intent(context, InvestmentClubsMainView.class));
//                    else {
//                        context.startActivity(new Intent(context, TermsAndConditionsView.class));
//                        progressDialog.dismiss();
//                    }
//                }catch (Exception e){
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//                    showDialog("Failed To Read Data.Please Try Again Later");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<JsonObject> call, Throwable t) {
//                showDialog("Error On Connecting.Please Try Again Later");
//                t.printStackTrace();
//            }
//        });
    }
    @Override
    public void onAcceptTermsAndConditions(String cdsnumber) {
//        progressDialog.setMessage("Processing Please Wait...");
//        progressDialog.show();
//        Call<JsonObject> accept = api.acceptTerms(cdsnumber);
//        accept.enqueue(new Callback<JsonObject>() {
//            @Override
//            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
//                try{
//
//                    Log.d("lloda",response.body().toString());
//                    JSONObject j = new JSONObject(new Gson().toJson(response.body()));
//
//                    if(j.getBoolean("status")){
//                        context.startActivity(new Intent(context, InvestmentClubsMainView.class));
//                        ((TermsAndConditionsView)context).finish();
//                    }
//
//                    else{
//                        progressDialog.dismiss();
//                        showDialog(j.getString("message"));
//                    }
//                }catch (Exception e){
//                    e.printStackTrace();
//                    progressDialog.dismiss();
//                    showDialog("Failed To Read Data.Please Try Again Later");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<JsonObject> call, Throwable t) {
//                showDialog("Error On Connecting.Please Try Again Later");
//                t.printStackTrace();
//            }
//        });
    }
    @Override
    public void onLoadClubOrders(String cdsnumber) {
        String url = ip + "getMyOrders1?cdsnumber="+cdsnumber;

        StringRequest clubJson = new StringRequest(Request.Method.POST, url,
                response ->
                {
                },
                error ->
                {
                    progressDialog.dismiss();
                    showDialog(error.getMessage());

                });
        AppConfig.getInstance().addToRequestQueue(clubJson);
    }
    @Override
    public void onLoadClubTransCompanies(String cdsnumber, InvestmentClub.ClubServicesListener clubServicesListener) {
        progressDialog.setMessage("loading ...");
        progressDialog.show();
        String url = String.format("transCompanies?group_cds_number=%s",cdsnumber);
        String api = ip.concat(url);
        Log.d("lloda club_holdings",api);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(api,
                response -> {
                    try{

                        List<ClubTransCompany> clubTransCompanies = new ArrayList<>();
                        for(int i = 0;i<response.length();i++){
                            ClubTransCompany company = new ClubTransCompany();
                            company.setCompany(response.getJSONObject(i).getString("Company"));
                            clubTransCompanies.add(company);
                        }
                        new ClubTransCompaniesDialog(context,clubTransCompanies,"Select Company",cdsnumber,clubServicesListener).show();
                        progressDialog.dismiss();
                    }catch (Exception e){
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }

                },error -> {
            progressDialog.dismiss();
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
    }
    @Override
    public void onLoadClubStatementOnCompany(String cdsnumber, String company, Dialog dialog) {
//        dialog.dismiss();
//        Call<List<Statement>> statementCall = api.clubStatement(cdsnumber,company);
//        statementCall.enqueue(new Callback<List<Statement>>() {
//            @Override
//            public void onResponse(Call<List<Statement>> call, Response<List<Statement>> response) {
//                recyclerView.setAdapter(new ClubStatementAdapter(response.body(),recyclerView,context));
//            }
//            @Override
//            public void onFailure(Call<List<Statement>> call, Throwable t) {
//                t.printStackTrace();
//            }
//        });
    }
    @Override
    public void onLoadInvestmentStatementDrillDownForIndividual(String cdsnumber, String clubcdsnumber, String company) {
        progressDialog.setMessage("loading ....");
        progressDialog.show();
        String url = ip + String.format("HoldingsDrillDown?groupid=%s&company=%s&cdsnumber=%s",clubcdsnumber,company,cdsnumber);
        Log.d("lloda drilldown",url);
        jsonArrayRequest = new JsonArrayRequest(url,
                response ->
                {
                    List<DrillDown> drillDones = new ArrayList<>();
                    try {
                        for(int i =0;i<response.length();i++){
                            JSONObject drill_down = response.getJSONObject(i);
                            DrillDown drillDone = new DrillDown(
                                    drill_down.getString("Date_Created"),
                                    drill_down.getString("shares")
                            );
                            drillDones.add(drillDone);
                        }
                        new IndividualDrillDownDialog(context,drillDones,"Statement").show();
                        progressDialog.dismiss();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                },
                error ->{
            progressDialog.dismiss();
                    error.printStackTrace();
                });
        AppConfig.getInstance().addToRequestQueue(jsonArrayRequest);
    }

    @Override
    public void onAddClubRequestsURC(String gcdsnumber, String fname, String sname, String email, String phone, String clubphone, String clubname, ClubModel clubModel) {
        progressDialog.setMessage("Sending Invitation");
        progressDialog.show();
        JSONObject jo = new JSONObject();
        try{

            jo.put("groupCdsNumber",gcdsnumber);
            jo.put("fistName",fname);
            jo.put("surname",sname);
            jo.put("email",email);
            jo.put("phone",phone);
            jo.put("fromCdsNumber",clubModel.getChairman().getCdsNumber());

        }catch (Exception e){
            progressDialog.dismiss();
            e.printStackTrace();
            return;
        }

        JsonObjectRequest jor = new JsonObjectRequest(Constants.COMPLETE_URL("clubs/invite"),jo,response -> {
                    try{
                        JSONObject j =response;
                        progressDialog.dismiss();
                        boolean b = j.getBoolean("status");
                        if(b){
                            new AlertDialog.Builder(context)
                                    .setMessage(j.getString("message"))
                                    .setPositiveButton("ok",null)
                                    .create()
                                    .show();
                        }else{
                            showDialog(j.getString("message"));
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    progressDialog.dismiss();
                    showDialog("Failed To Read Data.Please Try Again Later");
                    }
        },error -> {
            progressDialog.dismiss();
                showDialog("Error On Connecting.Please Try Again Later");
                error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jor);

    }

    @Override
    public void onContribute(String cCdsNumber, String mCdsNumber, String amount,Activity activity) {
        progressDialog.setMessage("Posting Contribution....");
        progressDialog.show();

        JsonObjectRequest jr = new JsonObjectRequest(Constants.COMPLETE_URL("cash/transfer/club"),
                Constants.amountClubJSON(cCdsNumber,mCdsNumber,Float.parseFloat(amount)),response -> {
            progressDialog.dismiss();
                try {
                    activity.recreate();
                    Toast.makeText(activity,response.getString("message"),Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                }
        },error -> {
            progressDialog.dismiss();
            showDialog("Error Occurred,Please Try Again!");
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jr);
    }

    @Override
    public void onWithdraw(String cCdsNumber, String mCdsNumber, String amount, Activity activity) {
        progressDialog.setMessage("Withdrawing ....");
        progressDialog.show();

        JsonObjectRequest jr = new JsonObjectRequest(Constants.COMPLETE_URL("cash/withdraw/club"),
                Constants.amountClubJSON(cCdsNumber,mCdsNumber,Float.parseFloat(amount)),response -> {
            progressDialog.dismiss();
            try {
                activity.recreate();
                Toast.makeText(activity,response.getString("message"),Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                progressDialog.dismiss();
                e.printStackTrace();
            }
        },error -> {
            progressDialog.dismiss();
            showDialog("Error Occurred,Please Try Again!");
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jr);
    }

    private void showDialog(String message){
        new AlertDialog.Builder(context)
                .setMessage(message)
                .setPositiveButton("ok",null)
                .create()
                .show();
    }
    private int convertToInt(String s){
        int i;
        try{
            i = Integer.parseInt(s);
        }catch (Exception e){
            i = 0;
        }
        return i;
    }
    private double convertToDouble(String s){
        double i;
        try{
            i = Double.parseDouble(s);
        }catch (Exception e){
            i = 0;
        }
        return i;
    }

    private void showDialogRefreshable(String message){
        if(icRefreshRefreshLister != null){
            new AlertDialog.Builder(context)
                    .setMessage(message)
                    .setPositiveButton("ok",(dialog, which)
                            -> icRefreshRefreshLister.doRefresh(""))
                    .create()
                    .show();
        }
    }
    public void setIcRefreshRefreshLister(InvestmentClub.ICRefreshRefreshLister icRefreshRefreshLister) {
        this.icRefreshRefreshLister = icRefreshRefreshLister;
    }
}
