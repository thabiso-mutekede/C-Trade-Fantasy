package zw.co.escrow.ctradelive.setup.services;

import android.app.Activity;
import android.util.Log;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MarketWatchETFAdapter;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MarketWatchFINSECAdapter;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.MarketWatchZSEAdapter;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.MarketWatchETF;
import zw.co.escrow.ctradelive.model.MarketWatchFINSEC;
import zw.co.escrow.ctradelive.model.MarketWatchZSE;
import zw.co.escrow.ctradelive.setup.listeners.CTradeDataListener;

public class CTradeDataServices implements CTradeDataListener {
    private final Activity context;
    private final RecyclerView recyclerView;

    public CTradeDataServices(Activity context, RecyclerView recyclerView) {
        this.context = context;
        this.recyclerView = recyclerView;
    }

    public CTradeDataServices(Activity context) {
        this.context = context;
        this.recyclerView = null;
    }

    @Override
    public void getZSEMarketWatch(ClubModel clubModel) {

        JsonArrayRequest jr = new JsonArrayRequest(Constants.COMPLETE_URL("data/zse/equity"),
                response -> {

                    List<MarketWatchZSE> marketWatchZSEList = new ArrayList<>();
                    try{

                        for(int i = 0;i<response.length();i++){
                            JSONObject c = response.getJSONObject(i);
                            MarketWatchZSE marketWatchZSE = new MarketWatchZSE();
                            marketWatchZSE.setTicker(c.getString("ticker"));
                            marketWatchZSE.setAsk_Volume(c.getDouble("askVolume"));
                            marketWatchZSE.setBest_bid(c.getDouble("bestBid"));
                            marketWatchZSE.setBid_Volume(c.getDouble("bidVolume"));
                            marketWatchZSE.setFullCompanyName(c.getString("thefullname"));
                            marketWatchZSE.setBest_Ask(c.getDouble("bestAsk"));
                            marketWatchZSE.setPrevChange(c.getDouble("priceChange"));
                            marketWatchZSE.setPrevPer(c.getDouble("percentageChange"));
                            marketWatchZSE.setPrevPrice(c.getDouble("prevPrice"));
                            marketWatchZSE.setCurrent_price(c.getDouble("currentPrice"));

                            marketWatchZSEList.add(marketWatchZSE);
                        }

                        MarketWatchZSEAdapter marketWatchZSEAdapter = new MarketWatchZSEAdapter(context, marketWatchZSEList,recyclerView,clubModel);
                        recyclerView.setAdapter(marketWatchZSEAdapter);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                },error -> {
            error.printStackTrace();
        });

        AppConfig.getInstance().addToRequestQueue(jr);

    }

    @Override
    public void getFINSECMarketWatch(ClubModel clubModel) {
        JsonArrayRequest jr = new JsonArrayRequest(Constants.COMPLETE_URL("data/finsec"),
                response -> {

                    List<MarketWatchFINSEC> marketWatchFINSECList = new ArrayList<>();
                    try{
                        for(int i = 0;i<response.length();i++){
                            JSONObject c = response.getJSONObject(i);
                            MarketWatchFINSEC marketWatchFINSEC = new MarketWatchFINSEC();
                            marketWatchFINSEC.setMarket_company(c.getString("market_company"));
                            marketWatchFINSEC.setMarket_bbv(c.getDouble("market_bbv"));
                            marketWatchFINSEC.setMarket_bp(c.getDouble("market_bp"));
                            marketWatchFINSEC.setMarket_va(c.getDouble("market_va"));
                            marketWatchFINSEC.setMarket_ap(c.getDouble("market_ap"));
                            marketWatchFINSEC.setMarket_vwap(c.getDouble("market_vwap"));
                            marketWatchFINSEC.setMarket_lv(c.getDouble("market_lv"));
                            marketWatchFINSEC.setMarket_lp(c.getDouble("market_lp"));
                            marketWatchFINSEC.setMarket_tv(c.getDouble("market_tv"));
                            marketWatchFINSEC.setMarket_to(c.getDouble("market_to"));
                            marketWatchFINSEC.setMarket_open(c.getDouble("market_open"));
                            marketWatchFINSEC.setMarket_high(c.getDouble("market_high"));
                            marketWatchFINSEC.setMarket_low(c.getDouble("market_low"));
                            marketWatchFINSEC.setMarket_change(c.getDouble("market_change"));
                            marketWatchFINSEC.setMarket_per_change(c.getDouble("market_per_change"));
                            marketWatchFINSEC.setDetails(c.getString("details"));
                            marketWatchFINSEC.setFullCompanyName(c.getString("fullCompanyName"));
                            marketWatchFINSECList.add(marketWatchFINSEC);
                        }

                        MarketWatchFINSECAdapter marketWatchFINSECAdapter = new MarketWatchFINSECAdapter(context,marketWatchFINSECList,clubModel);
                        recyclerView.setAdapter(marketWatchFINSECAdapter);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                },error -> {
            error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }

    @Override
    public void getMarketWatchETF() {
        JsonArrayRequest jr = new JsonArrayRequest(Constants.COMPLETE_URL("data/zse/etf"),
                response -> {

                    List<MarketWatchETF> marketWatchETFList = new ArrayList<>();
                    try {
                        Log.d("em",response.toString());
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject c = response.getJSONObject(i);
                            MarketWatchETF marketWatchETF = new MarketWatchETF();
                            marketWatchETF.setTicker(c.getString("ticker"));
                            marketWatchETF.setAsk_Volume(c.getDouble("askVolume"));
                            marketWatchETF.setBest_bid(c.getDouble("bestBid"));
                            marketWatchETF.setBid_Volume(c.getDouble("bidVolume"));
                            marketWatchETF.setFullCompanyName(c.getString("thefullname"));
                            marketWatchETF.setBest_Ask(c.getDouble("bestAsk"));
                            marketWatchETF.setPrevChange(c.getDouble("priceChange"));
                            marketWatchETF.setPrevPer(c.getDouble("percentageChange"));
                            marketWatchETF.setPrevPrice(c.getDouble("prevPrice"));
                            marketWatchETF.setCurrent_price(c.getDouble("currentPrice"));

                            marketWatchETFList.add(marketWatchETF);
                        }
                        MarketWatchETFAdapter marketWatchETFAdapter = new MarketWatchETFAdapter(context, marketWatchETFList, recyclerView);
                        recyclerView.setAdapter(marketWatchETFAdapter);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },error -> {
            error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }

    @Override
    public void getHighLow(String company, Integer period, List<TextView> highTxt, List<TextView> lowTxt) {
//        Call<List<HighLow>> call = api.getHighLow(company,period);
//        call.enqueue(new Callback<List<HighLow>>() {
//            @Override
//            public void onResponse(Call<List<HighLow>> call, Response<List<HighLow>> response) {
//                List<HighLow> responseBody = response.body();
//                if(responseBody != null){
//                    HighLow highLow = responseBody.get(0);
//                    double high = highLow.getHigh();
//                    double low = highLow.getLow();
//
//                    for(TextView txt : highTxt)
//                        txt.setText(String.valueOf(high));
//
//                    for(TextView txt : lowTxt)
//                        txt.setText(String.valueOf(low));
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<HighLow>> call, Throwable t) {
//                t.printStackTrace();
//            }
//        });
    }
}
