package zw.co.escrow.ctradelive.view;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputLayout;

import java.text.DateFormat;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.MyOrder;

public class AmmedOrderActivity extends AppCompatActivity {

    private Utils utils;

    private TextInputLayout outlinedTextFieldPrice, outlinedTextFieldQuantity;
    private static final String TAG = "PostInvestmentActivity";
    private TextView txtType, txtQuantity, txtDate, txtPrice;
    private DateFormat formatter;
    private String cds_number,heading,title;
    private ProgressDialog progressDialog;
    private Toolbar toolbar;
    private MyOrder myOrder;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ammed_order);


        initWidgets();
        progressDialog = new ProgressDialog(this);


        myOrder = getIntent().getParcelableExtra("my_order");


        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(AmmedOrderActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("Edit order");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }




        txtType.setText(String.format("Type: %s", myOrder.getType()));
        txtQuantity.setText(String.format("Quantity: %s", myOrder.getQuantity()));
        txtDate.setText(myOrder.getDate());



        txtPrice.setText(String.format("Price: %s", myOrder.getPrice()));







        findViewById(R.id.btnAmmend).setOnClickListener(view -> {

            String price = outlinedTextFieldPrice.getEditText().getText().toString();
            String quantity = outlinedTextFieldQuantity.getEditText().getText().toString();


            if (price.equals("") || price.equals("0")) {
                outlinedTextFieldPrice.setError("Amount should be greater than 0");
            }
            else if (quantity.equals("") || quantity.equals("0") || quantity.length() == 0){
                outlinedTextFieldQuantity.setError("Please enter quantity");

            }
            else {
                outlinedTextFieldPrice.setErrorEnabled(false);
                outlinedTextFieldQuantity.setErrorEnabled(false);

                Toast.makeText(this, "Hi Loyd ammend order here", Toast.LENGTH_SHORT).show();


            }

        });





    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initWidgets(){

        outlinedTextFieldPrice =findViewById(R.id.outlinedTextFieldPrice);
        outlinedTextFieldQuantity =findViewById(R.id.outlinedTextFieldQuantity);

        txtType =findViewById(R.id.txtType);
        txtQuantity =findViewById(R.id.txtQuantity);
        txtDate =findViewById(R.id.txtDate);
        txtPrice=findViewById(R.id.txtPrice);

    }


    private void postInvest( View view) {

        Toast.makeText(this, "Hi Lloyd please implement ammend order here", Toast.LENGTH_SHORT).show();


    }


}