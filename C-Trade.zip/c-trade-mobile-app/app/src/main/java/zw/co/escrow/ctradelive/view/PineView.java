package zw.co.escrow.ctradelive.view;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;

import zw.co.escrow.ctradelive.R;


public class PineView extends AppCompatActivity {

    private static final String TAG = "PineView";

    private String userEntered, userPin = "8888";

    private final int PIN_LENGTH = 4;
    private boolean keyPadLockedFlag = false;
    private Context appContext;

    private TextView pinBox0, pinBox1, pinBox2, pinBox3, ForgetPin, errorNoted;

    private TextView[] pinBoxArray;

    private RelativeLayout TextView0, TextView1, TextView2, TextView3, TextView4, TextView5,
            TextView6, TextView7, TextView8, TextView9;

    private ImageView TextViewDelete;
    private long timestamp, timestampNow;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zzkepad);
        appContext = this;
        userEntered = "";
        SharedPreferences prfs = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        userPin = prfs.getString("mypin", "");
        timestamp = prfs.getLong("timestamp", 100L);

        Calendar calendar = Calendar.getInstance();
        System.out.println(calendar.getTime());
        calendar.add(Calendar.MINUTE, 5);
        timestampNow =  calendar.getTime().getTime();
        Log.e("timestampNow :",timestampNow+"") ;



        TextViewDelete = findViewById(R.id.hash);

        View parentLayout = findViewById(android.R.id.content);
        Snackbar.make(parentLayout, R.string.pin_sent_to_email, Snackbar.LENGTH_INDEFINITE)
                .setAction("OK", view -> {

                })
                .setActionTextColor(getResources().getColor(android.R.color.holo_green_light))
                .show();

        TextViewDelete.setOnClickListener(v -> {
                    if (keyPadLockedFlag) {
                        return;
                    }

                    if (userEntered.length() > 0) {
                        userEntered = userEntered.substring(0, userEntered.length() - 1);
                        pinBoxArray[userEntered.length()]
                                .setBackgroundResource(R.drawable.pin_code_round_empty);
                    }
                }
        );
        ForgetPin = findViewById(R.id.forget_pin);
        ForgetPin.setOnClickListener(view -> {
            finish();
            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
            startActivity(new Intent(PineView.this, MainActivity.class));
        });

        errorNoted = findViewById(R.id.errornoted);
        if(timestamp>timestampNow){
            errorNoted.setText("Your OTO expired Press \n Resend pin ");

            errorNoted.setVisibility(View.VISIBLE);
        }

        pinBox0 = findViewById(R.id.pinBox0);
        pinBox1 = findViewById(R.id.pinBox1);
        pinBox2 = findViewById(R.id.pinBox2);
        pinBox3 = findViewById(R.id.pinBox3);

        pinBoxArray = new TextView[PIN_LENGTH];
        pinBoxArray[0] = pinBox0;
        pinBoxArray[1] = pinBox1;
        pinBoxArray[2] = pinBox2;
        pinBoxArray[3] = pinBox3;

        View.OnClickListener pinTextViewHandler = v -> {

            if (keyPadLockedFlag) {
                return;
            }

            RelativeLayout pressedTextViewx = (RelativeLayout) v;
            TextView pressedTextView = (TextView) pressedTextViewx.getChildAt(0);

            if (userEntered.length() < PIN_LENGTH) {

                userEntered = userEntered + pressedTextView.getText();
                Log.d("PinView", "User entered=" + userEntered);

                //Update pin boxes
                pinBoxArray[userEntered.length() - 1].setBackgroundResource(R.drawable.pin_code_round_full); // setText("8");

                if (userEntered.length() == PIN_LENGTH) {
                    Calendar calendare = Calendar.getInstance();
                    System.out.println(calendare.getTime());
                    //calendare.(Calendar.MINUTE, 5);
                    timestampNow =  calendare.getTime().getTime();

                    long diff = timestampNow - timestamp;
                    if(diff >= 5 * 60 * 1000)
                    {
                        errorNoted.setText("Your OTO expired Press \n Resend pin ");
                        errorNoted.setVisibility(View.VISIBLE);
                    } else{

                    if (userPin.equals(userEntered)) {

                    } else {
                        errorNoted.setVisibility(View.VISIBLE);
                        pinBoxArray[0].setBackgroundResource(R.drawable.pin_code_round_empty);

                        pinBoxArray[1].setBackgroundResource(R.drawable.pin_code_round_empty);

                        pinBoxArray[2].setBackgroundResource(R.drawable.pin_code_round_empty);

                        pinBoxArray[3].setBackgroundResource(R.drawable.pin_code_round_empty);

                    }

                    }
                }
            } else {
                //Roll over
                pinBoxArray[0].setText("");
                pinBoxArray[1].setText("");
                pinBoxArray[2].setText("");
                pinBoxArray[3].setText("");

                userEntered = "";

                userEntered = userEntered + pressedTextView.getText();
                Log.v("PinView", "User entered=" + userEntered);

                //Update pin boxes
                pinBoxArray[userEntered.length() - 1].
                        setBackgroundResource(R.drawable.pin_code_round_full);
            }
        };


        TextView0 = findViewById(R.id.zero1);

        TextView0.setOnClickListener(pinTextViewHandler);

        TextView1 = findViewById(R.id.one1);

        TextView1.setOnClickListener(pinTextViewHandler);

        TextView2 = findViewById(R.id.two1);

        TextView2.setOnClickListener(pinTextViewHandler);

        TextView3 = findViewById(R.id.three1);

        TextView3.setOnClickListener(pinTextViewHandler);

        TextView4 = findViewById(R.id.four1);

        TextView4.setOnClickListener(pinTextViewHandler);

        TextView5 = findViewById(R.id.five1);

        TextView5.setOnClickListener(pinTextViewHandler);

        TextView6 = findViewById(R.id.six1);

        TextView6.setOnClickListener(pinTextViewHandler);

        TextView7 = findViewById(R.id.seven1);

        TextView7.setOnClickListener(pinTextViewHandler);

        TextView8 = findViewById(R.id.eight1);

        TextView8.setOnClickListener(pinTextViewHandler);

        TextView9 = findViewById(R.id.nine1);

        TextView9.setOnClickListener(pinTextViewHandler);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed(); // Cerrar esta actividad
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
       // new DashboardActivity().finish();
        Toast.makeText(PineView.this,"onBackPressed", Toast.LENGTH_LONG).show();
    }
}