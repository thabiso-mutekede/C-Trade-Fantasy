package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.IPO;
import zw.co.escrow.ctradelive.view.IpoView;

public class IPOsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<IPO> ipos;
    private final Context context;
    private static final String TAG = "IPOsAdapter";
    private final RecyclerView recyclerView;

    public IPOsAdapter(Context context,List<IPO> ipos,RecyclerView recyclerView) {
        this.ipos = ipos;
        this.context = context;
        this.recyclerView = recyclerView;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.ipo_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);

        view.setOnClickListener(v ->{
            IPO ipo = ipos.get(recyclerView.getChildAdapterPosition(view));
            context.startActivity(new Intent(context, IpoView.class).putExtra("ipo",ipo));
        });

        return new IPOViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((IPOViewHolder)holder).onBindData(ipos.get(position));
    }


    @Override
    public int getItemCount() {
        return ipos.size();
    }

    static class IPOViewHolder extends RecyclerView.ViewHolder{


        private TextView issuerCode,dailyLimit,interestRate,status;



        public IPOViewHolder(@NonNull View itemView) {
            super(itemView);
            issuerCode = itemView.findViewById(R.id.txtIssuerCode);
            dailyLimit = itemView.findViewById(R.id.txtDailyLimit);
            interestRate = itemView.findViewById(R.id.txtInterestRate);
            status = itemView.findViewById(R.id.txtStatus);
        }

        private void onBindData(IPO ipo){
            issuerCode.setText(ipo.getIssuer_Code());
            dailyLimit.setText("Daily Limit : "+ipo.getDailyLimit());
            interestRate.setText("Int Rate : "+ipo.getInterestRate());
            if(ipo.getIPOSTATUS() == 1) status.setText("OPEN");
            else status.setText("CLOSED");

        }
    }
}