package zw.co.escrow.ctradelive.view.dialogs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import zw.co.escrow.ctradelive.R;

public class TempActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);
    }
}