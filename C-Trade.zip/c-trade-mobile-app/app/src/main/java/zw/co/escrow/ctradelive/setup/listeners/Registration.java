package zw.co.escrow.ctradelive.setup.listeners;


import android.content.Context;
import android.graphics.Bitmap;

public class Registration {
    public interface DataListener{
        void createCTradeAccount(Context context,String client, Bitmap bitmap,Bitmap id);
    }
}
