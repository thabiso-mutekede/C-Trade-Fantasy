package zw.co.escrow.ctradelive.view;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

import java.util.Calendar;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.MarketWatchETF;
import zw.co.escrow.ctradelive.model.MarketWatchFINSEC;
import zw.co.escrow.ctradelive.model.MarketWatchZSE;
import zw.co.escrow.ctradelive.view.fragments.CompanyAnalysisFragment;

public class CompanyAnalysisActivity extends AppCompatActivity {


    private Utils utils;
    private FragmentPagerItemAdapter watchListPagerAdapter;
    private ViewPager watchListPager;
    private SmartTabLayout watchListPagerTab;
    private String[] companyDetails;
    private TextView txtTicker, txtCompanyName, txtBestBid, txtDay, txtCurrentPrice, txtPercentageChange;
    private CardView cardView;
    private static final String TAG = "CompanyAnalysisActivity";
    private Toolbar toolbar;
    private MarketWatchZSE marketWatchZSE;
    private MarketWatchETF marketWatchETF;
    private MarketWatchFINSEC marketWatchFINSEC;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_analysis);
        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(CompanyAnalysisActivity.this);

        initWidgets();

        toolbar=findViewById(R.id.home_toolbar);

        setSupportActionBar(toolbar);

        watchListPagerTab = findViewById(R.id.viewpagertab);
        watchListPager = findViewById(R.id.viewPagerWatchList);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }

        utils = new Utils(this);
        marketWatchETF = getIntent().getParcelableExtra("etf");
        marketWatchZSE = getIntent().getParcelableExtra("ZSE");
        marketWatchFINSEC = getIntent().getParcelableExtra("FINSEC");
        Calendar calendar = Calendar.getInstance();


        if (marketWatchZSE != null){
            txtTicker.setText(marketWatchZSE.getTicker());
            txtCompanyName.setText(marketWatchZSE.getFullCompanyName());
            txtBestBid.setText(String.format("%s", marketWatchZSE.getBest_bid()));
            txtDay.setText(calendar.getTime().toString().substring(0, calendar.getTime().toString().indexOf('G')));
            txtCurrentPrice.setText(String.format("%s", marketWatchZSE.getCurrent_price()));


            txtPercentageChange.setText(String.format("%s%%", marketWatchZSE.getPrevChange()));


            if (marketWatchZSE.getPrevChange() > 0){
                cardView.setCardBackgroundColor(getResources().getColor(R.color.colorDarkGreen));
            }

            setUpWatchList(marketWatchZSE);

        }
        else if (marketWatchETF != null){
            txtTicker.setText(marketWatchETF.getTicker());
            txtCompanyName.setText(marketWatchETF.getFullCompanyName());
            txtBestBid.setText(String.format("%s", marketWatchETF.getBest_bid()));
            txtDay.setText(calendar.getTime().toString().substring(0, calendar.getTime().toString().indexOf('G')));
            txtCurrentPrice.setText(String.format("%s", marketWatchETF.getCurrent_price()));
            txtPercentageChange.setText(String.format("%s%%", marketWatchETF.getPrevChange()));

            if (marketWatchETF.getPrevChange() > 0){
                cardView.setCardBackgroundColor(getResources().getColor(R.color.colorDarkGreen));
            }
            setUpWatchList(marketWatchETF);

        }
        else if (marketWatchFINSEC != null){

            txtTicker.setText(marketWatchFINSEC.getMarket_company());
            txtCompanyName.setText(marketWatchFINSEC.getFullCompanyName());
            txtBestBid.setText(String.format("%s", marketWatchFINSEC.getMarket_bp()));
            txtDay.setText(calendar.getTime().toString().substring(0, calendar.getTime().toString().indexOf('G')));
            txtCurrentPrice.setText(String.format("%s", marketWatchFINSEC.getMarket_vwap()));
            txtPercentageChange.setText(String.format("%s%%", marketWatchFINSEC.getMarket_per_change()));

            if (marketWatchFINSEC.getMarket_per_change() > 0){
                cardView.setCardBackgroundColor(getResources().getColor(R.color.colorDarkGreen));
            }
            setUpWatchList(marketWatchFINSEC);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initWidgets(){
        txtTicker = findViewById(R.id.txtTicker);
        txtCompanyName = findViewById(R.id.txtCompanyName);
        txtBestBid = findViewById(R.id.txtBestBid);
        txtDay = findViewById(R.id.txtDay);
        txtCurrentPrice = findViewById(R.id.txtCurrentPrice);
        txtPercentageChange = findViewById(R.id.txtPercentageChange);
        cardView = findViewById(R.id.wl_change_indicator);
    }



    private void setUpWatchList(MarketWatchZSE marketWatchZSE){

        Bundle bundle = new Bundle();
        bundle.putBoolean("isClub",getIntent().getBooleanExtra("isClub",false));
        bundle.putParcelable("club",getIntent().getParcelableExtra("club"));
        bundle.putString("cdsnumber",getIntent().getStringExtra("cdsnumber"));
        bundle.putParcelable(getString(R.string.EXCHANGE),marketWatchZSE);

        setUpViewPager(bundle);

    }
    private void setUpWatchList(MarketWatchETF marketWatchETF){

        Bundle bundle = new Bundle();
        bundle.putBoolean("isClub",getIntent().getBooleanExtra("isClub",false));
        bundle.putParcelable("club",getIntent().getParcelableExtra("club"));
        bundle.putString("cdsnumber",getIntent().getStringExtra("cdsnumber"));
        bundle.putParcelable(Constants.ETF,marketWatchETF);





        setUpViewPager(bundle);



    }

    private void setUpWatchList(MarketWatchFINSEC marketWatchFINSEC){

        Bundle bundle = new Bundle();
        bundle.putBoolean("isClub",getIntent().getBooleanExtra("isClub",false));
        bundle.putParcelable("club",getIntent().getParcelableExtra("club"));
        bundle.putString("cdsnumber",getIntent().getStringExtra("cdsnumber"));
        bundle.putParcelable(getString(R.string.EXCHANGE),marketWatchFINSEC);
        setUpViewPager(bundle);


    }

    private void setUpViewPager(Bundle bundle){
        watchListPagerAdapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("OVERVIEW", CompanyAnalysisFragment.class, bundle)
                //.add("EARNINGS", MarketWatchPlaceHolderFragment.class)
                //.add("FINANCIAL DATA", MarketWatchPlaceHolderFragment.class)
                .create());
        watchListPager.setAdapter(watchListPagerAdapter);
        watchListPagerTab.setViewPager(watchListPager);
    }


}