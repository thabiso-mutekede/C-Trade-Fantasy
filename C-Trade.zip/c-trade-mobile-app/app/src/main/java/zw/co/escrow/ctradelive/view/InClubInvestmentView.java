package zw.co.escrow.ctradelive.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;


import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;
import zw.co.escrow.ctradelive.setup.services.InvestmentClubService;


public class InClubInvestmentView extends AppCompatActivity {

    private Toolbar toolbar;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ClubModel club;
    private InvestmentClub.ClubServicesListener clubServicesListener;
    private RecyclerView recyclerView;
    private String cdsnumber;


    TextView txt1,txt2,txt3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_club_investment_view);

        txt3 = findViewById(R.id.mt);

        txt1 = findViewById(R.id.club_tot);
        txt2 = findViewById(R.id.my_tot);

        swipeRefreshLayout = findViewById(R.id.refresher);
        swipeRefreshLayout.setOnRefreshListener(()->recreate());

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Investments");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());
        recyclerView = findViewById(R.id.investments_recycler);
        clubServicesListener = new InvestmentClubService(this,recyclerView);


        YoYo.with(Techniques.Flash)
                .duration(5000)
                .repeat(1000000)
                .playOn(findViewById(R.id.club_statement));

        club = getIntent().getParcelableExtra("club");
        cdsnumber = getSharedPreferences("CTRADE",MODE_PRIVATE).getString("cds_number","");
        if(club.isMember())findViewById(R.id.club_statement_ll).setVisibility(View.GONE);
        findViewById(R.id.club_statement).setOnClickListener(v ->
        startActivity(new Intent(this,ClubHoldingsView.class).putExtra("club",club)));
        clubServicesListener.onLoadClubInvestments(club.getClubCdsNumber(),cdsnumber,txt1,txt2);
        Snackbar.make(findViewById(R.id.rr), "Swipe Down To Refresh Page",
                BaseTransientBottomBar.LENGTH_LONG).show();

        txt3.setText("'"+club.getClubName()+"' Total");
    }

}