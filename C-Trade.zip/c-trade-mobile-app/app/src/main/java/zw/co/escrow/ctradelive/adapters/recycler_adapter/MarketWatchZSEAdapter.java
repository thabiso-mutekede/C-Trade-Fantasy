package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.ClubModel;
import zw.co.escrow.ctradelive.model.MarketWatchZSE;
import zw.co.escrow.ctradelive.view.CompanyAnalysisActivity;

public class MarketWatchZSEAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<MarketWatchZSE> marketWatchZSE;
    private Activity activity;
    private static final String TAG = "MarketWatchZSEAdapter";
    private final RecyclerView recyclerView;
    private final ClubModel clubModel;
    private SharedPreferences sharedPreferences;

    public MarketWatchZSEAdapter(Activity activity, List<MarketWatchZSE> marketWatchZSE, RecyclerView recyclerView, ClubModel clubModel) {
        this.marketWatchZSE = marketWatchZSE;
        this.activity = activity;
        this.recyclerView = recyclerView;
        this.clubModel = clubModel;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.watch_list_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        view.setOnClickListener(v-> {

            Intent intent = new Intent(activity, CompanyAnalysisActivity.class);

            MarketWatchZSE zse = marketWatchZSE.get(recyclerView.getChildAdapterPosition(view));
            intent.putExtra("ZSE", zse);
            intent.putExtra("EQUITY",true);
            sharedPreferences = activity.getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
            intent.putExtra("cdsnumber",sharedPreferences.getString("cds_number",""));
            if(clubModel != null){
                intent.putExtra("isClub",true);
                intent.putExtra("club",clubModel);
            }
            activity.startActivity(intent);

        });

        return new WatchListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((WatchListViewHolder)holder).onBindData(marketWatchZSE.get(position),activity);
    }


    @Override
    public int getItemCount() {
        return marketWatchZSE.size();
    }

    static class WatchListViewHolder extends RecyclerView.ViewHolder{

        private TextView txtTicker, txtCompanyName, txtBestBid, txtBestAsk, txtCurrentPrice, txtPercentageChange;
        private CardView cardView, cardViewCompany;

        public WatchListViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTicker = itemView.findViewById(R.id.txtTicker);
            txtCompanyName = itemView.findViewById(R.id.txtCompanyName);
            txtBestBid = itemView.findViewById(R.id.txtBestBid);
            txtBestAsk = itemView.findViewById(R.id.txtBestAsk);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtPercentageChange = itemView.findViewById(R.id.txtPercentageChange);
            cardView = itemView.findViewById(R.id.wl_change_indicator);
            cardViewCompany = itemView.findViewById(R.id.cardViewCompany);
        }

        public void onBindData(MarketWatchZSE marketWatchZSE,Activity activity){
            txtTicker.setText(marketWatchZSE.getTicker());
            txtCompanyName.setText(marketWatchZSE.getFullCompanyName());
            txtBestBid.setText(String.format("BEST BID: %s", marketWatchZSE.getBest_bid()));
            txtBestAsk.setText(String.format("BEST ASK: %s", marketWatchZSE.getBest_Ask()));
            txtCurrentPrice.setText(String.valueOf(marketWatchZSE.getCurrent_price()));
            txtPercentageChange.setText(String.format("%s%%", Constants.roundToDecimalPrice(Float.parseFloat(String.valueOf(marketWatchZSE.getPrevPer())))));

            if (marketWatchZSE.getPrevChange() > 0){
                cardView.setCardBackgroundColor(activity.getResources().getColor(R.color.colorDarkGreen));
            }
        }
    }
}