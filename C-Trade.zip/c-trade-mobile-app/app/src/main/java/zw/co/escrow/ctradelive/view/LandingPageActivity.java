package zw.co.escrow.ctradelive.view;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.adapters.ImageSliderAdapter;
import zw.co.escrow.ctradelive.model.SliderItem;

public class LandingPageActivity extends AppCompatActivity {

    private final int UPDATE_REQUEST_CODE = 1000;
    private final String[] landingPageMessages = {"Welcome to C-Trade mobile"
            , "Easy and Convenient Securities Trading"
            , "Trade on the go!"
            , "Manage your portfolio anywhere"
            , "Step out of your comfort zone and start an investment club"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);

        Utils.setStatusBarColor(LandingPageActivity.this);

        initSlider(landingPageMessages);
        YoYo.with(Techniques.Flash)
                .duration(5000)
                .repeat(1000000)
                .playOn(findViewById(R.id.floating_action_button));
        findViewById(R.id.floating_action_button).setOnClickListener(view -> {
            startActivity(new Intent(LandingPageActivity.this, MainActivity.class));
        });
        //checkUpDate();
    }

    private void checkUpDate(){
        AppUpdateManager appUpdateManager = AppUpdateManagerFactory.create(this);
        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(result -> {

            if(result.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
            result.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)){
                try {
                    appUpdateManager.startUpdateFlowForResult(result,AppUpdateType.IMMEDIATE,this,UPDATE_REQUEST_CODE);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }
            }
        }).addOnFailureListener(e -> {
            e.printStackTrace();
            showExitDialog("Failed To Connect To CTrade Now Please Try Again Later!.");
        });

    }

    private void initSlider(String[] landingPageMessages) {

        List<Integer> images = new ArrayList<>();


        images.add(R.drawable.a1);
        images.add(R.drawable.a2);
        images.add(R.drawable.a3);
        images.add(R.drawable.a4);
        images.add(R.drawable.a5);


        SliderView sliderView = findViewById(R.id.imageSlider);
        ImageSliderAdapter imageSliderAdapter = new ImageSliderAdapter(this);
        imageSliderAdapter.setOnSlideTaped(() -> startActivity(new Intent(LandingPageActivity.this, MainActivity.class)));
        sliderView.setSliderAdapter(imageSliderAdapter);

        SliderItem sliderItem;
        List<SliderItem> mSliderItems = new ArrayList<>();


        int count = 0;
        for (int image:images) {

            if (images != null){
                sliderItem = new SliderItem(R.drawable.a1, landingPageMessages[count]);
                mSliderItems.add(sliderItem);
                count++;
            }


        }

        if (!mSliderItems.isEmpty()){
            imageSliderAdapter.renewItems(mSliderItems);
            sliderView.setIndicatorAnimation(IndicatorAnimations.WORM); //set indicator animation by using SliderLayout.IndicatorAnimations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
            sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
            sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
            sliderView.setIndicatorSelectedColor(R.color.colorAccent);
            sliderView.setIndicatorUnselectedColor(R.color.colorAccent);
            sliderView.setScrollTimeInSec(5); //set scroll delay in seconds :
            sliderView.startAutoCycle();
        }

    }

    private void showExitDialog(String msg){
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setMessage(msg)
                .setPositiveButton("Ok",(dialogInterface, i) -> finish())
                .create();

        alertDialog.setOnShowListener(dialogInterface -> alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorAccent )));
        alertDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //checkUpDate();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case UPDATE_REQUEST_CODE:
                if(resultCode == RESULT_CANCELED) finish();
                else if(requestCode == RESULT_OK) startActivity(new Intent(LandingPageActivity.this, MainActivity.class));
                break;
        }
    }
}