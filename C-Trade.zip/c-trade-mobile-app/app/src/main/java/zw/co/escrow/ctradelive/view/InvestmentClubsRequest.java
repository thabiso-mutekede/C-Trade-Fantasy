package zw.co.escrow.ctradelive.view;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.recycler_adapter.RequestAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.model.RequestModel;
import zw.co.escrow.ctradelive.setup.listeners.InvestmentClub;

public class InvestmentClubsRequest extends AppCompatActivity implements InvestmentClub.ICRefreshRefreshLister {

    private RecyclerView recyclerView;
    private Toolbar toolbar;
    private List<RequestModel> requestModelList;
    private String cdsNumber,email;
    private final String ip = AppConfig.getIp();
    private String url;
    private SwipeRefreshLayout swipeRefreshLayout;

    ProgressDialog progressDialog;
    private InvestmentClub.ClubServicesListener clubServicesListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_investment_clubs_request);

        swipeRefreshLayout = findViewById(R.id.refresher);
        progressDialog = new ProgressDialog(this);
        recyclerView = findViewById(R.id.request_rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        requestModelList = getIntent().getParcelableArrayListExtra("requests");
        cdsNumber = getIntent().getExtras().getString("cdsnumber");
        email = getIntent().getExtras().getString("email");
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Pending Requests");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());

        swipeRefreshLayout.setOnRefreshListener(()->{
            onLoadRequestForRefresh(cdsNumber,email);
            swipeRefreshLayout.setRefreshing(false);
        });

        onLoadRequestForRefresh(cdsNumber,email);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        //RequestAdapter requestAdapter = new RequestAdapter(cdsNumber,requestModelList,this,recyclerView,isInvite);
        //recyclerView.setAdapter(requestAdapter);
    }
    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void doRefresh(String msg) {
        onLoadRequestForRefresh(cdsNumber,email);
    }

    public void onLoadRequestForRefresh(String cdsnumber, String type) {
        progressDialog.setMessage("checking for club invites....");
        progressDialog.show();
        JSONObject jo = new JSONObject();
        try{
            jo.put("cdsNumber",cdsnumber);
            jo.put("email",email);
        }catch (Exception e){
            e.printStackTrace();
        }
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(Request.Method.POST, Constants.COMPLETE_URL("clubs/invitation"),jo, response -> {
            try {
                if(response.length() <= 0){
                    progressDialog.dismiss();
                }else{
                    List<RequestModel> requestModels = new ArrayList<>();
                    for(int i = 0;i < response.length();i++){
                        JSONObject j = response.getJSONObject(i);
                        RequestModel requestModel = new RequestModel();
                        requestModel.setClubname(j.getString("name"));
                        //requestModel.setCds(j.getString("cds"));
                        requestModel.setToken(j.getString("token"));
                        requestModel.setEmail(j.getString("email"));
                        //requestModel.setPhone(j.getString("phone"));
                        //requestModel.setDate(j.getString("date"));
                        //requestModel.setName(j.getString("name"));
                        requestModels.add(requestModel);
                    }
                    RequestAdapter requestAdapter = new RequestAdapter(cdsnumber, this, requestModels,this,recyclerView);
                    recyclerView.setAdapter(requestAdapter);
                }
                progressDialog.dismiss();
            }catch (Exception e){
                progressDialog.dismiss();
                e.printStackTrace();
                showDialog("Failed To Read Data.Try Again Later");
            }
        },error -> {
            error.printStackTrace();
            progressDialog.dismiss();
            showDialog("Failed To Connect Please Try Again Later");
        });
        AppConfig.getInstance().addToRequestQueue(jr);
    }
    private void showDialog(String message){
        new AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("ok",null)
                .create()
                .show();
    }

}