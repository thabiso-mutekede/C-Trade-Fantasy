package zw.co.escrow.ctradelive.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.adapters.NewsFeedsAdapter;
import zw.co.escrow.ctradelive.model.NewsFeed;

public class NewsFeedsActivity extends AppCompatActivity {

    private Utils utils;


    RecyclerView recyclerView;
    TextView toolbarTextView;

    private List<NewsFeed> counterList = new ArrayList<>();
    private NewsFeedsAdapter mStatementAdapter;
    private String cdsNumber;
    private ProgressBar progressBar;
    private Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_feeds);

        //Change the status bar color to black to match the app's theme and should be in every activity
        Utils.setStatusBarColor(NewsFeedsActivity.this);

        utils = new Utils(this);

        TextView chartToolBarTvTitle = findViewById(R.id.chartToolBarTvTitle);
        chartToolBarTvTitle.setText("NEWS");

        toolbar=findViewById(R.id.home_toolbar);


        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.show();
        }




        progressBar = findViewById(R.id.progressBarUnitTrust);
        recyclerView = findViewById(R.id.recycler_view_feeds);

        counterList.clear();


        getTrusts();

        SharedPreferences prfs = getSharedPreferences("CTRADE", Context.MODE_PRIVATE);
        cdsNumber = prfs.getString("cds_number", "");

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    private void enableUserInteraction() {

            progressBar.setVisibility(View.GONE);
            this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

    }

    private void disableUserInteraction() {

            progressBar.setVisibility(View.VISIBLE);
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

    }

    private void getTrusts() {

        Log.d("tavman loan_application", " here");

        disableUserInteraction();

        String url = AppConfig.getIp() + "/getnewsfeeds";

        StringRequest jsonObjRequest1 =
                new StringRequest(Request.Method.POST, url,
                        trustsSuccessListener(),
                        trustsErrorListener()) {
                };

        jsonObjRequest1.setRetryPolicy(new DefaultRetryPolicy(
                AppConfig.REASONABLE_RETRY_MS,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        AppConfig.getInstance().addToRequestQueue(jsonObjRequest1);
    }

    private Response.Listener<String> trustsSuccessListener() {

        Log.d("tavman success listener", " trusts");

        return response -> {
            Log.d("tavman response trusts", "" + response);

            enableUserInteraction();

            try {
                System.out.println(response);

                if (response.equals(getString(R.string.no_data_was_found))) {
                    //showDialog(getString(R.string.no_data_was_found));
                } else {

                    try {

                        JSONArray jsonArray = new JSONArray(response);

                        if (jsonArray.length() > 0) {

                            Log.d("Json array size ", " is " + jsonArray.length());

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                System.out.println("Json object " + jsonObject);
                                String company =
                                        jsonObject.optString("Heading");
                                String message = jsonObject.optString("Message");


                                counterList.add(new NewsFeed(message,
                                        company, "active", "passive"));

                            }

                            Log.d("tavman list ", "" + counterList.size());
                            mStatementAdapter = new NewsFeedsAdapter(this,counterList, recyclerView);
                            configureRecyclerView();

                        } else {
                            //showDialog(getString(R.string.no_data_was_found));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        //showDialog(getString(R.string.no_data_was_found));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        };

    }

    private Response.ErrorListener trustsErrorListener() {

        return error -> {

            Log.d("tavman error listener", error.toString());
            enableUserInteraction();

            try {

                new AlertDialog.Builder(this)
                        .setTitle(R.string.result)
                        .setCancelable(false)
                        .setMessage(getString(R.string.badnetwork))
                        .setPositiveButton("OK", (dialog, which) -> {

                        })
                        .show();
            } catch (Exception e) {
            }
        };
    }

    private void showDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.result)
                .setCancelable(false)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> {

                })
                .show();
    }

    private void configureRecyclerView() {

        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager mLayoutManager =
                new LinearLayoutManager(this);

        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(mStatementAdapter);


    }


    @SuppressLint("StaticFieldLeak")
    public class PostingUnitTrust extends AsyncTask<String, Void, String> {
        String add_info_url;

        @Override
        protected void onPreExecute() {
            add_info_url = AppConfig.getApiV2() + "/OrderPostingMakeNew";
        }

        @Override
        protected String doInBackground(String... args) {
            String company, security, tif, orderTrans, orderType,
                    price, quantity, cdsNumber, source, broker, expiryDate, corpName, corpId;
            company = args[0].trim();
            security = args[1];
            tif = args[2];
            orderTrans = args[3];
            orderType = args[4];
            quantity = args[5];
            price = args[6];
            cdsNumber = args[7];
            broker = args[8];
            source = args[9];
            corpName = args[10];
            corpId = args[11];
            expiryDate = args[12];
            Log.d("My URL", add_info_url);

            try {
                URL url = new URL(add_info_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setConnectTimeout(AppConfig.REASONABLE_RETRY_MS);
                httpURLConnection.setReadTimeout(AppConfig.REASONABLE_RETRY_MS);

                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(new OutputStreamWriter(outputStream,
                                "UTF-8"));

                String data_string;

                data_string =
                        URLEncoder.encode("company", "UTF-8") + "="
                                + URLEncoder.encode(company, "UTF-8")

                                + "&" + URLEncoder.encode("security", "UTF-8") + "=" +
                                URLEncoder.encode(security, "UTF-8")

                                + "&" + URLEncoder.encode("tif", "UTF-8") + "="
                                + URLEncoder.encode(tif, "UTF-8")

                                + "&" + URLEncoder.encode("orderTrans", "UTF-8") + "="
                                + URLEncoder.encode(orderTrans, "UTF-8")

                                + "&" + URLEncoder.encode("orderType", "UTF-8") + "="
                                + URLEncoder.encode(orderType, "UTF-8")

                                + "&" + URLEncoder.encode("quantity", "UTF-8") + "="
                                + URLEncoder.encode(quantity, "UTF-8")

                                + "&" + URLEncoder.encode("price", "UTF-8") + "="
                                + URLEncoder.encode(price, "UTF-8")

                                + "&" + URLEncoder.encode("cdsNumber", "UTF-8")
                                + "=" + URLEncoder.encode(cdsNumber, "UTF-8")

                                + "&" + URLEncoder.encode("broker", "UTF-8")
                                + "=" + URLEncoder.encode(broker, "UTF-8")

                                + "&" + URLEncoder.encode("source", "UTF-8")
                                + "=" + URLEncoder.encode(source, "UTF-8")

                                + "&" + URLEncoder.encode("date_", "UTF-8")
                                + "=" + URLEncoder.encode(expiryDate, "UTF-8");


                Log.d("My URL", data_string);
                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =
                        new BufferedReader(
                                new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;

            } catch (MalformedURLException e) {
                return "Bad Url " + e.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return "Cant Reach " + e.toString();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            enableUserInteraction();

            Log.d("tavman myTag", result);

            String message;

            if (result.equalsIgnoreCase("1"))
                message = "Your order has been posted successfully!";
            else message = result;

            new AlertDialog.Builder(NewsFeedsActivity.this)
                    .setTitle(R.string.result)
                    .setCancelable(false)
                    .setMessage(message)
                    //.setMessage(R.string.order_posting_successful)
                    .setPositiveButton("OK", (dialog, which) -> {
                        NewsFeedsActivity.this.recreate();
                            }
                    ).setNegativeButton("Cancel",
                    (dialogInterface, i) -> {
                        NewsFeedsActivity.this.recreate();
                    })
                    .show();

        }

        @Override
        protected void onProgressUpdate(Void... values) {
            enableUserInteraction();
            super.onProgressUpdate(values);
        }

    }


}