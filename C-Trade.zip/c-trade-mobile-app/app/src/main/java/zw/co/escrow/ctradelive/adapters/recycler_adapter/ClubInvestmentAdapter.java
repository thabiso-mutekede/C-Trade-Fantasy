package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Investment;

public class ClubInvestmentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private final List<Investment> investments;

    public ClubInvestmentAdapter(List<Investment> investments) {
        this.investments = investments;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.club_investment_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new InvestmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((InvestmentViewHolder)holder).onBindData(investments.get(position));
    }

    @Override
    public int getItemCount() {
        return investments.size();
    }

    private class InvestmentViewHolder extends RecyclerView.ViewHolder{

        TextView  txtCounter,txtType,txtUnits,txtValue,txtPrice,txtMyShare;

        public InvestmentViewHolder(@NonNull View itemView) {
            super(itemView);
            txtCounter = itemView.findViewById(R.id.txtCounter);
            txtType = itemView.findViewById(R.id.txtType);
            txtUnits = itemView.findViewById(R.id.txtQuantity);
            txtValue = itemView.findViewById(R.id.txtValue);
            txtPrice = itemView.findViewById(R.id.txtPrice);
            txtMyShare = itemView.findViewById(R.id.txtMyShare);

        }

        public void onBindData(Investment investment) {

            txtCounter.setText(investment.getCounter());
            txtType.setText(investment.getType());
            txtUnits.setText("Club Units : "+getThousandSep(roundToDecimalPlaceShare(convertToFloat(investment.getUnits()))));
            Log.d("lloda - 4dp",getThousandSep(roundToDecimalPlaceShare(convertToFloat(investment.getUnits())))+" "+roundToDecimalPlaceShare(convertToFloat(investment.getUnits()))+" "+convertToFloat(investment.getUnits()));
            txtValue.setText("My Value : "+getThousandSep(roundToDecimalPrice(convertToFloat(investment.getPrice()) * convertToFloat(investment.getMyshare()))));
            txtPrice.setText("Price : "+getThousandSep(roundToDecimalPrice(convertToFloat(investment.getPrice()))));
            txtMyShare.setText("My Share : "+getThousandSep(roundToDecimalPrice(convertToFloat(investment.getMyshare()))));
        }
    }

    private Float convertToFloat(String s){
        float i;
        try{
            i = Float.parseFloat(s);
        }catch (Exception e){
            i = 0;
        }
        return i;
    }

    private String getThousandSep(Float amount){
        return String.format("%,.2f",amount);
    }
    private Float roundToDecimalPlaceShare(Float amount){
        String value = String.format("%.4f",amount);
        return Float.parseFloat(value);
    }
    private Float roundToDecimalPrice(Float amount){
        String value = String.format("%.2f",amount);
        return Float.parseFloat(value);
    }
}
