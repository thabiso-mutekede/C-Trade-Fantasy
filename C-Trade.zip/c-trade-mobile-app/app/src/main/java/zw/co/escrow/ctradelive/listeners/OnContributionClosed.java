package zw.co.escrow.ctradelive.listeners;

import android.app.Dialog;

public interface OnContributionClosed {
    void process(String transType, String amount, Dialog dialog);
}
