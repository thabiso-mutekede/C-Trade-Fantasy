package zw.co.escrow.ctradelive.view.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnProductSelected;

public class ProductsFragment extends Fragment implements View.OnClickListener {

    private OnProductSelected onProductSelected;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.products_fragment,container,false);
        view.findViewById(R.id.equities_).setOnClickListener(this);
        view.findViewById(R.id.etfs_).setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.equities_:
                onProductSelected.click(Constants.EQUITY);
                break;
            case R.id.etfs_:
                onProductSelected.click(Constants.ETF);
                break;
        }

    }

    public void setOnProductSelected(OnProductSelected onProductSelected) {
        this.onProductSelected = onProductSelected;
    }
}
