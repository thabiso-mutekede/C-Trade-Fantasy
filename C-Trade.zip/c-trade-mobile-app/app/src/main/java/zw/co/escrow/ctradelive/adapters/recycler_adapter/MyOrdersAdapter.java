package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.listeners.OnCancelOrder;
import zw.co.escrow.ctradelive.model.MyOrder;

public class MyOrdersAdapter extends RecyclerView.Adapter<MyOrdersAdapter.MyOrdersViewHolder> {

    private final List<MyOrder> myOrderList;
    private Activity activity;
    private MyOrder myOrder;
    private String cdsNumber;
    private final RecyclerView recyclerView;
    private OnCancelOrder onCancelOrder;



    public MyOrdersAdapter(Activity activity, List<MyOrder> myOrderList, RecyclerView recyclerView, @NonNull String cdsNumber) {
        this.myOrderList = myOrderList;
        this.activity = activity;
        this.recyclerView = recyclerView;
        this.cdsNumber = cdsNumber;
    }
    @Override
    public int getItemViewType(int position) {
        return R.layout.my_orders_adapter_view;
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @NonNull
    @Override
    public MyOrdersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        view.setOnClickListener(v->{

            myOrder = myOrderList.get(recyclerView.getChildLayoutPosition(view));
            AlertDialog.Builder alertDialogB = new AlertDialog.Builder(activity);
            String status = myOrder.getStatus();

            if(status.equalsIgnoreCase("1"))status = "OPEN";

            alertDialogB.setTitle("My order ")
                    .setMessage("Type : ".concat(myOrder.getType().concat("\n"))
                            .concat("Company : ")
                            .concat(myOrder.getCounter().concat("\n"))
                            .concat("Status : ")
                            .concat(status.concat("\n"))
                            .concat("Quantity : ")
                            .concat(myOrder.getQuantity()).concat("\n")
                            .concat("Date : ")
                            .concat(myOrder.getDate()).concat("\n")
                            .concat("Value :")
                            .concat(myOrder.getValue()).concat("\n")
                            .concat("Reason : ").concat(myOrder.getRej_message()))
                    .setCancelable(false);
            if(myOrder.getStatus().equalsIgnoreCase("OPEN") ||
                    myOrder.getStatus().equalsIgnoreCase("AUTO TRADE")){
                alertDialogB.setNegativeButton("Cancel Order", (dialogInterface, which) -> {
                    if(onCancelOrder != null){
                        onCancelOrder.cancelOrder(cdsNumber,myOrder.getId(),myOrder.getType());
                    }
                }).setNeutralButton("Close",null);;
            }else {
                alertDialogB.setPositiveButton("ok",null);
            }
            AlertDialog alertDialog = alertDialogB.create();
            alertDialog.setOnShowListener(dialogInterface -> {
                alertDialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(activity.getColor(R.color.white));
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(activity.getColor(R.color.colorAccent));
                alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(activity.getColor(R.color.red));
            });
            alertDialog.show();
        });
        return new MyOrdersViewHolder(view);    }

    @Override
    public void onBindViewHolder(@NonNull MyOrdersViewHolder holder, int position) {


        String status = myOrderList.get(position).getStatus().equalsIgnoreCase("1")?"OPEN":myOrderList.get(position).getStatus();

        holder.txtType.setText(myOrderList.get(position).getType());
        holder.txtQuantity.setText(String.format("Quantity: %s", myOrderList.get(position).getQuantity()));
        holder.txtDate.setText(myOrderList.get(position).getDate());
        holder.txtCurrentPrice.setText(String.format("Price: %s", myOrderList.get(position).getPrice()));
        holder.txtValue.setText(String.format("Value: %s",Constants.getThousandSep(Constants.roundToDecimalPlaceShare(Constants.convertToFloat(String.valueOf(myOrderList.get(position).getValue()))))));
        holder.txtCounter.setText(myOrderList.get(position).getCounter());

        if (myOrderList.get(position).getStatus().equals("Matched")){
            holder.wl_change_indicator.setCardBackgroundColor(activity.getResources().getColor(R.color.colorDarkGreen));
        }
        myOrder = myOrderList.get(position);
    }



    @Override
    public int getItemCount() {
        return myOrderList.size();
    }



    public static class MyOrdersViewHolder extends RecyclerView.ViewHolder{

        private TextView txtType, txtQuantity, txtDate, txtCurrentPrice, txtValue,txtCounter;
        private CardView cardView, wl_change_indicator;

        public MyOrdersViewHolder(@NonNull View itemView) {
            super(itemView);

            txtCounter = itemView.findViewById(R.id.txtCounter);
            txtType = itemView.findViewById(R.id.txtType);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtCurrentPrice = itemView.findViewById(R.id.txtCurrentPrice);
            txtValue = itemView.findViewById(R.id.txtValue);
            cardView = itemView.findViewById(R.id.cardView);
            wl_change_indicator = itemView.findViewById(R.id.wl_change_indicator);

        }
    }

    public void setOnCancelOrder(OnCancelOrder onCancelOrder) {
        this.onCancelOrder = onCancelOrder;
    }
}