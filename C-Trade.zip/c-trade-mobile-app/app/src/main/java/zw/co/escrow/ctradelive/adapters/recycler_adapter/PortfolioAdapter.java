package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Portfolio;

public class PortfolioAdapter extends RecyclerView.Adapter {

    private final List<Portfolio> portfolioList;

    public PortfolioAdapter(List<Portfolio> portfolioList) {
        this.portfolioList = portfolioList;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.portfolio_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType,parent,false);
        return new PortfolioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((PortfolioViewHolder)holder).onBindData(portfolioList.get(position));
    }

    @Override
    public int getItemCount() {
        return portfolioList.size();
    }


    private class PortfolioViewHolder extends RecyclerView.ViewHolder{

        TextView tickerTxt,compNameTxt,txtQuantity,txtNet,txtMovement,txtValue;

        public PortfolioViewHolder(@NonNull View itemView) {
            super(itemView);

            tickerTxt = itemView.findViewById(R.id.txtTicker);
            compNameTxt = itemView.findViewById(R.id.txtCompanyName);
            txtNet = itemView.findViewById(R.id.txtNet);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            txtMovement = itemView.findViewById(R.id.txtNetMovement);
            txtValue = itemView.findViewById(R.id.txtCurrentPrice);

        }
        public void onBindData(Portfolio portfolio){
            tickerTxt.setText(portfolio.getCounter());
            compNameTxt.setText(portfolio.getCompanyFullName());
            txtNet.setText("Current Price: "+portfolio.getCurrentprice());

            float cp = convertToFloat(String.valueOf(portfolio.getCurrentprice()));
            float q = convertToFloat(String.valueOf(portfolio.getNumbershares()));
            float value = cp * q;
            txtQuantity.setText("Quantity: "+Constants.getThousandSep(Constants.roundToDecimalPlaceShare(convertToFloat(String.valueOf(portfolio.getNumbershares())))));
            txtValue.setText("value : "+Constants.getThousandSep(Constants.roundToDecimalPlaceShare(value)));
            Float prevValue = convertToFloat(String.valueOf(portfolio.getNumbershares()) )* convertToFloat(String.valueOf(portfolio.getPrevprice()));
            Float todayValue = convertToFloat(String.valueOf(portfolio.getNumbershares())) * convertToFloat(String.valueOf(portfolio.getCurrentprice()));
            Float movement = todayValue - prevValue;
            txtMovement.setText("net :" + Constants.getThousandSep(Constants.roundToDecimalPlaceShare(movement)));

        }

        private Float convertToFloat(String s){
            float i;
            try{
                i = Float.parseFloat(s);
            }catch (Exception e){
                i = 0;
            }
            return i;
        }

        private double convertToDouble(String s){
            double i;
            try{
                i = Double.parseDouble(s);
            }catch (Exception e){
                i = 0;
            }
            return i;
        }



    }

}