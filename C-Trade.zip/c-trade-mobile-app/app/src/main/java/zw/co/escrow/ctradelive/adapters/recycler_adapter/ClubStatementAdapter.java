package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Statement;




public class ClubStatementAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<Statement> statements;
    private final RecyclerView recyclerView;
    private final Context context;

    public ClubStatementAdapter(List<Statement> statements, RecyclerView recyclerView, Context context) {
        this.statements = statements;
        this.recyclerView = recyclerView;
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.club_statement_adapter_view;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(viewType,parent,false);
        return new StatementViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((StatementViewHolder)holder).onBindData(statements.get(position));
    }

    @Override
    public int getItemCount() {
        return statements.size();
    }

    private class StatementViewHolder extends RecyclerView.ViewHolder{

        TextView tvFullName,tvMobileNumber,tvCounter,tvShares;

        public StatementViewHolder(@NonNull View itemView) {
            super(itemView);

            tvFullName = itemView.findViewById(R.id.txtFullName);
            tvMobileNumber = itemView.findViewById(R.id.txtMobile);
            tvCounter =itemView.findViewById(R.id.txtCounter);
            tvShares = itemView.findViewById(R.id.txtShares);
        }

        public void onBindData(Statement statement) {
            tvFullName.setText(statement.getFullName());
            tvMobileNumber.setText(statement.getMobile());
            tvCounter.setText(statement.getCompany());
            tvShares.setText("Shares : "+getThousandSep(roundToDecimalPlace(convertToFloat(statement.getShares()))));
        }

        private Float convertToFloat(String s){
            float i;
            try{
                i = Float.parseFloat(s);
            }catch (Exception e){
                i = 0;
            }
            return i;
        }
        private String getThousandSep(String amount){
            Float value = convertToFloat(amount);
            DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance(Locale.US);
            DecimalFormatSymbols symbols = formatter.getDecimalFormatSymbols();
            symbols.setGroupingSeparator(',');
            formatter.setDecimalFormatSymbols(symbols);
            return formatter.format(value.longValue());
        }
        private String roundToDecimalPlace(Float amount){
            DecimalFormat df = new DecimalFormat("#.#");
            return df.format(amount);

        }
    }
}
