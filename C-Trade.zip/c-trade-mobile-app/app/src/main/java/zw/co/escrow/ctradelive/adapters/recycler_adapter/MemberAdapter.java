package zw.co.escrow.ctradelive.adapters.recycler_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.model.Member;


public class MemberAdapter extends RecyclerView.Adapter {

    private final List<Member> memberList;
    private final Context context;
    private final RecyclerView recyclerView;

    public MemberAdapter(List<Member> memberList, Context context, RecyclerView recyclerView) {
        this.memberList = memberList;
        this.context = context;
        this.recyclerView = recyclerView;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView;
        itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.member_adapter_view, parent, false);

        return new MyClubsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((MyClubsViewHolder)holder).bindData(memberList.get(position));
    }

    @Override
    public int getItemCount() {
        return memberList.size();
    }


    private class MyClubsViewHolder extends RecyclerView.ViewHolder{

        TextView member_name_tv,mphone_tv,contribution_tv,investment_tv;

        public MyClubsViewHolder(@NonNull View itemView) {
            super(itemView);

            member_name_tv = itemView.findViewById(R.id.memberInvestmentmember_name);
            mphone_tv = itemView.findViewById(R.id.memberInvestmentmember_phone);
            contribution_tv = itemView.findViewById(R.id.txt_contribution);
            investment_tv = itemView.findViewById(R.id.txtInvestment);
        }

        public void bindData(Member member){

            member_name_tv.setText(member.getName());
            mphone_tv.setText(member.getPhone());
            contribution_tv.setText("Balance: ZWL"+member.getContribution());
            investment_tv.setText("Portfolio : "+member.getInvestment());

        }
        private int convertToInt(String s){
            int i;
            try{
                i = Integer.parseInt(s);
            }catch (Exception e){
                i = 0;
            }
            return i;
        }
    }
}
