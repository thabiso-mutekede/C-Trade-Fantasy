package zw.co.escrow.ctradelive.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.view.fragments.AvailableTrustFragment;

public class UnitTrustOrdersView extends AppCompatActivity {

    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_unit_trust_orders_view);
        super.onCreate(savedInstanceState);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("UNIT TRUST ORDERS");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(v -> finish());
        getSupportFragmentManager().beginTransaction().add(R.id.container,new AvailableTrustFragment(),"lloda").commit();

    }
}