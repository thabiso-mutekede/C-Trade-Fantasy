package zw.co.escrow.ctradelive.view.fragments.individual_create_account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.textfield.TextInputLayout;

import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.Utils;
import zw.co.escrow.ctradelive.model.RegistrationData;
import zw.co.escrow.ctradelive.view_model.LoginViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class SecurityDetailsFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "DETAILS";

    private LoginViewModel loginViewModel;
    private Utils utils;
    private RegistrationData registrationData;
    private TextInputLayout outlinedTextFieldFavBook, outlinedTextFieldMotherMaidenName, outlinedTextFieldRoad;



    public static SecurityDetailsFragment newInstance(RegistrationData registrationData) {
        SecurityDetailsFragment fragment = new SecurityDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(ARG_SECTION_NUMBER, registrationData);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginViewModel = ViewModelProviders.of(this).get(LoginViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
        }
        loginViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_security_details, container, false);

        initWidgets(root);

        utils = new Utils(getActivity());


        if (getArguments() != null) {
            registrationData = getArguments().getParcelable(ARG_SECTION_NUMBER);
            registrationData.getRegistrationSession().setCredentialsDone(true);
        }
        if(registrationData.getRegistrationSession().isQnaDone())setUpFields();
        root.findViewById(R.id.btnNext).setOnClickListener(v->{

            String book = outlinedTextFieldFavBook.getEditText().getText().toString()
                    ,motherMaidenName = outlinedTextFieldMotherMaidenName.getEditText().getText().toString()
                    ,road = outlinedTextFieldRoad.getEditText().getText().toString();



            if (book.equals("")) {
                outlinedTextFieldFavBook.setError("Please add favorite book");
            }
            else if (motherMaidenName.equals("")) {
                outlinedTextFieldMotherMaidenName.setError("Please add mother maiden name");

            }
            else if (road.equals("")) {
                outlinedTextFieldRoad.setError("Please add road");

            }
            else {
                registrationData.setBook(book);
                registrationData.setMotherName(motherMaidenName);
                registrationData.setRoad(road);

                utils.startNewFragment(root, SecurityDetailsFragment.this, UploadParticularsFragment.newInstance(registrationData) );
            }
        });
        return root;
    }

    private void setUpFields() {
        outlinedTextFieldFavBook.getEditText().setText(registrationData.getBook());
        outlinedTextFieldMotherMaidenName.getEditText().setText(registrationData.getMotherName());
        outlinedTextFieldRoad.getEditText().setText(registrationData.getRoad());
    }

    private void initWidgets(View view){
        outlinedTextFieldFavBook =view.findViewById(R.id.outlinedTextFieldFavBook);
        outlinedTextFieldMotherMaidenName =view.findViewById(R.id.outlinedTextFieldMotherMaidenName);
        outlinedTextFieldRoad =view.findViewById(R.id.outlinedTextFieldRoad);
    }
}