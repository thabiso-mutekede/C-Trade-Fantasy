package zw.co.escrow.ctradelive.view.dialogs;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.listeners.TableDataClickListener;

import zw.co.escrow.ctradelive.AppConfig;
import zw.co.escrow.ctradelive.Constants;
import zw.co.escrow.ctradelive.R;
import zw.co.escrow.ctradelive.adapters.column_adapters.UniversalHeaderAdapter;
import zw.co.escrow.ctradelive.adapters.header_adapters.MyCashColumnAdapter;
import zw.co.escrow.ctradelive.data_repository.JSONArrayRequestWithObject;
import zw.co.escrow.ctradelive.data_repository.ListRequest;
import zw.co.escrow.ctradelive.model.MyCashData;
import zw.co.escrow.ctradelive.model.Transaction;

public class MyCashDialog extends Dialog implements TableDataClickListener {

    private TableView tableView;
    private final String cdsNumber;
    private final List<String> table_headers = Arrays.asList("Date","Description","Amount","Balance");
    List<MyCashData> myCashDataList;
    private RecyclerView portfolioRecyclerView;
    private Toolbar toolbar;

    public MyCashDialog(@NonNull Context context, String cdsNumber,int i) {
        super(context);
        this.cdsNumber = cdsNumber;
        setContentView(R.layout.activity_my_cash_view);
        myCashDataList = new ArrayList<>();

        toolbar = findViewById(R.id.toolbar);
        if(i == 1)
            toolbar.setTitle("My Transactions".toUpperCase());
        else
            toolbar.setTitle("Club Transactions".toUpperCase());
        toolbar.setNavigationIcon(R.drawable.ic_baseline_close_24);
        toolbar.setNavigationOnClickListener(v -> dismiss());

        fetchTransactions();

        Window window = getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public void onDataClicked(int rowIndex, Object clickedData) {
        
    }



    private void fetchTransactions(){

        Log.d("fetch","fetching");
        JSONArrayRequestWithObject jr = new JSONArrayRequestWithObject(Request.Method.POST
                , Constants.COMPLETE_URL("cash/transactions")
                , Constants.cdsNumberJSON(cdsNumber),
                response -> {
                    Log.d("fetch",response.toString());
                    try{
                        List<Transaction> myCashDataList = new ArrayList<>();
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject c = response.getJSONObject(i);
                            Transaction myCashData = new Transaction();
                            myCashData.setDate(c.getString("day"));
                            myCashData.setAmmount((float) c.getDouble("amount"));
                            myCashData.setBalance(String.valueOf(c.getDouble("balance")));
                            myCashData.setType(c.getString("transType"));
                            myCashData.setDesc(c.getString("description"));
                            myCashDataList.add(myCashData);
                        }
                        tableView = findViewById(R.id.portfolio_table);
                        tableView.setColumnCount(4);
                        tableView.setHeaderAdapter(new UniversalHeaderAdapter(getContext(),table_headers.size(),table_headers));
                        tableView.setDataAdapter(new MyCashColumnAdapter(getContext(),myCashDataList));
                        tableView.addDataClickListener(MyCashDialog.this::onDataClicked);

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }, error -> {
            Log.d("fetch","error");
            error.printStackTrace();
        });
        AppConfig.getInstance().addToRequestQueue(jr);

    }

}